(function(){var e=Object.defineProperty,t=(e,t,n)=>()=>{if(n)throw n[0];try{return e&&(t=e(e=0)),t}catch(e){throw n=[e],e}},n=(t,n)=>{let r={};for(var i in t)e(r,i,{get:t[i],enumerable:!0});return n||e(r,Symbol.toStringTag,{value:`Module`}),r},r,i,a,o,s,c,l,u,d,f=t((()=>{r=globalThis,i=r.ShadowRoot&&(r.ShadyCSS===void 0||r.ShadyCSS.nativeShadow)&&`adoptedStyleSheets`in Document.prototype&&`replace`in CSSStyleSheet.prototype,a=Symbol(),o=new WeakMap,s=class{constructor(e,t,n){if(this._$cssResult$=!0,n!==a)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o,t=this.t;if(i&&e===void 0){let n=t!==void 0&&t.length===1;n&&(e=o.get(t)),e===void 0&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),n&&o.set(t,e))}return e}toString(){return this.cssText}},c=e=>new s(typeof e==`string`?e:e+``,void 0,a),l=(e,...t)=>{let n=e.length===1?e[0]:t.reduce((t,n,r)=>t+(e=>{if(!0===e._$cssResult$)return e.cssText;if(typeof e==`number`)return e;throw Error(`Value passed to 'css' function must be a 'css' function result: `+e+`. Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.`)})(n)+e[r+1],e[0]);return new s(n,e,a)},u=(e,t)=>{if(i)e.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(let n of t){let t=document.createElement(`style`),i=r.litNonce;i!==void 0&&t.setAttribute(`nonce`,i),t.textContent=n.cssText,e.appendChild(t)}},d=i?e=>e:e=>e instanceof CSSStyleSheet?(e=>{let t=``;for(let n of e.cssRules)t+=n.cssText;return c(t)})(e):e})),p,ee,te,ne,re,ie,ae,oe,se,ce,le,ue,de,fe,pe,me=t((()=>{f(),{is:p,defineProperty:ee,getOwnPropertyDescriptor:te,getOwnPropertyNames:ne,getOwnPropertySymbols:re,getPrototypeOf:ie}=Object,ae=globalThis,oe=ae.trustedTypes,se=oe?oe.emptyScript:``,ce=ae.reactiveElementPolyfillSupport,le=(e,t)=>e,ue={toAttribute(e,t){switch(t){case Boolean:e=e?se:null;break;case Object:case Array:e=e==null?e:JSON.stringify(e)}return e},fromAttribute(e,t){let n=e;switch(t){case Boolean:n=e!==null;break;case Number:n=e===null?null:Number(e);break;case Object:case Array:try{n=JSON.parse(e)}catch{n=null}}return n}},de=(e,t)=>!p(e,t),fe={attribute:!0,type:String,converter:ue,reflect:!1,useDefault:!1,hasChanged:de},Symbol.metadata??=Symbol(`metadata`),ae.litPropertyMetadata??=new WeakMap,pe=class extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=fe){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){let n=Symbol(),r=this.getPropertyDescriptor(e,n,t);r!==void 0&&ee(this.prototype,e,r)}}static getPropertyDescriptor(e,t,n){let{get:r,set:i}=te(this.prototype,e)??{get(){return this[t]},set(e){this[t]=e}};return{get:r,set(t){let a=r?.call(this);i?.call(this,t),this.requestUpdate(e,a,n)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??fe}static _$Ei(){if(this.hasOwnProperty(le(`elementProperties`)))return;let e=ie(this);e.finalize(),e.l!==void 0&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty(le(`finalized`)))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty(le(`properties`))){let e=this.properties,t=[...ne(e),...re(e)];for(let n of t)this.createProperty(n,e[n])}let e=this[Symbol.metadata];if(e!==null){let t=litPropertyMetadata.get(e);if(t!==void 0)for(let[e,n]of t)this.elementProperties.set(e,n)}this._$Eh=new Map;for(let[e,t]of this.elementProperties){let n=this._$Eu(e,t);n!==void 0&&this._$Eh.set(n,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){let t=[];if(Array.isArray(e)){let n=new Set(e.flat(1/0).reverse());for(let e of n)t.unshift(d(e))}else e!==void 0&&t.push(d(e));return t}static _$Eu(e,t){let n=t.attribute;return!1===n?void 0:typeof n==`string`?n:typeof e==`string`?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(e=>e(this))}addController(e){(this._$EO??=new Set).add(e),this.renderRoot!==void 0&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){let e=new Map,t=this.constructor.elementProperties;for(let n of t.keys())this.hasOwnProperty(n)&&(e.set(n,this[n]),delete this[n]);e.size>0&&(this._$Ep=e)}createRenderRoot(){let e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return u(e,this.constructor.elementStyles),e}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(e=>e.hostConnected?.())}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach(e=>e.hostDisconnected?.())}attributeChangedCallback(e,t,n){this._$AK(e,n)}_$ET(e,t){let n=this.constructor.elementProperties.get(e),r=this.constructor._$Eu(e,n);if(r!==void 0&&!0===n.reflect){let i=(n.converter?.toAttribute===void 0?ue:n.converter).toAttribute(t,n.type);this._$Em=e,i==null?this.removeAttribute(r):this.setAttribute(r,i),this._$Em=null}}_$AK(e,t){let n=this.constructor,r=n._$Eh.get(e);if(r!==void 0&&this._$Em!==r){let e=n.getPropertyOptions(r),i=typeof e.converter==`function`?{fromAttribute:e.converter}:e.converter?.fromAttribute===void 0?ue:e.converter;this._$Em=r;let a=i.fromAttribute(t,e.type);this[r]=a??this._$Ej?.get(r)??a,this._$Em=null}}requestUpdate(e,t,n,r=!1,i){if(e!==void 0){let a=this.constructor;if(!1===r&&(i=this[e]),n??=a.getPropertyOptions(e),!((n.hasChanged??de)(i,t)||n.useDefault&&n.reflect&&i===this._$Ej?.get(e)&&!this.hasAttribute(a._$Eu(e,n))))return;this.C(e,t,n)}!1===this.isUpdatePending&&(this._$ES=this._$EP())}C(e,t,{useDefault:n,reflect:r,wrapped:i},a){n&&!(this._$Ej??=new Map).has(e)&&(this._$Ej.set(e,a??t??this[e]),!0!==i||a!==void 0)||(this._$AL.has(e)||(this.hasUpdated||n||(t=void 0),this._$AL.set(e,t)),!0===r&&this._$Em!==e&&(this._$Eq??=new Set).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}let e=this.scheduleUpdate();return e!=null&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(let[e,t]of this._$Ep)this[e]=t;this._$Ep=void 0}let e=this.constructor.elementProperties;if(e.size>0)for(let[t,n]of e){let{wrapped:e}=n,r=this[t];!0!==e||this._$AL.has(t)||r===void 0||this.C(t,void 0,n,r)}}let e=!1,t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach(e=>e.hostUpdate?.()),this.update(t)):this._$EM()}catch(t){throw e=!1,this._$EM(),t}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach(e=>e.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&=this._$Eq.forEach(e=>this._$ET(e,this[e])),this._$EM()}updated(e){}firstUpdated(e){}},pe.elementStyles=[],pe.shadowRootOptions={mode:`open`},pe[le(`elementProperties`)]=new Map,pe[le(`finalized`)]=new Map,ce?.({ReactiveElement:pe}),(ae.reactiveElementVersions??=[]).push(`2.1.2`)}));function he(e,t){if(!Oe(e)||!e.hasOwnProperty(`raw`))throw Error(`invalid template strings array`);return be===void 0?t:be.createHTML(t)}function ge(e,t,n=e,r){if(t===ze)return t;let i=r===void 0?n._$Cl:n._$Co?.[r],a=De(t)?void 0:t._$litDirective$;return i?.constructor!==a&&(i?._$AO?.(!1),a===void 0?i=void 0:(i=new a(e),i._$AT(e,n,r)),r===void 0?n._$Cl=i:(n._$Co??=[])[r]=i),i!==void 0&&(t=ge(e,i._$AS(e,t.values),i,r)),t}var _e,ve,ye,be,xe,Se,Ce,we,Te,Ee,De,Oe,ke,Ae,je,Me,Ne,Pe,Fe,Ie,Le,Re,m,ze,h,Be,Ve,He,Ue,We,Ge,Ke,qe,Je,Ye,Xe,Ze,Qe,$e=t((()=>{_e=globalThis,ve=e=>e,ye=_e.trustedTypes,be=ye?ye.createPolicy(`lit-html`,{createHTML:e=>e}):void 0,xe=`$lit$`,Se=`lit$${Math.random().toFixed(9).slice(2)}$`,Ce=`?`+Se,we=`<${Ce}>`,Te=document,Ee=()=>Te.createComment(``),De=e=>e===null||typeof e!=`object`&&typeof e!=`function`,Oe=Array.isArray,ke=e=>Oe(e)||typeof e?.[Symbol.iterator]==`function`,Ae=`[ 	
\f\r]`,je=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,Me=/-->/g,Ne=/>/g,Pe=RegExp(`>|${Ae}(?:([^\\s"'>=/]+)(${Ae}*=${Ae}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,`g`),Fe=/'/g,Ie=/"/g,Le=/^(?:script|style|textarea|title)$/i,Re=e=>(t,...n)=>({_$litType$:e,strings:t,values:n}),m=Re(1),Re(2),Re(3),ze=Symbol.for(`lit-noChange`),h=Symbol.for(`lit-nothing`),Be=new WeakMap,Ve=Te.createTreeWalker(Te,129),He=(e,t)=>{let n=e.length-1,r=[],i,a=t===2?`<svg>`:t===3?`<math>`:``,o=je;for(let t=0;t<n;t++){let n=e[t],s,c,l=-1,u=0;for(;u<n.length&&(o.lastIndex=u,c=o.exec(n),c!==null);)u=o.lastIndex,o===je?c[1]===`!--`?o=Me:c[1]===void 0?c[2]===void 0?c[3]!==void 0&&(o=Pe):(Le.test(c[2])&&(i=RegExp(`</`+c[2],`g`)),o=Pe):o=Ne:o===Pe?c[0]===`>`?(o=i??je,l=-1):c[1]===void 0?l=-2:(l=o.lastIndex-c[2].length,s=c[1],o=c[3]===void 0?Pe:c[3]===`"`?Ie:Fe):o===Ie||o===Fe?o=Pe:o===Me||o===Ne?o=je:(o=Pe,i=void 0);let d=o===Pe&&e[t+1].startsWith(`/>`)?` `:``;a+=o===je?n+we:l>=0?(r.push(s),n.slice(0,l)+xe+n.slice(l)+Se+d):n+Se+(l===-2?t:d)}return[he(e,a+(e[n]||`<?>`)+(t===2?`</svg>`:t===3?`</math>`:``)),r]},Ue=class e{constructor({strings:t,_$litType$:n},r){let i;this.parts=[];let a=0,o=0,s=t.length-1,c=this.parts,[l,u]=He(t,n);if(this.el=e.createElement(l,r),Ve.currentNode=this.el.content,n===2||n===3){let e=this.el.content.firstChild;e.replaceWith(...e.childNodes)}for(;(i=Ve.nextNode())!==null&&c.length<s;){if(i.nodeType===1){if(i.hasAttributes())for(let e of i.getAttributeNames())if(e.endsWith(xe)){let t=u[o++],n=i.getAttribute(e).split(Se),r=/([.?@])?(.*)/.exec(t);c.push({type:1,index:a,name:r[2],strings:n,ctor:r[1]===`.`?qe:r[1]===`?`?Je:r[1]===`@`?Ye:Ke}),i.removeAttribute(e)}else e.startsWith(Se)&&(c.push({type:6,index:a}),i.removeAttribute(e));if(Le.test(i.tagName)){let e=i.textContent.split(Se),t=e.length-1;if(t>0){i.textContent=ye?ye.emptyScript:``;for(let n=0;n<t;n++)i.append(e[n],Ee()),Ve.nextNode(),c.push({type:2,index:++a});i.append(e[t],Ee())}}}else if(i.nodeType===8){if(i.data===Ce)c.push({type:2,index:a});else{let e=-1;for(;(e=i.data.indexOf(Se,e+1))!==-1;)c.push({type:7,index:a}),e+=Se.length-1}}a++}}static createElement(e,t){let n=Te.createElement(`template`);return n.innerHTML=e,n}},We=class{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){let{el:{content:t},parts:n}=this._$AD,r=(e?.creationScope??Te).importNode(t,!0);Ve.currentNode=r;let i=Ve.nextNode(),a=0,o=0,s=n[0];for(;s!==void 0;){if(a===s.index){let t;s.type===2?t=new Ge(i,i.nextSibling,this,e):s.type===1?t=new s.ctor(i,s.name,s.strings,this,e):s.type===6&&(t=new Xe(i,this,e)),this._$AV.push(t),s=n[++o]}a!==s?.index&&(i=Ve.nextNode(),a++)}return Ve.currentNode=Te,r}p(e){let t=0;for(let n of this._$AV)n!==void 0&&(n.strings===void 0?n._$AI(e[t]):(n._$AI(e,n,t),t+=n.strings.length-2)),t++}},Ge=class e{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,n,r){this.type=2,this._$AH=h,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=n,this.options=r,this._$Cv=r?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode,t=this._$AM;return t!==void 0&&e?.nodeType===11&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=ge(this,e,t),De(e)?e===h||e==null||e===``?(this._$AH!==h&&this._$AR(),this._$AH=h):e!==this._$AH&&e!==ze&&this._(e):e._$litType$===void 0?e.nodeType===void 0?ke(e)?this.k(e):this._(e):this.T(e):this.$(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==h&&De(this._$AH)?this._$AA.nextSibling.data=e:this.T(Te.createTextNode(e)),this._$AH=e}$(e){let{values:t,_$litType$:n}=e,r=typeof n==`number`?this._$AC(e):(n.el===void 0&&(n.el=Ue.createElement(he(n.h,n.h[0]),this.options)),n);if(this._$AH?._$AD===r)this._$AH.p(t);else{let e=new We(r,this),n=e.u(this.options);e.p(t),this.T(n),this._$AH=e}}_$AC(e){let t=Be.get(e.strings);return t===void 0&&Be.set(e.strings,t=new Ue(e)),t}k(t){Oe(this._$AH)||(this._$AH=[],this._$AR());let n=this._$AH,r,i=0;for(let a of t)i===n.length?n.push(r=new e(this.O(Ee()),this.O(Ee()),this,this.options)):r=n[i],r._$AI(a),i++;i<n.length&&(this._$AR(r&&r._$AB.nextSibling,i),n.length=i)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e!==this._$AB;){let t=ve(e).nextSibling;ve(e).remove(),e=t}}setConnected(e){this._$AM===void 0&&(this._$Cv=e,this._$AP?.(e))}},Ke=class{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,n,r,i){this.type=1,this._$AH=h,this._$AN=void 0,this.element=e,this.name=t,this._$AM=r,this.options=i,n.length>2||n[0]!==``||n[1]!==``?(this._$AH=Array(n.length-1).fill(new String),this.strings=n):this._$AH=h}_$AI(e,t=this,n,r){let i=this.strings,a=!1;if(i===void 0)e=ge(this,e,t,0),a=!De(e)||e!==this._$AH&&e!==ze,a&&(this._$AH=e);else{let r=e,o,s;for(e=i[0],o=0;o<i.length-1;o++)s=ge(this,r[n+o],t,o),s===ze&&(s=this._$AH[o]),a||=!De(s)||s!==this._$AH[o],s===h?e=h:e!==h&&(e+=(s??``)+i[o+1]),this._$AH[o]=s}a&&!r&&this.j(e)}j(e){e===h?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??``)}},qe=class extends Ke{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===h?void 0:e}},Je=class extends Ke{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==h)}},Ye=class extends Ke{constructor(e,t,n,r,i){super(e,t,n,r,i),this.type=5}_$AI(e,t=this){if((e=ge(this,e,t,0)??h)===ze)return;let n=this._$AH,r=e===h&&n!==h||e.capture!==n.capture||e.once!==n.once||e.passive!==n.passive,i=e!==h&&(n===h||r);r&&this.element.removeEventListener(this.name,this,n),i&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){typeof this._$AH==`function`?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}},Xe=class{constructor(e,t,n){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=n}get _$AU(){return this._$AM._$AU}_$AI(e){ge(this,e)}},Ze=_e.litHtmlPolyfillSupport,Ze?.(Ue,Ge),(_e.litHtmlVersions??=[]).push(`3.3.2`),Qe=(e,t,n)=>{let r=n?.renderBefore??t,i=r._$litPart$;if(i===void 0){let e=n?.renderBefore??null;r._$litPart$=i=new Ge(t.insertBefore(Ee(),e),e,void 0,n??{})}return i._$AI(e),i}})),et,g,tt,nt=t((()=>{me(),me(),$e(),$e(),et=globalThis,g=class extends pe{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){let e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){let t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=Qe(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return ze}},g._$litElement$=!0,g.finalized=!0,et.litElementHydrateSupport?.({LitElement:g}),tt=et.litElementPolyfillSupport,tt?.({LitElement:g}),(et.litElementVersions??=[]).push(`4.2.2`)})),rt=t((()=>{})),_=t((()=>{me(),$e(),nt(),rt()})),v,it=t((()=>{v=e=>(t,n)=>{n===void 0?customElements.define(e,t):n.addInitializer(()=>{customElements.define(e,t)})}}));function y(e){return(t,n)=>typeof n==`object`?ot(e,t,n):((e,t,n)=>{let r=t.hasOwnProperty(n);return t.constructor.createProperty(n,e),r?Object.getOwnPropertyDescriptor(t,n):void 0})(e,t,n)}var at,ot,st=t((()=>{me(),at={attribute:!0,type:String,converter:ue,reflect:!1,hasChanged:de},ot=(e=at,t,n)=>{let{kind:r,metadata:i}=n,a=globalThis.litPropertyMetadata.get(i);if(a===void 0&&globalThis.litPropertyMetadata.set(i,a=new Map),r===`setter`&&((e=Object.create(e)).wrapped=!0),a.set(n.name,e),r===`accessor`){let{name:r}=n;return{set(n){let i=t.get.call(this);t.set.call(this,n),this.requestUpdate(r,i,e,!0,n)},init(t){return t!==void 0&&this.C(r,void 0,e,t),t}}}if(r===`setter`){let{name:r}=n;return function(n){let i=this[r];t.call(this,n),this.requestUpdate(r,i,e,!0,n)}}throw Error(`Unsupported decorator location: `+r)}}));function b(e){return y({...e,state:!0,attribute:!1})}var ct=t((()=>{st()})),lt=t((()=>{})),ut,dt=t((()=>{ut=(e,t,n)=>(n.configurable=!0,n.enumerable=!0,Reflect.decorate&&typeof t!=`object`&&Object.defineProperty(e,t,n),n)}));function ft(e,t){return(n,r,i)=>{let a=t=>t.renderRoot?.querySelector(e)??null;if(t){let{get:e,set:t}=typeof r==`object`?n:i??(()=>{let e=Symbol();return{get(){return this[e]},set(t){this[e]=t}}})();return ut(n,r,{get(){let n=e.call(this);return n===void 0&&(n=a(this),(n!==null||this.hasUpdated)&&t.call(this,n)),n}})}return ut(n,r,{get(){return a(this)}})}}var pt=t((()=>{dt()})),mt=t((()=>{})),ht=t((()=>{})),gt=t((()=>{})),_t=t((()=>{})),x=t((()=>{it(),st(),ct(),lt(),pt(),mt(),ht(),gt(),_t()}));_(),x();var vt={en:{"panel.title":`RoomMind`,"analytics.overview_title":`Understand your home's climate`,"analytics.overview_hint":`Explore temperature trends, energy usage and how RoomMind is learning each room.`,"settings.hub.eyebrow":`Workspace`,"settings.hub.title":`Settings, made simple`,"settings.hub.description":`Choose what you want to adjust. Everyday controls stay separate from system configuration and advanced tools.`,"settings.hub.running":`Automatic climate control active`,"settings.hub.paused":`Automatic climate control paused`,"settings.hub.navigation":`Settings categories`,"settings.hub.category_label":`Category`,"settings.hub.overview":`Everyday`,"settings.hub.overview_hint":`Preferences, comfort and presence`,"settings.hub.system":`Heating system`,"settings.hub.system_hint":`Boiler, AC units and sensors`,"settings.hub.protection":`Safety & alerts`,"settings.hub.protection_hint":`Mold protection and diagnostics`,"settings.hub.advanced":`Advanced`,"settings.hub.advanced_hint":`Learning and maintenance`,"settings.hub.heating":`Boiler & electrical budget`,"settings.hub.heating_hint":`Hydraulic bypass, boiler timing and AC start-power limits.`,"room.nav.overview":`Climate & comfort`,"room.nav.equipment":`Devices & sensors`,"room.nav.advanced":`Automation & insights`,"room.nav.description":`Select an area of this room to explore and edit.`,"panel.overview":`Your home, at a glance`,"panel.overview_hint":`Room temperatures and the systems that need your attention.`,"panel.control_active":`Automatic control on`,"panel.control_paused":`Automatic control paused`,"panel.subtitle":`Climate management`,"panel.tab.rooms":`Rooms`,"panel.edit":`Edit room`,"panel.tab.settings":`Settings`,"panel.loading":`Loading...`,"panel.no_areas":`No areas configured in Home Assistant.`,"panel.no_areas_hint":`Add areas in HA settings to get started.`,"badge.beta":`Beta`,"badge.beta_hint":`This feature is in beta and may change or be restructured in future updates.`,"common.learn_more":`Learn more`,"panel.stat.rooms":`Rooms`,"panel.stat.heating":`Heating`,"panel.stat.cooling":`Cooling`,"panel.stat.vacation":`Vacation`,"panel.stat.away":`Away`,"panel.stat.mold":`Mold`,"panel.hide_room":`Hide`,"panel.unhide":`Show`,"panel.hidden_rooms":`Hidden rooms`,"panel.floor_other":`Other`,"panel.reorder":`Reorder rooms`,"panel.reorder_done":`Done`,"room.back":`Back to rooms`,"room.section.climate_mode":`Climate Mode`,"room.section.schedule":`Schedule & Temperatures`,"room.section.control_mode":`Control Mode`,"room.section.devices":`Devices`,"room.section.sensors":`Sensors`,"room.section.windows":`Window Sensors`,"room.control_mode.full_control":`Full Control`,"room.control_mode.managed":`Managed`,"room.control_mode.external_sensor":`External sensor: {sensor}`,"room.control_mode.no_sensor":`No external temperature sensor assigned`,"room.control_mode.mpc_active":`MPC active`,"room.control_mode.mpc_learning":`Learning`,"room.control_mode.device_setpoint":`Device setpoint: {temp}`,"room.control_mode.power":`Power: {power}%`,"room.control_mode.full_control_info":`RoomMind has full control over your climate devices. An external temperature sensor provides the actual room temperature, enabling proportional setpoint calculation. The device setpoint is dynamically adjusted based on MPC power output. The thermal model (EKF) learns your room's behavior for optimal comfort and energy efficiency.`,"room.control_mode.managed_info":`RoomMind sets the target temperature on your device (from schedule, override, or vacation settings), but the device self-regulates using its own internal sensor. No proportional boost, no thermal model learning, and no MPC optimization. For more precise control, assign an external temperature sensor in the Devices section.`,"room.delete":`Delete room`,"room.deleting":`Deleting...`,"room.saving":`Saving...`,"room.saved":`Saved`,"room.error_saving":`Error saving`,"room.confirm_delete":`Remove RoomMind configuration for "{name}"?`,"room.error_save_fallback":`Failed to save configuration`,"room.error_delete_fallback":`Failed to delete configuration`,"room.climate_control_toggle":`Climate control`,"room.climate_control_hint":`When disabled, RoomMind stops controlling devices in this room. They keep their current settings and may continue heating or cooling on their own. RoomMind will not turn them off.`,"room.outdoor_toggle":`Outdoor area`,"room.outdoor_hint":`Disables climate control, mold detection, and model training. Sensor monitoring continues.`,"room.alias.placeholder":`Custom display name`,"room.alias.clear":`Reset to area name`,"override.label":`Temporary Override`,"override.comfort":`Comfort`,"override.eco":`Eco`,"override.custom":`Custom`,"override.target":`Target:`,"override.heat_to":`Heat to:`,"override.cool_above":`Cool above:`,"override.invalid_band":`Cooling target must be at or above the heating target`,"override.activate_for":`Activate for:`,"override.error_set":`Failed to set override`,"override.error_clear":`Failed to clear override`,"hero.target":`Target`,"hero.override":`Override`,"hero.remaining":`{time} remaining`,"hero.humidity":`{value}% humidity`,"hero.device_setpoint":`Device set to {value}{unit}`,"hero.heat_source_primary":`Heating: TRV`,"hero.heat_source_secondary":`Heating: AC`,"hero.heat_source_both":`Heating: TRV + AC`,"hero.permanent":`Permanent`,"hero.waiting":`Waiting for sensor data...`,"hero.not_configured":`Not configured yet`,"hero.mpc_learning_paused":`MPC learning paused`,"hero.temperature_sensor_unavailable":`Temperature sensor unavailable; climate control is paused`,"hero.mpc_learning_progress":`Thermal model learning: {confidence}% confidence`,"hero.mpc_learning_paused.outdoor_unavailable":`RoomMind needs an outdoor temperature to learn this room's thermal model. The configured outdoor sensor is unavailable and no weather entity is set as a fallback. Configure either in Settings.`,"hero.compressor_protection_min_off":`Compressor protection: waiting for min-off`,"hero.compressor_protection_min_run":`Compressor protection: min-run active`,"hero.compressor_protection_info":`This room shares an outdoor compressor with other rooms. To prevent short-cycling, the shared compressor group enforces a minimum run time and a minimum off time before this device is allowed to switch again.`,"card.target":`Target`,"card.waiting":`Waiting for data...`,"card.humidity":`{value}% humidity`,"card.thermostat":`Thermostat`,"card.thermostats":`Thermostats`,"card.ac":`AC`,"card.acs":`ACs`,"card.climate_device":`climate device`,"card.climate_devices":`climate devices`,"card.temp_sensor":`temp sensor`,"card.temp_sensors":`temp sensors`,"card.no_climate":`No climate devices`,"card.outdoor":`Outdoor`,"card.tap_configure":`Tap to configure`,"card.mpc_active":`MPC active`,"card.mpc_learning":`MPC learning`,"card.not_controlled":`Not controlled by RoomMind`,"mode.auto":`Auto`,"mode.auto_desc":`Heats & cools automatically based on target temperature`,"mode.heat_only":`Heat Only`,"mode.heat_only_desc":`Only uses thermostats, ACs stay off`,"mode.cool_only":`Cool Only`,"mode.cool_only_desc":`Only uses ACs, thermostats stay off`,"mode.heating":`Heating`,"mode.cooling":`Cooling`,"mode.idle":`Standby`,"schedule.add_schedule":`Add schedule`,"schedule.select_schedule":`Select schedule helper`,"schedule.create_helper_hint":`Create new schedule helper in HA settings`,"schedule.selector_label":`Schedule selector entity`,"schedule.selector_value_boolean":`Current: {value}`,"schedule.selector_value_number":`Current value: {value}`,"schedule.selector_warning":`Multiple schedules but no selector set. Only the first will be used.`,"schedule.off_action_label":`Action when schedule is off`,"schedule.off_action_eco":`Use eco temperature`,"schedule.off_action_off":`Turn off devices`,"schedule.state_active":`Active`,"schedule.state_inactive":`Inactive`,"schedule.state_unreachable":`Unreachable`,"schedule.no_schedules":`No schedules configured`,"schedule.done":`Done`,"schedule.view_comfort":`Comfort: {temp}{unit}`,"schedule.view_eco":`Eco: {temp}{unit}`,"schedule.view_selector":`Active schedule selected by: {name}`,"schedule.view_selector_prefix":`Active schedule selected by:`,"schedule.help_header":`How do schedules work?`,"schedule.help_temps_title":`How is the target temperature determined?`,"schedule.help_temps":`The target temperature follows this priority chain:`,"schedule.help_temps_1":`<strong>Manual override</strong> – A temporary boost/eco/custom override always takes highest priority.`,"schedule.help_temps_2":`<strong>Block temperature</strong> – If the active schedule block has a <code>temperature</code> value in its data, that value is used.`,"schedule.help_temps_3":`<strong>Comfort temperature</strong> – If the schedule is "on" but the block has no temperature, the comfort fallback temperature below is used.`,"schedule.help_temps_4":`<strong>Eco temperature</strong> – When the schedule is "off" (outside all time blocks), the eco temperature is used.`,"schedule.help_block_title":`Setting temperature per time block`,"schedule.help_block":`You can set a specific temperature for each time block by adding a <code>temperature</code> value in the schedule's YAML configuration:`,"schedule.help_block_note":`If a block has no <code>temperature</code> data, the comfort fallback temperature is used instead.`,"schedule.help_split_title":`Separate heating/cooling targets per block`,"schedule.help_split":`For auto-mode rooms, you can set separate heating and cooling targets per time block using <code>heat_temperature</code> and <code>cool_temperature</code>:`,"schedule.help_split_note":`If only one is set, the other falls back to the room's comfort temperature. These keys take priority over <code>temperature</code> when present.`,"schedule.help_multi_title":`Multiple schedules`,"schedule.help_multi":`You can add multiple schedules and switch between them using a <strong>selector entity</strong>. This can be an <code>input_boolean</code> (toggles between schedule 1 and 2) or an <code>input_number</code> (selects by number). Without a selector entity, only the first schedule is used.`,"schedule.column_comfort":`Comfort`,"schedule.column_eco":`Eco`,"schedule.row_heat":`Heat`,"schedule.row_cool":`Cool`,"schedule.view_heat":`Heat: {comfort} / {eco}{unit}`,"schedule.view_cool":`Cool: {comfort} / {eco}{unit}`,"schedule.comfort_hint_auto":`Comfort: target when schedule is on. Eco: target when schedule is off. Rows set the target for heating and cooling.`,"schedule.comfort_label":`Fallback comfort temperature`,"schedule.eco_label":`Eco temperature`,"schedule.comfort_hint":`Used when schedule is "on" but no temperature is set in the block`,"schedule.from_schedule":`{temp}{unit} from schedule`,"schedule.from_schedule_split":`{heat}{unit} / {cool}{unit} from schedule`,"schedule.fallback":`{temp}{unit} (fallback)`,"schedule.eco_detail":`{temp}{unit} (eco)`,"devices.climate_entities":`Climate entities`,"devices.temp_sensors":`Temperature sensors`,"devices.humidity_sensors":`Humidity sensors`,"devices.no_climate":`No climate entities found in this area.`,"devices.no_temp_sensors":`No temperature sensors found in this area.`,"devices.no_humidity_sensors":`No humidity sensors found in this area.`,"devices.occupancy_sensors":`Occupancy Sensors`,"devices.no_occupancy_sensors":`No occupancy sensors found in this area`,"devices.occupancy_sensor_hint":`Improves thermal model accuracy by tracking room occupancy`,"devices.window_sensors":`Window / door sensors`,"devices.no_window_sensors":`No window/door sensors found in this area.`,"devices.window_open_delay":`Delay before pausing`,"devices.window_close_delay":`Delay before resuming`,"devices.wall_factor":`Wall factor (f_Rsi)`,"devices.wall_factor_hint":`How cold the room's coldest wall spot is: used to estimate humidity where mold forms. Lower = colder wall = higher risk.`,"devices.wall_preset":`Wall type`,"devices.wall_preset_plain":`Plain wall`,"devices.wall_preset_corner":`Corner / north wall`,"devices.wall_preset_bridge":`Shutter box, beam or pillar`,"devices.wall_preset_measured":`Measured`,"devices.wall_measure_hint":`Calibrate with a measurement: on a cold day, measure the moldy spot with an infrared thermometer (surface mode).`,"devices.wall_measure_surface":`Wall`,"devices.wall_measure_room":`Room`,"devices.wall_measure_outdoor":`Outdoor`,"devices.wall_measure_apply":`Use f = {value}`,"devices.wall_measure_invalid":`Measurement not usable: needs at least 5 °C between room and outdoor and a result between 0.50 and 0.95.`,"devices.add_entity":`Add entity`,"devices.done":`Done`,"devices.other_area":`Other area`,"devices.type_thermostat":`Thermostat`,"devices.type_ac":`Climate Device`,"devices.type_label":`Type`,"devices.select_to_configure":`Select a device to configure`,"devices.heating_system_type":`Heating System Type`,"devices.heating_system_type_info":`After heating stops, radiators and especially underfloor systems continue to release stored heat. RoomMind accounts for this residual heat to avoid overshooting and improve model accuracy. Underfloor rooms also get longer minimum run times.`,"devices.system_type_none":`Standard (no residual heat)`,"devices.system_type_radiator":`Radiator`,"devices.system_type_underfloor":`Underfloor Heating`,"devices.underfloor_delay_hint":`Underfloor heating has long restart times. A window-open delay of at least 5 minutes is recommended to avoid unnecessary shutoffs.`,"devices.heating_system_type_boost_hint":`Tip: If the heating system has changed, you can accelerate re-learning under Settings.`,"devices.idle_action":`When idle`,"devices.idle_action_off":`Turn off`,"devices.idle_action_fan_only":`Fan only`,"devices.idle_action_setback":`Setback`,"devices.idle_action_low":`Low setpoint (keep awake)`,"devices.idle_action_low_hint":`Lowers the setpoint to the device minimum instead of sending off. Prevents TRVs that hibernate in off mode from losing later commands.`,"devices.idle_fan_mode":`Fan speed`,"devices.idle_fan_mode_keep":`Don't change`,"devices.fan_only_conditions":`Fan-only conditions`,"devices.fan_only_only_after_cooling":`Only after cooling`,"devices.fan_only_require_presence":`Only when tracked people are home`,"devices.fan_only_require_schedule":`Only during an active schedule`,"devices.fan_only_seasons":`Allowed seasons`,"devices.fan_only_season_spring":`Spring`,"devices.fan_only_season_summer":`Summer`,"devices.fan_only_season_autumn":`Autumn`,"devices.fan_only_season_winter":`Winter`,"devices.fan_only_season_hint":`Season filters require Home Assistant's Season integration, which provides sensor.season. If it is unavailable, fan-only stays off.`,"devices.setpoint_mode":`Setpoint mode`,"devices.setpoint_mode_proportional":`Proportional (valve control)`,"devices.setpoint_mode_direct":`Direct (device regulates)`,"devices.setpoint_mode_hint":`Direct sends the actual room target to the device — best for thermostats and space heaters that regulate themselves. Proportional sends a boosted setpoint toward the device max_temp — best for radiator valves (TRVs).`,"devices.valve_protection_excluded":`Excluded from valve protection`,"devices.valve_protection_exclude_hint":`This entity will not be cycled by valve protection (e.g. virtual boiler entities)`,"devices.info.types_title":`Device types`,"devices.info.types_body":`Thermostat means a radiator thermostat / TRV. Climate Device means an AC, heat pump, or other climate entity used for cooling or forced-air heating. Both are Home Assistant climate entities; the distinction is how RoomMind controls them.`,"devices.info.control_title":`How RoomMind controls them`,"devices.info.control_body":`Setpoint mode only applies to thermostats in Full Control rooms with an external temperature sensor. Use Proportional when RoomMind should drive heating output by sending boosted setpoints. Use Direct when the device should regulate itself around the real target temperature.`,"devices.info.modes_title":`Idle behavior`,"devices.info.modes_body":`When idle only applies to Climate Devices. Turn off powers the device down. Fan only keeps airflow without heating or cooling. Setback keeps the current mode active but moves the target 2°C away from the room target. This setback offset is currently fixed. For Thermostats, Low keeps the TRV active at its minimum setpoint instead of off, useful for battery-powered Zigbee TRVs that sleep when set to off.`,"devices.info.heat_source_title":`Smart source selection`,"devices.info.heat_source_body":`This appears only when a room has both a thermostat/TRV and a Climate Device plus an external temperature sensor. RoomMind can then choose which source should handle heating based on temperature gap and outdoor conditions.`,"hero.window_open":`Window open – paused`,"card.window_open":`Window open`,"room.section.covers":`Covers & Blinds`,"covers.section_title":`Covers & Blinds`,"covers.auto_control":`Automatic blind control`,"covers.auto_control_hint":`RoomMind closes blinds when solar gain is predicted to overheat the room.`,"covers.deploy_threshold":`Deploy threshold`,"covers.deploy_threshold_hint":`Close blinds when predicted temperature exceeds target by this amount.`,"covers.min_position":`Minimum open position`,"covers.min_position_hint":`Blinds will never close further than this (0 = fully closed allowed).`,"covers.override_minutes":`Override pause duration`,"covers.override_minutes_hint":`How long to pause automatic control after manual cover movement. Set to 0 for no pause.`,"covers.no_covers":`No cover entities configured.`,"covers.no_covers_in_area":`No cover entities found in this area.`,"covers.add_cover":`Add cover entity...`,"covers.shading_active":`Shading active`,"covers.auto_paused":`Auto paused (manual override)`,"covers.auto_paused_until":`Auto control paused until`,"covers.resume_auto":`Resume automatic control`,"covers.done":`Done`,"covers.night_close":`Close at night`,"covers.night_close_hint":`Automatically close covers at sunset and open at sunrise.`,"covers.night_close_active":`Night closing active`,"covers.schedule_group_title":`Schedule`,"covers.solar_group_title":`Solar control`,"covers.schedule_section":`Cover schedules`,"covers.schedule_section_hint":`Define time windows for cover control using HA schedule helpers. In Force position mode the schedule's position overrides solar/thermal logic. In Allow solar protection mode RoomMind decides the position within the active window.`,"covers.add_schedule":`Add cover schedule...`,"covers.schedule_mode_force":`Force position`,"covers.schedule_mode_gate":`Allow solar protection`,"covers.schedule_mode_gate_short":`Solar gate`,"covers.schedule_position":`Position`,"covers.schedule_position_hint":`Cover position when this schedule is active (0% = fully closed, 100% = fully open).`,"covers.schedule_selector":`Schedule selector entity`,"covers.schedule_selector_hint":`Choose which schedule is active. input_boolean: off=#1, on=#2. input_number: value selects schedule number.`,"covers.schedule_selector_warning":`Multiple schedules configured but no selector set. Only the first schedule will be used.`,"covers.schedule_state_active":`Active`,"covers.schedule_state_inactive":`Inactive`,"covers.schedule_state_unreachable":`Unreachable`,"covers.schedule_active":`Schedule active`,"covers.schedule_create_link":`Create schedule helper`,"covers.night_position":`Night position`,"covers.night_position_hint":`Cover position when night close is active (0% = fully closed). Covers with an individual min. position will never go below that.`,"covers.night_close_advanced":`Advanced`,"covers.night_close_elevation":`Sun position threshold`,"covers.night_close_elevation_hint":`How far below or above the horizon the sun must be. 0° = exactly at sunset/sunrise. Negative = darker (e.g. -6° = dusk, when it's noticeably dark). Positive = still bright (e.g. 5° = sun still visible above horizon).`,"covers.night_close_offset":`Time offset`,"covers.night_close_offset_hint":`Additional shift relative to the sun position threshold. Positive = close later (e.g. +20 = 20 min after threshold is reached), negative = close earlier.`,"covers.outdoor_min_temp":`Min. outdoor temperature`,"covers.outdoor_min_temp_hint":`Don't close covers for solar protection below this outdoor temperature. Solar heat gain is welcome when it's cold.`,"covers.per_cover_title":`Per-cover settings`,"covers.per_cover_hint":`Set the compass direction each cover faces and optional individual minimum positions.`,"covers.per_cover_min_short":`Min`,"covers.per_cover_min_position":`Min. position`,"covers.per_cover_min_position_hint":`Individual minimum position per cover. Covers will never close further than this. Useful when blinds are physically fully closed at a position > 0%.`,"covers.snap_deploy":`Snap to minimum position`,"covers.snap_deploy_hint":`Close covers directly to the minimum position instead of gradually closing. Recommended for triple-pane windows where intermediate positions can cause thermal stress.`,"covers.info.selection_title":`Cover selection`,"covers.info.selection_body":`Select covers/blinds from this area or add entities from other areas. RoomMind tracks their position and can control them automatically.`,"covers.info.schedule_title":`Schedule control`,"covers.info.schedule_body":`Use HA schedule helpers to define times when covers should close (e.g. privacy in the evening). The schedule's position attribute determines how far they close. Schedules override all other automatic logic.`,"covers.info.solar_title":`Solar/thermal control`,"covers.info.solar_body":`When automatic control is enabled, RoomMind predicts whether solar radiation will overheat the room and closes blinds preventively. It uses learned thermal data when available, otherwise a conservative default. The deploy threshold controls how much predicted overshoot is needed before blinds close.`,"covers.info.night_title":`Night closing`,"covers.info.night_body":`Closes covers at sunset and opens them at sunrise. You can set a custom night position (e.g. 10% = almost closed but not fully).`,"covers.info.override_title":`Manual override`,"covers.info.override_body":`If you manually move a cover, RoomMind detects this and pauses automatic control for the configured duration. This prevents fighting with the user.`,"covers.info.priority_title":`Priority order`,"covers.info.priority_body":`Manual override > Schedule > Night close > Solar/thermal control. Higher priority rules always win. When no rule applies, covers stay open.`,"covers.info.entities_title":`HA entities`,"covers.info.entities_body":`RoomMind creates two entities per room for external use: switch.roommind_{area}_cover_auto (enable/disable automatic cover control — usable in automations or dashboards) and binary_sensor.roommind_{area}_cover_paused (on when manual override is active, e.g. after manually moving a cover).`,"covers.orientation_group_title":`Cover orientation`,"covers.orientation_hint":`Set the compass direction each cover faces. RoomMind uses this to skip solar deployment when the sun is not shining on that side of the building.`,"covers.orientation_none":`Any direction`,"covers.orientation_N":`N`,"covers.orientation_NE":`NE`,"covers.orientation_E":`E`,"covers.orientation_SE":`SE`,"covers.orientation_S":`S`,"covers.orientation_SW":`SW`,"covers.orientation_W":`W`,"covers.orientation_NW":`NW`,"covers.orientation_N_full":`North`,"covers.orientation_NE_full":`Northeast`,"covers.orientation_E_full":`East`,"covers.orientation_SE_full":`Southeast`,"covers.orientation_S_full":`South`,"covers.orientation_SW_full":`Southwest`,"covers.orientation_W_full":`West`,"covers.orientation_NW_full":`Northwest`,"settings.general_title":`General`,"settings.group_by_floor":`Group rooms by floor`,"settings.climate_control_active":`Climate control active`,"settings.climate_control_hint":`When disabled, RoomMind continues to monitor all sensors and train the model, but sends no commands to your heating or cooling devices. Your devices keep their current mode and setpoint and may continue heating or cooling on their own. RoomMind will not turn them off.`,"settings.learning_title":`Model Training`,"settings.learning_hint":`When paused, RoomMind stops collecting new measurement data and training the thermal model. Existing model data is preserved.`,"settings.learning_exceptions":`Exceptions`,"settings.learning_room_paused":`room paused`,"settings.learning_rooms_paused":`rooms paused`,"settings.sensors_title":`Sensors & Data Sources`,"settings.control_title":`Control`,"settings.outdoor_sensor":`Outdoor Temperature`,"settings.outdoor_sensor_label":`Outdoor temperature sensor`,"settings.outdoor_current":`Currently {temp}{unit} outside`,"settings.outdoor_waiting":`Waiting for sensor data...`,"settings.outdoor_humidity_sensor":`Outdoor Humidity`,"settings.outdoor_humidity_label":`Outdoor humidity sensor`,"settings.outdoor_humidity_current":`Currently {value}% outside`,"settings.smart_control":`Smart Climate Control`,"settings.smart_control_hint":`Configure outdoor temperature limits for heating and cooling.`,"settings.outdoor_cooling_min":`Minimum outdoor temp for cooling`,"settings.outdoor_cooling_min_hint":`AC stays off when outdoor temperature is below this value`,"settings.outdoor_heating_max":`Maximum outdoor temp for heating`,"settings.outdoor_heating_max_hint":`Heating stays off when outdoor temperature exceeds this value`,"settings.saving":`Saving...`,"settings.saved":`Saved`,"settings.error":`Error saving`,"devices.using_builtin_sensor":`Using thermostat's built-in sensor`,"settings.climate_intelligence":`Climate Intelligence`,"settings.control_mode":`Control Mode`,"settings.control_mode_simple":`Simple (Bang-Bang)`,"settings.control_mode_mpc":`Intelligent (MPC)`,"settings.control_mode_hint":`MPC learns your room's thermal behavior for optimal control`,"settings.comfort_weight":`Priority`,"settings.comfort_weight_comfort":`Comfort`,"settings.comfort_weight_efficiency":`Efficiency`,"settings.comfort_weight_hint":`Balances temperature precision against energy use. Comfort reacts earlier and stays closer to target. Efficiency allows more drift to reduce heating/cooling runtime.`,"settings.weather_entity":`Weather Forecast`,"settings.weather_entity_hint":`Optional: enables predictive outdoor temperature planning, and acts as a fallback when the outdoor sensor is unavailable`,"settings.outdoor_unavailable_notify":`Notify when outdoor temperature is unavailable`,"settings.outdoor_unavailable_notify_hint":`Show a Home Assistant notification when neither the outdoor sensor nor the weather entity has reported a temperature for 30 minutes. While this is the case, RoomMind pauses thermal model learning to avoid corruption.`,"settings.prediction_enabled":`Temperature prediction`,"settings.prediction_enabled_hint":`Show predicted temperature trend in analytics charts. Disable if you experience slow performance.`,"vacation.title":`Vacation Mode`,"vacation.hint":`Sets all rooms to a setback temperature until the end date.`,"vacation.active_label":`Vacation mode active`,"vacation.end_date":`End date & time`,"vacation.setback_temp":`Setback temperature`,"vacation.no_end_date":`No end date`,"vacation.deactivate":`Deactivate`,"tabs.analytics":`Analytics`,"analytics.select_room":`Select Room`,"analytics.temperature":`Temperature`,energy_title:`Energy consumption`,energy_subtitle:`Measured AC demand and learned 3-hour forecast`,energy_room_power:`Room total`,energy_forecast:`Room forecast`,energy_forecast_short:`forecast`,energy_now:`Power now`,energy_period:`Energy in range`,energy_next_3h:`Forecast next 3h`,energy_learning:`Learning samples`,"analytics.target":`Target`,"analytics.prediction":`Prediction`,"analytics.outdoor":`Outdoor`,"analytics.model_status":`Model Status`,"analytics.confidence":`Confidence`,"analytics.heating_rate":`Heating Strength`,"analytics.cooling_rate":`Cooling Strength`,"analytics.solar_gain":`Solar Gain`,"analytics.occupancy_gain":`Occupancy Gain`,"analytics.time_constant":`Time Constant`,"analytics.samples":`Samples`,"analytics.prediction_accuracy":`Prediction Accuracy`,"analytics.avg_deviation":`Avg. Deviation`,"analytics.data_sources":`Data Sources`,"analytics.data_points":`Data Points`,"analytics.control_mode":`Control Mode`,"analytics.control_mode_mpc":`MPC active`,"analytics.control_mode_bangbang":`MPC learning`,"analytics.last_model_update":`Last Model Update`,"analytics.accuracy_idle":`Accuracy (Idle)`,"analytics.accuracy_heating":`Accuracy (Heating)`,"analytics.info.accuracy_idle":`How precisely the model predicts temperature when neither heating nor cooling is active. A lower value means the model understands your room's natural heat loss well. This is the first value to improve because idle data is collected continuously.`,"analytics.info.accuracy_heating":`How precisely the model predicts temperature during active heating. This value stays high initially because the model needs real heating cycles to learn from. Once your heating has run a few times, this value will drop and MPC control becomes available.`,"analytics.info.confidence":`Overall model readiness for intelligent MPC control, combining two factors: data quantity (how many idle and active-mode samples have been collected) and prediction accuracy (how precise the temperature forecasts are). Confidence starts at 0% and rises as the model collects data and learns. Around 50% means enough idle data but still waiting for heating/cooling cycles. Above 80% means the model has enough data and accurate predictions — MPC control becomes available. 100% is the theoretical maximum when predictions are as accurate as physically possible.`,"analytics.info.time_constant":`How long it takes your room to naturally cool down halfway toward the outdoor temperature when heating is off. A longer time constant means better insulation — the room holds warmth longer. A short time constant means the room cools quickly. The model learns this by observing temperature drops during idle periods.`,"analytics.info.heating_rate":`How strongly your heating affects the room temperature. A higher value means your heating system warms the room faster relative to its thermal mass. The model learns this by observing how quickly the temperature rises during active heating, and uses it to predict how long heating needs to run.`,"analytics.info.cooling_rate":`How strongly your AC affects the room temperature. A higher value means the AC cools the room faster relative to its thermal mass. The model learns this by observing how quickly the temperature drops during active cooling, and uses it to predict how long the AC needs to run.`,"analytics.info.solar_gain":`The estimated effect of solar radiation through windows on room temperature. The model learns this by observing how the room warms during sunny periods when heating is off. Rooms with large south-facing windows will have higher values. The model uses this to reduce heating when solar gain is expected.`,"analytics.info.occupancy_gain":`The estimated heat contribution from occupancy (people, pets, computers) while the room is occupied. The model learns this by observing temperature changes when the configured occupancy sensors are active. Separating this from solar gain prevents body heat from being misattributed to sunlight. Only shown when at least one occupancy sensor is configured for this room.`,"analytics.info.data_sources":`Number of measurement samples used for model training.`,"analytics.info.data_points":`Total number of observations the model has been trained on. More data points generally lead to better predictions. The model collects a new data point roughly every 3 minutes while RoomMind is running.`,"analytics.no_data":`No data yet — model is learning`,"analytics.loading":`Loading analytics...`,"settings.reset_title":`Reset Thermal Data`,"settings.reset_hint":`Clear learned thermal model data and history. The model will start learning from scratch.`,"settings.reset_all_label":`All rooms`,"settings.reset_all_hint":`Clear thermal data and history for all rooms at once.`,"settings.reset_all_btn":`Reset all`,"settings.reset_all_confirm":`Clear all learned thermal data and history for ALL rooms? All models will start learning from scratch.`,"settings.reset_room_label":`Individual room`,"settings.reset_room_hint":`Select a room to clear its thermal data and history.`,"settings.reset_room_confirm":`Clear all learned thermal data and history for this room? The model will start learning from scratch.`,"settings.reset_room_select":`Select room`,"settings.reset_btn":`Reset`,"settings.reset_no_rooms":`No configured rooms.`,"settings.boost_title":`Accelerate Learning`,"settings.boost_hint":`The thermal model learns your room's heating and cooling behavior over time. After major changes (new radiator, AC, insulation, furniture), the model may be inaccurate. This increases the model's uncertainty so it adapts faster to new conditions.`,"settings.boost_label":`Accelerate learning`,"settings.boost_room_select":`Select room`,"settings.boost_btn":`Accelerate`,"settings.boost_cooldown":`Active – re-learning in progress`,"settings.boost_no_rooms":`No configured rooms.`,"analytics.range_1d":`Today`,"analytics.range_2d":`2 days`,"analytics.range_7d":`Week`,"analytics.range_30d":`Month`,"analytics.export":`Measurements`,"analytics.heating_period":`Heating`,"analytics.cooling_period":`Cooling`,"analytics.blind_position":`Blind position`,"analytics.window_open_period":`Window open`,"analytics.chart_info_title":`How to read this chart`,"analytics.exported":`Exported!`,"analytics.copy_diagnostics":`Diagnostics`,"analytics.export_download":`Download file`,"analytics.export_clipboard":`Copy to clipboard`,"analytics.copied_to_clipboard":`Copied!`,"analytics.range_from":`From`,"analytics.range_to":`To`,"analytics.chart_info_body":`**Lines:** The solid orange line shows the measured room temperature. The green dashed line is the target temperature from your schedule. The blue dotted line is the model's temperature prediction.

**Shaded areas:** Red shading marks heating periods, blue marks cooling, and teal marks times when a window was open.

**Future forecast (right of the 'now' line):** The green dashed line shows the upcoming schedule targets for the next 3 hours. The blue dotted line shows the predicted temperature trend.

**Prediction modes:** When 'MPC active' is shown, the prediction uses the full MPC optimizer with intelligent pre-heating/pre-cooling. While the model is still learning, a simpler simulation is used.

**Limitations:** The prediction assumes current conditions stay constant (outdoor temperature, window state). The simulation accuracy depends on how well the thermal model has learned your room — early on, predictions may be less accurate. Once MPC activates, predictions become significantly more reliable.`,"presence.title":`Presence Detection`,"presence.hint":`Uses eco temperature when nobody is home.`,"presence.hint_detail":`When enabled, all rooms switch to eco temperature as soon as none of the configured persons are home. You can optionally restrict per room which persons are relevant.`,"presence.add_person":`Add person`,"presence.add_entity":`Add presence entity`,"presence.person_label":`Person`,"room.section.presence":`Presence`,"presence.room_help_header":`How does per-room presence work?`,"presence.room_help_body":`Select which persons are relevant for this room. The room switches to eco temperature when none of the selected persons are home. Without selection, the global rule applies: eco when nobody is home.`,"presence.state_home":`Home`,"presence.state_away":`Away`,"presence.room_none_assigned":`Global rule — eco when nobody is home`,"presence.missing_entity_hint":`This entity no longer exists in Home Assistant — uncheck it to remove it from this room.`,"presence.ignore_toggle":`Ignore presence`,"presence.ignore_hint":`Controls how this room reacts to presence. You can assign specific persons below. The room switches to eco when none of the assigned persons are home. Use the toggle above to skip detection entirely and always follow the schedule.`,"presence.help_ignore_title":`What does "Ignore presence" do?`,"presence.help_ignore_body":`When enabled, this room skips presence detection entirely. It always follows its schedule and never switches to eco based on who is home. Useful for rooms that should maintain temperature regardless of presence, such as a server room, a pet room, or a guest room used by someone not tracked by Home Assistant.`,"presence.tile_ignored":`Presence detection is ignored. Room always follows its schedule.`,"presence.away_action_label":`Action when nobody is home`,"presence.away_action_eco":`Use eco temperature`,"presence.away_action_off":`Turn off devices`,"presence.clears_override_label":`Absence stops override`,"presence.clears_override_hint":`When nobody is home, manual overrides are paused and the room follows the away action. When someone returns, the override resumes until it expires.`,"card.presence_away":`Away`,"valve_protection.title":`Valve Protection`,"valve_protection.hint":`Periodically opens idle TRV valves briefly to prevent seizing or calcification.`,"valve_protection.interval_label":`Cycle interval`,"valve_protection.interval_suffix":`days`,"valve_protection.interval_hint":`How long a valve can be idle before being cycled (1–90 days)`,"compressor.title":`Compressor Protection`,"compressor.no_groups":`No compressor groups configured.`,"compressor.add_group":`Add compressor group`,"compressor.group_name":`Group name`,"compressor.members":`Indoor units`,"compressor.members_hint":`Select all climate devices powered by this compressor (indoor splits, TRVs on radiators, fan coils).`,"compressor.min_run":`Minimum run time`,"compressor.min_run_hint":`Compressor must run at least this long once started.`,"compressor.min_run_suffix":`min`,"compressor.min_off":`Minimum off time`,"compressor.min_off_hint":`Compressor must stay off at least this long after stopping.`,"compressor.min_off_suffix":`min`,"compressor.delete":`Delete group`,"compressor.delete_confirm":`Delete compressor group "{name}"?`,"compressor.master_entity":`Master device`,"compressor.master_entity_hint":`The central unit that powers the indoor devices in this group, e.g. a gas boiler, outdoor heat pump unit, or ducted AC master switch. RoomMind will turn it on when any room needs heating or cooling, and off when all rooms are idle. Leave empty to use only the action script or short-cycle protection.`,"compressor.conflict_resolution":`Conflict resolution`,"compressor.conflict_resolution_hint":`Determines what happens when some rooms need heating while others need cooling at the same time. Heating priority: heating always wins (safest for frost protection). Cooling priority: cooling always wins. Majority: the mode with more rooms wins, ties go to heating. Outdoor temperature: uses the outdoor heating max threshold from settings to decide automatically.`,"compressor.conflict_heating_priority":`Heating priority (frost protection)`,"compressor.conflict_cooling_priority":`Cooling priority`,"compressor.conflict_majority":`Majority wins`,"compressor.conflict_outdoor_temp":`Based on outdoor temperature`,"compressor.action_script":`Action script`,"compressor.action_script_hint":`A Home Assistant script that runs whenever the heating/cooling demand changes. Useful for systems that need special commands, e.g. cancelling a Vaillant Quick Veto or toggling a relay. Works with or without a master device. Without a master device, only the script is triggered. Receives variables: action (heat/cool/idle), master_entity, members, active_members.`,"compressor.enforce_uniform_mode":`Enforce uniform mode`,"compressor.enforce_uniform_mode_hint":`All thermostats in this group must operate in the same HVAC mode (all heating or all cooling). Rooms that disagree with the resolved group mode will be set to idle. Use this for heat pumps that start automatically but require all connected units to run the same mode.`,"mold.title":`Mold Risk Protection`,"mold.detection":`Mold Detection`,"mold.detection_desc":`Receive notifications when humidity indicates mold risk`,"mold.threshold":`Humidity threshold (%)`,"mold.threshold_hint":`Alert when room humidity stays above this value`,"mold.sustained":`Sustained duration (minutes)`,"mold.sustained_hint":`Alert only after risk persists for this long`,"mold.prevention":`Mold Prevention`,"mold.prevention_desc":`Dry at-risk walls with a dehumidifier or protected DRY cycles. Never heats; at night the AC only acts on a critical risk.`,"mold.prevention_sustained":`Risk duration before prevention`,"mold.prevention_sustained_hint":`At 65% estimated wall RH, early DRY may start after 2 hours. At 70%, this duration applies; at 80%, at most 10 minutes. Cycles last up to 30 minutes with a 60-minute retry pause.`,"mold.dehumidification":`Prefer dehumidification when safe`,"mold.dehumidification_desc":`Use an AC's dry mode first only when the room is warm enough; otherwise RoomMind uses its configured heat-pump / boiler plan.`,"mold.dehumidification_min_temperature":`Minimum room temperature for dehumidification`,"mold.dehumidification_min_temperature_hint":`DRY starts at this room temperature and stops 1°C below (21°C minimum). Applies to AC DRY only: a dedicated dehumidifier runs at any temperature.`,"card.mold_warning":`Mold risk`,"card.mold_critical":`Mold danger!`,"card.mold_prevention":`Mold prevention`,"room.mold_surface_rh":`Est. surface humidity: {value}%`,"settings.intro.general":`Basic display and control settings.`,"settings.intro.sensors":`Configure outdoor sensors and weather data for accurate climate control.`,"settings.intro.control":`Choose how RoomMind controls your climate devices and set priority and thresholds.`,"settings.intro.presence":`Automatically reduce temperature when nobody is home.`,"settings.intro.vacation":`Set all rooms to a reduced temperature while you are away.`,"settings.intro.valve":`Periodically move idle TRV valves to prevent seizing or calcification.`,"settings.intro.compressor":`Manage groups of indoor units that share an outdoor compressor or central heating source. Optionally assign a master device (boiler, outdoor unit) to automatically turn on/off based on room demand. Short-cycle protection prevents rapid on/off switching that can damage equipment.`,"settings.intro.mold":`Monitor humidity and automatically reduce mold risk.`,"settings.intro.notifications":`Configure who receives alerts and how.`,"settings.intro.learning":`Manage thermal model training and accelerate re-learning after changes.`,"settings.intro.reset":`Clear learned thermal model data. The model will start learning from scratch.`,"notifications.title":`Notifications`,"notifications.window_open_after":`Window open alert after`,"notifications.window_open_after_hint":`Send an alert after this many minutes with the window open. Set 0 to disable.`,"notifications.enabled":`Enable notifications`,"notifications.enabled_hint":`When disabled, no notifications are sent — neither to devices nor to the HA sidebar.`,"notifications.desc":`Choose which devices receive alerts. Without targets, alerts appear in the HA sidebar.`,"notifications.add_target_label":`Add notification device`,"notifications.add_target_hint":`Type the entity ID if your device is not listed (e.g. notify.mobile_app_...). You can find it under Settings → Devices → your phone → Notify entity.`,"notifications.target_unnamed":`Unnamed device`,"notifications.target_person":`Person`,"notifications.target_when_always":`Always`,"notifications.target_when_home":`Only when home`,"notifications.cooldown":`Notification cooldown (minutes)`,"notifications.cooldown_hint":`Minimum time between repeated alerts per room`,"notifications.mold_prevention_notify":`Notify when mold prevention activates`,"notifications.mold_prevention_notify_hint":`Also send a notification when prevention activates (temperature raised)`,"room.section.heat_source":`Heat Source Orchestration`,"heat_source.toggle":`Smart source selection`,"heat_source.power_estimate":`Backup AC power estimate`,"heat_source.power_estimate_hint":`RoomMind automatically learns peak demand for heating, cooling and dry modes, adding 30% headroom. This backup is only used until each mode has at least 6 valid samples. With 0 W, starts without learned data are safely blocked.`,"heat_source.budget_heating":`Heating`,"heat_source.budget_cooling":`Cooling`,"heat_source.budget_dry":`Dehumidifying`,"heat_source.budget_learned":`learned`,"heat_source.budget_fallback":`manual backup`,"heat_source.budget_unknown":`awaiting data`,"preview.title":`Safety preview`,"preview.intro":`Read-only simulation of AC electrical budget and compressor admission.`,"preview.mode":`Simulated climate mode`,"preview.run":`Simulate without acting`,"preview.scope":`Does not switch any device. Shows hypothetical start admission from current power readings; schedules, season gates and thermal MPC are not simulated.`,"preview.error":`Could not load the preview.`,"preview.headroom":`House headroom`,"preview.meter":`Power meter`,"preview.healthy":`recent`,"preview.unavailable":`stale or unavailable`,"preview.boiler":`Boiler`,"preview.bypass":`Bypass readback`,"preview.acknowledged":`confirmed by HA state`,"preview.not_acknowledged":`not confirmed (normal if boiler is off)`,"preview.current_reasons":`Current decisions`,"preview.reason_eligible":`Eligible to start based on electrical/compressor safety`,"preview.reason_control_disabled":`Climate control disabled`,"preview.reason_room_safety":`Room safety gate (window or forced off)`,"preview.reason_compressor_protection":`Compressor minimum-off protection`,"preview.reason_power_budget":`Insufficient or unknown electrical headroom`,"heat_source.toggle_hint":`When this room has both radiator thermostats and an AC/heat pump, RoomMind intelligently routes heating demand to the most efficient device based on temperature gap and outdoor conditions.`,"heat_source.primary_delta":`Boiler activation threshold`,"heat_source.primary_delta_hint":`Only activate the primary source when the temperature gap exceeds this value. Below this threshold, only the fast secondary source is used.`,"heat_source.primary_delta_suffix":`°C`,"heat_source.outdoor_threshold":`Outdoor preference switchover`,"heat_source.outdoor_threshold_hint":`Above this outdoor temperature, prefer the AC/heat pump (higher efficiency). Below, prefer the gas boiler/radiator.`,"heat_source.outdoor_threshold_suffix":`°C`,"heat_source.ac_min_outdoor":`Min. outdoor temp for AC heating`,"heat_source.ac_min_outdoor_hint":`Disable AC heating entirely below this temperature to protect the heat pump hardware.`,"heat_source.ac_min_outdoor_suffix":`°C`,"heat_source.summary_disabled":`Smart source selection is off`,"devices.keep_fan_only_window":`Keep fan-only with open window`,"devices.keep_fan_only_window_hint":`Heating and cooling pause, but an AC already in fan-only mode stays on.`,"settings.temperature_rounding":`Physical temperature rounding`,"settings.temperature_rounding_hint":`When a climate device cannot represent RoomMind's 0.5° setpoint, choose how the physical target is rounded.`,"settings.temperature_rounding_nearest":`Nearest supported value`,"settings.temperature_rounding_down":`Round down (26.5° → 26°)`,"settings.temperature_rounding_up":`Round up (26.5° → 27°)`,"devices.power_sensor":`Power sensor`,"devices.power_sensor_hint":`Instantaneous electrical consumption sensor for this AC. W and kW sensors are supported and used for energy history and adaptive predictions.`,"analytics.energy_title":`Energy consumption`,"analytics.energy_subtitle":`Measured device power and learned forecast`,"analytics.energy_chart_info_body":`Solid lines show measured power. Dashed segments continue from the latest measurement with the learned three-hour forecast. Tap a legend item to hide or restore a series. Pinch or scroll horizontally to zoom; the vertical dashed line marks now.`,"analytics.energy_room_power":`Room power`,"analytics.energy_forecast":`Forecast`,"analytics.energy_forecast_short":`Forecast`,"analytics.energy_now":`Now`,"analytics.energy_period":`Period energy`,"analytics.energy_next_3h":`Next 3 hours`,"analytics.energy_learning":`Learning samples`,"analytics.energy_confidence":`Forecast confidence`,"analytics.energy_confidence_low":`Low`,"analytics.energy_confidence_medium":`Medium`,"analytics.energy_confidence_high":`High`,"analytics.energy_cost_today":`Cost today`,"analytics.energy_cost_7d":`Cost last 7 days`,"analytics.energy_cost_next_3h":`Cost next 3h`,"analytics.comparison_title":`Room comparison`,"analytics.comparison_info":`Compare the selected period: kWh is measured climate energy, € is its estimated cost, Active is total heating/cooling time, ΔT/kWh shows temperature change per unit of energy, and To target is the average time to reach the scheduled temperature.`,"analytics.comparison_data_incomplete":`Incomplete data`,"analytics.comparison_quality_insufficient_samples":`too few samples`,"analytics.comparison_quality_no_power_measurements":`no power measurements`,"analytics.comparison_quality_history_gaps":`gaps in history`,"analytics.comparison_room":`Room`,"analytics.comparison_active":`Active`,"analytics.comparison_efficiency":`ΔT/kWh`,"analytics.comparison_target":`To target`,"settings.energy_price":`Climate energy price`,"settings.energy_price_hint":`Price (EUR/kWh)`,"hero.window_impact":`Window open for {minutes} min: {impact}{unit} vs forecast`,"hero.power_budget_blocked":`Climate start delayed by house power budget`,"hero.preconditioning_active":`Pre-conditioning active for the next scheduled target`,"hero.preconditioning_planned":`Pre-conditioning planned at {time}`,"hero.ac_efficiency_issue":`AC is using normal power but responding slowly`,"hero.window_recovery":`Estimated recovery after closing: {minutes} min`,"insights.decision.title":`Why RoomMind is acting`,"insights.decision.window_open":`Climate control is paused because a window is open.`,"insights.decision.power_budget":`Climate demand is limited by the configured power budget.`,"insights.decision.compressor_min_off":`The compressor is waiting for its minimum off time.`,"insights.decision.compressor_min_run":`The compressor is completing its minimum run time.`,"insights.decision.override_boost":`A Boost override is currently in control.`,"insights.decision.override_eco":`An Eco override is currently in control.`,"insights.decision.override_custom":`A custom temperature override is currently in control.`,"insights.decision.override_active":`A manual override is currently in control.`,"insights.decision.presence_away":`Away mode is adjusting this room.`,"insights.decision.mold_prevention":`Mold prevention is protecting this room.`,"insights.decision.humidity_comfort":`Dehumidification is running for humidity comfort.`,"insights.decision.smart_ventilation":`Smart ventilation is keeping air circulating.`,"insights.decision.preconditioning":`Predictive control is preconditioning the room.`,"insights.decision.heat_source":`RoomMind selected the current heat source for this room.`,"insights.decision.mode_heating":`The room is heating toward its current target.`,"insights.decision.mode_cooling":`The room is cooling toward its current target.`,"insights.decision.mode_idle":`The room is at target and no climate action is needed.`,"insights.readiness.title":`Room readiness`,"insights.readiness.ready":`Ready for predictive comfort ({ready}/{total} checks complete).`,"insights.readiness.basic":`Basic climate control is ready ({ready}/{total} checks complete).`,"insights.readiness.needs_setup":`Complete the required setup to enable climate control ({ready}/{total} checks complete).`,"insights.readiness.item.devices.ready":`Climate device configured`,"insights.readiness.item.devices.missing":`Add at least one climate device`,"insights.readiness.item.temperature_sensor.ready":`External temperature sensor configured`,"insights.readiness.item.temperature_sensor.recommended":`Add an external temperature sensor for Full Control`,"insights.readiness.item.schedule.ready":`Schedule configured`,"insights.readiness.item.schedule.recommended":`Add a schedule to automate comfort and eco temperatures`,"insights.readiness.item.predictive_control.ready":`Predictive control inputs are available`,"insights.readiness.item.predictive_control.recommended":`Add outdoor temperature to unlock predictive control`,"insights.readiness.item.climate_control.missing":`Enable climate control for this room`,"card.comfort_score":`Comfort {score}%`,"card.comfort_excellent":`Excellent comfort`,"card.comfort_good":`Good comfort`,"card.comfort_fair":`Comfort needs attention`,"card.comfort_poor":`Poor comfort`,"card.issues":`{count} active room issue(s)`,"insights.comfort.title":`Comfort score explained`,"insights.comfort.summary":`Starts at 100; active conditions subtract points.`,"insights.comfort.base":`Starting score`,"insights.comfort.total":`Current score`,"insights.comfort.no_penalty":`No penalty`,"insights.comfort.factor.temperature.unavailable":`Temperature reading unavailable`,"insights.comfort.factor.temperature.below_target":`Temperature below target`,"insights.comfort.factor.temperature.above_target":`Temperature above target`,"insights.comfort.factor.temperature.on_target":`Temperature on target`,"insights.comfort.factor.humidity.unavailable":`Humidity is not assessed`,"insights.comfort.factor.humidity.below_target":`Humidity below target`,"insights.comfort.factor.humidity.above_target":`Humidity above target`,"insights.comfort.factor.humidity.on_target":`Humidity on target`,"insights.comfort.factor.window.open":`Window is open`,"insights.comfort.factor.window.closed":`Window is closed`,"insights.comfort.factor.air_quality.warning":`Mold risk warning`,"insights.comfort.factor.air_quality.critical":`Critical mold risk`,"insights.comfort.factor.air_quality.ok":`No mold risk`,"insights.comfort.factor.anomalies.active":`Active room anomalies`,"insights.comfort.factor.anomalies.none":`No active anomalies`,"room.section.comfort":`Comfort & profiles`,"room.section.area":`Area settings`,"comfort.profiles":`Active comfort profile`,"comfort.profile.default":`No profile (schedule)`,"comfort.profile.work":`Work`,"comfort.profile.sleep":`Sleep`,"comfort.profile.guests":`Guests`,"comfort.profile.away":`Away`,"comfort.night_mode":`Night mode`,"comfort.control_enabled":`Room control enabled`,"comfort.night_mode_hint":`Gradually adjusts the room targets during the selected night period.`,"comfort.night_start":`Start`,"comfort.night_end":`End`,"comfort.night_heat_delta":`Heating offset (°C)`,"comfort.night_cool_delta":`Cooling offset (°C)`,"comfort.night_ramp":`Transition time (min)`,"dehumidifier.title":`Dehumidifier`,"dehumidifier.add":`Add dehumidifier`,"dehumidifier.configure":`Configure dehumidifier`,"dehumidifier.device":`Physical device`,"dehumidifier.device_hint":`Choose a dehumidifier or smart plug. Plug-controlled appliances must restart when power returns.`,"dehumidifier.mode":`Device control`,"dehumidifier.auto":`Automatic`,"dehumidifier.manual":`Manual`,"dehumidifier.manual_hint":`RoomMind leaves manual runs untouched, including laundry drying. Open the device name to use Home Assistant controls.`,"dehumidifier.served_rooms":`Served rooms`,"dehumidifier.host_included":`The room hosting the device is always included.`,"dehumidifier.shared_hint":`Shared control uses each room’s own sensor. Host window and night rules apply; pause at 45% and resume at 50% in the host, subject to device limits.`,"dehumidifier.min_run_minutes":`Minimum run time`,"dehumidifier.min_off_minutes":`Minimum off time`,"dehumidifier.power_watts":`Nominal power`,"dehumidifier.power_hint":`Required for new starts when the electrical power budget is enabled.`,"dehumidifier.comfort":`Humidity comfort`,"dehumidifier.comfort_hint":`Adding a device does not enable comfort automatically. Active profiles can override this room’s humidity target. Mold prevention follows its existing settings.`,"dehumidifier.target":`Room humidity target`,"dehumidifier.tolerance":`Humidity tolerance`,"dehumidifier.priority":`Humidity priority`,"dehumidifier.priority_comfort":`Comfort`,"dehumidifier.priority_balanced":`Balanced`,"dehumidifier.priority_energy":`Energy saving`,"dehumidifier.empty":`No dedicated or shared device assigned. Automatic AC Dry remains available.`,"dehumidifier.host":`Located in`,"dehumidifier.requests":`Requests from`,"dehumidifier.device_target":`Device target`,"dehumidifier.floor":`Host humidity limit`,"dehumidifier.drying":`Dehumidifying`,"dehumidifier.on":`On`,"dehumidifier.off":`Off`,"dehumidifier.idle":`On, idle`,"dehumidifier.request_mold":`Mold prevention requested`,"dehumidifier.request_comfort":`Humidity comfort requested`,"dehumidifier.reason_unavailable":`Device unavailable`,"dehumidifier.reason_manual":`Manual control`,"dehumidifier.reason_disabled":`Automatic control disabled`,"dehumidifier.reason_sensor":`Host humidity reading unavailable`,"dehumidifier.reason_window":`Host window open`,"dehumidifier.reason_humidity_floor":`Host humidity limit reached`,"dehumidifier.reason_min_off":`Waiting for minimum off time`,"dehumidifier.reason_min_run":`Completing minimum run time`,"dehumidifier.reason_night":`Host quiet hours`,"dehumidifier.reason_power_budget":`Waiting for electrical capacity or nominal power`,"dehumidifier.reason_error":`Device command failed`,"dehumidifier.assigned":`Serving this room’s request`,"dehumidifier.command_on":`Turn-on command sent`,"dehumidifier.command_off":`Turn-off command sent`,"dehumidifier.intro":`Choose who controls the appliance, which rooms it serves, and the humidity goal for this room.`,"dehumidifier.how_it_works":`How automatic control works`,"dehumidifier.guide_device":`Automatic lets RoomMind start and stop the appliance for humidity comfort or mold prevention. Global climate control and climate control in the host room must both be enabled. Manual leaves control to you.`,"dehumidifier.guide_comfort":`Each room opts into humidity comfort separately and has its own target. Mold prevention follows its own settings, even with comfort off. Active profiles can override the room target.`,"dehumidifier.guide_shared":`Selecting a room lets its humidity demand request this appliance. Each served room needs a humidity reading. Air must circulate between rooms; the host’s windows, quiet hours and humidity protection apply to the whole appliance.`,"dehumidifier.disabled_hint":`To allow automatic starts, enable climate control in general settings and in the host room, {room}. Enabling humidity comfort alone is not enough.`,"dehumidifier.auto_hint":`RoomMind manages its own runs and supported humidity setpoints. If you turn the device on, it leaves it untouched until you turn it off.`,"dehumidifier.manual_option_hint":`You control the appliance through Home Assistant.`,"dehumidifier.coverage_hint":`Register the appliance where it is located. Add other rooms only if air can circulate between them.`,"dehumidifier.host_room":`Host · always included`,"dehumidifier.additional_rooms":`Additional rooms`,"dehumidifier.shared_available":`A shared appliance already serves this room`,"dehumidifier.shared_available_hint":`You can configure this room’s comfort below without adding another appliance. Change sharing in the host room.`,"dehumidifier.room_comfort":`Humidity in this room`,"dehumidifier.tolerance_hint":`Tolerance and priority determine how far humidity can rise above the target before requesting drying. A larger margin reduces starts. Drying stops near the target.`,"dehumidifier.priority_comfort_hint":`Request drying sooner`,"dehumidifier.priority_balanced_hint":`Standard humidity margin`,"dehumidifier.priority_energy_hint":`Allow a larger humidity rise`,"dehumidifier.protections":`Appliance protection and power`,"dehumidifier.timing_hint":`Minimum run and off times limit frequent switching. The off delay also applies after a restart. Protective stops can interrupt the minimum run time.`,"dehumidifier.shared_device":`Shared appliance · served rooms`,"dehumidifier.local_device":`Dedicated appliance · served room`,"dehumidifier.device_details":`Appliance target and protection`,"dehumidifier.device_target_hint":`For a shared appliance, its target follows the host humidity protection limit. It can differ from this room’s comfort target: each room requests drying using its own target.`,"dehumidifier.comfort_enabled":`Comfort enabled`,"dehumidifier.comfort_disabled":`Comfort disabled`,"dehumidifier.measured":`Measured humidity`,"dehumidifier.comfort_off_hint":`This room does not request drying for comfort. Mold prevention still follows its own settings.`,"dehumidifier.status_pending":`Appliance registered. Waiting for its operating status.`,"equipment.open":`Open`,"equipment.closed":`Closed`,"equipment.unavailable":`Unavailable`,"equipment.no_devices":`No heating or cooling appliances assigned yet.`,"equipment.no_sensors":`Assign sensors to measure the conditions in this room.`,"equipment.edit_devices":`Manage appliances`,"equipment.edit_sensors":`Manage sensors`,"dehumidifier.waiting_hint":`Ready: the appliance starts when a served room requests drying, subject to its protections.`,"settings.boiler.min_demand_rooms":`Requests needed to start the boiler`,"settings.boiler.min_demand_hint":`Below this number, radiators that want heat wait with their valves closed. Once running, the boiler keeps going while anything asks for heat.`,"settings.boiler.min_run_minutes":`Minimum run (min)`,"settings.boiler.min_off_minutes":`Minimum off (min)`,"settings.boiler.fault_retry_minutes":`Retry after a fault (min)`,"settings.boiler.child_lock":`Lock bypass valve buttons`,"settings.boiler.child_lock_hint":`Turns on the valve's child lock so a button press cannot take the bypass out of forced heat and stop the boiler.`,"settings.boiler.max_wait_minutes":`Maximum wait below the quorum (min)`,"settings.boiler.max_wait_hint":`A room asking for heat this long starts the boiler on its own, so radiator-only rooms are never left cold. 0 keeps the quorum strict.`,"comfort.profile_clear_hint":`Tap the active profile again, or "No profile", to go back to the schedule and comfort/eco temperatures.`,"settings.boiler.demand_unit":`Count requests by`,"settings.boiler.demand_unit_valves":`Radiator valves (a room with 2 radiators counts 2)`,"settings.boiler.demand_unit_rooms":`Rooms`},de:{"panel.title":`RoomMind`,"analytics.overview_title":`Das Raumklima im Überblick`,"analytics.overview_hint":`Entdecken Sie Temperaturverläufe, Energieverbrauch und den Lernfortschritt von RoomMind.`,"settings.hub.eyebrow":`Steuerzentrale`,"settings.hub.title":`Einstellungen mit Überblick`,"settings.hub.description":`Wählen Sie, was Sie einstellen möchten. Alltägliche Optionen bleiben von der Anlagentechnik und erweiterten Werkzeugen getrennt.`,"settings.hub.running":`Automatische Klimaregelung aktiv`,"settings.hub.paused":`Automatische Klimaregelung pausiert`,"settings.hub.navigation":`Einstellungskategorien`,"settings.hub.category_label":`Kategorie`,"settings.hub.overview":`Alltag`,"settings.hub.overview_hint":`Komfort, Anwesenheit und Vorlieben`,"settings.hub.system":`Heizanlage`,"settings.hub.system_hint":`Kessel, Klimageräte und Sensoren`,"settings.hub.protection":`Schutz und Hinweise`,"settings.hub.protection_hint":`Schimmel, Meldungen und Diagnose`,"settings.hub.advanced":`Erweitert`,"settings.hub.advanced_hint":`Lernen und Wartung`,"settings.hub.heating":`Heizkessel und Strombudget`,"settings.hub.heating_hint":`Hydraulischer Bypass, Kesseltiming und Leistungsgrenzen.`,"room.nav.overview":`Klima und Komfort`,"room.nav.equipment":`Geräte und Sensoren`,"room.nav.advanced":`Automatik und Analyse`,"room.nav.description":`Wählen Sie einen Bereich zum Ansehen oder Bearbeiten.`,"panel.overview":`Ihr Zuhause im Überblick`,"panel.overview_hint":`Raumtemperaturen und Anlagen mit Handlungsbedarf.`,"panel.control_active":`Automatische Steuerung aktiv`,"panel.control_paused":`Automatische Steuerung pausiert`,"panel.subtitle":`Klimasteuerung`,"panel.tab.rooms":`Räume`,"panel.tab.settings":`Einstellungen`,"panel.edit":`Raum bearbeiten`,"panel.loading":`Laden...`,"panel.no_areas":`Keine Bereiche in Home Assistant konfiguriert.`,"panel.no_areas_hint":`Bereiche in den HA-Einstellungen anlegen.`,"badge.beta":`Beta`,"badge.beta_hint":`Dieses Feature ist in der Beta-Phase und kann sich in zukünftigen Updates noch ändern.`,"common.learn_more":`Mehr erfahren`,"panel.stat.rooms":`Räume`,"panel.stat.heating":`Heizen`,"panel.stat.cooling":`Kühlen`,"panel.stat.vacation":`Urlaub`,"panel.stat.away":`Abwesend`,"panel.stat.mold":`Schimmel`,"panel.hide_room":`Ausblenden`,"panel.unhide":`Einblenden`,"panel.hidden_rooms":`Ausgeblendete Räume`,"panel.floor_other":`Sonstige`,"panel.reorder":`Räume sortieren`,"panel.reorder_done":`Fertig`,"room.back":`Zurück zu den Räumen`,"room.section.climate_mode":`Klimamodus`,"room.section.schedule":`Zeitplan & Temperaturen`,"room.section.control_mode":`Steuerungsmodus`,"room.section.devices":`Geräte`,"room.section.sensors":`Sensoren`,"room.section.windows":`Fenstersensoren`,"room.control_mode.full_control":`Full Control`,"room.control_mode.managed":`Managed`,"room.control_mode.external_sensor":`Externer Sensor: {sensor}`,"room.control_mode.no_sensor":`Kein externer Temperatursensor zugewiesen`,"room.control_mode.mpc_active":`MPC aktiv`,"room.control_mode.mpc_learning":`Lernphase`,"room.control_mode.device_setpoint":`Geräte-Setpoint: {temp}`,"room.control_mode.power":`Leistung: {power}%`,"room.control_mode.full_control_info":`RoomMind hat volle Kontrolle über deine Klimageräte. Ein externer Temperatursensor liefert die tatsächliche Raumtemperatur, was eine proportionale Setpoint-Berechnung ermöglicht. Der Geräte-Setpoint wird dynamisch basierend auf der MPC-Leistung angepasst. Das thermische Modell (EKF) lernt das Verhalten deines Raums für optimalen Komfort und Energieeffizienz.`,"room.control_mode.managed_info":`RoomMind setzt die Zieltemperatur auf deinem Gerät (aus Zeitplan, Override oder Urlaubsmodus), aber das Gerät regelt selbstständig mit seinem internen Sensor. Kein proportionaler Boost, kein thermisches Modell-Lernen und keine MPC-Optimierung. Für präzisere Steuerung einen externen Temperatursensor in der Geräte-Sektion zuweisen.`,"room.delete":`Raum löschen`,"room.deleting":`Wird gelöscht...`,"room.saving":`Speichern...`,"room.saved":`Gespeichert`,"room.error_saving":`Fehler beim Speichern`,"room.confirm_delete":`RoomMind-Konfiguration für "{name}" entfernen?`,"room.error_save_fallback":`Konfiguration konnte nicht gespeichert werden`,"room.error_delete_fallback":`Konfiguration konnte nicht gelöscht werden`,"room.climate_control_toggle":`Klimasteuerung`,"room.climate_control_hint":`Wenn deaktiviert, steuert RoomMind die Geräte in diesem Raum nicht mehr. Sie behalten ihre aktuellen Einstellungen und können eigenständig weiter heizen oder kühlen. RoomMind schaltet sie nicht aus.`,"room.outdoor_toggle":`Außenbereich`,"room.outdoor_hint":`Deaktiviert Klimasteuerung, Schimmelerkennung und Modell-Training. Sensorüberwachung läuft weiter.`,"room.alias.placeholder":`Eigener Anzeigename`,"room.alias.clear":`Auf Bereichsname zurücksetzen`,"override.label":`Temporärer Override`,"override.comfort":`Komfort`,"override.eco":`Eco`,"override.custom":`Individuell`,"override.target":`Ziel:`,"override.heat_to":`Heizen bis:`,"override.cool_above":`Kühlen ab:`,"override.invalid_band":`Das Kühlziel muss mindestens so hoch wie das Heizziel sein`,"override.activate_for":`Aktivieren für:`,"override.error_set":`Override konnte nicht gesetzt werden`,"override.error_clear":`Override konnte nicht aufgehoben werden`,"hero.target":`Ziel`,"hero.override":`Override`,"hero.remaining":`noch {time}`,"hero.humidity":`{value}% Luftfeuchtigkeit`,"hero.device_setpoint":`Gerät auf {value}{unit}`,"hero.heat_source_primary":`Heizung: TRV`,"hero.heat_source_secondary":`Heizung: AC`,"hero.heat_source_both":`Heizung: TRV + AC`,"hero.permanent":`Dauerhaft`,"hero.waiting":`Warte auf Sensordaten...`,"hero.not_configured":`Noch nicht konfiguriert`,"hero.mpc_learning_paused":`MPC-Lernen pausiert`,"hero.temperature_sensor_unavailable":`Temperatursensor nicht verfuegbar; Klimasteuerung pausiert`,"hero.mpc_learning_progress":`Thermisches Modell lernt: {confidence}% Konfidenz`,"hero.window_recovery":`Geschaetzte Erholung nach dem Schliessen: {minutes} Min.`,"hero.mpc_learning_paused.outdoor_unavailable":`RoomMind benötigt eine Außentemperatur, um das thermische Modell dieses Raums zu lernen. Der konfigurierte Außensensor ist nicht verfügbar und es ist keine Wetter-Entity als Fallback gesetzt. Konfiguriere eine der beiden in den Einstellungen.`,"hero.compressor_protection_min_off":`Kompressorschutz: wartet auf Mindestpause`,"hero.compressor_protection_min_run":`Kompressorschutz: Mindestlaufzeit aktiv`,"hero.compressor_protection_info":`Dieser Raum teilt sich eine Außeneinheit (Kompressor) mit anderen Räumen. Um Kurzzyklen zu vermeiden, erzwingt die Kompressorgruppe eine Mindestlaufzeit und eine Mindestpause, bevor dieses Gerät wieder umschalten darf.`,"card.target":`Ziel`,"card.waiting":`Warte auf Daten...`,"card.humidity":`{value}% Luftfeuchtigkeit`,"card.thermostat":`Thermostat`,"card.thermostats":`Thermostate`,"card.ac":`Klimaanlage`,"card.acs":`Klimaanlagen`,"card.climate_device":`Klimagerät`,"card.climate_devices":`Klimageräte`,"card.temp_sensor":`Temperatursensor`,"card.temp_sensors":`Temperatursensoren`,"card.no_climate":`Keine Klimageräte`,"card.outdoor":`Außen`,"card.tap_configure":`Tippen zum Konfigurieren`,"card.mpc_active":`MPC aktiv`,"card.mpc_learning":`MPC lernt`,"card.not_controlled":`Nicht von RoomMind gesteuert`,"mode.auto":`Automatisch`,"mode.auto_desc":`Heizt und kühlt automatisch basierend auf der Zieltemperatur`,"mode.heat_only":`Nur Heizen`,"mode.heat_only_desc":`Nutzt nur Thermostate, Klimaanlagen bleiben aus`,"mode.cool_only":`Nur Kühlen`,"mode.cool_only_desc":`Nutzt nur Klimaanlagen, Thermostate bleiben aus`,"mode.heating":`Heizen`,"mode.cooling":`Kühlen`,"mode.idle":`Standby`,"schedule.add_schedule":`Zeitplan hinzufügen`,"schedule.select_schedule":`Zeitplan-Helfer auswählen`,"schedule.create_helper_hint":`Neuen Zeitplan-Helfer in HA erstellen`,"schedule.selector_label":`Zeitplan-Auswahl`,"schedule.selector_value_boolean":`Aktuell: {value}`,"schedule.selector_value_number":`Aktueller Wert: {value}`,"schedule.selector_warning":`Mehrere Zeitpläne, aber keine Auswahl-Entity gesetzt. Nur der erste wird verwendet.`,"schedule.off_action_label":`Aktion wenn Zeitplan aus`,"schedule.off_action_eco":`Eco-Temperatur verwenden`,"schedule.off_action_off":`Geräte ausschalten`,"schedule.state_active":`Aktiv`,"schedule.state_inactive":`Inaktiv`,"schedule.state_unreachable":`Nicht erreichbar`,"schedule.no_schedules":`Keine Zeitpläne konfiguriert`,"schedule.done":`Fertig`,"schedule.view_comfort":`Komfort: {temp}{unit}`,"schedule.view_eco":`Eco: {temp}{unit}`,"schedule.view_selector":`Aktiver Zeitplan gewählt durch: {name}`,"schedule.view_selector_prefix":`Aktiver Zeitplan gewählt durch:`,"schedule.help_header":`Wie funktionieren Zeitpläne?`,"schedule.help_temps_title":`Wie wird die Zieltemperatur bestimmt?`,"schedule.help_temps":`Die Zieltemperatur folgt dieser Prioritätskette:`,"schedule.help_temps_1":`<strong>Manueller Override</strong> – Ein temporärer Komfort-/Eco-/Individueller Override hat immer die höchste Priorität.`,"schedule.help_temps_2":`<strong>Block-Temperatur</strong> – Wenn der aktive Zeitblock einen <code>temperature</code>-Wert in seinen Daten hat, wird dieser verwendet.`,"schedule.help_temps_3":`<strong>Komforttemperatur</strong> – Wenn der Zeitplan "an" ist, aber der Block keine Temperatur hat, wird die Komfort-Fallback-Temperatur verwendet.`,"schedule.help_temps_4":`<strong>Eco-Temperatur</strong> – Wenn der Zeitplan "aus" ist (außerhalb aller Zeitblöcke), wird die Eco-Temperatur verwendet.`,"schedule.help_block_title":`Temperatur pro Zeitblock setzen`,"schedule.help_block":`Du kannst für jeden Zeitblock eine eigene Temperatur setzen, indem du einen <code>temperature</code>-Wert in der YAML-Konfiguration des Zeitplans angibst:`,"schedule.help_block_note":`Wenn ein Block keinen <code>temperature</code>-Wert hat, wird stattdessen die Komfort-Fallback-Temperatur verwendet.`,"schedule.help_split_title":`Getrennte Heiz-/Kühlziele pro Block`,"schedule.help_split":`Für Räume im Auto-Modus kannst du pro Zeitblock separate Heiz- und Kühlziele mit <code>heat_temperature</code> und <code>cool_temperature</code> setzen:`,"schedule.help_split_note":`Wenn nur eines gesetzt ist, wird das andere auf die Komforttemperatur des Raumes zurückgesetzt. Diese Schlüssel haben Vorrang vor <code>temperature</code>.`,"schedule.help_multi_title":`Mehrere Zeitpläne`,"schedule.help_multi":`Du kannst mehrere Zeitpläne hinzufügen und mit einer <strong>Auswahl-Entity</strong> zwischen ihnen wechseln. Das kann ein <code>input_boolean</code> (wechselt zwischen Zeitplan 1 und 2) oder ein <code>input_number</code> (wählt nach Nummer) sein. Ohne Auswahl-Entity wird nur der erste Zeitplan verwendet.`,"schedule.column_comfort":`Komfort`,"schedule.column_eco":`Eco`,"schedule.row_heat":`Heizen`,"schedule.row_cool":`Kühlen`,"schedule.view_heat":`Heizen: {comfort} / {eco}{unit}`,"schedule.view_cool":`Kühlen: {comfort} / {eco}{unit}`,"schedule.comfort_hint_auto":`Komfort: Ziel wenn Zeitplan an. Eco: Ziel wenn Zeitplan aus. Zeilen: Ziel für Heizen bzw. Kühlen.`,"schedule.comfort_label":`Komfort-Fallback-Temperatur`,"schedule.eco_label":`Eco-Temperatur`,"schedule.comfort_hint":`Wird verwendet wenn der Zeitplan "an" ist, aber keine Temperatur im Block gesetzt ist`,"schedule.from_schedule":`{temp}{unit} vom Zeitplan`,"schedule.from_schedule_split":`{heat}{unit} / {cool}{unit} vom Zeitplan`,"schedule.fallback":`{temp}{unit} (Fallback)`,"schedule.eco_detail":`{temp}{unit} (Eco)`,"devices.climate_entities":`Klimageräte`,"devices.temp_sensors":`Temperatursensoren`,"devices.humidity_sensors":`Feuchtigkeitssensoren`,"devices.no_climate":`Keine Klimageräte in diesem Bereich gefunden.`,"devices.no_temp_sensors":`Keine Temperatursensoren in diesem Bereich gefunden.`,"devices.no_humidity_sensors":`Keine Feuchtigkeitssensoren in diesem Bereich gefunden.`,"devices.occupancy_sensors":`Anwesenheitssensoren`,"devices.no_occupancy_sensors":`Keine Anwesenheitssensoren in diesem Bereich gefunden`,"devices.occupancy_sensor_hint":`Verbessert die Genauigkeit des Wärmemodells durch Erkennung der Raumbelegung`,"devices.window_sensors":`Fenster- / Türsensoren`,"devices.no_window_sensors":`Keine Fenster-/Türsensoren in diesem Bereich gefunden.`,"devices.window_open_delay":`Verzögerung vor Pause`,"devices.window_close_delay":`Verzögerung vor Wiederaufnahme`,"devices.wall_factor":`Wandfaktor (f_Rsi)`,"devices.wall_factor_hint":`Wie kalt die kälteste Wandstelle des Raums ist: dient zur Schätzung der Feuchte dort, wo Schimmel entsteht. Niedriger = kältere Wand = höheres Risiko.`,"devices.wall_preset":`Wandtyp`,"devices.wall_preset_plain":`Normale Wand`,"devices.wall_preset_corner":`Ecke / Nordwand`,"devices.wall_preset_bridge":`Rollladenkasten, Träger oder Pfeiler`,"devices.wall_preset_measured":`Gemessen`,"devices.wall_measure_hint":`Mit einer Messung kalibrieren: an einem kalten Tag die Schimmelstelle mit einem Infrarotthermometer (Oberflächenmodus) messen.`,"devices.wall_measure_surface":`Wand`,"devices.wall_measure_room":`Raum`,"devices.wall_measure_outdoor":`Außen`,"devices.wall_measure_apply":`f = {value} übernehmen`,"devices.wall_measure_invalid":`Messung nicht verwendbar: mindestens 5 °C Unterschied zwischen Raum und außen und ein Ergebnis zwischen 0,50 und 0,95 nötig.`,"devices.add_entity":`Entität hinzufügen`,"devices.done":`Fertig`,"devices.other_area":`Anderer Bereich`,"devices.type_thermostat":`Thermostat`,"devices.type_ac":`Klimagerät`,"devices.type_label":`Typ`,"devices.select_to_configure":`Gerät zum Konfigurieren auswählen`,"devices.heating_system_type":`Heizungstyp`,"devices.heating_system_type_info":`Nach dem Abschalten geben Heizkörper und besonders Fußbodenheizungen gespeicherte Wärme weiter ab. RoomMind berücksichtigt diese Nachlaufwärme, um Überschwingen zu vermeiden und die Modellgenauigkeit zu verbessern. Fußbodenheizungen erhalten außerdem längere Mindestlaufzeiten.`,"devices.system_type_none":`Standard (kein Nachlauf)`,"devices.system_type_radiator":`Heizkörper`,"devices.system_type_underfloor":`Fußbodenheizung`,"devices.underfloor_delay_hint":`Fußbodenheizung hat lange Anlaufzeiten. Eine Fenster-Verzögerung von mindestens 5 Minuten wird empfohlen, um unnötige Abschaltungen zu vermeiden.`,"devices.heating_system_type_boost_hint":`Tipp: Wenn sich die Heizungsart geändert hat, kannst du unter Einstellungen das Lernen beschleunigen.`,"devices.idle_action":`Im Leerlauf`,"devices.idle_action_off":`Ausschalten`,"devices.idle_action_fan_only":`Nur Ventilator`,"devices.idle_action_setback":`Absenkung`,"devices.idle_action_low":`Niedriger Sollwert (wach halten)`,"devices.idle_action_low_hint":`Senkt den Sollwert auf das Geräteminimum ab, statt auszuschalten. Verhindert, dass TRVs, die im Aus-Modus in Tiefschlaf gehen, spätere Befehle verlieren.`,"devices.idle_fan_mode":`Lüftergeschwindigkeit`,"devices.idle_fan_mode_keep":`Nicht ändern`,"devices.fan_only_conditions":`Bedingungen für Nur Ventilator`,"devices.fan_only_only_after_cooling":`Nur nach dem Kühlen`,"devices.fan_only_require_presence":`Nur wenn erfasste Personen zu Hause sind`,"devices.fan_only_require_schedule":`Nur während eines aktiven Zeitplans`,"devices.fan_only_seasons":`Erlaubte Jahreszeiten`,"devices.fan_only_season_spring":`Frühling`,"devices.fan_only_season_summer":`Sommer`,"devices.fan_only_season_autumn":`Herbst`,"devices.fan_only_season_winter":`Winter`,"devices.fan_only_season_hint":`Saisonfilter benötigen die Home-Assistant-Integration Season, die sensor.season bereitstellt. Falls sie nicht verfügbar ist, bleibt Nur Ventilator aus.`,"devices.setpoint_mode":`Sollwert-Modus`,"devices.setpoint_mode_proportional":`Proportional (Ventilsteuerung)`,"devices.setpoint_mode_direct":`Direkt (Gerät regelt selbst)`,"devices.setpoint_mode_hint":`Direkt sendet die tatsächliche Raum-Zieltemperatur ans Gerät — geeignet für Thermostate und Heizlüfter mit eigener Regelung. Proportional sendet einen erhöhten Sollwert Richtung Geräte-max_temp — geeignet für Heizkörperventile (TRVs).`,"devices.valve_protection_excluded":`Vom Ventilschutz ausgenommen`,"devices.valve_protection_exclude_hint":`Dieses Gerät wird nicht vom Ventilschutz bewegt (z.B. virtuelle Kessel-Entitäten)`,"devices.info.types_title":`Gerätetypen`,"devices.info.types_body":`Thermostat bedeutet Heizkörperthermostat / TRV. Klimagerät bedeutet AC, Wärmepumpe oder eine andere Klima-Entität für Kühlung oder Warmluftheizung. Beides sind Home-Assistant-Klima-Entitäten; der Unterschied liegt darin, wie RoomMind sie ansteuert.`,"devices.info.control_title":`Wie RoomMind sie steuert`,"devices.info.control_body":`Der Sollwert-Modus gilt nur für Thermostate in Räumen mit Full Control und externem Temperatursensor. Verwende Proportional, wenn RoomMind die Heizleistung über angehobene Sollwerte steuern soll. Verwende Direkt, wenn das Gerät selbst um den echten Zielwert regeln soll.`,"devices.info.modes_title":`Verhalten im Leerlauf`,"devices.info.modes_body":`Im Leerlauf gilt nur für Klimageräte. Ausschalten schaltet das Gerät aus. Nur Ventilator hält die Luftzirkulation ohne Heizen oder Kühlen aufrecht. Absenkung lässt den aktuellen Modus aktiv, verschiebt den Sollwert aber um 2°C vom Raumziel weg. Dieser Offset ist derzeit fest. Für Thermostate hält Niedrig den TRV aktiv auf minimalem Sollwert statt ihn auszuschalten, nützlich für batteriebetriebene Zigbee-TRVs, die beim Ausschalten in den Tiefschlaf gehen.`,"devices.info.heat_source_title":`Intelligente Quellenwahl`,"devices.info.heat_source_body":`Diese Funktion erscheint nur, wenn ein Raum sowohl ein Thermostat/TRV als auch ein Klimagerät und zusätzlich einen externen Temperatursensor hat. RoomMind kann dann je nach Temperaturdifferenz und Außenbedingungen auswählen, welche Quelle das Heizen übernimmt.`,"hero.window_open":`Fenster offen – pausiert`,"card.window_open":`Fenster offen`,"room.section.covers":`Rollos & Jalousien`,"covers.section_title":`Rollos & Jalousien`,"covers.auto_control":`Automatische Rollosteuerung`,"covers.auto_control_hint":`RoomMind schließt Rollos, wenn Solarwärme den Raum voraussichtlich überhitzen würde.`,"covers.deploy_threshold":`Auslöseschwelle`,"covers.deploy_threshold_hint":`Rollos schließen, wenn die vorhergesagte Temperatur den Zielwert um diesen Betrag übersteigt.`,"covers.min_position":`Minimale Öffnungsposition`,"covers.min_position_hint":`Rollos werden nie weiter als diese Position geschlossen (0 = vollständig schließen erlaubt).`,"covers.override_minutes":`Override-Pausendauer`,"covers.override_minutes_hint":`Wie lange die automatische Steuerung nach manueller Rolloverstellung pausiert. 0 = keine Pause.`,"covers.no_covers":`Keine Rollo-Entitäten konfiguriert.`,"covers.no_covers_in_area":`Keine Rollo-Entitäten in diesem Bereich gefunden.`,"covers.add_cover":`Rollo-Entität hinzufügen...`,"covers.shading_active":`Beschattung aktiv`,"covers.auto_paused":`Automatik pausiert (manuell übersteuert)`,"covers.auto_paused_until":`Automatik pausiert bis`,"covers.resume_auto":`Automatik jetzt fortsetzen`,"covers.done":`Fertig`,"covers.night_close":`Nachts automatisch schließen`,"covers.night_close_hint":`Rolläden bei Sonnenuntergang schließen und bei Sonnenaufgang öffnen.`,"covers.night_close_active":`Nachtschließung aktiv`,"covers.schedule_group_title":`Zeitplan`,"covers.solar_group_title":`Solar-Steuerung`,"covers.schedule_section":`Rolläden-Zeitpläne`,"covers.schedule_section_hint":`Definiere Zeitfenster für die Rolladensteuerung. Im Modus 'Position erzwingen' überschreibt der Zeitplan die Solar-/Thermik-Logik. Im Modus 'Sonnenschutz erlauben' entscheidet RoomMind innerhalb des aktiven Zeitfensters selbst über die Position.`,"covers.add_schedule":`Zeitplan hinzufügen...`,"covers.schedule_mode_force":`Position erzwingen`,"covers.schedule_mode_gate":`Sonnenschutz erlauben`,"covers.schedule_mode_gate_short":`Solarschutz-Gate`,"covers.schedule_position":`Position`,"covers.schedule_position_hint":`Rolloposition wenn dieser Zeitplan aktiv ist (0% = vollständig geschlossen, 100% = vollständig offen).`,"covers.schedule_selector":`Zeitplan-Selektor`,"covers.schedule_selector_hint":`Bestimmt welcher Zeitplan aktiv ist. input_boolean: aus=#1, an=#2. input_number: Wert wählt Zeitplan-Nummer.`,"covers.schedule_selector_warning":`Mehrere Zeitpläne konfiguriert aber kein Selektor gesetzt. Nur der erste Zeitplan wird verwendet.`,"covers.schedule_state_active":`Aktiv`,"covers.schedule_state_inactive":`Inaktiv`,"covers.schedule_state_unreachable":`Nicht erreichbar`,"covers.schedule_active":`Zeitplan aktiv`,"covers.schedule_create_link":`Zeitplan-Helfer erstellen`,"covers.night_position":`Nachtposition`,"covers.night_position_hint":`Rolloposition wenn Nachtschließung aktiv ist (0% = vollständig geschlossen). Bei Rollos mit individueller Min. Position wird diese nie unterschritten.`,"covers.night_close_advanced":`Erweitert`,"covers.night_close_elevation":`Sonnenstand-Schwellwert`,"covers.night_close_elevation_hint":`Wie weit die Sonne unter oder über dem Horizont stehen muss. 0° = genau bei Sonnenuntergang/-aufgang. Negativ = dunkler (z.B. -6° = Dämmerung, wenn es merklich dunkel wird). Positiv = noch hell (z.B. 5° = Sonne noch sichtbar).`,"covers.night_close_offset":`Zeitversatz`,"covers.night_close_offset_hint":`Zusätzliche Verschiebung relativ zum Sonnenstand-Schwellwert. Positiv = später schließen (z.B. +20 = 20 Min. nach Erreichen des Schwellwerts), negativ = früher.`,"covers.outdoor_min_temp":`Min. Außentemperatur`,"covers.outdoor_min_temp_hint":`Rollos bei dieser Außentemperatur nicht für Sonnenschutz schließen. Bei Kälte ist der Solareintrag erwünscht.`,"covers.per_cover_title":`Pro-Rollo Einstellungen`,"covers.per_cover_hint":`Himmelsrichtung pro Rollo und optionale individuelle Mindestposition.`,"covers.per_cover_min_short":`Min`,"covers.per_cover_min_position":`Min. Position`,"covers.per_cover_min_position_hint":`Individuelle Mindestposition pro Rollo. Rollos werden nicht weiter geschlossen. Nützlich wenn Rollos physisch schon bei > 0% ganz zu sind.`,"covers.snap_deploy":`Direkt auf Minimalposition`,"covers.snap_deploy_hint":`Rolläden direkt auf die Minimalposition schließen statt schrittweise. Empfohlen für Dreifachverglasung, bei der Zwischenpositionen thermische Spannungen verursachen können.`,"covers.info.selection_title":`Rollo-Auswahl`,"covers.info.selection_body":`Wähle Rollos/Jalousien aus diesem Bereich oder füge Entitäten aus anderen Bereichen hinzu. RoomMind verfolgt deren Position und kann sie automatisch steuern.`,"covers.info.schedule_title":`Zeitplan-Steuerung`,"covers.info.schedule_body":`Verwende HA-Zeitplan-Helfer um festzulegen, wann Rollos schließen sollen (z.B. Sichtschutz am Abend). Das Positions-Attribut des Zeitplans bestimmt, wie weit sie schließen. Zeitpläne überschreiben alle andere Automatik-Logik.`,"covers.info.solar_title":`Solar-/Thermik-Steuerung`,"covers.info.solar_body":`Bei aktivierter Automatik sagt RoomMind vorher, ob Sonneneinstrahlung den Raum überhitzen wird und schließt Rollos präventiv. Es nutzt gelernte Thermodaten wenn verfügbar, sonst einen konservativen Standardwert. Die Auslöseschwelle bestimmt, wie viel vorhergesagte Überschreitung nötig ist.`,"covers.info.night_title":`Nachtschließung`,"covers.info.night_body":`Schließt Rollos bei Sonnenuntergang und öffnet sie bei Sonnenaufgang. Du kannst eine eigene Nachtposition setzen (z.B. 10% = fast geschlossen aber nicht komplett).`,"covers.info.override_title":`Manuelles Übersteuern`,"covers.info.override_body":`Wenn du ein Rollo manuell bewegst, erkennt RoomMind dies und pausiert die Automatik für die konfigurierte Dauer. So wird nicht gegen den Nutzer gearbeitet.`,"covers.info.priority_title":`Prioritätsreihenfolge`,"covers.info.priority_body":`Manuelles Override > Zeitplan > Nachtschließung > Solar-/Thermik-Steuerung. Höhere Priorität gewinnt immer. Wenn keine Regel greift, bleiben Rollos offen.`,"covers.info.entities_title":`HA-Entitäten`,"covers.info.entities_body":`RoomMind erstellt zwei Entitäten pro Raum zur externen Nutzung: switch.roommind_{bereich}_cover_auto (automatische Rollosteuerung ein-/ausschalten — nutzbar in Automatisierungen oder Dashboards) und binary_sensor.roommind_{bereich}_cover_paused (an wenn manuelles Override aktiv ist, z.B. nach manuellem Bewegen eines Rollos).`,"covers.orientation_group_title":`Rolloausrichtung`,"covers.orientation_hint":`Himmelsrichtung, in die das Rollo zeigt. RoomMind nutzt dies, um Sonnenschutz zu überspringen, wenn die Sonne nicht auf diese Gebäudeseite scheint.`,"covers.orientation_none":`Beliebige Richtung`,"covers.orientation_N":`N`,"covers.orientation_NE":`NO`,"covers.orientation_E":`O`,"covers.orientation_SE":`SO`,"covers.orientation_S":`S`,"covers.orientation_SW":`SW`,"covers.orientation_W":`W`,"covers.orientation_NW":`NW`,"covers.orientation_N_full":`Nord`,"covers.orientation_NE_full":`Nordost`,"covers.orientation_E_full":`Ost`,"covers.orientation_SE_full":`Südost`,"covers.orientation_S_full":`Süd`,"covers.orientation_SW_full":`Südwest`,"covers.orientation_W_full":`West`,"covers.orientation_NW_full":`Nordwest`,"settings.general_title":`Allgemein`,"settings.group_by_floor":`Räume nach Etagen gruppieren`,"settings.climate_control_active":`Klimasteuerung aktiv`,"settings.climate_control_hint":`Wenn deaktiviert, überwacht RoomMind weiterhin alle Sensoren und trainiert das Modell, sendet aber keine Befehle an deine Heizungen oder Klimaanlagen. Die Geräte behalten ihren aktuellen Modus und Sollwert und können eigenständig weiter heizen oder kühlen. RoomMind schaltet sie nicht aus.`,"settings.learning_title":`Modell-Training`,"settings.learning_hint":`Wenn pausiert, sammelt RoomMind keine neuen Messdaten und trainiert das thermische Modell nicht weiter. Bestehende Modelldaten bleiben erhalten.`,"settings.learning_exceptions":`Ausnahmen`,"settings.learning_room_paused":`Raum pausiert`,"settings.learning_rooms_paused":`Räume pausiert`,"settings.sensors_title":`Sensoren & Datenquellen`,"settings.control_title":`Steuerung`,"settings.outdoor_sensor":`Außentemperatur`,"settings.outdoor_sensor_label":`Außentemperatursensor`,"settings.outdoor_current":`Aktuell {temp}{unit} draußen`,"settings.outdoor_waiting":`Warte auf Sensordaten...`,"settings.outdoor_humidity_sensor":`Außenluftfeuchtigkeit`,"settings.outdoor_humidity_label":`Außenluftfeuchtigkeitssensor`,"settings.outdoor_humidity_current":`Aktuell {value}% draußen`,"settings.smart_control":`Intelligente Klimasteuerung`,"settings.smart_control_hint":`Außentemperaturgrenzen für Heiz- und Kühlentscheidungen konfigurieren.`,"settings.outdoor_cooling_min":`Mindest-Außentemperatur für Kühlung`,"settings.outdoor_cooling_min_hint":`Klimaanlage bleibt aus wenn Außentemperatur unter diesem Wert`,"settings.outdoor_heating_max":`Maximal-Außentemperatur für Heizung`,"settings.outdoor_heating_max_hint":`Heizung bleibt aus wenn Außentemperatur über diesem Wert`,"settings.saving":`Speichern...`,"settings.saved":`Gespeichert`,"settings.error":`Fehler beim Speichern`,"devices.using_builtin_sensor":`Nutzt den eingebauten Thermostat-Sensor`,"settings.climate_intelligence":`Klimaintelligenz`,"settings.control_mode":`Steuerungsmodus`,"settings.control_mode_simple":`Einfach (Ein/Aus)`,"settings.control_mode_mpc":`Intelligent (MPC)`,"settings.control_mode_hint":`MPC lernt das thermische Verhalten deiner Räume für optimale Steuerung`,"settings.comfort_weight":`Priorität`,"settings.comfort_weight_comfort":`Komfort`,"settings.comfort_weight_efficiency":`Effizienz`,"settings.comfort_weight_hint":`Gewichtet Temperaturgenauigkeit gegen Energieverbrauch. Komfort reagiert früher und bleibt näher am Zielwert. Effizienz erlaubt mehr Abweichung, um Heiz- und Kühllaufzeiten zu reduzieren.`,"settings.weather_entity":`Wettervorhersage`,"settings.weather_entity_hint":`Optional: ermöglicht vorausschauende Außentemperaturplanung und dient als Fallback wenn der Außensensor nicht verfügbar ist`,"settings.outdoor_unavailable_notify":`Hinweis bei fehlender Außentemperatur`,"settings.outdoor_unavailable_notify_hint":`Zeigt eine Home-Assistant-Benachrichtigung, wenn weder Außensensor noch Wetter-Entity 30 Minuten lang eine Temperatur geliefert haben. In dieser Zeit pausiert RoomMind das Lernen des thermischen Modells, um Korruption zu vermeiden.`,"settings.prediction_enabled":`Temperaturvorhersage`,"settings.prediction_enabled_hint":`Zeigt den vorhergesagten Temperaturverlauf im Analyse-Diagramm. Bei langsamer Performance deaktivieren.`,"vacation.title":`Urlaubsmodus`,"vacation.hint":`Setzt alle Räume auf eine Absenktemperatur bis zum Enddatum.`,"vacation.active_label":`Urlaubsmodus aktiv`,"vacation.end_date":`Enddatum & Uhrzeit`,"vacation.setback_temp":`Absenktemperatur`,"vacation.no_end_date":`Kein Enddatum`,"vacation.deactivate":`Deaktivieren`,"tabs.analytics":`Analyse`,"analytics.select_room":`Raum auswählen`,"analytics.temperature":`Temperatur`,"analytics.target":`Ziel`,"analytics.prediction":`Vorhersage`,"analytics.outdoor":`Außen`,"analytics.model_status":`Modellstatus`,"analytics.confidence":`Konfidenz`,"analytics.heating_rate":`Heizstärke`,"analytics.cooling_rate":`Kühlstärke`,"analytics.solar_gain":`Solargewinn`,"analytics.occupancy_gain":`Anwesenheitsgewinn`,"analytics.time_constant":`Zeitkonstante`,"analytics.samples":`Datenpunkte`,"analytics.prediction_accuracy":`Vorhersagegenauigkeit`,"analytics.avg_deviation":`Durchschn. Abweichung`,"analytics.data_sources":`Datenquellen`,"analytics.data_points":`Datenpunkte`,"analytics.control_mode":`Steuerungsmodus`,"analytics.control_mode_mpc":`MPC aktiv`,"analytics.control_mode_bangbang":`MPC wird trainiert`,"analytics.last_model_update":`Letztes Modell-Update`,"analytics.accuracy_idle":`Genauigkeit (Leerlauf)`,"analytics.accuracy_heating":`Genauigkeit (Heizen)`,"analytics.info.accuracy_idle":`Wie genau das Modell die Temperatur vorhersagt, wenn weder geheizt noch gekühlt wird. Ein niedrigerer Wert bedeutet, dass das Modell den natürlichen Wärmeverlust deines Raums gut versteht. Dieser Wert verbessert sich als erstes, da Leerlauf-Daten kontinuierlich gesammelt werden.`,"analytics.info.accuracy_heating":`Wie genau das Modell die Temperatur während des aktiven Heizens vorhersagt. Dieser Wert bleibt anfangs hoch, da das Modell echte Heizzyklen zum Lernen braucht. Sobald deine Heizung ein paar Mal gelaufen ist, sinkt dieser Wert und die intelligente MPC-Steuerung wird verfügbar.`,"analytics.info.confidence":`Gesamte Modellreife für die intelligente MPC-Steuerung, basierend auf zwei Faktoren: Datenmenge (wie viele Leerlauf- und Aktiv-Messwerte gesammelt wurden) und Vorhersagegenauigkeit (wie präzise die Temperaturprognosen sind). Die Konfidenz startet bei 0% und steigt mit zunehmenden Daten. Etwa 50% bedeutet: genug Leerlaufdaten, aber noch zu wenig Heiz-/Kühlzyklen. Über 80% bedeutet: genug Daten und genaue Vorhersagen — MPC-Steuerung wird verfügbar. 100% ist das theoretische Maximum, wenn die Vorhersagen so genau wie physikalisch möglich sind.`,"analytics.info.time_constant":`Wie lange es dauert, bis sich die Raumtemperatur bei ausgeschalteter Heizung halbwegs der Außentemperatur annähert. Eine längere Zeitkonstante bedeutet bessere Dämmung — der Raum hält die Wärme länger. Eine kurze Zeitkonstante bedeutet schnelles Auskühlen. Das Modell lernt diesen Wert, indem es Temperaturabfälle im Leerlauf beobachtet.`,"analytics.info.heating_rate":`Wie stark deine Heizung die Raumtemperatur beeinflusst. Ein höherer Wert bedeutet, dass dein Heizsystem den Raum schneller erwärmt relativ zur thermischen Masse. Das Modell lernt dies durch Beobachtung der Temperaturanstiege beim Heizen und nutzt es um vorherzusagen, wie lange geheizt werden muss.`,"analytics.info.cooling_rate":`Wie stark deine Klimaanlage die Raumtemperatur beeinflusst. Ein höherer Wert bedeutet schnellere Kühlung relativ zur thermischen Masse. Das Modell lernt dies durch Beobachtung der Temperaturabfälle bei aktiver Kühlung und nutzt es um vorherzusagen, wie lange gekühlt werden muss.`,"analytics.info.solar_gain":`Der geschätzte Effekt der Sonneneinstrahlung durch Fenster auf die Raumtemperatur. Wird gelernt, indem beobachtet wird, wie sich der Raum bei Sonnenschein erwärmt, wenn nicht geheizt wird. Räume mit großen Südfenstern haben höhere Werte. Das Modell nutzt dies um die Heizung zu reduzieren, wenn Solargewinn erwartet wird.`,"analytics.info.occupancy_gain":`Der geschätzte Wärmebeitrag durch Anwesenheit (Personen, Haustiere, Computer), solange der Raum belegt ist. Wird gelernt, indem Temperaturänderungen beobachtet werden, während die konfigurierten Anwesenheitssensoren aktiv sind. Durch die Trennung vom Solargewinn wird Körperwärme nicht mehr fälschlich der Sonneneinstrahlung zugeschrieben. Wird nur angezeigt, wenn für diesen Raum mindestens ein Anwesenheitssensor konfiguriert ist.`,"analytics.info.data_sources":`Anzahl der Messwerte, die für das Modelltraining verwendet werden.`,"analytics.info.data_points":`Gesamtzahl der Beobachtungen, mit denen das Modell trainiert wurde. Mehr Datenpunkte führen in der Regel zu besseren Vorhersagen. Das Modell sammelt etwa alle 3 Minuten einen neuen Datenpunkt während RoomMind läuft.`,"analytics.no_data":`Noch keine Daten — Modell lernt`,"analytics.loading":`Analyse wird geladen...`,"settings.reset_title":`Thermische Daten zurücksetzen`,"settings.reset_hint":`Gelernte thermische Modelldaten und Verlauf löschen. Das Modell beginnt von vorne zu lernen.`,"settings.reset_all_label":`Alle Räume`,"settings.reset_all_hint":`Thermische Daten und Verlauf für alle Räume auf einmal löschen.`,"settings.reset_all_btn":`Alle zurücksetzen`,"settings.reset_all_confirm":`Alle gelernten thermischen Daten und Verlauf für ALLE Räume löschen? Alle Modelle beginnen von vorne zu lernen.`,"settings.reset_room_label":`Einzelner Raum`,"settings.reset_room_hint":`Wähle einen Raum, um dessen thermische Daten und Verlauf zu löschen.`,"settings.reset_room_confirm":`Alle gelernten thermischen Daten und Verlauf für diesen Raum löschen? Das Modell beginnt von vorne zu lernen.`,"settings.reset_room_select":`Raum auswählen`,"settings.reset_btn":`Zurücksetzen`,"settings.reset_no_rooms":`Keine konfigurierten Räume.`,"settings.boost_title":`Lernen beschleunigen`,"settings.boost_hint":`Das thermische Modell lernt das Heiz- und Kühlverhalten deines Raumes über die Zeit. Nach grösseren Änderungen (neuer Heizkörper, Klimaanlage, Dämmung, Möbel) kann das Modell ungenau sein. Dies erhöht die Unsicherheit des Modells, damit es sich schneller an die neuen Bedingungen anpasst.`,"settings.boost_label":`Lernen beschleunigen`,"settings.boost_room_select":`Raum auswählen`,"settings.boost_btn":`Beschleunigen`,"settings.boost_cooldown":`Aktiv – Neues Lernen läuft`,"settings.boost_no_rooms":`Keine konfigurierten Räume.`,"analytics.range_1d":`Heute`,"analytics.range_2d":`2 Tage`,"analytics.range_7d":`Woche`,"analytics.range_30d":`Monat`,"analytics.export":`Messdaten`,"analytics.heating_period":`Heizen`,"analytics.cooling_period":`Kühlung`,"analytics.window_open_period":`Fenster offen`,"analytics.blind_position":`Rolloposition`,"analytics.chart_info_title":`So liest du dieses Diagramm`,"analytics.exported":`Exportiert!`,"analytics.copy_diagnostics":`Diagnose`,"analytics.export_download":`Datei herunterladen`,"analytics.export_clipboard":`In Zwischenablage kopieren`,"analytics.copied_to_clipboard":`Kopiert!`,"analytics.range_from":`Von`,"analytics.range_to":`Bis`,"analytics.chart_info_body":`**Linien:** Die durchgezogene orangene Linie zeigt die gemessene Raumtemperatur. Die grüne gestrichelte Linie ist die Zieltemperatur aus deinem Zeitplan. Die blaue gepunktete Linie ist die Temperaturvorhersage des Modells.

**Schattierte Bereiche:** Rote Schattierung markiert Heizperioden, blaue Kühlung und türkise Bereiche zeigen an, wenn ein Fenster offen war.

**Zukunftsprognose (rechts der 'Jetzt'-Linie):** Die grüne gestrichelte Linie zeigt die kommenden Zieltemperaturen für die nächsten 3 Stunden. Die blaue gepunktete Linie zeigt den vorhergesagten Temperaturverlauf.

**Vorhersage-Modus:** Wenn 'MPC aktiv' angezeigt wird, nutzt die Vorhersage den vollständigen MPC-Optimizer mit intelligentem Vorheizen/-kühlen. Solange das Modell noch lernt, wird eine einfachere Simulation verwendet.

**Einschränkungen:** Die Vorhersage nimmt an, dass aktuelle Bedingungen konstant bleiben (Außentemperatur, Fensterstatus). Die Genauigkeit hängt davon ab, wie gut das Modell deinen Raum bereits gelernt hat — anfangs können die Vorhersagen ungenau sein. Sobald MPC aktiviert wird, werden die Vorhersagen deutlich zuverlässiger.`,"presence.title":`Anwesenheitserkennung`,"presence.hint":`Eco-Temperatur wenn niemand zu Hause ist.`,"presence.hint_detail":`Wenn aktiviert, werden alle Räume auf Eco-Temperatur gesetzt, sobald keine der konfigurierten Personen zu Hause ist. Pro Raum kann optional eingeschränkt werden, welche Personen relevant sind.`,"presence.add_person":`Person hinzufügen`,"presence.add_entity":`Präsenz-Entity hinzufügen`,"presence.person_label":`Person`,"room.section.presence":`Anwesenheit`,"presence.room_help_header":`Wie funktioniert die Raum-Anwesenheit?`,"presence.room_help_body":`Wähle aus, welche Personen für diesen Raum relevant sind. Der Raum schaltet auf Eco-Temperatur, wenn keine der ausgewählten Personen zu Hause ist. Ohne Auswahl greift die globale Regel: Eco wenn niemand zu Hause ist.`,"presence.state_home":`Zu Hause`,"presence.state_away":`Abwesend`,"presence.room_none_assigned":`Globale Regel — Eco wenn niemand zu Hause ist`,"presence.missing_entity_hint":`Diese Entity existiert nicht mehr in Home Assistant — abwählen, um sie aus diesem Raum zu entfernen.`,"presence.ignore_toggle":`Anwesenheit ignorieren`,"presence.ignore_hint":`Hier wird festgelegt, wie dieser Raum auf Anwesenheit reagiert. Unten kannst du einzelne Personen zuweisen. Der Raum wechselt auf Eco, wenn keine der zugewiesenen Personen zu Hause ist. Mit dem Toggle oben wird die Erkennung komplett übersprungen und der Raum heizt immer nach Zeitplan.`,"presence.help_ignore_title":`Was bewirkt "Ignore presence"?`,"presence.help_ignore_body":`Wenn aktiviert, ignoriert dieser Raum die Anwesenheitserkennung komplett. Er folgt immer seinem Zeitplan und wechselt nie aufgrund von Anwesenheit auf Eco. Nützlich für Räume, die unabhängig von Anwesenheit ihre Temperatur halten sollen, etwa Serverräume, Tierzimmer oder Gästezimmer mit Personen, die nicht in Home Assistant getrackt werden.`,"presence.tile_ignored":`Anwesenheitserkennung ist deaktiviert. Raum folgt immer dem Zeitplan.`,"presence.away_action_label":`Aktion wenn niemand zuhause`,"presence.away_action_eco":`Eco-Temperatur verwenden`,"presence.away_action_off":`Geräte ausschalten`,"presence.clears_override_label":`Abwesenheit beendet Override`,"presence.clears_override_hint":`Sobald niemand zuhause ist, wird ein manueller Override pausiert und der Raum folgt der Abwesenheits-Aktion. Kommt jemand zurück, läuft der Override weiter, bis er abläuft.`,"card.presence_away":`Abwesend`,"valve_protection.title":`Ventilschutz`,"valve_protection.hint":`Bewegt inaktive TRV-Ventile regelmäßig kurz, um Festsitzen oder Verkalkung zu verhindern.`,"valve_protection.interval_label":`Zyklusintervall`,"valve_protection.interval_suffix":`Tage`,"valve_protection.interval_hint":`Wie lange ein Ventil inaktiv sein darf, bevor es bewegt wird (1–90 Tage)`,"compressor.title":`Kompressorschutz`,"compressor.no_groups":`Keine Kompressorgruppen konfiguriert.`,"compressor.add_group":`Kompressorgruppe hinzufügen`,"compressor.group_name":`Gruppenname`,"compressor.members":`Innengeräte`,"compressor.members_hint":`Alle Klimageräte auswählen, die von diesem Kompressor versorgt werden (Splits, TRVs an Radiatoren, Fan Coils).`,"compressor.min_run":`Mindestlaufzeit`,"compressor.min_run_hint":`Kompressor muss nach dem Start mindestens so lange laufen.`,"compressor.min_run_suffix":`Min.`,"compressor.min_off":`Mindestauszeit`,"compressor.min_off_hint":`Kompressor muss nach dem Stopp mindestens so lange aus bleiben.`,"compressor.min_off_suffix":`Min.`,"compressor.delete":`Gruppe löschen`,"compressor.delete_confirm":`Kompressorgruppe "{name}" löschen?`,"compressor.master_entity":`Hauptgerät`,"compressor.master_entity_hint":`Das zentrale Gerät das die Innengeräte dieser Gruppe versorgt, z.B. ein Gaskessel, eine Wärmepumpen-Außeneinheit oder ein Kanalklima-Hauptschalter. RoomMind schaltet es ein wenn ein Raum Heiz- oder Kühlbedarf hat und aus wenn alle Räume im Leerlauf sind. Leer lassen um nur das Aktionsskript oder den Kurzzyklusschutz zu verwenden.`,"compressor.conflict_resolution":`Konfliktlösung`,"compressor.conflict_resolution_hint":`Bestimmt was passiert wenn einige Räume heizen und andere gleichzeitig kühlen wollen. Heizpriorität: Heizen gewinnt immer (sicherste Option für Frostschutz). Kühlpriorität: Kühlen gewinnt immer. Mehrheit: Der Modus mit mehr Räumen gewinnt, bei Gleichstand wird geheizt. Außentemperatur: Entscheidet automatisch anhand des Heiz-Schwellwerts aus den Einstellungen.`,"compressor.conflict_heating_priority":`Heizpriorität (Frostschutz)`,"compressor.conflict_cooling_priority":`Kühlpriorität`,"compressor.conflict_majority":`Mehrheit gewinnt`,"compressor.conflict_outdoor_temp":`Nach Außentemperatur`,"compressor.action_script":`Aktionsskript`,"compressor.action_script_hint":`Ein Home Assistant Skript das bei jedem Wechsel des Heiz-/Kühlbedarfs ausgeführt wird. Nützlich für Systeme die spezielle Befehle benötigen, z.B. zum Aufheben eines Vaillant Quick Veto oder Schalten eines Relais. Funktioniert mit oder ohne Hauptgerät. Ohne Hauptgerät wird nur das Skript ausgelöst. Erhält Variablen: action (heat/cool/idle), master_entity, members, active_members.`,"compressor.enforce_uniform_mode":`Einheitlichen Modus erzwingen`,"compressor.enforce_uniform_mode_hint":`Alle Thermostate in dieser Gruppe müssen im gleichen HVAC-Modus arbeiten (alle heizen oder alle kühlen). Räume, die dem aufgelösten Gruppenmodus widersprechen, werden auf Leerlauf gesetzt. Für Wärmepumpen die automatisch starten, aber alle angeschlossenen Geräte im gleichen Modus benötigen.`,"mold.title":`Schimmelschutz`,"mold.detection":`Schimmelerkennung`,"mold.detection_desc":`Benachrichtigung bei Schimmelgefahr durch hohe Luftfeuchtigkeit`,"mold.threshold":`Feuchtigkeitsschwelle (%)`,"mold.threshold_hint":`Warnung wenn die Raumluftfeuchte diesen Wert dauerhaft überschreitet`,"mold.sustained":`Mindestdauer (Minuten)`,"mold.sustained_hint":`Warnung erst nach anhaltender Überschreitung`,"mold.prevention":`Schimmelprävention`,"mold.prevention_desc":`Gefährdete Wände mit Entfeuchter oder geschützten DRY-Zyklen trocknen. Heizt nie; nachts greift die Klimaanlage nur bei kritischem Risiko ein.`,"mold.prevention_sustained":`Risikodauer vor dem Eingriff`,"mold.prevention_sustained_hint":`Bei 65 % Wandfeuchte nach 2 Std. sanftes DRY; bei 70 % nach gewählter Dauer; bei 80 % nach max. 10 Min. Max. 30 Min. Betrieb, 60 Min. Pause.`,"mold.dehumidification":`Entfeuchtung bevorzugen, wenn sicher`,"mold.dehumidification_desc":`Den Dry-Modus der Klimaanlage nur bei ausreichend warmer Raumluft zuerst verwenden; andernfalls folgt der konfigurierte Wärmepumpen-/Kesselplan.`,"mold.dehumidification_min_temperature":`Mindest-Raumtemperatur für Entfeuchtung`,"mold.dehumidification_min_temperature_hint":`DRY startet ab dieser Raumtemperatur und stoppt 1 °C darunter (mindestens 21 °C). Gilt nur für DRY der Klimaanlage: ein eigener Entfeuchter läuft bei jeder Temperatur.`,"card.mold_warning":`Schimmelrisiko`,"card.mold_critical":`Schimmelgefahr!`,"card.mold_prevention":`Schimmelschutz`,"room.mold_surface_rh":`Geschätzte Oberflächenfeuchte: {value}%`,"settings.intro.general":`Grundlegende Anzeige- und Steuerungseinstellungen.`,"settings.intro.sensors":`Außensensoren und Wetterdaten für eine präzise Klimasteuerung konfigurieren.`,"settings.intro.control":`Wähle, wie RoomMind deine Klimageräte steuert und setze Priorität und Schwellenwerte.`,"settings.intro.presence":`Temperatur automatisch absenken wenn niemand zu Hause ist.`,"settings.intro.vacation":`Alle Räume auf eine reduzierte Temperatur setzen während du abwesend bist.`,"settings.intro.valve":`Inaktive TRV-Ventile regelmäßig bewegen um Festsitzen oder Verkalkung zu verhindern.`,"settings.intro.compressor":`Gruppen von Innengeräten verwalten die sich einen Außenkompressor oder eine zentrale Heizquelle teilen. Optional ein Hauptgerät (Kessel, Außeneinheit) zuweisen das automatisch je nach Raumbedarf ein- und ausgeschaltet wird. Kurzzyklusschutz verhindert schnelles Ein-/Ausschalten das Geräte beschädigen kann.`,"settings.intro.mold":`Luftfeuchtigkeit überwachen und Schimmelrisiko automatisch reduzieren.`,"settings.intro.notifications":`Konfiguriere wer Benachrichtigungen erhält und wie.`,"settings.intro.learning":`Thermisches Modelltraining verwalten und Lernen nach Änderungen beschleunigen.`,"settings.intro.reset":`Gelernte thermische Modelldaten löschen. Das Modell beginnt von vorne zu lernen.`,"notifications.title":`Benachrichtigungen`,"notifications.window_open_after":`Fenster-offen-Warnung nach`,"notifications.window_open_after_hint":`Nach dieser Zeit mit offenem Fenster benachrichtigen. 0 deaktiviert die Warnung.`,"notifications.enabled":`Benachrichtigungen aktivieren`,"notifications.enabled_hint":`Wenn deaktiviert, werden keine Benachrichtigungen gesendet — weder an Geräte noch an die HA-Seitenleiste.`,"notifications.desc":`Wähle die Geräte, die Benachrichtigungen erhalten. Ohne Ziele erscheint eine Meldung in der HA-Seitenleiste.`,"notifications.add_target_label":`Benachrichtigungsgerät hinzufügen`,"notifications.add_target_hint":`Tippe die Entity-ID ein, falls dein Gerät nicht angezeigt wird (z.B. notify.mobile_app_...). Du findest sie unter Einstellungen → Geräte → dein Telefon → Notify-Entität.`,"notifications.target_unnamed":`Unbenanntes Gerät`,"notifications.target_person":`Person`,"notifications.target_when_always":`Immer`,"notifications.target_when_home":`Nur wenn zuhause`,"notifications.cooldown":`Benachrichtigungspause (Minuten)`,"notifications.cooldown_hint":`Mindestabstand zwischen wiederholten Warnungen pro Raum`,"notifications.mold_prevention_notify":`Bei Aktivierung der Prävention benachrichtigen`,"notifications.mold_prevention_notify_hint":`Auch benachrichtigen wenn die Prävention aktiviert wird (Temperaturerhöhung)`,"room.section.heat_source":`Heizquellen-Orchestrierung`,"heat_source.toggle":`Intelligente Quellenauswahl`,"heat_source.power_estimate":`Reserveleistung der Klimaanlage`,"heat_source.power_estimate_hint":`RoomMind lernt die Spitzenleistung für Heizen, Kühlen und Entfeuchten automatisch, mit 30 % Sicherheitsaufschlag. Dieser Ersatzwert gilt nur bis 6 gültige Messwerte pro Modus vorliegen. Bei 0 W werden Starts ohne Lerndaten sicher blockiert.`,"heat_source.budget_heating":`Heizen`,"heat_source.budget_cooling":`Kühlen`,"heat_source.budget_dry":`Entfeuchten`,"heat_source.budget_learned":`gelernt`,"heat_source.budget_fallback":`manuelle Reserve`,"heat_source.budget_unknown":`noch keine Daten`,"preview.title":`Sicherheitsvorschau`,"preview.intro":`Schreibgeschützte Simulation von Leistungsbudget und Kompressorschutz.`,"preview.mode":`Simulierter Modus`,"preview.run":`Ohne Schaltbefehle simulieren`,"preview.scope":`Schaltet keine Geräte. Prüft elektrische Freigabe und Kompressorschutz, aber nicht Zeitpläne, Saisongrenzen oder MPC.`,"preview.error":`Vorschau nicht verfügbar.`,"preview.headroom":`Verfügbare Leistung`,"preview.meter":`Leistungssensor`,"preview.healthy":`aktuell`,"preview.unavailable":`veraltet oder nicht verfügbar`,"preview.boiler":`Heizkessel`,"preview.bypass":`Bypass-Rückmeldung`,"preview.acknowledged":`durch HA-Zustand bestätigt`,"preview.not_acknowledged":`nicht bestätigt (normal bei Kessel aus)`,"preview.current_reasons":`Aktuelle Entscheidungen`,"preview.reason_eligible":`Start gemäß Leistungsbudget und Kompressorschutz zulässig`,"preview.reason_control_disabled":`Klimasteuerung deaktiviert`,"preview.reason_room_safety":`Raumschutz (Fenster oder erzwungen aus)`,"preview.reason_compressor_protection":`Kompressor-Mindestpause`,"preview.reason_power_budget":`Leistung unzureichend oder unbekannt`,"heat_source.toggle_hint":`Wenn dieser Raum sowohl Heizkörper-Thermostate als auch eine AC/Wärmepumpe hat, leitet RoomMind die Heizanforderung intelligent an das effizienteste Gerät weiter, basierend auf Temperaturlücke und Außenbedingungen.`,"heat_source.primary_delta":`Boiler-Aktivierungsschwelle`,"heat_source.primary_delta_hint":`Primärquelle erst aktivieren, wenn die Temperaturlücke diesen Wert überschreitet. Darunter wird nur die schnelle Sekundärquelle genutzt.`,"heat_source.primary_delta_suffix":`°C`,"heat_source.outdoor_threshold":`Außentemperatur-Umschaltpunkt`,"heat_source.outdoor_threshold_hint":`Über dieser Außentemperatur die AC/Wärmepumpe bevorzugen (höhere Effizienz). Darunter den Gas-Boiler/Heizkörper.`,"heat_source.outdoor_threshold_suffix":`°C`,"heat_source.ac_min_outdoor":`Min. Außentemp. für AC-Heizen`,"heat_source.ac_min_outdoor_hint":`AC-Heizen unter dieser Temperatur komplett deaktivieren, um die Wärmepumpen-Hardware zu schützen.`,"heat_source.ac_min_outdoor_suffix":`°C`,"heat_source.summary_disabled":`Intelligente Quellenwahl ist aus`,"devices.keep_fan_only_window":`Nur Lüften bei offenem Fenster beibehalten`,"devices.keep_fan_only_window_hint":`Heizen und Kühlen werden pausiert, aber ein Klimagerät im Nur-Lüften-Modus bleibt eingeschaltet.`,"settings.temperature_rounding":`Rundung der Gerätetemperatur`,"settings.temperature_rounding_hint":`Legt fest, wie RoomMind auf die vom Klimagerät unterstützte Schrittweite rundet.`,"settings.temperature_rounding_nearest":`Nächster unterstützter Wert`,"settings.temperature_rounding_down":`Abrunden (26,5° → 26°)`,"settings.temperature_rounding_up":`Aufrunden (26,5° → 27°)`,"devices.power_sensor":`Leistungssensor`,"devices.power_sensor_hint":`Sensor für den momentanen Stromverbrauch dieser Klimaanlage. W- und kW-Sensoren werden für Energieverlauf und adaptive Prognosen unterstützt.`,"analytics.energy_title":`Energieverbrauch`,"analytics.energy_subtitle":`Gemessene Geräteleistung und gelernte Prognose`,"analytics.energy_chart_info_body":`Durchgezogene Linien zeigen die gemessene Leistung. Gestrichelte Segmente setzen an der letzten Messung mit der gelernten Drei-Stunden-Prognose fort. Tippe auf einen Legendeneintrag, um eine Reihe ein- oder auszublenden. Zum Zoomen horizontal scrollen oder zwei Finger verwenden; die vertikale gestrichelte Linie markiert jetzt.`,"analytics.energy_room_power":`Raumleistung`,"analytics.energy_forecast":`Prognose`,"analytics.energy_forecast_short":`Prognose`,"analytics.energy_now":`Jetzt`,"analytics.energy_period":`Energie im Zeitraum`,"analytics.energy_next_3h":`Nächste 3 Stunden`,"analytics.energy_learning":`Lernmesswerte`,"analytics.energy_confidence":`Prognosesicherheit`,"analytics.energy_confidence_low":`Niedrig`,"analytics.energy_confidence_medium":`Mittel`,"analytics.energy_confidence_high":`Hoch`,"analytics.energy_cost_today":`Kosten heute`,"analytics.energy_cost_7d":`Kosten letzte 7 Tage`,"analytics.energy_cost_next_3h":`Kosten nächste 3 Std.`,"analytics.comparison_title":`Raumvergleich`,"analytics.comparison_info":`Vergleicht den ausgewählten Zeitraum: kWh ist die gemessene Klimaanlagenenergie, € die geschätzten Kosten, Aktiv die gesamte Heiz-/Kühlzeit, ΔT/kWh die Temperaturänderung pro Energieeinheit und Bis Ziel die durchschnittliche Zeit bis zur Solltemperatur.`,"analytics.comparison_data_incomplete":`Unvollständige Daten`,"analytics.comparison_quality_insufficient_samples":`zu wenige Messwerte`,"analytics.comparison_quality_no_power_measurements":`keine Leistungsmessungen`,"analytics.comparison_quality_history_gaps":`Lücken im Verlauf`,"analytics.comparison_room":`Raum`,"analytics.comparison_active":`Aktiv`,"analytics.comparison_efficiency":`ΔT/kWh`,"analytics.comparison_target":`Bis Ziel`,"settings.energy_price":`Energiepreis der Klimaanlage`,"settings.energy_price_hint":`Preis (EUR/kWh)`,"hero.window_impact":`Fenster seit {minutes} Min. offen: {impact}{unit} gegenüber Prognose`,"hero.power_budget_blocked":`Klimastart wegen Hausstrombudget verschoben`,"hero.preconditioning_active":`Vorkonditionierung für das nächste Zeitplan-Ziel aktiv`,"hero.preconditioning_planned":`Vorkonditionierung geplant um {time}`,"hero.ac_efficiency_issue":`Klimagerät verbraucht normal, reagiert aber langsam`,"insights.comfort.title":`Komfortbewertung erklÃ¤rt`,"insights.comfort.summary":`Der Wert beginnt bei 100; aktive Bedingungen ziehen Punkte ab.`,"insights.comfort.base":`Ausgangswert`,"insights.comfort.total":`Aktueller Wert`,"insights.comfort.no_penalty":`Kein Abzug`,"insights.comfort.factor.temperature.unavailable":`Temperaturwert nicht verfÃ¼gbar`,"insights.comfort.factor.temperature.below_target":`Temperatur unter Sollwert`,"insights.comfort.factor.temperature.above_target":`Temperatur Ã¼ber Sollwert`,"insights.comfort.factor.temperature.on_target":`Temperatur im Sollbereich`,"insights.comfort.factor.humidity.unavailable":`Luftfeuchtigkeit wird nicht bewertet`,"insights.comfort.factor.humidity.below_target":`Luftfeuchtigkeit unter Sollwert`,"insights.comfort.factor.humidity.above_target":`Luftfeuchtigkeit Ã¼ber Sollwert`,"insights.comfort.factor.humidity.on_target":`Luftfeuchtigkeit im Sollbereich`,"insights.comfort.factor.window.open":`Fenster ist offen`,"insights.comfort.factor.window.closed":`Fenster ist geschlossen`,"insights.comfort.factor.air_quality.warning":`Warnung vor Schimmelrisiko`,"insights.comfort.factor.air_quality.critical":`Kritisches Schimmelrisiko`,"insights.comfort.factor.air_quality.ok":`Kein Schimmelrisiko`,"insights.comfort.factor.anomalies.active":`Aktive Raumanomalien`,"insights.comfort.factor.anomalies.none":`Keine aktiven Anomalien`,"dehumidifier.title":`Luftentfeuchter`,"dehumidifier.add":`Luftentfeuchter hinzufügen`,"dehumidifier.configure":`Luftentfeuchter konfigurieren`,"dehumidifier.device":`Physisches Gerät`,"dehumidifier.device_hint":`Luftentfeuchter oder smarte Steckdose wählen. Das Gerät muss nach Stromrückkehr selbst starten.`,"dehumidifier.mode":`Gerätesteuerung`,"dehumidifier.auto":`Automatisch`,"dehumidifier.manual":`Manuell`,"dehumidifier.manual_hint":`RoomMind lässt manuell gestartete Geräte unverändert, auch beim Wäschetrocknen. Den Gerätenamen für Home-Assistant-Steuerungen öffnen.`,"dehumidifier.served_rooms":`Versorgte Räume`,"dehumidifier.host_included":`Der Aufstellraum ist immer enthalten.`,"dehumidifier.shared_hint":`Jeder Raum nutzt seinen Sensor. Fenster und Nachtzeit des Aufstellraums gelten; Pause bei 45%, Fortsetzung bei 50%, innerhalb der Gerätegrenzen.`,"dehumidifier.min_run_minutes":`Mindestlaufzeit`,"dehumidifier.min_off_minutes":`Mindestausschaltzeit`,"dehumidifier.power_watts":`Nennleistung`,"dehumidifier.power_hint":`Bei aktivem Leistungsbudget für neue Starts erforderlich.`,"dehumidifier.comfort":`Feuchtigkeitskomfort`,"dehumidifier.comfort_hint":`Ein Gerät aktiviert den Komfort nicht automatisch. Aktive Profile können den Zielwert ersetzen. Schimmelprävention folgt ihren bisherigen Einstellungen.`,"dehumidifier.target":`Zielfeuchtigkeit im Raum`,"dehumidifier.tolerance":`Feuchtigkeitstoleranz`,"dehumidifier.priority":`Feuchtigkeitspriorität`,"dehumidifier.priority_comfort":`Komfort`,"dehumidifier.priority_balanced":`Ausgewogen`,"dehumidifier.priority_energy":`Energiesparen`,"dehumidifier.empty":`Kein eigenes oder gemeinsames Gerät zugewiesen. Automatischer Klima-Trockenmodus bleibt verfügbar.`,"dehumidifier.host":`Aufstellraum`,"dehumidifier.requests":`Anforderungen aus`,"dehumidifier.device_target":`Gerätezielwert`,"dehumidifier.floor":`Feuchtigkeitsgrenze im Aufstellraum`,"dehumidifier.drying":`Entfeuchtet`,"dehumidifier.on":`Ein`,"dehumidifier.off":`Aus`,"dehumidifier.idle":`Ein, inaktiv`,"dehumidifier.request_mold":`Schimmelprävention angefordert`,"dehumidifier.request_comfort":`Feuchtigkeitskomfort angefordert`,"dehumidifier.reason_unavailable":`Gerät nicht verfügbar`,"dehumidifier.reason_manual":`Manuelle Steuerung`,"dehumidifier.reason_disabled":`Automatische Steuerung deaktiviert`,"dehumidifier.reason_sensor":`Feuchtigkeitsmessung im Aufstellraum fehlt`,"dehumidifier.reason_window":`Fenster im Aufstellraum offen`,"dehumidifier.reason_humidity_floor":`Feuchtigkeitsgrenze im Aufstellraum erreicht`,"dehumidifier.reason_min_off":`Mindestausschaltzeit abwarten`,"dehumidifier.reason_min_run":`Mindestlaufzeit abschließen`,"dehumidifier.reason_night":`Nachtruhe im Aufstellraum`,"dehumidifier.reason_power_budget":`Elektrische Kapazität oder Nennleistung fehlt`,"dehumidifier.reason_error":`Gerätebefehl fehlgeschlagen`,"dehumidifier.assigned":`Bearbeitet die Anforderung dieses Raums`,"dehumidifier.command_on":`Einschaltbefehl gesendet`,"dehumidifier.command_off":`Ausschaltbefehl gesendet`,"dehumidifier.intro":`Lege fest, wer das Gerät steuert, welche Räume es versorgt und welches Feuchteziel für diesen Raum gilt.`,"dehumidifier.how_it_works":`So funktioniert die Automatik`,"dehumidifier.guide_device":`Automatisch erlaubt RoomMind, das Gerät für Feuchtekomfort oder Schimmelprävention zu starten und zu stoppen. Die globale Klimasteuerung und die des Aufstellraums müssen aktiv sein. Manuell steuerst du selbst.`,"dehumidifier.guide_comfort":`Jeder Raum aktiviert Feuchtekomfort separat und hat sein eigenes Ziel. Schimmelprävention folgt auch bei deaktiviertem Komfort ihren Einstellungen. Aktive Profile können das Raumziel ersetzen.`,"dehumidifier.guide_shared":`Ausgewählte Räume dürfen das Gerät anhand ihrer Feuchte anfordern. Jeder versorgte Raum braucht einen Feuchtewert. Luft muss zwischen den Räumen zirkulieren; Fenster, Ruhezeiten und Feuchteschutz des Aufstellraums gelten für das gesamte Gerät.`,"dehumidifier.disabled_hint":`Aktiviere für automatische Starts die Klimasteuerung in den allgemeinen Einstellungen und im Aufstellraum {room}. Feuchtekomfort allein reicht nicht aus.`,"dehumidifier.auto_hint":`RoomMind steuert eigene Starts und unterstützte Feuchtesollwerte. Wenn Sie das Gerät einschalten, bleibt es unverändert, bis Sie es ausschalten.`,"dehumidifier.manual_option_hint":`Du steuerst das Gerät über Home Assistant.`,"dehumidifier.coverage_hint":`Registriere das Gerät im Aufstellraum. Ergänze weitere Räume nur, wenn Luft zwischen ihnen zirkulieren kann.`,"dehumidifier.host_room":`Aufstellraum · immer enthalten`,"dehumidifier.additional_rooms":`Weitere Räume`,"dehumidifier.shared_available":`Ein gemeinsames Gerät versorgt diesen Raum bereits`,"dehumidifier.shared_available_hint":`Du kannst unten den Komfort dieses Raums einstellen, ohne ein weiteres Gerät hinzuzufügen. Die Freigabe wird im Aufstellraum geändert.`,"dehumidifier.room_comfort":`Feuchte in diesem Raum`,"dehumidifier.tolerance_hint":`Toleranz und Priorität bestimmen, wie weit die Feuchte vor einer Anforderung über das Ziel steigen darf. Ein größerer Spielraum reduziert Starts. Die Anforderung endet nahe dem Ziel.`,"dehumidifier.priority_comfort_hint":`Frühere Anforderung`,"dehumidifier.priority_balanced_hint":`Normaler Feuchtespielraum`,"dehumidifier.priority_energy_hint":`Größerer Feuchteanstieg erlaubt`,"dehumidifier.protections":`Geräteschutz und Leistung`,"dehumidifier.timing_hint":`Mindestlauf- und Stillstandszeiten begrenzen häufiges Schalten. Die Stillstandszeit gilt auch nach einem Neustart. Schutzmaßnahmen können die Mindestlaufzeit unterbrechen.`,"dehumidifier.shared_device":`Gemeinsames Gerät · versorgte Räume`,"dehumidifier.local_device":`Eigenes Gerät · versorgter Raum`,"dehumidifier.device_details":`Geräteziel und Schutz`,"dehumidifier.device_target_hint":`Bei einem gemeinsamen Gerät folgt der Gerätesollwert dem Feuchteschutz des Aufstellraums. Er kann vom Komfortziel dieses Raums abweichen: Jeder Raum fordert anhand seines eigenen Ziels an.`,"dehumidifier.comfort_enabled":`Komfort aktiv`,"dehumidifier.comfort_disabled":`Komfort deaktiviert`,"dehumidifier.measured":`Gemessene Feuchte`,"dehumidifier.comfort_off_hint":`Dieser Raum fordert keine Entfeuchtung für Komfort an. Schimmelprävention folgt weiterhin ihren eigenen Einstellungen.`,"dehumidifier.status_pending":`Gerät registriert. Betriebsstatus wird abgerufen.`,"equipment.open":`Offen`,"equipment.closed":`Geschlossen`,"equipment.unavailable":`Nicht verfügbar`,"equipment.no_devices":`Noch keine Heiz- oder Kühlgeräte zugeordnet.`,"equipment.no_sensors":`Ordne Sensoren zu, um die Bedingungen in diesem Raum zu erfassen.`,"equipment.edit_devices":`Geräte verwalten`,"equipment.edit_sensors":`Sensoren verwalten`,"dehumidifier.waiting_hint":`Bereit: Das Gerät startet, wenn ein versorgter Raum Entfeuchtung anfordert und die Schutzbedingungen erfüllt sind.`,"settings.boiler.min_demand_rooms":`Anforderungen zum Start des Kessels`,"settings.boiler.min_demand_hint":`Darunter warten Heizkörper mit Wärmebedarf mit geschlossenen Ventilen. Läuft der Kessel, bleibt er an, solange Wärme angefordert wird.`,"settings.boiler.min_run_minutes":`Mindestlaufzeit (min)`,"settings.boiler.min_off_minutes":`Mindeststillstand (min)`,"settings.boiler.fault_retry_minutes":`Neuversuch nach Störung (min)`,"settings.boiler.child_lock":`Tasten des Bypass-Ventils sperren`,"settings.boiler.child_lock_hint":`Aktiviert die Kindersicherung, damit ein Tastendruck den Bypass nicht aus dem Zwangsheizbetrieb nimmt und den Kessel stoppt.`,"settings.boiler.max_wait_minutes":`Maximale Wartezeit unter dem Quorum (min)`,"settings.boiler.max_wait_hint":`Ein Raum, der so lange Wärme anfordert, startet den Kessel allein, damit reine Heizkörperräume nicht kalt bleiben. 0 hält das Quorum strikt.`,"comfort.profile.default":`Kein Profil (Zeitplan)`,"comfort.profile_clear_hint":`Tippe erneut auf das aktive Profil oder auf "Kein Profil", um zum Zeitplan zurückzukehren.`,"settings.boiler.demand_unit":`Anforderungen zählen nach`,"settings.boiler.demand_unit_valves":`Heizkörperventilen (ein Raum mit 2 Heizkörpern zählt 2)`,"settings.boiler.demand_unit_rooms":`Räumen`},fr:{"panel.title":`RoomMind`,"analytics.overview_title":`Comprendre le climat de votre maison`,"analytics.overview_hint":`Explorez les températures, l'énergie consommée et l'apprentissage de RoomMind.`,"settings.hub.eyebrow":`Espace de contrôle`,"settings.hub.title":`Paramètres simplifiés`,"settings.hub.description":`Choisissez ce que vous souhaitez régler. Les fonctions quotidiennes sont séparées du système et des outils avancés.`,"settings.hub.running":`Contrôle automatique actif`,"settings.hub.paused":`Contrôle automatique en pause`,"settings.hub.navigation":`Catégories de paramètres`,"settings.hub.category_label":`Catégorie`,"settings.hub.overview":`Quotidien`,"settings.hub.overview_hint":`Préférences, confort et présence`,"settings.hub.system":`Installation`,"settings.hub.system_hint":`Chaudière, climatisation et capteurs`,"settings.hub.protection":`Sécurité et alertes`,"settings.hub.protection_hint":`Moisissures et diagnostics`,"settings.hub.advanced":`Avancé`,"settings.hub.advanced_hint":`Apprentissage et entretien`,"settings.hub.heating":`Chaudière et budget électrique`,"settings.hub.heating_hint":`Bypass hydraulique, délais et limites de puissance.`,"room.nav.overview":`Climat et confort`,"room.nav.equipment":`Appareils et capteurs`,"room.nav.advanced":`Automatismes et analyses`,"room.nav.description":`Choisissez la rubrique à consulter ou modifier.`,"panel.overview":`Votre maison en un coup d'œil`,"panel.overview_hint":`Températures et équipements nécessitant votre attention.`,"panel.control_active":`Contrôle automatique actif`,"panel.control_paused":`Contrôle automatique en pause`,"panel.subtitle":`Gestion du climat`,"panel.tab.rooms":`Pièces`,"panel.edit":`Éditer la pièce`,"panel.tab.settings":`Réglages`,"panel.loading":`Chargement...`,"panel.no_areas":`Aucune pièce configurée dans Home Assistant.`,"panel.no_areas_hint":`Ajoutez des pièces dans les réglages HA pour commencer.`,"badge.beta":`Bêta`,"badge.beta_hint":`Cette fonctionnalité est en version bêta et est susceptible d'être modifiée ou restructurée lors de futures mises à jour.`,"common.learn_more":`En savoir plus`,"panel.stat.rooms":`Pièces`,"panel.stat.heating":`Chauffage`,"panel.stat.cooling":`Refroidissement`,"panel.stat.vacation":`Vacances`,"panel.stat.away":`Absent`,"panel.stat.mold":`Moisissure`,"panel.hide_room":`Masquer`,"panel.unhide":`Afficher`,"panel.hidden_rooms":`Pièces masquées`,"panel.floor_other":`Autre`,"panel.reorder":`Réorganiser les pièces`,"panel.reorder_done":`Terminé`,"room.back":`Retour aux pièces`,"room.section.climate_mode":`Mode climatique`,"room.section.schedule":`Planification et températures`,"room.section.control_mode":`Mode de contrôle`,"room.section.devices":`Appareils`,"room.section.sensors":`Capteurs`,"room.section.windows":`Capteurs de fenêtres`,"room.control_mode.full_control":`Contrôle total`,"room.control_mode.managed":`Mode géré`,"room.control_mode.external_sensor":`Capteur externe: {sensor}`,"room.control_mode.no_sensor":`Aucun capteur de température externe configuré`,"room.control_mode.mpc_active":`MPC actif`,"room.control_mode.mpc_learning":`Apprentissage`,"room.control_mode.device_setpoint":`Consigne de l'appareil: {temp}`,"room.control_mode.power":`Puissance: {power}%`,"room.control_mode.full_control_info":`RoomMind assure un contrôle total de vos appareils de climatisation. Un capteur de température externe mesure la température réelle de la pièce, ce qui permet de calculer la consigne de manière proportionnelle. La consigne de l'appareil est ajustée de manière dynamique en fonction de la puissance de sortie du MPC. Le modèle thermique (EKF) apprend le comportement de votre pièce afin d'optimiser le confort et l'efficacité énergétique.`,"room.control_mode.managed_info":`RoomMind définit la température cible sur votre appareil (à partir de la planification, des dérogations ou du mode vacances), mais l'appareil s'autorégule à l'aide de son propre capteur interne. Pas d'amplification proportionnelle, pas d'apprentissage de modèle thermique et pas d'optimisation MPC. Pour un contrôle plus précis, configurez un capteur de température externe dans la section Appareils.`,"room.delete":`Supprimer une pièce`,"room.deleting":`Suppression...`,"room.saving":`Enregistrement...`,"room.saved":`Enregistré`,"room.error_saving":`Erreur pendant l'enregistrement`,"room.confirm_delete":`Effacer la configuration RoomMind de "{name}"?`,"room.error_save_fallback":`Échec de l'enregistrement de la configuration`,"room.error_delete_fallback":`Échec de la suppression de la configuration`,"room.climate_control_toggle":`Contrôle climatique`,"room.climate_control_hint":`Si désactivé, RoomMind ne contrôle plus les appareils de cette pièce. Ils conservent leurs réglages actuels et peuvent continuer à chauffer ou refroidir d'eux-mêmes. RoomMind ne les éteint pas.`,"room.outdoor_toggle":`Zone extérieure`,"room.outdoor_hint":`Désactive le contrôle climatique, la détection de moisissures et l'entraînement du modèle. La surveillance des capteurs se poursuit.`,"room.alias.placeholder":`Nom d'affichage personnalisé`,"room.alias.clear":`Revenir au nom de la pièce`,"override.label":`Dérogation temporaire`,"override.comfort":`Confort`,"override.eco":`Éco`,"override.custom":`Personnalisé`,"override.target":`Cible:`,"override.heat_to":`Chauffer jusqu'à:`,"override.cool_above":`Refroidir au-dessus de:`,"override.invalid_band":`La cible de refroidissement doit être supérieure ou égale à la cible de chauffage`,"override.activate_for":`Activer pendant:`,"override.error_set":`Échec lors de la configuration de la dérogation`,"override.error_clear":`Échec lors de la suppression de la dérogation`,"hero.target":`Cible`,"hero.override":`Dérogation`,"hero.remaining":`{time} restant`,"hero.humidity":`{value}% humidité`,"hero.device_setpoint":`Appareil réglé sur {value}{unit}`,"hero.heat_source_primary":`Chauffage: vannes thermostatiques`,"hero.heat_source_secondary":`Chauffage: Climatisation`,"hero.heat_source_both":`Chauffage: Vannes thermostatiques + Climatisation`,"hero.permanent":`Permanent`,"hero.waiting":`En attente des données du capteur...`,"hero.not_configured":`Pas encore configuré`,"hero.mpc_learning_paused":`Apprentissage du MPC en pause`,"hero.temperature_sensor_unavailable":`Capteur de temperature indisponible ; controle climatique en pause`,"hero.mpc_learning_progress":`Apprentissage du modele thermique : confiance {confidence}%`,"hero.window_recovery":`Retour estime apres fermeture : {minutes} min`,"hero.mpc_learning_paused.outdoor_unavailable":`RoomMind a besoin d'une température extérieure pour apprendre le modèle thermique de cette pièce. Le capteur extérieur configuré n'est pas disponible et aucune entité météo n'est définie comme solution de secours. Configurez l'un ou l'autre dans les Paramètres.`,"hero.compressor_protection_min_off":`Protection du compresseur : attente du délai minimal d'arrêt`,"hero.compressor_protection_min_run":`Protection du compresseur : durée minimale de fonctionnement active`,"hero.compressor_protection_info":`Cette pièce partage une unité extérieure (compresseur) avec d'autres pièces. Pour éviter les cycles courts, le groupe de compresseurs impose une durée minimale de fonctionnement et un délai minimal d'arrêt avant que cet appareil ne puisse à nouveau changer d'état.`,"card.target":`Cible`,"card.waiting":`En attente de données...`,"card.humidity":`{value}% humidité`,"card.thermostat":`Thermostat`,"card.thermostats":`Thermostats`,"card.ac":`Climatisation`,"card.acs":`Climatisations`,"card.climate_device":`appareil de climatisation`,"card.climate_devices":`appareils de climatisation`,"card.temp_sensor":`capteur temp.`,"card.temp_sensors":`capteurs temp.`,"card.no_climate":`Aucun appareil de climatisation`,"card.outdoor":`Extérieur`,"card.tap_configure":`Appuyez pour configurer`,"card.mpc_active":`MPC actif`,"card.mpc_learning":`MPC en apprentissage`,"card.not_controlled":`Pas contrôlé par RoomMind`,"mode.auto":`Auto`,"mode.auto_desc":`Chauffe et refroidit automatiquement en fonction de la température cible`,"mode.heat_only":`Chauffer seulement`,"mode.heat_only_desc":`Utilise seulement les thermostats, la climatisation reste éteinte`,"mode.cool_only":`Refroidir seulement`,"mode.cool_only_desc":`Utilise seulement la climatisation, les thermostats restent éteints`,"mode.heating":`Chauffage`,"mode.cooling":`Refroidissement`,"mode.idle":`En veille`,"schedule.add_schedule":`Ajouter une planification`,"schedule.select_schedule":`Sélectionnez la planification`,"schedule.create_helper_hint":`Créer une nouvelle planification dans les réglages HA`,"schedule.selector_label":`Entité sélecteur de planification`,"schedule.selector_value_boolean":`Actuel: {value}`,"schedule.selector_value_number":`Valeur actuelle: {value}`,"schedule.selector_warning":`Plusieurs planifications définies mais aucun sélecteur défini. Seule la première planification sera utilisée.`,"schedule.off_action_label":`Action quand la planification est désactivée`,"schedule.off_action_eco":`Utiliser la température Éco`,"schedule.off_action_off":`Éteindre les appareils`,"schedule.state_active":`Actif`,"schedule.state_inactive":`Inactif`,"schedule.state_unreachable":`Inaccessible`,"schedule.no_schedules":`Aucune planification configurée`,"schedule.done":`Terminé`,"schedule.view_comfort":`Confort: {temp}{unit}`,"schedule.view_eco":`Éco: {temp}{unit}`,"schedule.view_selector":`Planification active sélectionnée par: {name}`,"schedule.view_selector_prefix":`Planification active sélectionnée par:`,"schedule.help_header":`Comment fonctionnent les planifications ?`,"schedule.help_temps_title":`Comment la température cible est-elle déterminée ?`,"schedule.help_temps":`La température cible suit cette chaîne de priorité:`,"schedule.help_temps_1":`<strong>Dérogation manuelle</strong> – Une dérogation confort/éco/personnalisée a toujours la priorité la plus élevée.`,"schedule.help_temps_2":`<strong>Température du bloc</strong> – Si le bloc de planification actif possède une valeur <code>temperature</code> dans ses données, cette valeur est utilisée.`,"schedule.help_temps_3":`<strong>Température de confort</strong> – Si la planification est "activée" mais que le bloc n'a pas de température, la température de secours de confort ci-dessous est utilisée.`,"schedule.help_temps_4":`<strong>Température éco</strong> – Lorsque la planification est "désactivée" (en dehors de tous les blocs temporels), la température éco est utilisée.`,"schedule.help_block_title":`Définir la température par bloc horaire`,"schedule.help_block":`Vous pouvez définir une température spécifique pour chaque bloc horaire en ajoutant une valeur <code>temperature</code> dans la configuration YAML de la planification:`,"schedule.help_block_note":`Si un bloc n'a pas de donnée <code>temperature</code>, la température de secours de confort est utilisée à la place.`,"schedule.help_split_title":`Cibles de chauffage/refroidissement différentes par bloc`,"schedule.help_split":`Pour les pièces en mode auto, vous pouvez définir des cibles de chauffage et de refroidissement différentes par bloc horaire en utilisant <code>heat_temperature</code> et <code>cool_temperature</code> :`,"schedule.help_split_note":`Si une seule est définie, l'autre revient à la température de confort de la pièce. Ces clés ont la priorité sur <code>temperature</code> quand elles sont présentes.`,"schedule.help_multi_title":`Planifications multiples`,"schedule.help_multi":`Vous pouvez ajouter plusieurs planifications et basculer entre elles à l'aide d'une <strong>entité sélecteur</strong>. Cela peut être un <code>input_boolean</code> (bascule entre les planifications 1 et 2) ou un <code>input_number</code> (sélection par numéro). Sans entité sélecteur, seule la première planification est utilisée.`,"schedule.column_comfort":`Confort`,"schedule.column_eco":`Éco`,"schedule.row_heat":`Chauffage`,"schedule.row_cool":`Refroidissement`,"schedule.view_heat":`Chauffage : {comfort} / {eco}{unit}`,"schedule.view_cool":`Refroidissement : {comfort} / {eco}{unit}`,"schedule.comfort_hint_auto":`Confort : cible lorsque la planification est activée. Éco : cible lorsque la planification est désactivée. Les lignes définissent la cible pour le chauffage et le refroidissement.`,"schedule.comfort_label":`Température de confort de secours`,"schedule.eco_label":`Température éco`,"schedule.comfort_hint":`Utilisée lorsque la planification est "activée" mais aucune température n'est définie dans le bloc`,"schedule.from_schedule":`{temp}{unit} provenant de la planification`,"schedule.from_schedule_split":`{heat}{unit} / {cool}{unit} provenant de la planification`,"schedule.fallback":`{temp}{unit} (secours)`,"schedule.eco_detail":`{temp}{unit} (éco)`,"devices.climate_entities":`Entités climatiques`,"devices.temp_sensors":`Capteurs de température`,"devices.humidity_sensors":`Capteurs d'humidité`,"devices.no_climate":`Aucune entité climatique trouvée dans cette pièce.`,"devices.no_temp_sensors":`Aucun capteur de température trouvé dans cette pièce.`,"devices.no_humidity_sensors":`Aucun capteur d'humidité trouvé dans cette pièce.`,"devices.occupancy_sensors":`Capteurs de présence`,"devices.no_occupancy_sensors":`Aucun capteur de présence trouvé dans cette pièce`,"devices.occupancy_sensor_hint":`Améliore la précision du modèle thermique en suivant l'occupation de la pièce`,"devices.window_sensors":`Capteurs de fenêtre/porte`,"devices.no_window_sensors":`Aucun capteur de fenêtre/porte trouvé dans cette pièce.`,"devices.window_open_delay":`Délai avant la pause`,"devices.window_close_delay":`Délai avant la reprise`,"devices.wall_factor":`Facteur de paroi (f_Rsi)`,"devices.wall_factor_hint":`Indique à quel point le point le plus froid du mur est froid : sert à estimer l'humidité là où la moisissure se forme. Plus bas = mur plus froid = risque plus élevé.`,"devices.wall_preset":`Type de mur`,"devices.wall_preset_plain":`Mur standard`,"devices.wall_preset_corner":`Angle / mur nord`,"devices.wall_preset_bridge":`Coffre de volet, poutre ou pilier`,"devices.wall_preset_measured":`Mesuré`,"devices.wall_measure_hint":`Calibrez par une mesure : par temps froid, mesurez la zone moisie avec un thermomètre infrarouge (mode surface).`,"devices.wall_measure_surface":`Mur`,"devices.wall_measure_room":`Pièce`,"devices.wall_measure_outdoor":`Extérieur`,"devices.wall_measure_apply":`Utiliser f = {value}`,"devices.wall_measure_invalid":`Mesure inutilisable : il faut au moins 5 °C d'écart entre pièce et extérieur et un résultat entre 0,50 et 0,95.`,"devices.add_entity":`Ajouter une entité`,"devices.done":`Terminé`,"devices.other_area":`Autre pièce`,"devices.type_thermostat":`Thermostat`,"devices.type_ac":`Appareil climatique`,"devices.type_label":`Type`,"devices.select_to_configure":`Sélectionnez un appareil à configurer`,"devices.heating_system_type":`Type de système de chauffage`,"devices.heating_system_type_info":`Après l'arrêt du chauffage, les radiateurs et surtout les systèmes de chauffage au sol continuent de libérer la chaleur stockée. RoomMind tient compte de cette chaleur résiduelle pour éviter le dépassement et améliorer la précision du modèle. Les pièces avec chauffage au sol bénéficient également de temps de marche minimum plus longs.`,"devices.system_type_none":`Standard (pas de chaleur résiduelle)`,"devices.system_type_radiator":`Radiateur`,"devices.system_type_underfloor":`Chauffage au sol`,"devices.underfloor_delay_hint":`Le chauffage au sol a des temps de redémarrage longs. Un délai d'ouverture de fenêtre d'au moins 5 minutes est recommandé pour éviter des arrêts inutiles.`,"devices.heating_system_type_boost_hint":`Astuce : Si le système de chauffage a changé, vous pouvez accélérer le réapprentissage dans les Paramètres.`,"devices.idle_action":`Lorsque inactif`,"devices.idle_action_off":`Éteindre`,"devices.idle_action_fan_only":`Ventilateur uniquement`,"devices.idle_action_setback":`Décalage`,"devices.idle_action_low":`Consigne basse (maintenir actif)`,"devices.idle_action_low_hint":`Abaisse la consigne au minimum de l'appareil au lieu de l'éteindre. Empêche les TRV qui hibernent en mode off de perdre les commandes ultérieures.`,"devices.idle_fan_mode":`Vitesse du ventilateur`,"devices.idle_fan_mode_keep":`Ne pas changer`,"devices.fan_only_conditions":`Conditions de ventilation seule`,"devices.fan_only_only_after_cooling":`Uniquement après le refroidissement`,"devices.fan_only_require_presence":`Uniquement lorsque les personnes suivies sont présentes`,"devices.fan_only_require_schedule":`Uniquement pendant un planning actif`,"devices.fan_only_seasons":`Saisons autorisées`,"devices.fan_only_season_spring":`Printemps`,"devices.fan_only_season_summer":`Été`,"devices.fan_only_season_autumn":`Automne`,"devices.fan_only_season_winter":`Hiver`,"devices.fan_only_season_hint":`Les filtres saisonniers nécessitent l’intégration Season de Home Assistant, qui fournit sensor.season. Si elle est indisponible, la ventilation seule reste arrêtée.`,"devices.setpoint_mode":`Mode de consigne`,"devices.setpoint_mode_proportional":`Proportionnel (contrôle de vanne)`,"devices.setpoint_mode_direct":`Direct (l'appareil régule)`,"devices.setpoint_mode_hint":`Direct envoie la cible réelle de la pièce à l'appareil — idéal pour les thermostats et les chauffages d'appoint qui se régulent eux-mêmes. Proportionnel envoie une consigne renforcée vers la température maximale de l'appareil — idéal pour les vannes de radiateur (TRV).`,"devices.valve_protection_excluded":`Exclu de la protection des vannes`,"devices.valve_protection_exclude_hint":`Cette entité ne sera pas cyclée par la protection des vannes (ex. entités chaudière virtuelles)`,"devices.info.types_title":`Types d'appareil`,"devices.info.types_body":`Thermostat désigne un thermostat de radiateur / TRV. Appareil climatique désigne un climatiseur, une pompe à chaleur ou autre entité climatique utilisée pour le refroidissement ou le chauffage à air pulsé. Les deux sont des entités climatiques dans Home Assistant; la différence réside dans la façon dont RoomMind les contrôle.`,"devices.info.control_title":`Comment RoomMind les contrôle`,"devices.info.control_body":`Le mode de consigne ne s'applique qu'aux thermostats dans les pièces en Contrôle total disposant d'un capteur de température externe. Utilisez Proportionnel lorsque RoomMind doit piloter le chauffage en envoyant des consignes renforcées. Utilisez Direct lorsque l'appareil doit se réguler autour de la vraie température cible.`,"devices.info.modes_title":`Comportement en inactivité`,"devices.info.modes_body":`Lorsque inactif ne s'applique qu'aux appareils climatiques. Éteindre met l'appareil hors tension. Ventilateur uniquement maintient le débit d'air sans chauffage ni refroidissement. Décalage garde le mode actuel actif mais décale la cible de 2°C par rapport à la cible de la pièce. Ce décalage de réduction est actuellement fixe. Pour les thermostats, Consigne basse garde le TRV actif à sa consigne minimale au lieu de l'éteindre, utile pour les TRV Zigbee à batterie qui se mettent en veille lorsqu'ils sont à off.`,"devices.info.heat_source_title":`Sélection intelligente de source`,"devices.info.heat_source_body":`Cela apparaît uniquement lorsqu'une pièce possède à la fois un thermostat/TRV et un appareil climatique ainsi qu'un capteur de température externe. RoomMind peut alors choisir la source qui gérera le chauffage en fonction de l'écart de température et des conditions extérieures.`,"hero.window_open":`Fenêtre ouverte - en pause`,"card.window_open":`Fenêtre ouverte`,"room.section.covers":`Rideaux & stores`,"covers.section_title":`Rideaux & stores`,"covers.auto_control":`Contrôle automatique des stores`,"covers.auto_control_hint":`RoomMind ferme les stores lorsque le gain solaire risque de surchauffer la pièce.`,"covers.deploy_threshold":`Seuil de déploiement`,"covers.deploy_threshold_hint":`Ferme les stores lorsque la température prévue dépasse la cible de cette quantité.`,"covers.min_position":`Position d'ouverture minimale`,"covers.min_position_hint":`Les stores ne se fermeront jamais plus que cela (0 = fermeture totale autorisée).`,"covers.override_minutes":`Durée de pause de la dérogation`,"covers.override_minutes_hint":`Durée pendant laquelle le contrôle automatique est mis en pause après un mouvement manuel du store. Mettre 0 pour aucune pause.`,"covers.no_covers":`Aucune entité de store configurée.`,"covers.no_covers_in_area":`Aucune entité de store trouvée dans cette pièce.`,"covers.add_cover":`Ajouter une entité de store...`,"covers.shading_active":`Ombrage activé`,"covers.auto_paused":`Pause auto (dérogation manuelle)`,"covers.auto_paused_until":`Contrôle automatique en pause jusqu'à`,"covers.resume_auto":`Reprendre le contrôle automatique`,"covers.done":`Terminé`,"covers.night_close":`Fermer la nuit`,"covers.night_close_hint":`Ferme automatiquement les stores au coucher du soleil et les ouvre au lever du soleil.`,"covers.night_close_active":`Fermeture nocturne active`,"covers.schedule_group_title":`Planification`,"covers.solar_group_title":`Contrôle solaire`,"covers.schedule_section":`Planification des stores`,"covers.schedule_section_hint":`Définissez des créneaux horaires pour le contrôle des stores à l'aide des assistants de planification HA. En mode Forcer la position, la position de la planification l'emporte sur la logique solaire/thermique. En mode Autoriser la protection solaire, RoomMind décide de la position dans la fenêtre active.`,"covers.add_schedule":`Ajouter un horaire de store...`,"covers.schedule_mode_force":`Forcer la position`,"covers.schedule_mode_gate":`Autoriser la protection solaire`,"covers.schedule_mode_gate_short":`Portail solaire`,"covers.schedule_position":`Position`,"covers.schedule_position_hint":`Position du store lorsque cette planification est active (0% = entièrement fermé, 100% = entièrement ouvert).`,"covers.schedule_selector":`Entité sélecteur de planification`,"covers.schedule_selector_hint":`Choisissez quelle planification est active. input_boolean: off=#1, on=#2. input_number: la valeur sélectionne le numéro de planification.`,"covers.schedule_selector_warning":`Plusieurs planifications configurées mais aucun sélecteur défini. Seule la première planification sera utilisée.`,"covers.schedule_state_active":`Actif`,"covers.schedule_state_inactive":`Inactif`,"covers.schedule_state_unreachable":`Inaccessible`,"covers.schedule_active":`Horaire actif`,"covers.schedule_create_link":`Créer un assistant de planification`,"covers.night_position":`Position nocturne`,"covers.night_position_hint":`Position du store lorsque la fermeture nocturne est active (0% = entièrement fermé). Les stores avec une position minimale individuelle ne descendront jamais en dessous.`,"covers.night_close_advanced":`Avancé`,"covers.night_close_elevation":`Seuil de position du soleil`,"covers.night_close_elevation_hint":`À quelle distance sous ou au-dessus de l'horizon le soleil doit être. 0° = exactement au coucher/lever du soleil. Négatif = plus sombre (ex. -6° = crépuscule, lorsqu'il fait clairement sombre). Positif = encore lumineux (ex. 5° = le soleil encore visible au-dessus de l'horizon).`,"covers.night_close_offset":`Décalage horaire`,"covers.night_close_offset_hint":`Décalage supplémentaire par rapport au seuil de position du soleil. Positif = fermeture plus tard (ex. +20 = 20 min après le seuil), négatif = fermeture plus tôt.`,"covers.outdoor_min_temp":`Température extérieure min.`,"covers.outdoor_min_temp_hint":`Ne pas fermer les stores pour protéger du soleil en dessous de cette température extérieure. Le gain de chaleur solaire est bienvenu quand il fait froid.`,"covers.per_cover_title":`Paramètres par store`,"covers.per_cover_hint":`Définissez la direction cardinale de chaque store et les positions minimales individuelles éventuelles.`,"covers.per_cover_min_short":`Min`,"covers.per_cover_min_position":`Position min.`,"covers.per_cover_min_position_hint":`Position minimale individuelle par store. Les stores ne se fermeront jamais plus que cela. Utile lorsque les stores sont physiquement complètement fermés à une position > 0%.`,"covers.snap_deploy":`Forcer à la position minimale`,"covers.snap_deploy_hint":`Fermer les stores directement à la position minimale au lieu de les fermer progressivement. Recommandé pour les fenêtres à triple vitrage où les positions intermédiaires peuvent causer du stress thermique.`,"covers.info.selection_title":`Sélection de stores`,"covers.info.selection_body":`Sélectionnez les rideaux/stores de cette zone ou ajoutez des entités d'autres zones. RoomMind suit leur position et peut les contrôler automatiquement.`,"covers.info.schedule_title":`Contrôle via planification`,"covers.info.schedule_body":`Utilisez les assistants de planification HA pour définir les moments où les stores doivent se fermer (ex. intimité le soir). L'attribut de position de l'horaire détermine le degré de fermeture. Les planifications remplacent toute autre logique automatique.`,"covers.info.solar_title":`Contrôle solaire/thermique`,"covers.info.solar_body":`Lorsque le contrôle automatique est activé, RoomMind prédit si le rayonnement solaire surchaufferait la pièce et ferme les stores de manière préventive. Il utilise les données thermiques apprises lorsqu'elles sont disponibles, sinon une valeur par défaut prudente. Le seuil de déploiement détermine le dépassement prédit nécessaire avant de fermer les stores.`,"covers.info.night_title":`Fermeture nocturne`,"covers.info.night_body":`Ferme les stores au coucher du soleil et les ouvre au lever du soleil. Vous pouvez définir une position nocturne personnalisée (ex. 10% = presque fermé mais pas totalement).`,"covers.info.override_title":`Dérogation manuelle`,"covers.info.override_body":`Si vous déplacez manuellement un store, RoomMind le détecte et met le contrôle automatique en pause pendant la durée configurée. Cela évite les conflits avec l'utilisateur.`,"covers.info.priority_title":`Ordre de priorité`,"covers.info.priority_body":`Dérogation manuelle > Planification > Fermeture nocturne > Contrôle solaire/thermique. Les règles de priorité supérieure l'emportent toujours. Lorsqu'aucune règle ne s'applique, les stores restent ouverts.`,"covers.info.entities_title":`Entités HA`,"covers.info.entities_body":`RoomMind crée deux entités par pièce pour une utilisation externe: switch.roommind_{area}_cover_auto (activer/désactiver le contrôle automatique des stores — utilisable dans les automatisations ou tableaux de bord) et binary_sensor.roommind_{area}_cover_paused (activé lorsque la dérogation manuelle est en cours, ex. après un déplacement manuel d'un store).`,"covers.orientation_group_title":`Orientation du store`,"covers.orientation_hint":`Définissez la direction cardinale vers laquelle chaque store fait face. RoomMind utilise cela pour ignorer le déploiement solaire lorsque le soleil n'éclaire pas ce côté du bâtiment.`,"covers.orientation_none":`Pas de direction`,"covers.orientation_N":`N`,"covers.orientation_NE":`NE`,"covers.orientation_E":`E`,"covers.orientation_SE":`SE`,"covers.orientation_S":`S`,"covers.orientation_SW":`SO`,"covers.orientation_W":`O`,"covers.orientation_NW":`NO`,"covers.orientation_N_full":`Nord`,"covers.orientation_NE_full":`Nord-Est`,"covers.orientation_E_full":`Est`,"covers.orientation_SE_full":`Sud-Est`,"covers.orientation_S_full":`Sud`,"covers.orientation_SW_full":`Sud-Ouest`,"covers.orientation_W_full":`Ouest`,"covers.orientation_NW_full":`Nord-Ouest`,"settings.general_title":`Général`,"settings.group_by_floor":`Regrouper les pièces par étage`,"settings.climate_control_active":`Contrôle climatique actif`,"settings.climate_control_hint":`Lorsqu'il est désactivé, RoomMind continue de surveiller tous les capteurs et d'entraîner le modèle, mais n'envoie aucune commande à vos appareils de chauffage ou de refroidissement. Vos appareils conservent leur mode et leur consigne actuels et peuvent continuer à chauffer ou refroidir d'eux-mêmes. RoomMind ne les éteint pas.`,"settings.learning_title":`Entraînement du modèle`,"settings.learning_hint":`Lorsqu'il est en pause, RoomMind cesse de collecter de nouvelles mesures et d'entraîner le modèle thermique. Les données du modèle existant sont conservées.`,"settings.learning_exceptions":`Exceptions`,"settings.learning_room_paused":`pièce en pause`,"settings.learning_rooms_paused":`pièces en pause`,"settings.sensors_title":`Capteurs & sources de données`,"settings.control_title":`Contrôle`,"settings.outdoor_sensor":`Température extérieure`,"settings.outdoor_sensor_label":`Capteur de température extérieure`,"settings.outdoor_current":`Actuellement {temp}{unit} dehors`,"settings.outdoor_waiting":`En attente des données du capteur...`,"settings.outdoor_humidity_sensor":`Humidité extérieure`,"settings.outdoor_humidity_label":`Capteur d'humidité extérieure`,"settings.outdoor_humidity_current":`Actuellement {value}% dehors`,"settings.smart_control":`Contrôle climatique intelligent`,"settings.smart_control_hint":`Configurez les limites de température extérieure pour le chauffage et le refroidissement.`,"settings.outdoor_cooling_min":`Température extérieure minimale pour le refroidissement`,"settings.outdoor_cooling_min_hint":`Le climatiseur reste éteint lorsque la température extérieure est inférieure à cette valeur`,"settings.outdoor_heating_max":`Température extérieure maximale pour le chauffage`,"settings.outdoor_heating_max_hint":`Le chauffage reste éteint lorsque la température extérieure dépasse cette valeur`,"settings.saving":`Enregistrement...`,"settings.saved":`Enregistré`,"settings.error":`Erreur lors de l'enregistrement`,"devices.using_builtin_sensor":`Utilisation du capteur intégré du thermostat`,"settings.climate_intelligence":`Intelligence climatique`,"settings.control_mode":`Mode de contrôle`,"settings.control_mode_simple":`Simple (Bang-Bang)`,"settings.control_mode_mpc":`Intelligent (MPC)`,"settings.control_mode_hint":`Le MPC apprend le comportement thermique de votre pièce pour un contrôle optimal`,"settings.comfort_weight":`Priorité`,"settings.comfort_weight_comfort":`Confort`,"settings.comfort_weight_efficiency":`Efficacité`,"settings.comfort_weight_hint":`Équilibre la précision de la température avec la consommation d'énergie. Le confort réagit plus tôt et reste plus proche de la cible. L'efficacité permet plus de dérive pour réduire la durée de chauffage/refroidissement.`,"settings.weather_entity":`Prévision météo`,"settings.weather_entity_hint":`Optionnel : active la planification prédictive de la température extérieure et sert de secours lorsque le capteur extérieur est indisponible`,"settings.outdoor_unavailable_notify":`Notifier lorsque la température extérieure est indisponible`,"settings.outdoor_unavailable_notify_hint":`Afficher une notification Home Assistant lorsqu'aucun des capteurs extérieurs ni l'entité météo n'a signalé de température pendant 30 minutes. Pendant ce temps, RoomMind met en pause l'apprentissage du modèle thermique pour éviter la corruption.`,"settings.prediction_enabled":`Prédiction de température`,"settings.prediction_enabled_hint":`Afficher la tendance de température prédite dans les graphiques d'analyse. A désactiver si vous constatez de mauvaises performances.`,"vacation.title":`Mode vacances`,"vacation.hint":`Règle toutes les pièces sur une température réduite jusqu'à la date de fin.`,"vacation.active_label":`Mode vacances actif`,"vacation.end_date":`Date et heure de fin`,"vacation.setback_temp":`Température de réduction`,"vacation.no_end_date":`Pas de date de fin`,"vacation.deactivate":`Désactiver`,"tabs.analytics":`Analyses`,"analytics.select_room":`Sélectionner une pièce`,"analytics.temperature":`Température`,"analytics.target":`Cible`,"analytics.prediction":`Prédiction`,"analytics.outdoor":`Extérieur`,"analytics.model_status":`Statut du modèle`,"analytics.confidence":`Confiance`,"analytics.heating_rate":`Puissance de chauffage`,"analytics.cooling_rate":`Puissance de refroidissement`,"analytics.solar_gain":`Gain solaire`,"analytics.occupancy_gain":`Gain d'occupation`,"analytics.time_constant":`Constante de temps`,"analytics.samples":`Échantillons`,"analytics.prediction_accuracy":`Précision de la prédiction`,"analytics.avg_deviation":`Écart moyen`,"analytics.data_sources":`Sources de données`,"analytics.data_points":`Points de données`,"analytics.control_mode":`Mode de contrôle`,"analytics.control_mode_mpc":`MPC actif`,"analytics.control_mode_bangbang":`MPC en apprentissage`,"analytics.last_model_update":`Dernière mise à jour du modèle`,"analytics.accuracy_idle":`Précision (Inactif)`,"analytics.accuracy_heating":`Précision (Chauffage)`,"analytics.info.accuracy_idle":`À quel point le modèle prédit précisément la température lorsqu'aucun chauffage ni refroidissement n'est actif. Une valeur plus basse signifie que le modèle comprend bien la perte de chaleur naturelle de votre pièce. C'est la première valeur qui s'améliore car les données au repos sont collectées en continu.`,"analytics.info.accuracy_heating":`À quel point le modèle prédit précisément la température pendant que le chauffage est actif. Cette valeur reste élevée au début car le modèle a besoin de véritables cycles de chauffage pour apprendre. Une fois que votre chauffage a fonctionné plusieurs fois, cette valeur diminuera et le contrôle MPC deviendra disponible.`,"analytics.info.confidence":`Niveau global de préparation du modèle pour le contrôle MPC intelligent, combinant deux facteurs : la quantité de données (nombre d'échantillons en mode repos et actif) et la précision des prédictions (précision des prévisions de température). La confiance démarre à 0% et augmente à mesure que le modèle collecte des données et apprend. Environ 50% signifie qu'il y a suffisamment de données au repos mais qu'on attend encore des cycles de chauffage/refroidissement. Au-delà de 80% le modèle dispose de suffisamment de données et de prédictions précises — le contrôle MPC devient disponible. 100% est le maximum théorique lorsque les prédictions sont aussi précises que physiquement possible.`,"analytics.info.time_constant":`Durée nécessaire à votre pièce pour se refroidir naturellement jusqu'à la moitié de la différence avec la température extérieure lorsque le chauffage est éteint. Un temps constant plus long indique une meilleure isolation — la pièce conserve la chaleur plus longtemps. Un temps constant court signifie que la pièce se refroidit rapidement. Le modèle apprend cela en observant les baisses de température pendant les périodes d'inactivité.`,"analytics.info.heating_rate":`Intensité de l'effet de votre chauffage sur la température de la pièce. Une valeur plus élevée signifie que votre système de chauffage réchauffe la pièce plus rapidement par rapport à sa masse thermique. Le modèle apprend cela en observant la vitesse à laquelle la température augmente pendant que le chauffage est actif, et l'utilise pour prévoir la durée nécessaire du chauffage.`,"analytics.info.cooling_rate":`Intensité de l'effet de votre climatiseur sur la température de la pièce. Une valeur plus élevée signifie que le climatiseur refroidit la pièce plus rapidement par rapport à sa masse thermique. Le modèle apprend cela en observant la vitesse à laquelle la température baisse pendant le refroidissement actif, et l'utilise pour prévoir la durée nécessaire du fonctionnement du climatiseur.`,"analytics.info.solar_gain":`Effet estimé du rayonnement solaire à travers les fenêtres sur la température de la pièce. Le modèle apprend cela en observant comment la pièce se réchauffe pendant les périodes ensoleillées lorsque le chauffage est éteint. Les pièces avec de grandes fenêtres orientées sud auront des valeurs plus élevées. Le modèle utilise cela pour réduire le chauffage lorsqu'un gain solaire est attendu.`,"analytics.info.occupancy_gain":`Contribution thermique estimée due à l'occupation (personnes, animaux, ordinateurs) lorsque la pièce est occupée. Le modèle apprend cela en observant les variations de température lorsque les capteurs d'occupation configurés sont actifs. Séparer cela du gain solaire évite que la chaleur corporelle ne soit attribuée à tort à la lumière du soleil. Affiché uniquement lorsqu'au moins un capteur d'occupation est configuré pour cette pièce.`,"analytics.info.data_sources":`Nombre d'échantillons de mesure utilisés pour l'entraînement du modèle.`,"analytics.info.data_points":`Nombre total d'observations sur lesquelles le modèle a été entraîné. Plus de points de données conduisent généralement à de meilleures prédictions. Le modèle collecte un nouveau point de donnée environ toutes les 3 minutes tant que RoomMind fonctionne.`,"analytics.no_data":`Aucune donnée pour le moment — le modèle apprend`,"analytics.loading":`Chargement des analyses...`,"settings.reset_title":`Réinitialiser les données thermiques`,"settings.reset_hint":`Effacer les données thermiques du modèle et l'historique. Le modèle recommencera à apprendre à partir de zéro.`,"settings.reset_all_label":`Toutes les pièces`,"settings.reset_all_hint":`Effacer les données thermiques et l'historique de toutes les pièces en une fois.`,"settings.reset_all_btn":`Tout réinitialiser`,"settings.reset_all_confirm":`Effacer toutes les données thermiques et l'historique pour TOUTES les pièces ? Tous les modèles recommenceront à apprendre à partir de zéro.`,"settings.reset_room_label":`Pièce individuelle`,"settings.reset_room_hint":`Sélectionnez une pièce pour effacer ses données thermiques et son historique.`,"settings.reset_room_confirm":`Effacer toutes les données thermiques apprises et l'historique pour cette pièce ? Le modèle recommencera à apprendre à partir de zéro.`,"settings.reset_room_select":`Sélectionner une pièce`,"settings.reset_btn":`Réinitialiser`,"settings.reset_no_rooms":`Aucune pièce configurée.`,"settings.boost_title":`Accélérer l'apprentissage`,"settings.boost_hint":`Le modèle thermique apprend le comportement de chauffage et de refroidissement de votre pièce au fil du temps. Après des changements majeurs (nouveau radiateur, climatiseur, isolation, mobilier), le modèle peut être imprécis. Cela augmente l'incertitude du modèle afin qu'il s'adapte plus rapidement aux nouvelles conditions.`,"settings.boost_label":`Accélérer l'apprentissage`,"settings.boost_room_select":`Sélectionner une pièce`,"settings.boost_btn":`Accélérer`,"settings.boost_cooldown":`Actif - réapprentissage en cours`,"settings.boost_no_rooms":`Aucune pièce configurée.`,"analytics.range_1d":`Aujourd'hui`,"analytics.range_2d":`2 jours`,"analytics.range_7d":`Semaine`,"analytics.range_30d":`Mois`,"analytics.export":`Mesures`,"analytics.heating_period":`Chauffage`,"analytics.cooling_period":`Refroidissement`,"analytics.blind_position":`Position du store`,"analytics.window_open_period":`Fenêtre ouverte`,"analytics.chart_info_title":`Comment lire ce graphique`,"analytics.exported":`Exporté !`,"analytics.copy_diagnostics":`Diagnostics`,"analytics.export_download":`Télécharger le fichier`,"analytics.export_clipboard":`Copier dans le presse-papiers`,"analytics.copied_to_clipboard":`Copié !`,"analytics.range_from":`De`,"analytics.range_to":`À`,"analytics.chart_info_body":`**Lignes:** La ligne orange solide montre la température mesurée de la pièce. La ligne verte en pointillé représente la température cible de votre planning. La ligne bleue pointillée est la prédiction de température du modèle.

**Zones colorées:** Le rouge indique les périodes de chauffage, le bleu les périodes de refroidissement, et le turquoise les moments où une fenêtre était ouverte.

**Prévision future (à droite de la ligne « now »)** : La ligne verte en pointillé montre les objectifs de planning à venir pour les 3 prochaines heures. La ligne bleue pointillée montre la tendance de température prévue.

**Modes de prédiction :** Lorsque « MPC actif » est affiché, la prédiction utilise l'optimiseur complet MPC avec pré-chauffage/pré-refroidissement intelligent. Tant que le modèle apprend encore, une simulation plus simple est utilisée.

**Limites :** La prédiction suppose que les conditions actuelles restent constantes (température extérieure, état des fenêtres). La précision de la simulation dépend de la qualité d'apprentissage du modèle thermique de votre pièce — au début, les prédictions peuvent être moins précises. Une fois le MPC activé, les prédictions deviennent nettement plus fiables.`,"presence.title":`Détection de présence`,"presence.hint":`Utilise la température éco lorsque personne n'est présent.`,"presence.hint_detail":`Lorsque activé, toutes les pièces passent à la température éco dès qu'aucune des personnes configurées n'est à la maison. Vous pouvez éventuellement restreindre, par pièce, quelles personnes sont prises en compte.`,"presence.add_person":`Ajouter une personne`,"presence.add_entity":`Ajouter une entité de présence`,"presence.person_label":`Personne`,"room.section.presence":`Présence`,"presence.room_help_header":`Comment fonctionne la présence par pièce ?`,"presence.room_help_body":`Sélectionnez les personnes pertinentes pour cette pièce. La pièce passe à la température éco lorsqu'aucune des personnes sélectionnées n'est à la maison. Sans sélection, la règle globale s'applique : éco lorsqu'aucun occupant n'est présent.`,"presence.state_home":`À la maison`,"presence.state_away":`Absent`,"presence.room_none_assigned":`Règle globale — éco lorsqu'aucun occupant n'est présent`,"presence.missing_entity_hint":`Cette entité n'existe plus dans Home Assistant — décochez-la pour la retirer de cette pièce.`,"presence.ignore_toggle":`Ignorer la présence`,"presence.ignore_hint":`Contrôle la façon dont cette pièce réagit à la présence. Vous pouvez attribuer des personnes spécifiques ci-dessous. La pièce passe à l'éco lorsqu'aucune des personnes assignées n'est à la maison. Utilisez le commutateur ci-dessus pour ignorer totalement la détection et suivre toujours le planning.`,"presence.help_ignore_title":`Que fait « Ignorer la présence » ?`,"presence.help_ignore_body":`Lorsqu'elle est activée, cette pièce ignore complètement la détection de présence. Elle suit toujours son planning et ne passe jamais en mode éco en fonction de la présence. Utile pour les pièces qui doivent maintenir la température quel que soit l'occupant, comme une salle serveur, un espace pour animaux ou une chambre d'ami non suivie par Home Assistant.`,"presence.tile_ignored":`Détection de présence ignorée. La pièce suit toujours son planning.`,"presence.away_action_label":`Action lorsque personne n'est à la maison`,"presence.away_action_eco":`Utiliser la température éco`,"presence.away_action_off":`Éteindre les appareils`,"presence.clears_override_label":`L'absence annule la dérogation`,"presence.clears_override_hint":`Lorsque personne n'est à la maison, les dérogations manuelles sont suspendues et la pièce suit l'action d'absence. Quand quelqu'un revient, la dérogation reprend jusqu'à son expiration.`,"card.presence_away":`Absent`,"valve_protection.title":`Protection des vannes`,"valve_protection.hint":`Ouvre périodiquement et brièvement les vannes TRV inactives pour éviter le blocage ou la calcification.`,"valve_protection.interval_label":`Intervalle du cycle`,"valve_protection.interval_suffix":`jours`,"valve_protection.interval_hint":`Durée pendant laquelle une valve peut rester inactive avant d'être cyclée (1-90 jours)`,"compressor.title":`Protection du compresseur`,"compressor.no_groups":`Aucun groupe de compresseurs configuré.`,"compressor.add_group":`Ajouter un groupe de compresseur`,"compressor.group_name":`Nom du groupe`,"compressor.members":`Unités intérieures`,"compressor.members_hint":`Sélectionnez tous les appareils climatiques alimentés par ce compresseur (unités intérieures, TRV sur radiateurs, ventilo-convecteurs).`,"compressor.min_run":`Durée minimale de fonctionnement`,"compressor.min_run_hint":`Le compresseur doit fonctionner au moins aussi longtemps une fois démarré.`,"compressor.min_run_suffix":`min`,"compressor.min_off":`Durée minimale d'arrêt`,"compressor.min_off_hint":`Le compresseur doit rester arrêté au moins aussi longtemps après l'arrêt.`,"compressor.min_off_suffix":`min`,"compressor.delete":`Supprimer le groupe`,"compressor.delete_confirm":`Supprimer le groupe de compresseur "{name}" ?`,"compressor.master_entity":`Appareil maître`,"compressor.master_entity_hint":`L'unité centrale qui alimente les appareils intérieurs de ce groupe, par ex. une chaudière à gaz, une unité extérieure de pompe à chaleur ou l'interrupteur maître d'un système de climatisation gainé. RoomMind l'allumera dès qu'une pièce a besoin de chauffage ou de refroidissement, et l'éteindra lorsque toutes les pièces sont au repos. Laisser vide pour n'utiliser que le script d'action ou la protection contre les courts cycles.`,"compressor.conflict_resolution":`Résolution des conflits`,"compressor.conflict_resolution_hint":`Détermine ce qui se passe lorsque certaines pièces ont besoin de chauffage tandis que d'autres ont besoin de refroidissement simultanément. Priorité chauffage : le chauffage l'emporte toujours (le plus sûr pour la protection contre le gel). Priorité refroidissement : le refroidissement l'emporte toujours. Majorité : le mode avec le plus de pièces l'emporte, les égalités vont au chauffage. Température extérieure : utilise le seuil maximal de chauffage extérieur des paramètres pour décider automatiquement.`,"compressor.conflict_heating_priority":`Priorité chauffage (protection contre le gel)`,"compressor.conflict_cooling_priority":`Priorité refroidissement`,"compressor.conflict_majority":`Majorité l'emporte`,"compressor.conflict_outdoor_temp":`Selon la température extérieure`,"compressor.action_script":`Script d'action`,"compressor.action_script_hint":`Un script Home Assistant qui s'exécute chaque fois que la demande de chauffage/refroidissement change. Utile pour les systèmes nécessitant des commandes spécifiques, par ex. annuler un Vaillant Quick Veto ou basculer un relais. Fonctionne avec ou sans appareil maître. Sans appareil maître, seul le script est déclenché. Reçoit les variables : action (heat/cool/idle), master_entity, members, active_members.`,"compressor.enforce_uniform_mode":`Imposer un mode uniforme`,"compressor.enforce_uniform_mode_hint":`Tous les thermostats de ce groupe doivent fonctionner dans le même mode HVAC (tout chauffage ou tout refroidissement). Les pièces qui ne sont pas d'accord avec le mode de groupe résolu seront mises en mode repos. Utilisez cela pour les pompes à chaleur qui démarrent automatiquement mais exigent que toutes les unités connectées fonctionnent dans le même mode.`,"mold.title":`Protection contre le risque de moisissure`,"mold.detection":`Détection de moisissure`,"mold.detection_desc":`Recevoir des notifications lorsque l'humidité indique un risque de moisissure`,"mold.threshold":`Seuil d'humidité (%)`,"mold.threshold_hint":`Alerter lorsque l'humidité de la pièce reste au-dessus de cette valeur`,"mold.sustained":`Durée écoulée (minutes)`,"mold.sustained_hint":`Alerter uniquement quand le risque persiste aussi longtemps`,"mold.prevention":`Prévention de la moisissure`,"mold.prevention_desc":`Assécher les murs à risque avec un déshumidificateur ou des cycles DRY protégés. Ne chauffe jamais ; la nuit, le climatiseur n'agit qu'en cas de risque critique.`,"mold.prevention_sustained":`Durée de risque avant intervention`,"mold.prevention_sustained_hint":`À 65 % sur les murs, DRY peut démarrer après 2 h ; à 70 %, après la durée choisie ; à 80 %, en 10 min maximum. Cycle de 30 min maximum, pause de 60 min.`,"mold.dehumidification":`Privilégier la déshumidification si elle est sûre`,"mold.dehumidification_desc":`Utiliser d'abord le mode sec du climatiseur uniquement si la pièce est assez chaude ; sinon RoomMind applique le plan pompe à chaleur / chaudière configuré.`,"mold.dehumidification_min_temperature":`Température minimale pour la déshumidification`,"mold.dehumidification_min_temperature_hint":`DRY démarre à cette température et s'arrête 1 °C plus bas (minimum 21 °C). Ne concerne que le DRY du climatiseur : un déshumidificateur dédié fonctionne à toute température.`,"card.mold_warning":`Risque de moisissure`,"card.mold_critical":`Danger de moisissure !`,"card.mold_prevention":`Prévention de la moisissure`,"room.mold_surface_rh":`Humidité de surface estimée : {value}%`,"settings.intro.general":`Paramètres d'affichage et de contrôle de base.`,"settings.intro.sensors":`Configurez les capteurs extérieurs et les données météo pour un contrôle climatique précis.`,"settings.intro.control":`Choisissez comment RoomMind contrôle vos appareils climatiques et définissez les priorités et seuils.`,"settings.intro.presence":`Réduisez automatiquement la température lorsqu'aucun occupant n'est présent.`,"settings.intro.vacation":`Réglez toutes les pièces à une température réduite pendant votre absence.`,"settings.intro.valve":`Déplacez périodiquement les vannes TRV inactives pour éviter le blocage ou la calcification.`,"settings.intro.compressor":`Gérez les groupes d'unités intérieures qui partagent un compresseur extérieur ou une source de chauffage centrale. Vous pouvez assigner un dispositif maître (chaudière, unité extérieure) pour l'allumer/éteindre automatiquement selon la demande des pièces. La protection contre les courts cycles évite les commutations rapides qui peuvent endommager l'équipement.`,"settings.intro.mold":`Surveillez l'humidité et réduisez automatiquement le risque de moisissure.`,"settings.intro.notifications":`Configurez qui reçoit les alertes et comment.`,"settings.intro.learning":`Gérez l'entraînement du modèle thermique et accélérez le réapprentissage après des changements.`,"settings.intro.reset":`Effacez les données du modèle thermique appris. Le modèle recommencera à apprendre à partir de zéro.`,"notifications.title":`Notifications`,"notifications.window_open_after":`Alerte fenetre ouverte apres`,"notifications.window_open_after_hint":`Envoyer une alerte apres ce nombre de minutes avec la fenetre ouverte. 0 pour desactiver.`,"notifications.enabled":`Activer les notifications`,"notifications.enabled_hint":`Lorsqu'elles sont désactivées, aucune notification n'est envoyée — ni aux appareils, ni à la barre latérale HA.`,"notifications.desc":`Choisissez quels appareils reçoivent les alertes. Sans cibles, les alertes apparaissent dans la barre latérale HA.`,"notifications.add_target_label":`Ajouter un appareil de notification`,"notifications.add_target_hint":`Saisissez l'ID d'entité si votre appareil n'est pas répertorié (ex. notify.mobile_app_...). Vous pouvez le trouver sous Paramètres → Appareils → votre téléphone → entité de notification.`,"notifications.target_unnamed":`Appareil sans nom`,"notifications.target_person":`Personne`,"notifications.target_when_always":`Toujours`,"notifications.target_when_home":`Seulement lorsqu'à la maison`,"notifications.cooldown":`Temps de pause entre les notifications (minutes)`,"notifications.cooldown_hint":`Temps minimum entre des alertes répétées par pièce`,"notifications.mold_prevention_notify":`Notifier lorsque la prévention de moisissure s'active`,"notifications.mold_prevention_notify_hint":`Envoyer également une notification lorsque la prévention s'active (température augmentée)`,"room.section.heat_source":`Orchestration de la source de chaleur`,"heat_source.toggle":`Sélection intelligente de la source`,"heat_source.power_estimate":`Puissance de secours estimée du climatiseur`,"heat_source.power_estimate_hint":`RoomMind apprend la puissance maximale en chauffage, refroidissement et déshumidification, avec une marge de 30 %. Cette valeur sert de secours jusqu'à 6 mesures valides par mode. À 0 W, les démarrages sans historique sont bloqués.`,"heat_source.budget_heating":`Chauffage`,"heat_source.budget_cooling":`Refroidissement`,"heat_source.budget_dry":`Déshumidification`,"heat_source.budget_learned":`appris`,"heat_source.budget_fallback":`secours manuel`,"heat_source.budget_unknown":`données insuffisantes`,"preview.title":`Simulation de sécurité`,"preview.intro":`Prévisualisation sans commande : budget électrique et protection du compresseur.`,"preview.mode":`Mode simulé`,"preview.run":`Simuler sans agir`,"preview.scope":`Ne commande aucun appareil. Vérifie l'admission électrique et le compresseur, sans simuler les horaires, les saisons ou le contrôle MPC.`,"preview.error":`Simulation indisponible.`,"preview.headroom":`Puissance disponible`,"preview.meter":`Capteur électrique`,"preview.healthy":`récent`,"preview.unavailable":`périmé ou indisponible`,"preview.boiler":`Chaudière`,"preview.bypass":`Retour du bypass`,"preview.acknowledged":`confirmé par l'état HA`,"preview.not_acknowledged":`non confirmé (normal chaudière arrêtée)`,"preview.current_reasons":`Décisions actuelles`,"preview.reason_eligible":`Démarrage autorisé par le budget et le compresseur`,"preview.reason_control_disabled":`Contrôle climatique désactivé`,"preview.reason_room_safety":`Protection de la pièce (fenêtre ou arrêt forcé)`,"preview.reason_compressor_protection":`Protection anti-court-cycle`,"preview.reason_power_budget":`Puissance insuffisante ou inconnue`,"heat_source.toggle_hint":`Lorsque cette pièce possède à la fois des thermostats de radiateur et une climatisation/pompe à chaleur, RoomMind oriente intelligemment la demande de chauffage vers l'appareil le plus efficace en fonction de l'écart de température et des conditions extérieures.`,"heat_source.primary_delta":`Seuil d'activation de la chaudière`,"heat_source.primary_delta_hint":`Activez la source principale uniquement lorsque l'écart de température dépasse cette valeur. En dessous de ce seuil, seule la source secondaire rapide est utilisée.`,"heat_source.primary_delta_suffix":`°C`,"heat_source.outdoor_threshold":`Seuil de préférence extérieur`,"heat_source.outdoor_threshold_hint":`Au-dessus de cette température extérieure, privilégier la climatisation/pompe à chaleur (efficacité supérieure). En dessous, privilégier la chaudière à gaz/radiateur.`,"heat_source.outdoor_threshold_suffix":`°C`,"heat_source.ac_min_outdoor":`Température extérieure min. pour la climatisation`,"heat_source.ac_min_outdoor_hint":`Désactiver complètement la climatisation en dessous de cette température pour protéger le matériel de la pompe à chaleur.`,"heat_source.ac_min_outdoor_suffix":`°C`,"heat_source.summary_disabled":`La sélection intelligente de la source est désactivée`,"devices.keep_fan_only_window":`Maintenir la ventilation seule si la fenêtre est ouverte`,"devices.keep_fan_only_window_hint":`Le chauffage et le refroidissement sont suspendus, mais un climatiseur en ventilation seule reste allumé.`,"settings.temperature_rounding":`Arrondi de la température physique`,"settings.temperature_rounding_hint":`Définit comment RoomMind arrondit vers le pas pris en charge par l'appareil climatique.`,"settings.temperature_rounding_nearest":`Valeur prise en charge la plus proche`,"settings.temperature_rounding_down":`Arrondir vers le bas (26,5° → 26°)`,"settings.temperature_rounding_up":`Arrondir vers le haut (26,5° → 27°)`,"devices.power_sensor":`Capteur de puissance`,"devices.power_sensor_hint":`Capteur de consommation électrique instantanée de ce climatiseur. Les capteurs en W et kW servent à l’historique et aux prévisions adaptatives.`,"analytics.energy_title":`Consommation d’énergie`,"analytics.energy_subtitle":`Puissance mesurée des appareils et prévision apprise`,"analytics.energy_chart_info_body":`Les lignes continues montrent la puissance mesurée. Les segments pointillés prolongent la dernière mesure avec la prévision apprise à trois heures. Touchez un élément de légende pour masquer ou rétablir une série. Faites défiler horizontalement ou pincez pour zoomer ; la ligne verticale pointillée indique maintenant.`,"analytics.energy_room_power":`Puissance de la pièce`,"analytics.energy_forecast":`Prévision`,"analytics.energy_forecast_short":`Prévision`,"analytics.energy_now":`Maintenant`,"analytics.energy_period":`Énergie sur la période`,"analytics.energy_next_3h":`3 prochaines heures`,"analytics.energy_learning":`Échantillons d’apprentissage`,"analytics.energy_confidence":`Fiabilité de la prévision`,"analytics.energy_confidence_low":`Faible`,"analytics.energy_confidence_medium":`Moyenne`,"analytics.energy_confidence_high":`Élevée`,"analytics.energy_cost_today":`Coût aujourd’hui`,"analytics.energy_cost_7d":`Coût des 7 derniers jours`,"analytics.energy_cost_next_3h":`Coût des 3 prochaines h`,"analytics.comparison_title":`Comparaison des pièces`,"analytics.comparison_info":`Compare la période sélectionnée : kWh est l’énergie climatique mesurée, € son coût estimé, Actif le temps total de chauffage/refroidissement, ΔT/kWh la variation de température par unité d’énergie et Vers cible le temps moyen pour atteindre la température programmée.`,"analytics.comparison_data_incomplete":`Données incomplètes`,"analytics.comparison_quality_insufficient_samples":`trop peu d’échantillons`,"analytics.comparison_quality_no_power_measurements":`aucune mesure de puissance`,"analytics.comparison_quality_history_gaps":`lacunes dans l’historique`,"analytics.comparison_room":`Pièce`,"analytics.comparison_active":`Actif`,"analytics.comparison_efficiency":`ΔT/kWh`,"analytics.comparison_target":`Vers cible`,"settings.energy_price":`Prix de l’énergie climatique`,"settings.energy_price_hint":`Prix (EUR/kWh)`,"hero.window_impact":`Fenêtre ouverte depuis {minutes} min : {impact}{unit} vs prévision`,"hero.power_budget_blocked":`Démarrage de la climatisation retardé par le budget électrique`,"hero.preconditioning_active":`Pré-conditionnement actif pour la prochaine consigne`,"hero.preconditioning_planned":`Pré-conditionnement prévu à {time}`,"hero.ac_efficiency_issue":`La climatisation consomme normalement mais répond lentement`,"insights.comfort.title":`Explication du score de confort`,"insights.comfort.summary":`Le score commence Ã\xA0 100 ; les conditions actives retirent des points.`,"insights.comfort.base":`Score de dÃ©part`,"insights.comfort.total":`Score actuel`,"insights.comfort.no_penalty":`Aucune pÃ©nalitÃ©`,"insights.comfort.factor.temperature.unavailable":`Mesure de tempÃ©rature indisponible`,"insights.comfort.factor.temperature.below_target":`TempÃ©rature sous la consigne`,"insights.comfort.factor.temperature.above_target":`TempÃ©rature au-dessus de la consigne`,"insights.comfort.factor.temperature.on_target":`TempÃ©rature Ã\xA0 la consigne`,"insights.comfort.factor.humidity.unavailable":`HumiditÃ© non Ã©valuÃ©e`,"insights.comfort.factor.humidity.below_target":`HumiditÃ© sous la consigne`,"insights.comfort.factor.humidity.above_target":`HumiditÃ© au-dessus de la consigne`,"insights.comfort.factor.humidity.on_target":`HumiditÃ© Ã\xA0 la consigne`,"insights.comfort.factor.window.open":`FenÃªtre ouverte`,"insights.comfort.factor.window.closed":`FenÃªtre fermÃ©e`,"insights.comfort.factor.air_quality.warning":`Avertissement de risque de moisissure`,"insights.comfort.factor.air_quality.critical":`Risque de moisissure critique`,"insights.comfort.factor.air_quality.ok":`Aucun risque de moisissure`,"insights.comfort.factor.anomalies.active":`Anomalies actives de la piÃ¨ce`,"insights.comfort.factor.anomalies.none":`Aucune anomalie active`,"dehumidifier.title":`Déshumidificateur`,"dehumidifier.add":`Ajouter un déshumidificateur`,"dehumidifier.configure":`Configurer le déshumidificateur`,"dehumidifier.device":`Appareil physique`,"dehumidifier.device_hint":`Choisissez un déshumidificateur ou une prise connectée. L’appareil doit redémarrer au retour du courant.`,"dehumidifier.mode":`Commande de l’appareil`,"dehumidifier.auto":`Automatique`,"dehumidifier.manual":`Manuel`,"dehumidifier.manual_hint":`RoomMind laisse les démarrages manuels inchangés, y compris pour sécher le linge. Ouvrez le nom de l’appareil pour les commandes Home Assistant.`,"dehumidifier.served_rooms":`Pièces desservies`,"dehumidifier.host_included":`La pièce accueillant l’appareil est toujours incluse.`,"dehumidifier.shared_hint":`Chaque pièce utilise son capteur. Fenêtre et nuit de la pièce hôte s’appliquent ; pause à 45%, reprise à 50%, selon les limites de l’appareil.`,"dehumidifier.min_run_minutes":`Durée minimale de marche`,"dehumidifier.min_off_minutes":`Durée minimale d’arrêt`,"dehumidifier.power_watts":`Puissance nominale`,"dehumidifier.power_hint":`Requise pour les nouveaux démarrages si le budget électrique est actif.`,"dehumidifier.comfort":`Confort hygrométrique`,"dehumidifier.comfort_hint":`Ajouter un appareil n’active pas le confort. Le profil actif peut remplacer la cible. La prévention des moisissures conserve ses réglages.`,"dehumidifier.target":`Humidité cible de la pièce`,"dehumidifier.tolerance":`Tolérance d’humidité`,"dehumidifier.priority":`Priorité hygrométrique`,"dehumidifier.priority_comfort":`Confort`,"dehumidifier.priority_balanced":`Équilibrée`,"dehumidifier.priority_energy":`Économie d’énergie`,"dehumidifier.empty":`Aucun appareil dédié ou partagé. Le mode Dry automatique reste disponible.`,"dehumidifier.host":`Situé dans`,"dehumidifier.requests":`Demandes de`,"dehumidifier.device_target":`Cible de l’appareil`,"dehumidifier.floor":`Limite d’humidité de la pièce hôte`,"dehumidifier.drying":`Déshumidification en cours`,"dehumidifier.on":`Allumé`,"dehumidifier.off":`Éteint`,"dehumidifier.idle":`Allumé, en attente`,"dehumidifier.request_mold":`Prévention des moisissures demandée`,"dehumidifier.request_comfort":`Confort hygrométrique demandé`,"dehumidifier.reason_unavailable":`Appareil indisponible`,"dehumidifier.reason_manual":`Commande manuelle`,"dehumidifier.reason_disabled":`Commande automatique désactivée`,"dehumidifier.reason_sensor":`Mesure d’humidité de la pièce hôte absente`,"dehumidifier.reason_window":`Fenêtre ouverte dans la pièce hôte`,"dehumidifier.reason_humidity_floor":`Limite d’humidité de la pièce hôte atteinte`,"dehumidifier.reason_min_off":`Attente de la durée minimale d’arrêt`,"dehumidifier.reason_min_run":`Fin de la durée minimale de marche`,"dehumidifier.reason_night":`Repos nocturne de la pièce hôte`,"dehumidifier.reason_power_budget":`Attente de capacité électrique ou de puissance nominale`,"dehumidifier.reason_error":`Échec de la commande de l’appareil`,"dehumidifier.assigned":`Traite la demande de cette pièce`,"dehumidifier.command_on":`Commande de mise en marche envoyée`,"dehumidifier.command_off":`Commande d’arrêt envoyée`,"dehumidifier.intro":`Choisissez qui commande l’appareil, les pièces desservies et l’objectif d’humidité de cette pièce.`,"dehumidifier.how_it_works":`Fonctionnement du contrôle automatique`,"dehumidifier.guide_device":`En Automatique, RoomMind peut démarrer et arrêter l’appareil pour le confort d’humidité ou la prévention des moisissures. Les contrôles climatiques global et de la pièce hôte doivent être actifs. En Manuel, vous gardez la main.`,"dehumidifier.guide_comfort":`Chaque pièce active séparément son confort d’humidité et possède son objectif. La prévention des moisissures suit ses réglages même si le confort est désactivé. Les profils actifs peuvent remplacer l’objectif.`,"dehumidifier.guide_shared":`Une pièce sélectionnée peut demander cet appareil selon son humidité. Chaque pièce desservie doit avoir une mesure d’humidité. L’air doit circuler entre les pièces ; fenêtres, horaires de nuit et protection d’humidité de la pièce hôte s’appliquent à tout l’appareil.`,"dehumidifier.disabled_hint":`Pour autoriser les démarrages automatiques, activez le contrôle climatique général et celui de la pièce hôte, {room}. Le confort d’humidité seul ne suffit pas.`,"dehumidifier.auto_hint":`RoomMind gère ses propres démarrages et les consignes d’humidité prises en charge. Si vous allumez l’appareil, il reste inchangé jusqu’à ce que vous l’éteigniez.`,"dehumidifier.manual_option_hint":`Vous commandez l’appareil depuis Home Assistant.`,"dehumidifier.coverage_hint":`Associez l’appareil à sa pièce d’installation. Ajoutez d’autres pièces si l’air peut circuler entre elles.`,"dehumidifier.host_room":`Pièce hôte · toujours incluse`,"dehumidifier.additional_rooms":`Autres pièces à desservir`,"dehumidifier.shared_available":`Un appareil partagé dessert déjà cette pièce`,"dehumidifier.shared_available_hint":`Vous pouvez régler le confort de cette pièce ci-dessous sans ajouter d’appareil. Le partage se modifie dans la pièce hôte.`,"dehumidifier.room_comfort":`Humidité dans cette pièce`,"dehumidifier.tolerance_hint":`La tolérance et la priorité définissent la hausse d’humidité admise avant de demander une déshumidification. Une marge plus large réduit les démarrages. La demande cesse près de l’objectif.`,"dehumidifier.priority_comfort_hint":`Demande plus tôt`,"dehumidifier.priority_balanced_hint":`Marge d’humidité standard`,"dehumidifier.priority_energy_hint":`Accepte une hausse plus importante`,"dehumidifier.protections":`Protection de l’appareil et puissance`,"dehumidifier.timing_hint":`Les durées minimales de marche et d’arrêt limitent les cycles rapprochés. L’attente à l’arrêt s’applique aussi après un redémarrage. Les protections peuvent interrompre la durée minimale de marche.`,"dehumidifier.shared_device":`Appareil partagé · pièces desservies`,"dehumidifier.local_device":`Appareil dédié · pièce desservie`,"dehumidifier.device_details":`Consigne et protection de l’appareil`,"dehumidifier.device_target_hint":`Pour un appareil partagé, la consigne suit la limite de protection de la pièce hôte. Elle peut différer de l’objectif de confort de cette pièce : chacune demande selon son propre objectif.`,"dehumidifier.comfort_enabled":`Confort activé`,"dehumidifier.comfort_disabled":`Confort désactivé`,"dehumidifier.measured":`Humidité mesurée`,"dehumidifier.comfort_off_hint":`Cette pièce ne demande pas de déshumidification pour le confort. La prévention des moisissures suit toujours ses propres réglages.`,"dehumidifier.status_pending":`Appareil associé. En attente de son état de fonctionnement.`,"equipment.open":`Ouverte`,"equipment.closed":`Fermée`,"equipment.unavailable":`Indisponible`,"equipment.no_devices":`Aucun appareil de chauffage ou de climatisation associé.`,"equipment.no_sensors":`Associez des capteurs pour mesurer les conditions de cette pièce.`,"equipment.edit_devices":`Gérer les appareils`,"equipment.edit_sensors":`Gérer les capteurs`,"dehumidifier.waiting_hint":`Prêt : l’appareil démarre lorsqu’une pièce desservie demande une déshumidification, sous réserve des protections.`,"settings.boiler.min_demand_rooms":`Demandes nécessaires pour démarrer la chaudière`,"settings.boiler.min_demand_hint":`En dessous, les radiateurs qui demandent de la chaleur attendent vannes fermées. Une fois allumée, la chaudière reste en marche tant qu’une demande existe.`,"settings.boiler.min_run_minutes":`Marche minimale (min)`,"settings.boiler.min_off_minutes":`Arrêt minimal (min)`,"settings.boiler.fault_retry_minutes":`Nouvel essai après défaut (min)`,"settings.boiler.child_lock":`Verrouiller les boutons de la vanne de bypass`,"settings.boiler.child_lock_hint":`Active la sécurité enfant pour qu’un appui sur la vanne ne sorte pas le bypass du chauffage forcé et n’arrête pas la chaudière.`,"settings.boiler.max_wait_minutes":`Attente maximale sous le quorum (min)`,"settings.boiler.max_wait_hint":`Une pièce qui demande de la chaleur depuis ce temps démarre la chaudière seule, pour que les pièces à radiateurs ne restent pas froides. 0 garde le quorum strict.`,"comfort.profile.default":`Aucun profil (programmation)`,"comfort.profile_clear_hint":`Touchez à nouveau le profil actif, ou "Aucun profil", pour revenir à la programmation.`,"settings.boiler.demand_unit":`Compter les demandes par`,"settings.boiler.demand_unit_valves":`Vannes de radiateur (une pièce avec 2 radiateurs compte 2)`,"settings.boiler.demand_unit_rooms":`Pièces`},it:{"analytics.overview_title":`Comprendi il clima della tua casa`,"analytics.overview_hint":`Esplora l'andamento delle temperature, i consumi e ciò che RoomMind ha imparato su ogni stanza.`,"analytics.select_room":`Seleziona stanza`,"analytics.temperature":`Temperatura`,"analytics.target":`Obiettivo`,"analytics.prediction":`Previsione`,"analytics.outdoor":`Esterno`,"analytics.model_status":`Stato del modello`,"analytics.confidence":`Affidabilità`,"analytics.heating_rate":`Efficacia riscaldamento`,"analytics.cooling_rate":`Efficacia raffrescamento`,"analytics.solar_gain":`Apporto solare`,"analytics.occupancy_gain":`Apporto dovuto alla presenza`,"analytics.time_constant":`Inerzia termica`,"analytics.data_points":`Campioni osservati`,"analytics.data_sources":`Dati raccolti`,"analytics.samples":`Campioni`,"analytics.control_mode_mpc":`MPC attivo`,"analytics.control_mode_bangbang":`MPC in apprendimento`,"analytics.accuracy_idle":`Precisione (riposo)`,"analytics.accuracy_heating":`Precisione (riscaldamento)`,"analytics.no_data":`Nessun dato: il modello sta apprendendo`,"analytics.loading":`Caricamento analisi...`,"analytics.range_1d":`Oggi`,"analytics.range_2d":`2 giorni`,"analytics.range_7d":`Settimana`,"analytics.range_30d":`Mese`,"analytics.export":`Misurazioni`,"analytics.copy_diagnostics":`Diagnostica`,"analytics.export_download":`Scarica file`,"analytics.export_clipboard":`Copia negli appunti`,"analytics.exported":`Esportazione riuscita`,"analytics.copied_to_clipboard":`Copiato negli appunti`,"analytics.range_from":`Da`,"analytics.range_to":`A`,"analytics.chart_info_title":`Come leggere il grafico`,"analytics.window_open_period":`Finestra aperta`,"analytics.comparison_title":`Confronto tra stanze`,"analytics.comparison_room":`Stanza`,"analytics.comparison_active":`Attivo`,"analytics.comparison_target":`All'obiettivo`,"analytics.comparison_data_incomplete":`Dati incompleti`,"analytics.comparison_quality_insufficient_samples":`campioni insufficienti`,"analytics.comparison_quality_no_power_measurements":`nessuna misura di potenza`,"analytics.comparison_quality_history_gaps":`lacune nello storico`,"analytics.energy_title":`Consumi energetici`,"analytics.energy_subtitle":`Potenza misurata e previsione appresa`,"analytics.energy_room_power":`Potenza stanza`,"analytics.energy_forecast":`Previsione`,"analytics.energy_forecast_short":`Previsione`,"analytics.energy_now":`Adesso`,"analytics.energy_period":`Energia del periodo`,"analytics.energy_next_3h":`Prossime 3 ore`,"analytics.energy_learning":`Campioni appresi`,"analytics.energy_confidence":`Affidabilità previsione`,"analytics.energy_confidence_low":`Bassa`,"analytics.energy_confidence_medium":`Media`,"analytics.energy_confidence_high":`Alta`,"analytics.energy_cost_today":`Costo oggi`,"analytics.energy_cost_7d":`Costo ultimi 7 giorni`,"analytics.energy_cost_next_3h":`Costo prossime 3 ore`,"panel.tab.rooms":`Stanze`,"panel.tab.settings":`Impostazioni`,"panel.loading":`Caricamento...`,"panel.no_areas":`Nessuna stanza configurata in Home Assistant.`,"panel.no_areas_hint":`Aggiungi le aree nelle impostazioni di Home Assistant.`,"panel.stat.rooms":`Stanze`,"panel.stat.heating":`Riscaldamento`,"panel.stat.cooling":`Raffrescamento`,"panel.stat.vacation":`Vacanza`,"panel.stat.away":`Assenza`,"panel.stat.mold":`Muffa`,"panel.hide_room":`Nascondi stanza`,"panel.hidden_rooms":`Stanze nascoste`,"panel.unhide":`Mostra`,"panel.reorder":`Riordina le stanze`,"panel.reorder_done":`Fine`,"tabs.analytics":`Analisi`,"card.target":`Obiettivo`,"card.humidity":`Umidità {value}%`,"card.waiting":`In attesa dei dati...`,"card.no_climate":`Nessun dispositivo climatico`,"card.outdoor":`Esterno`,"card.not_controlled":`Stanza non controllata da RoomMind`,"card.mpc_active":`MPC attivo`,"card.mpc_learning":`MPC in apprendimento`,"card.window_open":`Finestra aperta`,"card.presence_away":`Casa vuota`,"card.mold_warning":`Rischio muffa`,"card.mold_critical":`Rischio muffa elevato`,"card.mold_prevention":`Prevenzione muffa`,"card.climate_device":`dispositivo climatico`,"card.climate_devices":`dispositivi climatici`,"card.temp_sensor":`sensore di temperatura`,"card.temp_sensors":`sensori di temperatura`,"card.tap_configure":`Apri per configurare`,"mode.auto":`Auto`,"mode.auto_desc":`Gestisce automaticamente riscaldamento e raffrescamento in base agli obiettivi`,"mode.heat_only":`Solo caldo`,"mode.heat_only_desc":`Utilizza solo i termostati: i climatizzatori restano spenti`,"mode.cool_only":`Solo freddo`,"mode.cool_only_desc":`Utilizza solo i climatizzatori: i termostati restano spenti`,"mode.heating":`Riscaldamento`,"mode.cooling":`Raffrescamento`,"mode.idle":`In attesa`,"hero.target":`Obiettivo`,"hero.humidity":`Umidità {value}%`,"hero.override":`Modifica temporanea`,"hero.remaining":`Ancora {time}`,"hero.permanent":`Senza scadenza`,"hero.waiting":`In attesa dei sensori...`,"hero.not_configured":`Da configurare`,"hero.window_open":`Finestra aperta: controllo sospeso`,"hero.mpc_learning_paused":`Apprendimento MPC in pausa`,"hero.compressor_protection_min_off":`Protezione compressore: attesa prima dell'avvio`,"hero.compressor_protection_min_run":`Protezione compressore: funzionamento minimo`,"hero.power_budget_blocked":`Avvio rinviato per il budget elettrico`,"hero.ac_efficiency_issue":`Il climatizzatore consuma normalmente ma raffresca lentamente`,"hero.window_recovery":`Recupero stimato dopo la chiusura: {minutes} min`,"settings.general_title":`Generali`,"settings.control_title":`Regolazione climatica`,"settings.sensors_title":`Sensori e dati`,"settings.learning_title":`Apprendimento del modello`,"settings.reset_title":`Ripristino dati termici`,"settings.climate_control_active":`Controllo climatico attivo`,"settings.group_by_floor":`Raggruppa stanze per piano`,"settings.saving":`Salvataggio...`,"settings.saved":`Salvato`,"settings.error":`Errore durante il salvataggio`,"settings.smart_control":`Controllo climatico intelligente`,"settings.climate_intelligence":`Intelligenza climatica`,"settings.control_mode":`Modalità di controllo`,"settings.control_mode_simple":`Semplice`,"settings.control_mode_mpc":`Predittivo (MPC)`,"settings.comfort_weight":`Priorità`,"settings.comfort_weight_comfort":`Comfort`,"settings.comfort_weight_efficiency":`Efficienza`,"settings.prediction_enabled":`Previsione della temperatura`,"settings.weather_entity":`Previsioni meteo`,"settings.outdoor_sensor":`Temperatura esterna`,"settings.outdoor_humidity_sensor":`Umidità esterna`,"settings.outdoor_cooling_min":`Temperatura esterna minima per raffrescare`,"settings.outdoor_heating_max":`Temperatura esterna massima per riscaldare`,"settings.intro.general":`Preferenze principali di visualizzazione e controllo.`,"settings.intro.sensors":`Sensori e sorgenti meteo per la regolazione climatica.`,"settings.intro.control":`Modalità di funzionamento e priorità tra comfort ed efficienza.`,"settings.intro.presence":`Regolazione automatica in base a chi si trova in casa.`,"settings.intro.vacation":`Riduci i consumi durante le assenze prolungate.`,"settings.intro.valve":`Manutenzione e protezione delle valvole termostatiche.`,"settings.intro.compressor":`Protezioni per i climatizzatori che condividono un compressore.`,"settings.intro.mold":`Monitoraggio e prevenzione del rischio muffa.`,"settings.intro.notifications":`Avvisi e destinatari delle notifiche.`,"settings.intro.learning":`Gestione dell'apprendimento termico delle stanze.`,"settings.intro.reset":`Cancella i dati appresi per ricominciare l'addestramento.`,"room.climate_control_toggle":`Controllo climatico`,"room.climate_control_hint":`Se disattivato, RoomMind non invia comandi ai dispositivi di questa stanza.`,"room.section.climate_mode":`Modalità climatica`,"room.section.schedule":`Programmazione e temperature`,"room.section.devices":`Dispositivi`,"room.section.sensors":`Sensori`,"room.section.covers":`Tapparelle e tende`,"room.section.presence":`Presenza`,"room.section.heat_source":`Scelta della sorgente termica`,"schedule.no_schedules":`Nessun programma configurato`,"schedule.add_schedule":`Aggiungi programma`,"override.label":`Modifica temporanea`,"override.comfort":`Comfort`,"override.eco":`Eco`,"override.custom":`Personalizzato`,"presence.title":`Rilevamento presenza`,"vacation.title":`Modalità vacanza`,"valve_protection.title":`Protezione valvole`,"compressor.title":`Protezione compressori`,"mold.title":`Prevenzione muffa`,"settings.hub.eyebrow":`Centro di controllo`,"settings.hub.title":`Impostazioni, senza complicazioni`,"settings.hub.description":`Scegli cosa vuoi configurare. Le regolazioni quotidiane restano separate dall'impianto, dalle protezioni e dagli strumenti avanzati.`,"settings.hub.running":`Controllo climatico automatico attivo`,"settings.hub.paused":`Controllo climatico automatico in pausa`,"settings.hub.navigation":`Categorie impostazioni`,"settings.hub.category_label":`Categoria`,"settings.hub.overview":`Quotidianità`,"settings.hub.overview_hint":`Preferenze, comfort e presenza`,"settings.hub.system":`Impianto`,"settings.hub.system_hint":`Caldaia, climatizzatori e sensori`,"settings.hub.protection":`Protezione e avvisi`,"settings.hub.protection_hint":`Muffa, notifiche e diagnostica`,"settings.hub.advanced":`Avanzate`,"settings.hub.advanced_hint":`Apprendimento e manutenzione`,"settings.hub.heating":`Caldaia e budget elettrico`,"settings.hub.heating_hint":`Bypass idraulico, tempi della caldaia e limiti di potenza degli split.`,"room.nav.overview":`Clima e comfort`,"room.nav.equipment":`Dispositivi e sensori`,"room.nav.advanced":`Automazioni e analisi`,"room.nav.description":`Scegli un'area della stanza per consultarla o modificarla.`,"panel.overview":`La tua casa, a colpo d'occhio`,"panel.overview_hint":`Temperature delle stanze e impianti che richiedono attenzione.`,"panel.control_active":`Controllo automatico attivo`,"panel.control_paused":`Controllo automatico in pausa`,"insights.decision.title":`Perché RoomMind sta agendo`,"insights.decision.window_open":`Il controllo clima è in pausa perché una finestra è aperta.`,"insights.decision.power_budget":`La richiesta climatica è limitata dal budget di potenza configurato.`,"insights.decision.compressor_min_off":`Il compressore attende il tempo minimo di spegnimento.`,"insights.decision.compressor_min_run":`Il compressore sta completando il tempo minimo di funzionamento.`,"insights.decision.override_boost":`È attivo un override Boost.`,"insights.decision.override_eco":`È attivo un override Eco.`,"insights.decision.override_custom":`È attivo un override con temperatura personalizzata.`,"insights.decision.override_active":`È attivo un override manuale.`,"insights.decision.presence_away":`La modalità assenza sta regolando questa stanza.`,"insights.decision.mold_prevention":`La prevenzione muffa sta proteggendo questa stanza.`,"mold.prevention_sustained":`Durata del rischio prima di intervenire`,"heat_source.power_estimate":`Potenza di riserva (fallback) del climatizzatore`,"heat_source.power_estimate_hint":`RoomMind apprende automaticamente il picco per riscaldamento, raffrescamento e deumidificazione, con un margine del 30%. Questo valore viene usato solo se mancano almeno 6 campioni validi per la modalità. Con 0 W, le nuove accensioni senza dati appresi vengono bloccate per sicurezza.`,"heat_source.budget_heating":`Riscaldamento`,"heat_source.budget_cooling":`Raffrescamento`,"heat_source.budget_dry":`Deumidificazione`,"heat_source.budget_learned":`appreso`,"heat_source.budget_fallback":`riserva manuale`,"heat_source.budget_unknown":`in attesa di dati`,"preview.title":`Simulazione di sicurezza`,"preview.intro":`Anteprima senza comandi di accensione: budget elettrico e protezione compressori.`,"preview.mode":`Modalità da simulare`,"preview.run":`Simula senza intervenire`,"preview.scope":`Non comanda dispositivi. Mostra se una nuova accensione sarebbe ammessa dal budget e dalle protezioni; non simula orari, soglie stagionali o controllo termico MPC.`,"preview.error":`Impossibile caricare la simulazione.`,"preview.headroom":`Potenza disponibile`,"preview.meter":`Sensore elettrico`,"preview.healthy":`aggiornato`,"preview.unavailable":`obsoleto o non disponibile`,"preview.boiler":`Caldaia`,"preview.bypass":`Conferma bypass`,"preview.acknowledged":`confermato dallo stato HA`,"preview.not_acknowledged":`non confermato (normale a caldaia spenta)`,"preview.current_reasons":`Motivi attuali`,"preview.reason_eligible":`Avvio consentito da budget e protezioni compressore`,"preview.reason_control_disabled":`Controllo climatico disattivato`,"preview.reason_room_safety":`Protezione stanza (finestra o spegnimento forzato)`,"preview.reason_compressor_protection":`Protezione tempo minimo di spegnimento`,"preview.reason_power_budget":`Potenza insufficiente o sconosciuta`,"mold.prevention_sustained_hint":`Al 65% stimato sulle pareti, DRY può intervenire dopo 2 ore; al 70% vale la durata scelta, all'80% bastano al massimo 10 minuti. Cicli fino a 30 minuti, seguiti da 60 minuti di pausa.`,"insights.decision.humidity_comfort":`La deumidificazione è attiva per il comfort dell'umidità.`,"insights.decision.smart_ventilation":`La ventilazione intelligente mantiene la circolazione dell'aria.`,"insights.decision.preconditioning":`Il controllo predittivo sta precondizionando la stanza.`,"insights.decision.heat_source":`RoomMind ha selezionato la sorgente di calore per questa stanza.`,"insights.decision.mode_heating":`La stanza si sta riscaldando verso il setpoint corrente.`,"insights.decision.mode_cooling":`La stanza si sta raffrescando verso il setpoint corrente.`,"insights.decision.mode_idle":`La stanza è al setpoint e non serve alcuna azione climatica.`,"insights.readiness.title":`Prontezza della stanza`,"insights.readiness.ready":`Pronta per il comfort predittivo ({ready}/{total} controlli completati).`,"insights.readiness.basic":`Il controllo climatico di base è pronto ({ready}/{total} controlli completati).`,"insights.readiness.needs_setup":`Completa la configurazione richiesta per abilitare il controllo climatico ({ready}/{total} controlli completati).`,"insights.readiness.item.devices.ready":`Dispositivo clima configurato`,"insights.readiness.item.devices.missing":`Aggiungi almeno un dispositivo clima`,"insights.readiness.item.temperature_sensor.ready":`Sensore di temperatura esterno configurato`,"insights.readiness.item.temperature_sensor.recommended":`Aggiungi un sensore esterno per il Controllo completo`,"insights.readiness.item.schedule.ready":`Programmazione configurata`,"insights.readiness.item.schedule.recommended":`Aggiungi una programmazione per automatizzare temperature comfort ed eco`,"insights.readiness.item.predictive_control.ready":`Gli input per il controllo predittivo sono disponibili`,"insights.readiness.item.predictive_control.recommended":`Aggiungi la temperatura esterna per sbloccare il controllo predittivo`,"insights.readiness.item.climate_control.missing":`Abilita il controllo climatico per questa stanza`,"card.comfort_score":`Comfort {score}%`,"card.comfort_excellent":`Comfort eccellente`,"card.comfort_good":`Comfort buono`,"card.comfort_fair":`Il comfort richiede attenzione`,"card.comfort_poor":`Comfort scarso`,"card.issues":`{count} problema/i attivo/i nella stanza`,"insights.comfort.title":`Come viene calcolato il comfort`,"insights.comfort.summary":`Il punteggio parte da 100; le condizioni attive sottraggono punti.`,"insights.comfort.base":`Punteggio iniziale`,"insights.comfort.total":`Punteggio attuale`,"insights.comfort.no_penalty":`Nessuna penalità`,"insights.comfort.factor.temperature.unavailable":`Lettura della temperatura non disponibile`,"insights.comfort.factor.temperature.below_target":`Temperatura sotto il setpoint`,"insights.comfort.factor.temperature.above_target":`Temperatura sopra il setpoint`,"insights.comfort.factor.temperature.on_target":`Temperatura al setpoint`,"insights.comfort.factor.humidity.unavailable":`Umidità non valutata`,"insights.comfort.factor.humidity.below_target":`Umidità sotto il setpoint`,"insights.comfort.factor.humidity.above_target":`Umidità sopra il setpoint`,"insights.comfort.factor.humidity.on_target":`Umidità al setpoint`,"insights.comfort.factor.window.open":`Finestra aperta`,"insights.comfort.factor.window.closed":`Finestra chiusa`,"insights.comfort.factor.air_quality.warning":`Avviso rischio muffa`,"insights.comfort.factor.air_quality.critical":`Rischio muffa critico`,"insights.comfort.factor.air_quality.ok":`Nessun rischio muffa`,"insights.comfort.factor.anomalies.active":`Anomalie attive della stanza`,"insights.comfort.factor.anomalies.none":`Nessuna anomalia attiva`,"room.section.comfort":`Comfort e profili`,"room.section.area":`Impostazioni area`,"comfort.profiles":`Profilo comfort attivo`,"comfort.profile.default":`Nessun profilo (programmazione)`,"comfort.profile.work":`Lavoro`,"comfort.profile.sleep":`Sonno`,"comfort.profile.guests":`Ospiti`,"comfort.profile.away":`Assente`,"comfort.night_mode":`Modalità notte`,"comfort.control_enabled":`Controllo della stanza attivo`,"comfort.night_mode_hint":`Regola gradualmente i setpoint della stanza nell'orario notturno selezionato.`,"comfort.night_start":`Inizio`,"comfort.night_end":`Fine`,"comfort.night_heat_delta":`Riduzione riscaldamento (°C)`,"comfort.night_cool_delta":`Aumento raffrescamento (°C)`,"comfort.night_ramp":`Durata transizione (min)`,"mold.dehumidification":`Preferisci la deumidificazione quando sicura`,"mold.dehumidification_desc":`Usa DRY in modo controllato, senza impostare temperatura o ventola: interviene solo se la stanza è abbastanza calda.`,"mold.dehumidification_min_temperature":`Temperatura ambiente minima per deumidificare`,"mold.dehumidification_min_temperature_hint":`DRY parte da questa temperatura e si arresta 1 °C sotto (minimo 21 °C). Vale solo per il DRY del condizionatore: il deumidificatore dedicato parte a qualsiasi temperatura.`,"devices.wall_factor":`Fattore parete (f_Rsi)`,"devices.wall_factor_hint":`Quanto è fredda la parete più fredda della stanza: serve a stimare l'umidità dove si forma la muffa. Più basso = parete più fredda = rischio più alto.`,"devices.wall_preset":`Tipo di parete`,"devices.wall_preset_plain":`Parete normale`,"devices.wall_preset_corner":`Angolo / parete a nord`,"devices.wall_preset_bridge":`Cassonetto, trave o pilastro`,"devices.wall_preset_measured":`Misurato`,"devices.wall_measure_hint":`Calibra con una misura: in una giornata fredda, misura con un termometro a infrarossi (modalità superficie) il punto con la muffa.`,"devices.wall_measure_surface":`Parete`,"devices.wall_measure_room":`Stanza`,"devices.wall_measure_outdoor":`Esterno`,"devices.wall_measure_apply":`Usa f = {value}`,"devices.wall_measure_invalid":`Misura non utilizzabile: servono almeno 5 °C di differenza tra stanza ed esterno e un risultato tra 0,50 e 0,95.`,"mold.prevention_desc":`Deumidifica le pareti a rischio con deumidificatore o cicli DRY protetti. Non riscalda mai; di notte il condizionatore interviene solo con rischio critico.`,"dehumidifier.title":`Deumidificatore`,"dehumidifier.add":`Aggiungi deumidificatore`,"dehumidifier.configure":`Configura deumidificatore`,"dehumidifier.device":`Dispositivo fisico`,"dehumidifier.device_hint":`Scegli un deumidificatore o una presa smart. Con una presa, l’apparecchio deve ripartire al ritorno della corrente.`,"dehumidifier.mode":`Gestione dispositivo`,"dehumidifier.auto":`Automatico`,"dehumidifier.manual":`Manuale`,"dehumidifier.manual_hint":`RoomMind lascia intatte le accensioni manuali, anche per asciugare i panni. Apri il nome del dispositivo per usare i controlli Home Assistant.`,"dehumidifier.served_rooms":`Stanze servite`,"dehumidifier.host_included":`La stanza che ospita il dispositivo è sempre inclusa.`,"dehumidifier.shared_hint":`Il controllo condiviso usa il sensore di ogni stanza. Valgono finestra e notte della stanza ospitante; pausa al 45% e ripresa al 50%, nei limiti del dispositivo.`,"dehumidifier.min_run_minutes":`Tempo minimo acceso`,"dehumidifier.min_off_minutes":`Tempo minimo spento`,"dehumidifier.power_watts":`Potenza nominale`,"dehumidifier.power_hint":`Necessaria per nuovi avvii quando il budget elettrico è attivo.`,"dehumidifier.comfort":`Comfort umidità`,"dehumidifier.comfort_hint":`Aggiungere un dispositivo non abilita il comfort automaticamente. Il profilo attivo può sostituire il target della stanza. La prevenzione muffa segue le sue impostazioni.`,"dehumidifier.target":`Target umidità stanza`,"dehumidifier.tolerance":`Tolleranza umidità`,"dehumidifier.priority":`Priorità umidità`,"dehumidifier.priority_comfort":`Comfort`,"dehumidifier.priority_balanced":`Bilanciata`,"dehumidifier.priority_energy":`Risparmio energetico`,"dehumidifier.empty":`Nessun dispositivo dedicato o condiviso associato. Resta disponibile il Dry automatico dello split.`,"dehumidifier.host":`Si trova in`,"dehumidifier.requests":`Richieste da`,"dehumidifier.device_target":`Target dispositivo`,"dehumidifier.floor":`Limite umidità stanza ospitante`,"dehumidifier.drying":`Sta deumidificando`,"dehumidifier.on":`Acceso`,"dehumidifier.off":`Spento`,"dehumidifier.idle":`Acceso, in attesa`,"dehumidifier.request_mold":`Richiesta prevenzione muffa`,"dehumidifier.request_comfort":`Richiesta comfort umidità`,"dehumidifier.reason_unavailable":`Dispositivo indisponibile`,"dehumidifier.reason_manual":`Gestione manuale`,"dehumidifier.reason_disabled":`Controllo automatico disabilitato`,"dehumidifier.reason_sensor":`Misura umidità stanza ospitante assente`,"dehumidifier.reason_window":`Finestra della stanza ospitante aperta`,"dehumidifier.reason_humidity_floor":`Raggiunto limite umidità stanza ospitante`,"dehumidifier.reason_min_off":`Attesa tempo minimo spento`,"dehumidifier.reason_min_run":`Completamento tempo minimo acceso`,"dehumidifier.reason_night":`Fascia notte della stanza ospitante`,"dehumidifier.reason_power_budget":`Attesa disponibilità elettrica o potenza nominale`,"dehumidifier.reason_error":`Comando al dispositivo non riuscito`,"dehumidifier.assigned":`Gestisce la richiesta di questa stanza`,"dehumidifier.command_on":`Comando di accensione inviato`,"dehumidifier.command_off":`Comando di spegnimento inviato`,"dehumidifier.intro":`Scegli chi gestisce l’apparecchio, quali stanze serve e l’obiettivo di umidità per questa stanza.`,"dehumidifier.how_it_works":`Come funziona il controllo automatico`,"dehumidifier.guide_device":`In Automatico RoomMind può avviare e fermare l’apparecchio per il comfort umidità o la prevenzione muffa. Devono essere attivi sia il controllo climatico generale sia quello della stanza ospitante. In Manuale lo gestisci tu.`,"dehumidifier.guide_comfort":`Ogni stanza abilita il comfort umidità separatamente e usa il proprio target. La prevenzione muffa segue le sue impostazioni anche con il comfort spento. I profili attivi possono sostituire il target della stanza.`,"dehumidifier.guide_shared":`Selezionare una stanza le permette di richiedere questo apparecchio in base alla sua umidità. Ogni stanza servita deve avere una misura di umidità. L’aria deve circolare tra le stanze; finestre, fascia notte e protezione dell’umidità della stanza ospitante valgono per tutto l’apparecchio.`,"dehumidifier.disabled_hint":`Per consentire gli avvii automatici, attiva il controllo climatico nelle impostazioni generali e nella stanza ospitante, {room}. Il solo comfort umidità acceso non basta.`,"dehumidifier.auto_hint":`RoomMind gestisce le proprie accensioni e i target umidità supportati. Se accendi tu il dispositivo, lo lascia invariato finché non lo spegni.`,"dehumidifier.manual_option_hint":`Lo gestisci tu dai controlli Home Assistant.`,"dehumidifier.coverage_hint":`Associa l’apparecchio alla stanza in cui si trova. Aggiungi altre stanze solo se l’aria può circolare tra loro.`,"dehumidifier.host_room":`Ospitante · sempre inclusa`,"dehumidifier.additional_rooms":`Altre stanze da servire`,"dehumidifier.shared_available":`Questa stanza è già servita da un apparecchio condiviso`,"dehumidifier.shared_available_hint":`Puoi impostare qui sotto il comfort di questa stanza senza aggiungere un altro apparecchio. La condivisione si modifica nella stanza ospitante.`,"dehumidifier.room_comfort":`Umidità in questa stanza`,"dehumidifier.tolerance_hint":`Tolleranza e priorità determinano quanto l’umidità può salire sopra il target prima di richiedere la deumidificazione. Un margine più ampio riduce gli avvii. La richiesta termina vicino al target.`,"dehumidifier.priority_comfort_hint":`Richiede l’avvio prima`,"dehumidifier.priority_balanced_hint":`Margine di umidità standard`,"dehumidifier.priority_energy_hint":`Consente una salita maggiore`,"dehumidifier.protections":`Protezioni dell’apparecchio e potenza`,"dehumidifier.timing_hint":`I tempi minimi acceso e spento limitano gli avvii ravvicinati. L’attesa da spento vale anche dopo un riavvio. Le protezioni possono interrompere il tempo minimo acceso.`,"dehumidifier.shared_device":`Apparecchio condiviso · stanze servite`,"dehumidifier.local_device":`Apparecchio dedicato · stanza servita`,"dehumidifier.device_details":`Target e protezione dell’apparecchio`,"dehumidifier.device_target_hint":`Per un apparecchio condiviso il target del dispositivo segue il limite di protezione della stanza ospitante. Può essere diverso dal target comfort di questa stanza: ogni stanza richiede la deumidificazione in base al proprio obiettivo.`,"dehumidifier.comfort_enabled":`Comfort attivo`,"dehumidifier.comfort_disabled":`Comfort disattivato`,"dehumidifier.measured":`Umidità misurata`,"dehumidifier.comfort_off_hint":`Questa stanza non richiede deumidificazione per il comfort. La prevenzione muffa continua a seguire le proprie impostazioni.`,"dehumidifier.status_pending":`Apparecchio associato. In attesa dello stato di funzionamento.`,"equipment.open":`Aperta`,"equipment.closed":`Chiusa`,"equipment.unavailable":`Non disponibile`,"devices.climate_entities":`Riscaldamento e climatizzazione`,"devices.temp_sensors":`Temperatura`,"devices.humidity_sensors":`Umidità`,"devices.occupancy_sensors":`Presenza`,"devices.window_sensors":`Finestre e porte`,"devices.window_open_delay":`Pausa dopo apertura`,"devices.window_close_delay":`Ripresa dopo chiusura`,"devices.heating_system_type":`Impianto di riscaldamento`,"devices.system_type_radiator":`Radiatori`,"devices.system_type_underfloor":`Riscaldamento a pavimento`,"room.outdoor_toggle":`Area esterna`,"room.outdoor_hint":`Contrassegna questa area come esterna per escluderla dal controllo del clima interno.`,"equipment.no_devices":`Nessun apparecchio di riscaldamento o climatizzazione associato.`,"equipment.no_sensors":`Associa i sensori per misurare le condizioni di questa stanza.`,"equipment.edit_devices":`Gestisci dispositivi`,"equipment.edit_sensors":`Gestisci sensori`,"dehumidifier.waiting_hint":`Pronto: l’apparecchio si avvia quando una stanza servita richiede deumidificazione, nel rispetto delle protezioni.`,"devices.idle_action_setback":`Mantenimento`,"devices.idle_action_low":`Potenza ridotta`,"devices.idle_action_fan_only":`Solo ventilazione`,"settings.boiler.min_demand_rooms":`Richieste necessarie per accendere la caldaia`,"settings.boiler.min_demand_hint":`Sotto questo numero, i radiatori che chiedono calore aspettano con le valvole chiuse. Una volta accesa, la caldaia resta accesa finché qualcosa chiede calore.`,"settings.boiler.min_run_minutes":`Accensione minima (min)`,"settings.boiler.min_off_minutes":`Spegnimento minimo (min)`,"settings.boiler.fault_retry_minutes":`Riprova dopo un blocco (min)`,"settings.boiler.child_lock":`Blocca i tasti della valvola di bypass`,"settings.boiler.child_lock_hint":`Attiva il blocco bambini della valvola, così una pressione dei tasti non toglie il bypass dal riscaldamento forzato e non ferma la caldaia.`,"settings.boiler.max_wait_minutes":`Attesa massima sotto il quorum (min)`,"settings.boiler.max_wait_hint":`Una stanza che chiede calore da così tanto accende la caldaia anche da sola, così le stanze con soli radiatori non restano fredde. 0 rende il quorum rigido.`,"comfort.profile_clear_hint":`Tocca di nuovo il profilo attivo, oppure "Nessun profilo", per tornare alla programmazione e alle temperature comfort/eco.`,"settings.boiler.demand_unit":`Conta le richieste per`,"settings.boiler.demand_unit_valves":`Valvole dei radiatori (una stanza con 2 radiatori vale 2)`,"settings.boiler.demand_unit_rooms":`Stanze`}};function S(e,t,n){let r=(vt[t]??vt[t.split(`-`)[0]]??vt.en)[e]??vt.en[e]??e;if(n)for(let[e,t]of Object.entries(n))r=r.replaceAll(`{${e}}`,String(t));return r}function yt(e,t){if(e.area_id)return e.area_id;if(e.device_id&&t){let n=t[e.device_id];if(n?.area_id)return n.area_id}return null}function bt(e,t,n){return t?Object.values(t).filter(t=>yt(t,n)===e):[]}function xt(e){switch(e){case`heating`:return`mode-heating`;case`cooling`:return`mode-cooling`;case`idle`:return`mode-idle`;default:return`mode-other`}}var St={heating:`mode.heating`,cooling:`mode.cooling`,idle:`mode.idle`};function Ct(e,t){return S(St[e],t)}var wt=l`
  .mode-pill {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 13px;
    font-weight: 500;
    padding: 4px 14px;
    border-radius: 16px;
  }

  .mode-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
  }

  .mode-heating {
    color: var(--warning-color, #ff9800);
    background: rgba(255, 152, 0, 0.12);
  }
  .mode-heating .mode-dot {
    background: var(--warning-color, #ff9800);
  }

  .mode-cooling {
    color: #2196f3;
    background: rgba(33, 150, 243, 0.12);
  }
  .mode-cooling .mode-dot {
    background: #2196f3;
  }

  .mode-idle {
    color: var(--secondary-text-color, #757575);
    background: rgba(0, 0, 0, 0.05);
  }
  .mode-idle .mode-dot {
    background: var(--disabled-text-color, #bdbdbd);
  }

  .mode-other {
    color: var(--secondary-text-color);
    background: rgba(0, 0, 0, 0.05);
  }
  .mode-other .mode-dot {
    background: var(--secondary-text-color);
  }
`,Tt=`M11.83,9L15,12.16C15,12.11 15,12.05 15,12A3,3 0 0,0 12,9C11.94,9 11.89,9 11.83,9M7.53,9.8L9.08,11.35C9.03,11.56 9,11.77 9,12A3,3 0 0,0 12,15C12.22,15 12.44,14.97 12.65,14.92L14.2,16.47C13.53,16.8 12.79,17 12,17A5,5 0 0,1 7,12C7,11.21 7.2,10.47 7.53,9.8M2,4.27L4.28,6.55L4.73,7C3.08,8.3 1.78,10 1,12C2.73,16.39 7,19.5 12,19.5C13.55,19.5 15.03,19.2 16.38,18.66L16.81,19.08L19.73,22L21,20.73L3.27,3M12,7A5,5 0 0,1 17,12C17,12.64 16.87,13.26 16.64,13.82L19.57,16.75C21.07,15.5 22.27,13.86 23,12C21.27,7.61 17,4.5 12,4.5C10.6,4.5 9.26,4.75 8,5.2L10.17,7.35C10.74,7.13 11.35,7 12,7Z`;function Et(e){return e.config?.unit_system?.temperature===`°F`}function C(e){return Et(e)?`°F`:`°C`}function w(e,t){return Et(t)?e*9/5+32:e}function T(e,t){return Et(t)?(e-32)*5/9:e}function Dt(e,t){return Et(t)?e*9/5:e}function E(e,t,n=1){return w(e,t).toFixed(n)}function D(e){return Et(e)?`1`:`0.5`}function O(e,t,n){return{min:String(Math.round(w(e,n))),max:String(Math.round(w(t,n)))}}function k(e,t,n,r){var i=arguments.length,a=i<3?t:r===null?r=Object.getOwnPropertyDescriptor(t,n):r,o;if(typeof Reflect==`object`&&typeof Reflect.decorate==`function`)a=Reflect.decorate(e,t,n,r);else for(var s=e.length-1;s>=0;s--)(o=e[s])&&(a=(i<3?o(a):i>3?o(t,n,a):o(t,n))||a);return i>3&&a&&Object.defineProperty(t,n,a),a}var A=t((()=>{}));_(),A();var j=class extends g{constructor(...e){super(...e),this.config=null,this.climateEntityCount=0,this.tempSensorCount=0,this.controlMode=`bangbang`,this.climateControlActive=!0,this.reordering=!1,this.canMoveUp=!1,this.canMoveDown=!1}static{this.styles=[wt,l`
      :host {
        display: block;
      }

      ha-card {
        cursor: pointer;
        transition:
          box-shadow 0.2s ease,
          transform 0.2s ease,
          border-color 0.2s ease;
        overflow: hidden;
        position: relative;
        height: 100%;
        box-sizing: border-box;
        --ha-card-border-radius: 18px;
        --ha-card-box-shadow: none;
        border: 1px solid var(--divider-color, rgba(128, 128, 128, 0.16));
      }

      ha-card:hover {
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.075);
        transform: translateY(-2px);
      }
      ha-card:focus-visible {
        outline: 2px solid var(--primary-color);
        outline-offset: 3px;
      }

      .hide-btn {
        --mdc-icon-button-size: 28px;
        --mdc-icon-size: 16px;
        color: var(--secondary-text-color);
        opacity: 0;
        transition: opacity 0.2s ease;
        position: absolute;
        top: 12px;
        right: 10px;
      }

      ha-card:hover .hide-btn {
        opacity: 0.4;
      }

      .hide-btn:hover {
        opacity: 1 !important;
      }
      @media (hover: none) {
        .hide-btn {
          opacity: 0.65;
        }
      }
      ha-card:focus-within .hide-btn {
        opacity: 1;
      }

      /* Colored left accent based on mode */
      .accent {
        position: absolute;
        left: 0;
        top: 0;
        right: 0;
        height: 3px;
      }

      .accent-heating {
        background: var(--warning-color, #ff9800);
      }

      .accent-cooling {
        background: #2196f3;
      }

      .accent-idle {
        background: var(--disabled-text-color, #bdbdbd);
      }

      .accent-unconfigured {
        background: transparent;
      }

      .card-inner {
        padding: 24px 22px 20px;
      }

      /* Header row: name + badge */
      .card-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
      }

      .card-status {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 6px;
        min-width: 0;
      }

      .area-name {
        font-size: 17px;
        font-weight: 700;
        color: var(--primary-text-color);
        margin: 0;
        letter-spacing: -0.025em;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        min-width: 0;
      }

      /* Card-specific mode-pill overrides (smaller than default) */
      .mode-pill {
        gap: 5px;
        font-size: 11px;
        font-weight: 650;
        padding: 5px 10px;
        border-radius: 999px;
      }

      .mode-dot {
        width: 7px;
        height: 7px;
      }

      /* Temperature display */
      .temp-section {
        display: flex;
        align-items: baseline;
        gap: 8px;
        margin: 23px 0 0 0;
        flex-wrap: wrap;
      }

      .current-temp {
        font-size: 46px;
        font-weight: 500;
        color: var(--primary-text-color);
        line-height: 1;
        font-variant-numeric: tabular-nums;
        letter-spacing: -0.05em;
      }

      .temp-unit {
        font-size: 18px;
        font-weight: 500;
        color: var(--secondary-text-color);
      }

      .target-info {
        font-size: 12px;
        color: var(--secondary-text-color);
        margin-left: auto;
        text-align: right;
        line-height: 1.45;
      }

      .target-value {
        font-weight: 500;
        color: var(--primary-text-color);
      }

      .override-icon {
        --mdc-icon-size: 14px;
        vertical-align: middle;
        margin-left: 4px;
        color: var(--warning-color, #ff9800);
      }

      .window-icon {
        --mdc-icon-size: 14px;
        vertical-align: middle;
        margin-left: 4px;
        color: var(--warning-color, #ff9800);
      }

      .away-icon {
        --mdc-icon-size: 14px;
        vertical-align: middle;
        margin-left: 4px;
        color: var(--info-color, #2196f3);
      }

      /* Footer row: humidity + MPC status */
      .card-footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 18px;
        min-height: 20px;
        padding-top: 14px;
        border-top: 1px solid var(--divider-color, rgba(128, 128, 128, 0.16));
        gap: 10px;
      }

      .humidity-info {
        font-size: 13px;
        color: var(--secondary-text-color);
      }

      .mpc-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        font-weight: 500;
        padding: 2px 8px 2px 6px;
        border-radius: 10px;
        --mdc-icon-size: 14px;
      }

      .mpc-badge.active {
        color: var(--success-color, #4caf50);
        background: rgba(76, 175, 80, 0.12);
      }

      .mpc-badge.learning {
        color: var(--secondary-text-color);
        background: rgba(158, 158, 158, 0.1);
      }

      .comfort-badge,
      .issue-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        font-weight: 500;
        padding: 2px 8px 2px 6px;
        border-radius: 10px;
        --mdc-icon-size: 14px;
        white-space: nowrap;
      }

      .comfort-badge.excellent,
      .comfort-badge.good {
        color: var(--success-color, #4caf50);
        background: rgba(76, 175, 80, 0.12);
      }

      .comfort-badge.fair {
        color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.12);
      }

      .comfort-badge.poor,
      .issue-badge {
        color: var(--error-color, #db4437);
        background: rgba(219, 68, 55, 0.12);
      }

      .mold-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        font-weight: 500;
        padding: 2px 8px 2px 6px;
        border-radius: 10px;
        --mdc-icon-size: 14px;
      }

      .mold-badge.warning {
        color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.12);
      }

      .mold-badge.critical {
        color: var(--error-color, #db4437);
        background: rgba(219, 68, 55, 0.12);
      }

      .mold-badge.prevention {
        color: var(--info-color, #2196f3);
        background: rgba(33, 150, 243, 0.12);
      }

      .outdoor-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        font-weight: 500;
        padding: 2px 8px 2px 6px;
        border-radius: 10px;
        --mdc-icon-size: 14px;
        color: var(--success-color, #4caf50);
        background: rgba(76, 175, 80, 0.12);
      }

      .badge-row {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
        justify-content: flex-end;
      }

      .no-temp {
        font-size: 24px;
        font-weight: 300;
        color: var(--secondary-text-color);
        line-height: 1;
      }

      .uncontrolled-hint {
        font-size: 11px;
        color: var(--disabled-text-color, #9e9e9e);
        margin-top: 6px;
      }

      .reorder-overlay {
        position: absolute;
        inset: 0;
        z-index: 2;
        display: flex;
        pointer-events: none;
        border-radius: inherit;
        overflow: hidden;
      }

      .reorder-half {
        pointer-events: auto;
        flex: 0 0 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: background 0.15s ease;
        background: rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.05);
      }

      .reorder-half.left {
        border-radius: inherit;
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        border-right: 1px solid rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.08);
      }

      .reorder-half.right {
        border-radius: inherit;
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
        border-left: 1px solid rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.08);
        margin-left: auto;
      }

      .reorder-half:hover {
        background: rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.1);
      }

      .reorder-half ha-icon-button {
        --mdc-icon-button-size: 36px;
        --mdc-icon-size: 20px;
        color: var(--secondary-text-color);
        pointer-events: none;
      }

      .reorder-half:hover ha-icon-button {
        color: var(--primary-text-color);
      }

      .reorder-half.disabled {
        opacity: 0.25;
        cursor: default;
      }

      .reorder-half.disabled:hover {
        background: rgba(var(--rgb-primary-text-color, 0, 0, 0), 0.05);
      }

      /* Device summary for unconfigured cards */
      .device-summary {
        font-size: 13px;
        color: var(--secondary-text-color);
        margin-top: 8px;
      }

      .device-summary.empty {
        color: var(--disabled-text-color, #9e9e9e);
        font-style: italic;
      }

      /* Configure prompt for unconfigured areas */
      .configure-prompt {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid var(--divider-color, #eee);
      }

      .configure-text {
        font-size: 13px;
        color: var(--secondary-text-color);
      }

      .configure-arrow {
        font-size: 18px;
        color: var(--primary-color);
      }

      /* Waiting state */
      .waiting {
        font-size: 13px;
        color: var(--disabled-text-color, #9e9e9e);
        font-style: italic;
        margin-top: 8px;
      }
    `]}render(){let e=this.climateEntityCount>0,t=(this.config?.devices?.length??0)>0||(this.config?.thermostats?.length??0)>0||(this.config?.acs?.length??0)>0,n=this.config?.is_outdoor??!1,r=this.config!==null&&t&&!n,i=this.config?.live,a=i?.mode,o=(!r||n)&&i&&(i.current_temp!==null||i.current_humidity!==null),s=r?a===`heating`?`accent-heating`:a===`cooling`?`accent-cooling`:`accent-idle`:o?`accent-idle`:`accent-unconfigured`;return m`
      <ha-card
        role="button"
        tabindex="0"
        aria-label=${this.config?.display_name||this.area.name}
        @click=${this._onCardClick}
        @keydown=${this._onCardKeydown}
      >
        <div class="accent ${s}"></div>
        ${this.reordering?h:m`<ha-icon-button
              class="hide-btn"
              .path=${Tt}
              title=${S(`panel.hidden_rooms`,this.hass.language)}
              aria-label=${S(`panel.hidden_rooms`,this.hass.language)}
              @click=${this._onHideClick}
            ></ha-icon-button>`}
        ${this.reordering?m`<div class="reorder-overlay">
              <div
                class="reorder-half left ${this.canMoveUp?``:`disabled`}"
                @click=${this._onMoveUp}
              >
                <ha-icon-button
                  .path=${`M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z`}
                ></ha-icon-button>
              </div>
              <div
                class="reorder-half right ${this.canMoveDown?``:`disabled`}"
                @click=${this._onMoveDown}
              >
                <ha-icon-button
                  .path=${`M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z`}
                ></ha-icon-button>
              </div>
            </div>`:h}
        <div class="card-inner">
          <div class="card-header">
            <h3 class="area-name">${this.config?.display_name||this.area.name}</h3>
            <span class="card-status">
              ${r&&i&&i.comfort_score&&(i.comfort_score.label===`poor`||i.comfort_score.label===`fair`)?this._renderComfortScore(i):h}
              ${r&&i?m`
                    <span class="mode-pill ${xt(i.mode)}">
                      <span class="mode-dot"></span>
                      ${Ct(i.mode,this.hass.language)}${i.heating_power>0&&i.heating_power<100?m` ${i.heating_power}%`:h}
                    </span>
                  `:h}
            </span>
          </div>

          ${r?this._renderConfigured():this.config?.live&&(this.config.live.current_temp!==null||this.config.live.current_humidity!==null)?this._renderSensorOnly():this._renderUnconfigured(e)}
        </div>
      </ha-card>
    `}_renderConfigured(){let e=this.config?.live;if(!e)return m`<div class="waiting">${S(`card.waiting`,this.hass.language)}</div>`;let t=this.controlMode===`mpc`&&!e.mpc_active;return m`
      <div class="temp-section">
        ${e.current_temp===null?m`<span class="no-temp">--</span>`:m`
              <span class="current-temp">${E(e.current_temp,this.hass)}</span>
              <span class="temp-unit">${C(this.hass)}</span>
            `}
        ${this._renderTargetInfo(e)}
      </div>
      <div class="card-footer">
        <span class="humidity-info">
          ${e.current_humidity===null?h:S(`card.humidity`,this.hass.language,{value:e.current_humidity.toFixed(0)})}
        </span>
        <span class="badge-row">
          ${this._renderIssueStatus(e)}
          ${e.mold_risk_level&&e.mold_risk_level!==`ok`?m`<span class="mold-badge ${e.mold_risk_level}">
                <ha-icon icon="mdi:water-alert"></ha-icon>
                ${e.mold_risk_level===`critical`?S(`card.mold_critical`,this.hass.language):S(`card.mold_warning`,this.hass.language)}
              </span>`:h}
          ${e.mold_prevention_active?m`<span class="mold-badge prevention">
                <ha-icon icon="mdi:shield-check"></ha-icon>
                ${S(`card.mold_prevention`,this.hass.language)}
              </span>`:h}
          ${t?m`<span class="mpc-badge ${e.mpc_active?`active`:`learning`}">
                <ha-icon .icon=${e.mpc_active?`mdi:brain`:`mdi:school-outline`}></ha-icon>
                ${e.mpc_active?S(`card.mpc_active`,this.hass.language):S(`card.mpc_learning`,this.hass.language)}
              </span>`:h}
        </span>
      </div>
      ${this.climateControlActive&&this.config?.climate_control_enabled===!1?m`<div class="uncontrolled-hint">
            ${S(`card.not_controlled`,this.hass.language)}
          </div>`:h}
    `}_renderComfortScore(e){let t=e.comfort_score;return m`
      ${t?m`<span
            class="comfort-badge ${t.label}"
            title=${S(`card.comfort_${t.label}`,this.hass.language)}
          >
            <ha-icon
              icon=${t.label===`excellent`||t.label===`good`?`mdi:heart`:`mdi:heart-half-full`}
            ></ha-icon>
            ${S(`card.comfort_score`,this.hass.language,{score:t.score})}
          </span>`:h}
    `}_renderIssueStatus(e){let t=e.anomalies??[];return m`
      ${t.length?m`<span
            class="issue-badge"
            title=${S(`card.issues`,this.hass.language,{count:t.length})}
          >
            <ha-icon icon="mdi:alert-circle"></ha-icon>${t.length}
          </span>`:h}
    `}_renderTargetInfo(e){if(e.target_temp===null&&e.heat_target===null)return h;let t=(this.config?.climate_mode??`auto`)===`auto`&&e.heat_target!=null&&e.cool_target!=null&&e.heat_target!==e.cool_target?m`<span class="target-value"
          >${E(e.heat_target,this.hass)} –
          ${E(e.cool_target,this.hass)}${C(this.hass)}</span
        >`:m`<span class="target-value"
          >${E(e.target_temp??e.heat_target,this.hass)}${C(this.hass)}</span
        >`;return m`
      <span class="target-info">
        ${S(`card.target`,this.hass.language)} ${t}
        ${e.override_active?m`<ha-icon class="override-icon" icon="mdi:timer-outline"></ha-icon>`:h}
        ${e.window_open?m`<ha-icon class="window-icon" icon="mdi:window-open-variant"></ha-icon>`:h}
        ${e.presence_away?m`<ha-icon class="away-icon" icon="mdi:home-off-outline"></ha-icon>`:h}
      </span>
    `}_renderSensorOnly(){let e=this.config.live,t=this.config?.is_outdoor??!1;return m`
      <div class="temp-section">
        ${e.current_temp===null?m`<span class="no-temp">--</span>`:m`
              <span class="current-temp">${E(e.current_temp,this.hass)}</span>
              <span class="temp-unit">${C(this.hass)}</span>
            `}
      </div>
      <div class="card-footer">
        <span class="humidity-info">
          ${e.current_humidity===null?h:S(`card.humidity`,this.hass.language,{value:e.current_humidity.toFixed(0)})}
        </span>
        <span class="badge-row">
          ${t?m`<span class="outdoor-badge">
                <ha-icon icon="mdi:tree"></ha-icon>
                ${S(`card.outdoor`,this.hass.language)}
              </span>`:h}
          ${e.mold_risk_level&&e.mold_risk_level!==`ok`?m`<span class="mold-badge ${e.mold_risk_level}">
                <ha-icon icon="mdi:water-alert"></ha-icon>
                ${e.mold_risk_level===`critical`?S(`card.mold_critical`,this.hass.language):S(`card.mold_warning`,this.hass.language)}
              </span>`:h}
        </span>
      </div>
    `}_renderUnconfigured(e){let t=this.hass.language;if(!e)return m`<div class="device-summary empty">${S(`card.no_climate`,t)}</div>`;let n=this.climateEntityCount,r=this.tempSensorCount;return m`
      <div class="device-summary">
        ${n}
        ${S(n===1?`card.climate_device`:`card.climate_devices`,t)}${r>0?` \u00B7 ${r} ${S(r===1?`card.temp_sensor`:`card.temp_sensors`,t)}`:``}
      </div>
      <div class="configure-prompt">
        <span class="configure-text">${S(`card.tap_configure`,t)}</span>
        <span class="configure-arrow">›</span>
      </div>
    `}_onCardClick(){this.dispatchEvent(new CustomEvent(`area-selected`,{detail:{areaId:this.area.area_id},bubbles:!0,composed:!0}))}_onCardKeydown(e){e.target!==e.currentTarget||e.key!==`Enter`&&e.key!==` `||(e.preventDefault(),this._onCardClick())}_onMoveUp(e){e.stopPropagation(),this.canMoveUp&&this.dispatchEvent(new CustomEvent(`move-room-up`,{detail:{areaId:this.area.area_id},bubbles:!0,composed:!0}))}_onMoveDown(e){e.stopPropagation(),this.canMoveDown&&this.dispatchEvent(new CustomEvent(`move-room-down`,{detail:{areaId:this.area.area_id},bubbles:!0,composed:!0}))}_onHideClick(e){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`hide-room`,{detail:{areaId:this.area.area_id},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],j.prototype,`area`,void 0),k([y({attribute:!1})],j.prototype,`config`,void 0),k([y({type:Number})],j.prototype,`climateEntityCount`,void 0),k([y({type:Number})],j.prototype,`tempSensorCount`,void 0),k([y({attribute:!1})],j.prototype,`hass`,void 0),k([y({type:String})],j.prototype,`controlMode`,void 0),k([y({type:Boolean})],j.prototype,`climateControlActive`,void 0),k([y({type:Boolean})],j.prototype,`reordering`,void 0),k([y({type:Boolean})],j.prototype,`canMoveUp`,void 0),k([y({type:Boolean})],j.prototype,`canMoveDown`,void 0),j=k([v(`rs-area-card`)],j);var Ot={ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},kt=e=>(...t)=>({_$litDirective$:e,values:t}),At=class{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,n){this._$Ct=e,this._$AM=t,this._$Ci=n}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}};$e();var jt=class extends At{constructor(e){if(super(e),this.it=h,e.type!==Ot.CHILD)throw Error(this.constructor.directiveName+`() can only be used in child bindings`)}render(e){if(e===h||e==null)return this._t=void 0,this.it=e;if(e===ze)return e;if(typeof e!=`string`)throw Error(this.constructor.directiveName+`() called with a non-string value`);if(e===this.it)return this._t;this.it=e;let t=[e];return t.raw=t,this._t={_$litType$:this.constructor.resultType,strings:t,values:[]}}};jt.directiveName=`unsafeHTML`,jt.resultType=1;var M=kt(jt);_(),x(),A();var Mt=class extends g{constructor(...e){super(...e),this.text=``,this.icon=`mdi:information-outline`,this._open=!1,this._style=`visibility: hidden;`,this._onDocPointer=e=>{e.composedPath().includes(this)||this._close()},this._onKey=e=>{e.key===`Escape`&&(e.stopPropagation(),this._close())},this._onScroll=()=>this._close()}disconnectedCallback(){super.disconnectedCallback(),this._removeListeners()}static{this.styles=l`
    :host {
      display: inline-flex;
      position: relative;
      vertical-align: middle;
      line-height: 0;
    }

    button {
      background: none;
      border: none;
      padding: 2px;
      margin: 0;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      color: var(--secondary-text-color);
      opacity: 0.65;
      transition:
        opacity 0.15s,
        color 0.15s,
        background 0.15s;
      border-radius: 50%;
      line-height: 0;
    }

    button:hover,
    button:focus-visible {
      opacity: 1;
      color: var(--primary-color);
      background: rgba(3, 169, 244, 0.1);
      outline: none;
    }

    button.open {
      opacity: 1;
      color: var(--primary-color);
      background: rgba(3, 169, 244, 0.12);
    }

    ha-icon {
      --mdc-icon-size: 16px;
    }

    .tooltip {
      position: fixed;
      z-index: 1100;
      max-width: 280px;
      min-width: 180px;
      width: max-content;
      padding: 10px 12px;
      background: var(--card-background-color, #1f1f1f);
      border: 1px solid var(--divider-color, rgba(255, 255, 255, 0.12));
      border-radius: 8px;
      font-size: 12px;
      font-weight: 400;
      line-height: 1.5;
      letter-spacing: normal;
      text-transform: none;
      color: var(--primary-text-color);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
      white-space: normal;
      pointer-events: auto;
      animation: tooltip-fade 0.15s ease-out;
    }

    @keyframes tooltip-fade {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }
  `}render(){return m`
      <button
        type="button"
        class=${this._open?`open`:``}
        @click=${this._toggle}
        aria-label="Info"
        aria-expanded=${this._open?`true`:`false`}
      >
        <ha-icon .icon=${this.icon}></ha-icon>
      </button>
      ${this._open?m`<div
            class="tooltip"
            role="tooltip"
            style=${this._style}
            @click=${e=>e.stopPropagation()}
          >
            ${this.text?this.text:h}<slot></slot>
          </div>`:h}
    `}_toggle(e){e.stopPropagation(),this._open?this._close():this._openTooltip()}_openTooltip(){this._open=!0,this._style=`visibility: hidden;`,requestAnimationFrame(()=>{this._positionTooltip()}),setTimeout(()=>{document.addEventListener(`pointerdown`,this._onDocPointer,!0),document.addEventListener(`keydown`,this._onKey,!0),document.addEventListener(`scroll`,this._onScroll,!0),window.addEventListener(`resize`,this._onScroll,!0)},0)}_positionTooltip(){let e=this.renderRoot.querySelector(`.tooltip`),t=this.renderRoot.querySelector(`button`);if(!e||!t)return;let n=t.getBoundingClientRect(),r=e.getBoundingClientRect(),i=window.innerWidth,a=window.innerHeight,o=a-n.bottom,s=n.top,c;c=o>=r.height+8?n.bottom+6:s>=r.height+8?n.top-r.height-6:Math.max(8,(a-r.height)/2);let l=n.left+n.width/2-r.width/2;l=Math.max(8,Math.min(l,i-r.width-8)),this._style=`top: ${c}px; left: ${l}px;`}_close(){this._open&&(this._open=!1,this._style=`visibility: hidden;`,this._removeListeners())}_removeListeners(){document.removeEventListener(`pointerdown`,this._onDocPointer,!0),document.removeEventListener(`keydown`,this._onKey,!0),document.removeEventListener(`scroll`,this._onScroll,!0),window.removeEventListener(`resize`,this._onScroll,!0)}};k([y({type:String})],Mt.prototype,`text`,void 0),k([y({type:String})],Mt.prototype,`icon`,void 0),k([b()],Mt.prototype,`_open`,void 0),k([b()],Mt.prototype,`_style`,void 0),Mt=k([v(`rs-info-icon`)],Mt),_(),x(),A();var Nt=`M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z`,Pt=`M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z`,N=class extends g{constructor(...e){super(...e),this.config=null,this.climateControlActive=!0,this.isOutdoor=!1,this.overrideInfo=null,this._countdown=``,this._editingName=!1,this._nameInput=``,this._controlModeInfoExpanded=!1}static{this.styles=[wt,l`
      :host {
        display: block;
      }

      ha-card {
        padding: 30px 30px 26px;
        position: relative;
        overflow: hidden;
        --ha-card-border-radius: 22px;
        --ha-card-box-shadow: none;
        border: 1px solid var(--divider-color, rgba(128, 128, 128, 0.16));
      }

      .hero-accent {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
      }

      .hero-accent-heating {
        background: linear-gradient(90deg, var(--warning-color, #ff9800), #ffb74d);
      }

      .hero-accent-cooling {
        background: linear-gradient(90deg, #2196f3, #64b5f6);
      }

      .hero-accent-idle {
        background: linear-gradient(90deg, var(--disabled-text-color, #bdbdbd), #e0e0e0);
      }

      .hero-accent-none {
        background: var(--divider-color, #e0e0e0);
      }

      .hero-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 16px;
      }

      .area-name {
        font-size: clamp(21px, 3vw, 27px);
        font-weight: 750;
        letter-spacing: -0.035em;
        color: var(--primary-text-color);
        margin: 0;
      }

      .hero-temps {
        display: flex;
        align-items: baseline;
        gap: 9px;
        flex-wrap: wrap;
      }

      .hero-current {
        font-size: clamp(48px, 5vw, 64px);
        font-weight: 450;
        color: var(--primary-text-color);
        line-height: 1;
        letter-spacing: -0.055em;
        font-variant-numeric: tabular-nums;
      }

      .hero-unit {
        font-size: 22px;
        font-weight: 500;
        color: var(--secondary-text-color);
      }

      .hero-target {
        margin-left: auto;
        text-align: right;
        min-width: 0;
      }

      .hero-target-label {
        font-size: 12px;
        color: var(--secondary-text-color);
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }

      .hero-target-value {
        font-size: 23px;
        font-weight: 650;
        letter-spacing: -0.025em;
        color: var(--primary-text-color);
      }

      /* Override-aware target styling */
      .hero-target-label.override-boost {
        color: var(--warning-color, #ff9800);
      }

      .hero-target-label.override-eco {
        color: #4caf50;
      }

      .hero-target-label.override-custom {
        color: #2196f3;
      }

      .hero-target-label ha-icon {
        --mdc-icon-size: 12px;
        vertical-align: middle;
      }

      .hero-target-countdown {
        font-size: 11px;
        color: var(--secondary-text-color);
        margin-top: 2px;
      }

      .hero-metric {
        display: flex;
        align-items: center;
        gap: 4px;
        font-size: 14px;
        color: var(--secondary-text-color);
        margin-top: 6px;
      }

      .hero-metric ha-icon {
        --mdc-icon-size: 16px;
        flex-shrink: 0;
      }

      .hero-metric.warning {
        color: var(--warning-color, #ff9800);
      }

      .hero-metric.critical {
        color: var(--error-color, #db4437);
      }

      .hero-metric.info {
        color: var(--info-color, #2196f3);
      }

      .hero-no-data {
        font-size: 14px;
        color: var(--disabled-text-color, #9e9e9e);
        font-style: italic;
        padding: 8px 0;
      }

      .hero-window-open {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 10px;
        margin-bottom: 12px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 500;
        color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.1);
      }

      .hero-window-open ha-icon {
        --mdc-icon-size: 18px;
      }

      .name-row {
        display: flex;
        align-items: center;
        gap: 4px;
      }

      .name-edit-btn {
        --mdc-icon-button-size: 28px;
        --mdc-icon-size: 16px;
        color: var(--secondary-text-color);
        opacity: 0;
        transition: opacity 0.15s;
      }

      .name-row:hover .name-edit-btn {
        opacity: 1;
      }

      @media (hover: none) {
        .name-edit-btn {
          opacity: 0.5;
        }
      }

      .name-edit-row {
        display: flex;
        align-items: center;
        gap: 4px;
      }

      .name-input {
        font-size: 22px;
        font-weight: 400;
        color: var(--primary-text-color);
        background: transparent;
        border: none;
        border-bottom: 2px solid var(--primary-color);
        outline: none;
        padding: 0 0 2px;
        width: 100%;
        font-family: inherit;
      }

      .name-done-btn {
        --mdc-icon-button-size: 28px;
        --mdc-icon-size: 16px;
        color: var(--primary-color);
      }

      .name-clear-btn {
        background: none;
        border: none;
        color: var(--secondary-text-color);
        font-size: 12px;
        cursor: pointer;
        padding: 2px 0;
        text-decoration: underline;
      }

      .hero-status-pills {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 2px;
        flex-shrink: 0;
      }
      @media (max-width: 550px) {
        ha-card {
          padding: 23px 19px 22px;
        }
        .hero-header {
          gap: 10px;
          align-items: flex-start;
        }
        .hero-status-pills {
          gap: 6px;
        }
        .hero-current {
          font-size: 48px;
        }
        .hero-target-value {
          font-size: 19px;
        }
      }
      .control-mode-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 11px;
        color: var(--secondary-text-color);
        cursor: pointer;
      }
      .control-mode-info-icon {
        --mdc-icon-size: 14px;
        opacity: 0.4;
      }
      .control-mode-badge:hover .control-mode-info-icon,
      .control-mode-info-icon.active {
        opacity: 0.8;
      }
      .control-mode-info-panel {
        padding: 8px 12px;
        margin-bottom: 8px;
        font-size: 12px;
        line-height: 1.5;
        color: var(--secondary-text-color);
        background: var(--secondary-background-color);
        border-radius: 8px;
      }

      .learning-paused rs-info-icon {
        margin-left: 2px;
      }

      .uncontrolled-hint {
        font-size: 12px;
        color: var(--disabled-text-color, #9e9e9e);
        margin-top: 8px;
      }
    `]}disconnectedCallback(){super.disconnectedCallback(),this._clearCountdownTimer()}updated(e){(e.has(`overrideInfo`)||e.has(`config`))&&this._updateCountdown()}_clearCountdownTimer(){this._countdownTimer&&=(clearInterval(this._countdownTimer),void 0)}_getOverrideUntil(){return this.overrideInfo?.active?this.overrideInfo.until:null}_updateCountdown(){if(this._clearCountdownTimer(),!this._getOverrideUntil()){let e=this._getEffectiveOverride();this._countdown=e?S(`hero.permanent`,this.hass?.language??`en`):``;return}let e=()=>{let e=this._getOverrideUntil();if(!e){this._countdown=``,this._clearCountdownTimer();return}let t=e-Date.now()/1e3;if(t<=0){this._countdown=``,this._clearCountdownTimer();return}let n=Math.floor(t/3600),r=Math.floor(t%3600/60);this._countdown=n>0?`${n}h ${r}m`:`${r}m`};e(),this._countdownTimer=setInterval(e,3e4)}_getEffectiveOverride(){return this.overrideInfo?.active?this.overrideInfo:null}_renderTargetSection(e){let t=e.target_temp,n=this.hass?.language??`en`,r=this._getEffectiveOverride();if(r){let e=r.type===`boost`?`mdi:fire`:r.type===`eco`?`mdi:leaf`:`mdi:thermometer`,i=r.type===`boost`?S(`override.comfort`,n):r.type===`eco`?S(`override.eco`,n):S(`override.custom`,n),a=`override-${r.type}`,o=r.heat,s=r.cool,c=o!=null&&s!=null&&o!==s,l=o??s??t;return m`
        <div class="hero-target">
          <div class="hero-target-label ${a}">
            <ha-icon icon=${e}></ha-icon>
            ${i} ${S(`hero.override`,n)}
          </div>
          <div class="hero-target-value">
            ${c?m`${E(o,this.hass)} –
                ${E(s,this.hass)}${C(this.hass)}`:l===null?`--`:m`${E(l,this.hass)}${C(this.hass)}`}
          </div>
          ${this._countdown?m`<div class="hero-target-countdown">
                ${S(`hero.remaining`,n,{time:this._countdown})}
              </div>`:h}
        </div>
      `}if(t!==null||e.heat_target!=null&&e.cool_target!=null){let r=(this.config?.climate_mode??`auto`)===`auto`&&e.heat_target!=null&&e.cool_target!=null&&e.heat_target!==e.cool_target?m`${E(e.heat_target,this.hass)} –
          ${E(e.cool_target,this.hass)}${C(this.hass)}`:m`${E(t??e.heat_target,this.hass)}${C(this.hass)}`;return m`
        <div class="hero-target">
          <div class="hero-target-label">${S(`hero.target`,n)}</div>
          <div class="hero-target-value">${r}</div>
        </div>
      `}return h}_toggleControlModeInfo(){this._controlModeInfoExpanded=!this._controlModeInfoExpanded}_onEditName(){this._nameInput=this.config?.display_name||``,this._editingName=!0,this.updateComplete.then(()=>{let e=this.renderRoot.querySelector(`.name-input`);e?.focus(),e?.select()})}_onNameInput(e){this._nameInput=e.target.value}_onNameKeydown(e){e.key===`Enter`?this._onNameDone():e.key===`Escape`&&(this._editingName=!1)}_onNameDone(){let e=this._nameInput.trim();this.dispatchEvent(new CustomEvent(`display-name-changed`,{detail:{value:e},bubbles:!0,composed:!0})),this._editingName=!1}_onNameClear(){this.dispatchEvent(new CustomEvent(`display-name-changed`,{detail:{value:``},bubbles:!0,composed:!0})),this._editingName=!1,this._nameInput=``}render(){let e=this.config?.live,t=e?.mode;return m`
      <ha-card>
        <div class="hero-accent ${e?t===`heating`?`hero-accent-heating`:t===`cooling`?`hero-accent-cooling`:`hero-accent-idle`:`hero-accent-none`}"></div>
        <div class="hero-header">
          ${this._editingName?m`
                <div class="name-edit-row">
                  <input
                    class="name-input"
                    type="text"
                    .value=${this._nameInput}
                    placeholder=${S(`room.alias.placeholder`,this.hass?.language??`en`)}
                    @input=${this._onNameInput}
                    @keydown=${this._onNameKeydown}
                  />
                  <ha-icon-button
                    class="name-done-btn"
                    .path=${Pt}
                    @click=${this._onNameDone}
                  ></ha-icon-button>
                </div>
                ${this.config?.display_name?m`<button class="name-clear-btn" @click=${this._onNameClear}>
                      ${S(`room.alias.clear`,this.hass?.language??`en`)}
                    </button>`:h}
              `:m`
                <div class="name-row">
                  <h2 class="area-name">${this.config?.display_name||this.area.name}</h2>
                  <ha-icon-button
                    class="name-edit-btn"
                    .path=${Nt}
                    @click=${this._onEditName}
                  ></ha-icon-button>
                </div>
              `}
          ${this.isOutdoor?h:m`
                <div class="hero-status-pills">
                  ${e?m`
                        <span class="mode-pill ${xt(e.mode)}">
                          <span class="mode-dot"></span>
                          ${Ct(e.mode,this.hass?.language??`en`)}${e.heating_power>0&&e.heating_power<100?m` ${e.heating_power}%`:h}
                        </span>
                      `:h}
                  ${this.config?m`
                        <span class="control-mode-badge" @click=${this._toggleControlModeInfo}>
                          ${this.config.temperature_sensor?S(`room.control_mode.full_control`,this.hass?.language??`en`):S(`room.control_mode.managed`,this.hass?.language??`en`)}
                          <ha-icon
                            class="control-mode-info-icon ${this._controlModeInfoExpanded?`active`:``}"
                            icon="mdi:information-outline"
                          ></ha-icon>
                        </span>
                      `:h}
                </div>
              `}
        </div>
        ${this._controlModeInfoExpanded&&this.config&&!this.isOutdoor?m`
              <div class="control-mode-info-panel">
                ${this.config.temperature_sensor?S(`room.control_mode.full_control_info`,this.hass?.language??`en`):S(`room.control_mode.managed_info`,this.hass?.language??`en`)}
              </div>
            `:h}
        ${e?m`
              ${e.window_open&&!this.isOutdoor?m`<div class="hero-window-open">
                    <ha-icon icon="mdi:window-open-variant"></ha-icon>
                    ${e.window_open_minutes!=null&&e.window_impact_c!=null?S(`hero.window_impact`,this.hass?.language??`en`,{minutes:String(e.window_open_minutes),impact:`${e.window_impact_c>=0?`+`:``}${e.window_impact_c.toFixed(1)}`,unit:C(this.hass)}):S(`hero.window_open`,this.hass?.language??`en`)}
                  </div>`:h}
              ${e.window_open&&e.window_recovery_minutes!=null&&!this.isOutdoor?m`<div class="hero-metric info">
                    <ha-icon icon="mdi:clock-fast"></ha-icon>
                    ${S(`hero.window_recovery`,this.hass?.language??`en`,{minutes:String(e.window_recovery_minutes)})}
                  </div>`:h}
              <div class="hero-temps">
                ${e.current_temp===null?m`<span class="hero-current" style="opacity: 0.3">--</span>`:m`
                      <span class="hero-current">${E(e.current_temp,this.hass)}</span>
                      <span class="hero-unit">${C(this.hass)}</span>
                    `}
                ${this.isOutdoor?h:this._renderTargetSection(e)}
              </div>
              ${e.current_humidity===null?h:m`<div class="hero-metric">
                    <ha-icon icon="mdi:water-percent"></ha-icon>
                    ${S(`hero.humidity`,this.hass?.language??`en`,{value:e.current_humidity.toFixed(0)})}
                  </div>`}
              ${e.device_setpoint!=null&&!this.isOutdoor?m`<div class="hero-metric">
                    <ha-icon
                      icon=${e.mode===`cooling`?`mdi:snowflake`:`mdi:radiator`}
                    ></ha-icon>
                    ${S(`hero.device_setpoint`,this.hass?.language??`en`,{value:E(e.device_setpoint,this.hass),unit:C(this.hass)})}
                  </div>`:h}
              ${e.active_heat_sources&&e.active_heat_sources!==`none`&&!this.isOutdoor?m`<div class="hero-metric">
                    <ha-icon icon="mdi:swap-horizontal"></ha-icon>
                    ${e.active_heat_sources===`primary`?S(`hero.heat_source_primary`,this.hass?.language??`en`):e.active_heat_sources===`secondary`?S(`hero.heat_source_secondary`,this.hass?.language??`en`):S(`hero.heat_source_both`,this.hass?.language??`en`)}
                  </div>`:h}
              ${e.compressor_protection_active&&!this.isOutdoor?m`<div class="hero-metric info">
                    <ha-icon icon="mdi:timer-sand"></ha-icon>
                    ${e.compressor_protection_reason===`min_run`?S(`hero.compressor_protection_min_run`,this.hass?.language??`en`):S(`hero.compressor_protection_min_off`,this.hass?.language??`en`)}
                    <rs-info-icon
                      icon="mdi:information-outline"
                      .text=${S(`hero.compressor_protection_info`,this.hass?.language??`en`)}
                    ></rs-info-icon>
                  </div>`:h}
              ${e.power_budget_blocked&&!this.isOutdoor?m`<div class="hero-metric warning">
                    <ha-icon icon="mdi:flash-alert"></ha-icon>
                    ${S(`hero.power_budget_blocked`,this.hass?.language??`en`)}
                  </div>`:h}
              ${e.preconditioning_active&&!this.isOutdoor?m`<div class="hero-metric info">
                    <ha-icon icon="mdi:calendar-clock"></ha-icon>
                    ${S(`hero.preconditioning_active`,this.hass?.language??`en`)}
                  </div>`:e.preconditioning_planned_at&&e.preconditioning_planned_at>Date.now()/1e3?m`<div class="hero-metric info">
                      <ha-icon icon="mdi:calendar-clock"></ha-icon>
                      ${S(`hero.preconditioning_planned`,this.hass?.language??`en`,{time:new Intl.DateTimeFormat(this.hass?.language??`en`,{hour:`2-digit`,minute:`2-digit`}).format(new Date(e.preconditioning_planned_at*1e3))})}
                    </div>`:h}
              ${e.ac_efficiency_status===`possible_issue`&&!this.isOutdoor?m`<div class="hero-metric warning">
                    <ha-icon icon="mdi:air-filter"></ha-icon>
                    ${S(`hero.ac_efficiency_issue`,this.hass?.language??`en`)}
                  </div>`:h}
              ${e.mold_surface_rh!=null&&!this.isOutdoor?m`<div
                    class="hero-metric ${e.mold_risk_level===`critical`?`critical`:e.mold_risk_level===`warning`?`warning`:``}"
                  >
                    <ha-icon icon="mdi:water-alert"></ha-icon>
                    ${S(`room.mold_surface_rh`,this.hass?.language??`en`,{value:String(e.mold_surface_rh.toFixed(0))})}
                  </div>`:h}
              ${e.mold_prevention_active&&!this.isOutdoor?m`<div class="hero-metric info">
                    <ha-icon icon="mdi:shield-check"></ha-icon>
                    ${S(e.mold_prevention_strategy===`dehumidifier`?`dehumidifier.request_mold`:`card.mold_prevention`,this.hass?.language??`en`)}
                  </div>`:h}
              ${e.learning_paused_reason===`outdoor_unavailable`&&!this.isOutdoor?m`<div class="hero-metric warning learning-paused">
                    <ha-icon icon="mdi:school-outline"></ha-icon>
                    ${S(`hero.mpc_learning_paused`,this.hass?.language??`en`)}
                    <rs-info-icon
                      icon="mdi:information-outline"
                      .text=${S(`hero.mpc_learning_paused.outdoor_unavailable`,this.hass?.language??`en`)}
                    ></rs-info-icon>
                  </div>`:h}
              ${this.config?.temperature_sensor&&e.current_temp===null&&!this.isOutdoor?m`<div class="hero-metric warning">
                    <ha-icon icon="mdi:thermometer-alert"></ha-icon>
                    ${S(`hero.temperature_sensor_unavailable`,this.hass?.language??`en`)}
                  </div>`:h}
              ${e.confidence!=null&&e.confidence<.5&&!e.mpc_active&&!this.isOutdoor?m`<div class="hero-metric info">
                    <ha-icon icon="mdi:school-outline"></ha-icon>
                    ${S(`hero.mpc_learning_progress`,this.hass?.language??`en`,{confidence:String(Math.round(e.confidence*100))})}
                  </div>`:h}
              ${!this.climateControlActive&&!this.isOutdoor?m`<div class="uncontrolled-hint">
                    ${S(`card.not_controlled`,this.hass?.language??`en`)}
                  </div>`:h}
            `:this.config?m`<div class="hero-no-data">
                ${S(`hero.waiting`,this.hass?.language??`en`)}
              </div>`:m`<div class="hero-no-data">
                ${S(`hero.not_configured`,this.hass?.language??`en`)}
              </div>`}
      </ha-card>
    `}};k([y({attribute:!1})],N.prototype,`hass`,void 0),k([y({attribute:!1})],N.prototype,`area`,void 0),k([y({attribute:!1})],N.prototype,`config`,void 0),k([y({type:Boolean})],N.prototype,`climateControlActive`,void 0),k([y({type:Boolean})],N.prototype,`isOutdoor`,void 0),k([y({attribute:!1})],N.prototype,`overrideInfo`,void 0),k([b()],N.prototype,`_countdown`,void 0),k([b()],N.prototype,`_editingName`,void 0),k([b()],N.prototype,`_nameInput`,void 0),k([b()],N.prototype,`_controlModeInfoExpanded`,void 0),N=k([v(`rs-hero-status`)],N),_(),x(),A();var Ft={window_open:`insights.decision.window_open`,power_budget:`insights.decision.power_budget`,compressor_min_off:`insights.decision.compressor_min_off`,compressor_min_run:`insights.decision.compressor_min_run`,override_boost:`insights.decision.override_boost`,override_eco:`insights.decision.override_eco`,override_custom:`insights.decision.override_custom`,override_active:`insights.decision.override_active`,presence_away:`insights.decision.presence_away`,mold_prevention:`insights.decision.mold_prevention`,humidity_comfort:`insights.decision.humidity_comfort`,smart_ventilation:`insights.decision.smart_ventilation`,preconditioning:`insights.decision.preconditioning`,heat_source:`insights.decision.heat_source`,mode_heating:`insights.decision.mode_heating`,mode_cooling:`insights.decision.mode_cooling`,mode_idle:`insights.decision.mode_idle`},It=class extends g{constructor(...e){super(...e),this.decisionReasons=[]}static{this.styles=l`
    :host {
      display: block;
    }
    ha-card {
      padding: 18px;
    }
    .insights-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 24px;
    }
    h3 {
      margin: 0 0 10px;
      font-size: 16px;
    }
    .subheading {
      margin-top: 0;
    }
    .decision,
    .check {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 8px 0;
      font-size: 14px;
    }
    .decision ha-icon {
      color: var(--primary-color);
    }
    .ready ha-icon {
      color: var(--success-color, #4caf50);
    }
    .recommended ha-icon {
      color: var(--warning-color, #ff9800);
    }
    .missing ha-icon {
      color: var(--error-color, #db4437);
    }
    .summary {
      color: var(--secondary-text-color);
      font-size: 13px;
    }
    .comfort-score {
      display: flex;
      align-items: center;
      gap: 8px;
      margin: 8px 0 2px;
      color: var(--primary-text-color);
      font-size: 14px;
      font-weight: 500;
    }
    .comfort-score ha-icon {
      color: var(--success-color, #4caf50);
    }
    .comfort-score.fair ha-icon {
      color: var(--warning-color, #ff9800);
    }
    .comfort-score.poor ha-icon {
      color: var(--error-color, #db4437);
    }
    .score-breakdown {
      margin-top: 16px;
      padding-top: 16px;
      border-top: 1px solid var(--divider-color);
    }
    .score-breakdown h3 {
      margin-bottom: 4px;
    }
    .score-base,
    .score-factor {
      display: flex;
      justify-content: space-between;
      gap: 12px;
      margin-top: 8px;
      font-size: 14px;
    }
    .score-base {
      font-weight: 500;
    }
    .score-factor .penalty {
      color: var(--error-color, #db4437);
      white-space: nowrap;
    }
    .score-factor .neutral {
      color: var(--secondary-text-color);
      white-space: nowrap;
    }
    @media (max-width: 680px) {
      .insights-grid {
        grid-template-columns: 1fr;
        gap: 16px;
      }
    }
  `}render(){let e=this.hass.language,t=this.decisionReasons.length?this.decisionReasons:[`mode_idle`];return m`
      <ha-card>
        <div class="insights-grid">
          <section>
            <h3>${S(`insights.decision.title`,e)}</h3>
            ${this.comfortScore?m`
                  <div class="comfort-score ${this.comfortScore.label}">
                    <ha-icon icon="mdi:heart"></ha-icon>
                    ${S(`card.comfort_score`,e,{score:this.comfortScore.score})}
                  </div>
                `:h}
            ${t.slice(0,3).map(t=>m`
                  <div class="decision">
                    <ha-icon icon="mdi:information-outline"></ha-icon>${S(Ft[t]??`insights.decision.mode_idle`,e)}
                  </div>
                `)}
          </section>
          ${this.readiness?m`<section>
                <h3 class="subheading">${S(`insights.readiness.title`,e)}</h3>
                <div class="summary">
                  ${S(`insights.readiness.${this.readiness.level}`,e,{ready:this.readiness.ready_count,total:this.readiness.total_count})}
                </div>
                ${this.readiness.items.map(t=>m`
                    <div class="check ${t.status}">
                      <ha-icon
                        icon=${t.status===`ready`?`mdi:check-circle`:t.status===`missing`?`mdi:alert-circle`:`mdi:information-outline`}
                      ></ha-icon>
                      ${S(`insights.readiness.item.${t.key}.${t.status}`,e)}
                    </div>
                  `)}
              </section>`:h}
        </div>
        ${this.comfortScore?.breakdown?m`<section class="score-breakdown">
              <h3>${S(`insights.comfort.title`,e)}</h3>
              <div class="summary">${S(`insights.comfort.summary`,e)}</div>
              <div class="score-base">
                <span>${S(`insights.comfort.base`,e)}</span>
                <span>100</span>
              </div>
              ${Object.entries(this.comfortScore.breakdown).map(([t,n])=>m`
                  <div class="score-factor">
                    <span
                      >${S(`insights.comfort.factor.${t}.${n.status}`,e)}</span
                    >
                    <span class=${n.penalty?`penalty`:`neutral`}>
                      ${n.penalty?`−${n.penalty}`:S(`insights.comfort.no_penalty`,e)}
                    </span>
                  </div>
                `)}
              <div class="score-base">
                <span>${S(`insights.comfort.total`,e)}</span>
                <span>${this.comfortScore.score}/100</span>
              </div>
            </section>`:h}
      </ha-card>
    `}};k([y({attribute:!1})],It.prototype,`hass`,void 0),k([y({attribute:!1})],It.prototype,`readiness`,void 0),k([y({type:Array})],It.prototype,`decisionReasons`,void 0),k([y({attribute:!1})],It.prototype,`comfortScore`,void 0),It=k([v(`rs-room-insights`)],It),_(),x(),A();var Lt=class extends g{constructor(...e){super(...e),this.climateMode=`auto`,this.language=`en`}static{this.styles=l`
    :host {
      display: block;
    }

    .mode-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 10px;
    }

    .mode-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
      padding: 14px 8px;
      border: 2px solid var(--divider-color, #e0e0e0);
      border-radius: 12px;
      cursor: pointer;
      transition:
        border-color 0.2s,
        background 0.2s,
        box-shadow 0.2s;
      background: transparent;
      font-family: inherit;
      color: var(--primary-text-color);
      text-align: center;
    }

    .mode-card:hover {
      border-color: var(--primary-color, #03a9f4);
      box-shadow: 0 2px 8px rgba(3, 169, 244, 0.1);
    }

    .mode-card[active] {
      border-color: var(--primary-color, #03a9f4);
      background: rgba(3, 169, 244, 0.06);
      box-shadow: 0 2px 8px rgba(3, 169, 244, 0.12);
    }

    .mode-card-icon {
      --mdc-icon-size: 24px;
    }

    .mode-card[active] .mode-card-icon {
      color: var(--primary-color, #03a9f4);
    }

    .mode-card-label {
      font-weight: 500;
      font-size: 13px;
    }

    .mode-card[active] .mode-card-label {
      color: var(--primary-color, #03a9f4);
    }
  `}render(){let e=this.language;return m`
      <div class="mode-grid">
        ${[{value:`auto`,labelKey:`mode.auto`,icon:`mdi:autorenew`},{value:`heat_only`,labelKey:`mode.heat_only`,icon:`mdi:fire`},{value:`cool_only`,labelKey:`mode.cool_only`,icon:`mdi:snowflake`}].map(t=>m`
            <button
              class="mode-card"
              ?active=${this.climateMode===t.value}
              @click=${()=>this._onModeClick(t.value)}
            >
              <ha-icon class="mode-card-icon" icon=${t.icon}></ha-icon>
              <div class="mode-card-label">${S(t.labelKey,e)}</div>
            </button>
          `)}
      </div>
    `}_onModeClick(e){this.dispatchEvent(new CustomEvent(`mode-changed`,{detail:{mode:e},bubbles:!0,composed:!0}))}};k([y({type:String})],Lt.prototype,`climateMode`,void 0),k([y({type:String})],Lt.prototype,`language`,void 0),Lt=k([v(`rs-climate-mode-selector`)],Lt);function P(e){return e.detail?.value??e.target.value??``}function F(e,t){e.dispatchEvent(new CustomEvent(`save-status`,{detail:{status:t},bubbles:!0,composed:!0}))}function Rt(e,t){e.dispatchEvent(new CustomEvent(`hass-more-info`,{bubbles:!0,composed:!0,detail:{entityId:t}}))}_(),x(),A();var zt=class e extends g{constructor(...e){super(...e),this.activeIndex=-1,this.selectorEntity=``,this.editing=!1}static{this.sharedStyles=l`
    :host {
      display: block;
    }

    .schedule-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
      margin-bottom: 12px;
    }

    .schedule-row {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 14px;
      border-radius: 8px;
      transition:
        background 0.3s,
        opacity 0.3s;
    }

    .schedule-row.active {
      background: rgba(76, 175, 80, 0.1);
    }
    .schedule-row.inactive {
      background: rgba(0, 0, 0, 0.04);
    }
    .schedule-row.unreachable {
      background: rgba(0, 0, 0, 0.02);
      opacity: 0.4;
    }

    .schedule-number {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      font-weight: 500;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background: var(--divider-color, #e0e0e0);
      color: var(--primary-text-color);
      flex-shrink: 0;
    }
    .schedule-row.active .schedule-number {
      background: #4caf50;
      color: #fff;
    }

    .schedule-status-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      flex-shrink: 0;
    }
    .schedule-row.active .schedule-status-dot {
      background: #4caf50;
      box-shadow: 0 0 6px rgba(76, 175, 80, 0.5);
    }
    .schedule-row.inactive .schedule-status-dot {
      background: var(--disabled-text-color, #bdbdbd);
    }
    .schedule-row.unreachable .schedule-status-dot {
      background: var(--disabled-text-color, #bdbdbd);
    }

    .schedule-name {
      flex: 1;
      font-size: 14px;
      font-weight: 500;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .schedule-link {
      cursor: pointer;
    }
    .schedule-link:hover {
      text-decoration: underline;
    }
    .schedule-row.active .schedule-name {
      color: var(--primary-text-color);
    }
    .schedule-row.inactive .schedule-name {
      color: var(--secondary-text-color);
    }
    .schedule-row.unreachable .schedule-name {
      color: var(--secondary-text-color);
    }

    .schedule-status {
      font-size: 12px;
      white-space: nowrap;
    }
    .schedule-row.active .schedule-status {
      color: #2e7d32;
    }
    .schedule-row.inactive .schedule-status {
      color: var(--secondary-text-color);
    }
    .schedule-row.unreachable .schedule-status {
      color: var(--secondary-text-color);
    }

    .schedule-controls {
      display: flex;
      align-items: center;
      gap: 2px;
      flex-shrink: 0;
    }
    .schedule-controls ha-icon-button {
      --mdc-icon-button-size: 28px;
      --mdc-icon-size: 16px;
    }

    .add-schedule-row {
      margin-top: 4px;
    }
    .add-schedule-row ha-select {
      width: 100%;
    }

    .helper-link {
      display: inline-block;
      margin-top: 4px;
      font-size: 12px;
      color: var(--primary-color);
      text-decoration: none;
    }
    .helper-link:hover {
      text-decoration: underline;
    }

    .no-schedules {
      font-size: 13px;
      color: var(--secondary-text-color);
      padding: 12px 0;
      text-align: center;
    }

    .form-label {
      display: block;
      font-size: 13px;
      font-weight: 500;
      color: var(--secondary-text-color);
      margin-bottom: 6px;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }

    .selector-section {
      margin-top: 16px;
    }

    .selector-value {
      font-size: 12px;
      color: var(--secondary-text-color);
      margin-top: 4px;
      padding-left: 4px;
    }

    .selector-warning {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-top: 8px;
      padding: 10px 14px;
      border-radius: 8px;
      background: rgba(255, 152, 0, 0.08);
      color: var(--warning-color, #ff9800);
      font-size: 13px;
    }
    .selector-warning ha-icon {
      --mdc-icon-size: 18px;
      flex-shrink: 0;
    }

    .section-hint {
      font-size: 12px;
      color: var(--secondary-text-color);
      line-height: 1.5;
      margin-bottom: 12px;
    }
  `}static{this.ICON_CLOSE=`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}static{this.ICON_UP=`M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z`}static{this.ICON_DOWN=`M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z`}_getScheduleState(e,t){if(t===0)return`inactive`;if(e===this.activeIndex)return`active`;if(!this.selectorEntity)return e===0?`active`:`unreachable`;let n=this.hass?.states?.[this.selectorEntity];if(!n)return`inactive`;if(this.selectorEntity.startsWith(`input_boolean.`))return e<=1?`inactive`:`unreachable`;if(this.selectorEntity.startsWith(`input_number.`)){let r=Number(n.attributes?.min??1),i=Number(n.attributes?.max??t);return e+1>=r&&e+1<=i?`inactive`:`unreachable`}return`inactive`}_getAvailableEntities(e){return this.hass?.states?Object.keys(this.hass.states).filter(t=>t.startsWith(`schedule.`)&&!e.has(t)):[]}_getFriendlyName(e){return this.hass?.states?.[e]?.attributes?.friendly_name||e}_renderAddRow(e,t,n,r){return m`
      <div class="add-schedule-row">
        <ha-select
          .value=${``}
          .label=${e}
          .options=${t.map(e=>({value:e,label:this._getFriendlyName(e)}))}
          @selected=${e=>{let t=P(e);t&&(n(t),requestAnimationFrame(()=>{e.target.value=``}))}}
          @closed=${e=>e.stopPropagation()}
          fixedMenuPosition
          naturalMenuWidth
        >
          ${t.map(e=>m`
              <ha-list-item value=${e}>${this._getFriendlyName(e)}</ha-list-item>
            `)}
        </ha-select>
        <a href="/config/helpers" target="_top" class="helper-link"> ${r} </a>
      </div>
    `}_renderSelectorSection(e,t,n,r,i){if(e<2)return h;let a=this.selectorEntity?this.hass?.states?.[this.selectorEntity]:null;return m`
      <div class="selector-section">
        <label class="form-label">${t}</label>
        <ha-entity-picker
          .hass=${this.hass}
          .value=${this.selectorEntity}
          .includeDomains=${[`input_boolean`,`input_number`]}
          allow-custom-entity
          @value-changed=${e=>{e.stopPropagation(),i(e.detail?.value??``)}}
        ></ha-entity-picker>
        ${this.selectorEntity&&a?m`
              <div class="selector-value">
                ${this.selectorEntity.startsWith(`input_boolean.`)?S(`schedule.selector_value_boolean`,this.hass.language,{value:a.state===`on`?`On`:`Off`}):S(`schedule.selector_value_number`,this.hass.language,{value:a.state})}
              </div>
            `:h}
        <div class="section-hint" style="margin-top:4px">${n}</div>
        ${e>1&&!this.selectorEntity?m`
              <div class="selector-warning">
                <ha-icon icon="mdi:alert-outline"></ha-icon>
                ${r}
              </div>
            `:h}
      </div>
    `}_renderScheduleControls(t,n,r,i){let a=n>=2;return m`
      <span class="schedule-controls">
        ${a&&t>0?m`
              <ha-icon-button
                .path=${e.ICON_UP}
                @click=${()=>r(t,-1)}
              ></ha-icon-button>
            `:h}
        ${a&&t<n-1?m`
              <ha-icon-button
                .path=${e.ICON_DOWN}
                @click=${()=>r(t,1)}
              ></ha-icon-button>
            `:h}
        <ha-icon-button
          .path=${e.ICON_CLOSE}
          @click=${()=>i(t)}
        ></ha-icon-button>
      </span>
    `}_openEntityInfo(e){Rt(this,e)}};k([y({attribute:!1})],zt.prototype,`hass`,void 0),k([y({type:Number})],zt.prototype,`activeIndex`,void 0),k([y({type:String})],zt.prototype,`selectorEntity`,void 0),k([y({type:Boolean})],zt.prototype,`editing`,void 0),_();var I=l`
  ha-textfield,
  ha-select,
  ha-entity-picker,
  ha-combo-box {
    --mdc-shape-small: 8px;
    --mdc-shape-medium: 8px;
    --md-filled-text-field-container-shape: 8px;
    --md-outlined-text-field-container-shape: 8px;
    display: block;
    border-radius: 8px;
    overflow: hidden;
    isolation: isolate;
    /* clip-path is more reliable than overflow:hidden for shape clipping
       on the bottom corners of MDC filled inputs. */
    clip-path: inset(0 round 8px);
  }

  /* ha-entity-picker wraps an inner ha-combo-box that doesn't always
     reach the host's bottom edge. Use a tighter clip so the visible
     input's bottom matches the inner's top radius. */
  ha-entity-picker {
    clip-path: inset(0 round 8px 8px 4px 4px);
  }
`;_(),x(),A();var L=class extends zt{constructor(...e){super(...e),this.schedules=[],this.comfortHeat=21,this.comfortCool=24,this.ecoHeat=17,this.ecoCool=27,this.climateMode=`auto`}set scheduleSelectorEntity(e){this.selectorEntity=e}get scheduleSelectorEntity(){return this.selectorEntity}set activeScheduleIndex(e){this.activeIndex=e}get activeScheduleIndex(){return this.activeIndex}static{this.styles=[zt.sharedStyles,I,l`
      .fallback-hint {
        font-size: 11px;
        color: var(--secondary-text-color);
        margin-top: 4px;
        font-style: italic;
      }

      .temp-inputs {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
        margin-top: 16px;
      }

      .temp-input-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      ha-textfield {
        flex: 1;
      }

      .view-temps {
        display: flex;
        gap: 16px;
        font-size: 13px;
        color: var(--secondary-text-color);
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid var(--divider-color, #eee);
      }

      .view-temps span {
        font-weight: 500;
        color: var(--primary-text-color);
      }

      .view-selector-info {
        font-size: 12px;
        color: var(--secondary-text-color);
        margin-top: 8px;
      }

      .temp-grid-auto {
        display: grid;
        grid-template-columns: auto 1fr 1fr;
        gap: 8px 12px;
        align-items: center;
        margin-top: 16px;
      }
      .temp-grid-header {
        font-size: 12px;
        font-weight: 600;
        color: var(--secondary-text-color);
        text-transform: uppercase;
        letter-spacing: 0.3px;
        text-align: center;
      }
      .temp-grid-row-label {
        display: flex;
        align-items: center;
        gap: 4px;
        font-size: 13px;
        font-weight: 500;
        color: var(--secondary-text-color);
        white-space: nowrap;
      }

      @media (max-width: 600px) {
        .temp-grid-auto {
          grid-template-columns: 1fr 1fr;
        }
        .temp-grid-row-label {
          grid-column: 1 / -1;
          margin-top: 8px;
        }
        .temp-grid-header {
          display: none;
        }
      }
    `]}render(){return this.editing?this._renderEditMode():this._renderViewMode()}_renderViewMode(){let e=this.hass.language,t=this.schedules.length>=2;return m`
      ${this.schedules.length>0?m`
            <div class="schedule-list">
              ${this.schedules.map((e,n)=>{let r=this._getScheduleState(n,this.schedules.length);return m`
                  <div class="schedule-row ${r}">
                    ${t?m`<span class="schedule-number">${n+1}</span>`:h}
                    <span class="schedule-status-dot"></span>
                    <span
                      class="schedule-name schedule-link"
                      @click=${()=>this._openEntityInfo(e.entity_id)}
                      >${this._getFriendlyName(e.entity_id)}</span
                    >
                    <span class="schedule-status">${this._getStatusText(n,r)}</span>
                  </div>
                `})}
            </div>
          `:m`<div class="no-schedules">${S(`schedule.no_schedules`,e)}</div>`}
      ${this.climateMode===`auto`?m`
            <div class="view-temps">
              ${S(`schedule.view_heat`,e,{comfort:E(this.comfortHeat,this.hass),eco:E(this.ecoHeat,this.hass),unit:C(this.hass)})}
               · 
              ${S(`schedule.view_cool`,e,{comfort:E(this.comfortCool,this.hass),eco:E(this.ecoCool,this.hass),unit:C(this.hass)})}
            </div>
          `:m`
            <div class="view-temps">
              ${S(`schedule.view_comfort`,e,{temp:E(this.climateMode===`cool_only`?this.comfortCool:this.comfortHeat,this.hass),unit:C(this.hass)})}
               · 
              ${S(`schedule.view_eco`,e,{temp:E(this.climateMode===`cool_only`?this.ecoCool:this.ecoHeat,this.hass),unit:C(this.hass)})}
            </div>
          `}
      ${this.scheduleSelectorEntity?m`<div class="view-selector-info">
            ${S(`schedule.view_selector_prefix`,e)}
            <span
              class="schedule-link"
              @click=${()=>this._openEntityInfo(this.scheduleSelectorEntity)}
              >${this._getFriendlyName(this.scheduleSelectorEntity)}</span
            >
          </div>`:h}
    `}_renderEditMode(){let e=this.hass.language,t=this.schedules.length,n=new Set(this.schedules.map(e=>e.entity_id));return m`
      ${this._renderScheduleList()}
      ${this._renderAddRow(S(`schedule.select_schedule`,e),this._getAvailableEntities(n),e=>this._addSchedule(e),S(`schedule.create_helper_hint`,e))}
      ${this._renderSelectorSection(t,S(`schedule.selector_label`,e),this.scheduleSelectorEntity?this._getSelectorValueText(e):``,S(`schedule.selector_warning`,e),e=>this._onSelectorEntityChange(e))}
      ${this._renderTemperatureInputs(e)}
    `}_renderScheduleList(){let e=this.hass.language,t=this.schedules.length;return t===0?m`<div class="no-schedules">${S(`schedule.no_schedules`,e)}</div>`:m`
      <div class="schedule-list">
        ${this.schedules.map((e,n)=>{let r=this._getScheduleState(n,t);return m`
            <div class="schedule-row ${r}">
              ${t>=2?m`<span class="schedule-number">${n+1}</span>`:h}
              <span class="schedule-status-dot"></span>
              <span class="schedule-name">${this._getFriendlyName(e.entity_id)}</span>
              <span class="schedule-status">${this._getStatusText(n,r)}</span>
              ${this._renderScheduleControls(n,t,(e,t)=>this._moveSchedule(e,t),e=>this._removeSchedule(e))}
            </div>
          `})}
      </div>
    `}_renderTemperatureInputs(e){return this.climateMode===`auto`?m`
        <div class="temp-grid-auto">
          <div class="temp-grid-header"></div>
          <div class="temp-grid-header">${S(`schedule.column_comfort`,e)}</div>
          <div class="temp-grid-header">${S(`schedule.column_eco`,e)}</div>
          <div class="temp-grid-row-label">
            <ha-icon icon="mdi:fire" style="--mdc-icon-size:16px"></ha-icon>
            ${S(`schedule.row_heat`,e)}
          </div>
          <ha-textfield
            type="number"
            .value=${String(w(this.comfortHeat,this.hass))}
            suffix=${C(this.hass)}
            step=${D(this.hass)}
            min=${O(5,35,this.hass).min}
            max=${O(5,35,this.hass).max}
            @change=${this._onComfortHeatChange}
          ></ha-textfield>
          <ha-textfield
            type="number"
            .value=${String(w(this.ecoHeat,this.hass))}
            suffix=${C(this.hass)}
            step=${D(this.hass)}
            min=${O(5,35,this.hass).min}
            max=${O(5,35,this.hass).max}
            @change=${this._onEcoHeatChange}
          ></ha-textfield>
          <div class="temp-grid-row-label">
            <ha-icon icon="mdi:snowflake" style="--mdc-icon-size:16px"></ha-icon>
            ${S(`schedule.row_cool`,e)}
          </div>
          <ha-textfield
            type="number"
            .value=${String(w(this.comfortCool,this.hass))}
            suffix=${C(this.hass)}
            step=${D(this.hass)}
            min=${O(5,35,this.hass).min}
            max=${O(5,35,this.hass).max}
            @change=${this._onComfortCoolChange}
          ></ha-textfield>
          <ha-textfield
            type="number"
            .value=${String(w(this.ecoCool,this.hass))}
            suffix=${C(this.hass)}
            step=${D(this.hass)}
            min=${O(5,35,this.hass).min}
            max=${O(5,35,this.hass).max}
            @change=${this._onEcoCoolChange}
          ></ha-textfield>
        </div>
      `:m`
      <div class="temp-inputs">
        <div class="temp-input-group">
          <ha-textfield
            type="number"
            label=${S(`schedule.comfort_label`,e)}
            suffix=${C(this.hass)}
            step=${D(this.hass)}
            .value=${String(w(this.climateMode===`cool_only`?this.comfortCool:this.comfortHeat,this.hass))}
            min=${O(5,35,this.hass).min}
            max=${O(5,35,this.hass).max}
            @change=${this.climateMode===`cool_only`?this._onComfortCoolChange:this._onComfortHeatChange}
          ></ha-textfield>
        </div>
        <div class="temp-input-group">
          <ha-textfield
            type="number"
            label=${S(`schedule.eco_label`,e)}
            suffix=${C(this.hass)}
            step=${D(this.hass)}
            .value=${String(w(this.climateMode===`cool_only`?this.ecoCool:this.ecoHeat,this.hass))}
            min=${O(5,35,this.hass).min}
            max=${O(5,35,this.hass).max}
            @change=${this.climateMode===`cool_only`?this._onEcoCoolChange:this._onEcoHeatChange}
          ></ha-textfield>
        </div>
      </div>
      <div class="fallback-hint">${S(`schedule.comfort_hint`,e)}</div>
    `}_getSelectorValueText(e){let t=this.hass?.states?.[this.scheduleSelectorEntity];return t?this.scheduleSelectorEntity.startsWith(`input_boolean.`)?S(`schedule.selector_value_boolean`,e,{value:t.state===`on`?`On`:`Off`}):S(`schedule.selector_value_number`,e,{value:t.state}):``}_getStatusText(e,t){let n=this.hass.language;if(t===`unreachable`)return S(`schedule.state_unreachable`,n);if(t===`inactive`)return S(`schedule.state_inactive`,n);let r=this.schedules[e],i=this.hass?.states?.[r.entity_id];if(!i)return S(`schedule.state_active`,n);if(i.state===`on`){let e=i.attributes??{},t=e.temperature;if(t!=null)return S(`schedule.from_schedule`,n,{temp:String(t),unit:C(this.hass)});let r=e.heat_temperature,a=e.cool_temperature;return r!=null||a!=null?S(`schedule.from_schedule_split`,n,{heat:String(r??this.comfortHeat),cool:String(a??this.comfortCool),unit:C(this.hass)}):S(`schedule.fallback`,n,{temp:E(this.climateMode===`cool_only`?this.comfortCool:this.comfortHeat,this.hass),unit:C(this.hass)})}return S(`schedule.eco_detail`,n,{temp:E(this.climateMode===`cool_only`?this.ecoCool:this.ecoHeat,this.hass),unit:C(this.hass)})}_addSchedule(e){this._emitSchedules([...this.schedules,{entity_id:e}])}_removeSchedule(e){this._emitSchedules(this.schedules.filter((t,n)=>n!==e))}_moveSchedule(e,t){let n=e+t;if(n<0||n>=this.schedules.length)return;let r=[...this.schedules];[r[e],r[n]]=[r[n],r[e]],this._emitSchedules(r)}_emitSchedules(e){this.dispatchEvent(new CustomEvent(`schedules-changed`,{detail:{value:e},bubbles:!0,composed:!0}))}_onSelectorEntityChange(e){this.dispatchEvent(new CustomEvent(`schedule-selector-changed`,{detail:{value:e},bubbles:!0,composed:!0}))}_onComfortHeatChange(e){let t=e.target,n=T(parseFloat(t.value)||w(21,this.hass),this.hass);this.dispatchEvent(new CustomEvent(`comfort-heat-changed`,{detail:{value:n},bubbles:!0,composed:!0})),this.comfortCool<n&&this.dispatchEvent(new CustomEvent(`comfort-cool-changed`,{detail:{value:n},bubbles:!0,composed:!0}))}_onComfortCoolChange(e){let t=e.target,n=T(parseFloat(t.value)||w(24,this.hass),this.hass);this.dispatchEvent(new CustomEvent(`comfort-cool-changed`,{detail:{value:n},bubbles:!0,composed:!0})),this.comfortHeat>n&&this.dispatchEvent(new CustomEvent(`comfort-heat-changed`,{detail:{value:n},bubbles:!0,composed:!0}))}_onEcoHeatChange(e){let t=e.target,n=T(parseFloat(t.value)||w(17,this.hass),this.hass);this.dispatchEvent(new CustomEvent(`eco-heat-changed`,{detail:{value:n},bubbles:!0,composed:!0})),this.ecoCool<n&&this.dispatchEvent(new CustomEvent(`eco-cool-changed`,{detail:{value:n},bubbles:!0,composed:!0}))}_onEcoCoolChange(e){let t=e.target,n=T(parseFloat(t.value)||w(27,this.hass),this.hass);this.dispatchEvent(new CustomEvent(`eco-cool-changed`,{detail:{value:n},bubbles:!0,composed:!0})),this.ecoHeat>n&&this.dispatchEvent(new CustomEvent(`eco-heat-changed`,{detail:{value:n},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],L.prototype,`schedules`,void 0),k([y({type:String})],L.prototype,`scheduleSelectorEntity`,null),k([y({type:Number})],L.prototype,`activeScheduleIndex`,null),k([y({type:Number})],L.prototype,`comfortHeat`,void 0),k([y({type:Number})],L.prototype,`comfortCool`,void 0),k([y({type:Number})],L.prototype,`ecoHeat`,void 0),k([y({type:Number})],L.prototype,`ecoCool`,void 0),k([y({type:String})],L.prototype,`climateMode`,void 0),L=k([v(`rs-schedule-settings`)],L);var Bt={underfloor:2,radiator:1,"":0};function Vt(e){let t=``;for(let n of e){if(n.type!==`trv`)continue;let e=n.heating_system_type??``;(Bt[e]??0)>(Bt[t]??0)&&(t=e)}return t}_();var Ht=l`
  .master {
    display: flex;
    flex-direction: column;
    gap: 12px;
    min-width: 0;
  }

  .master-list {
    display: flex;
    flex-direction: column;
    gap: 4px;
    min-width: 0;
  }

  .master-row {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 8px 10px;
    border-radius: 10px;
    cursor: pointer;
    transition:
      background 0.15s,
      border-color 0.15s;
    border: 1px solid transparent;
    min-width: 0;
  }

  .master-row:hover {
    background: rgba(255, 255, 255, 0.03);
  }

  .master-row.focused {
    background: rgba(3, 169, 244, 0.08);
    border-color: rgba(3, 169, 244, 0.5);
  }

  .master-row ha-checkbox {
    flex-shrink: 0;
    margin-left: -8px;
  }

  .master-info {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .master-name-row {
    display: flex;
    align-items: center;
    gap: 6px;
    min-width: 0;
  }

  .master-name {
    font-size: 14px;
    font-weight: 450;
    color: var(--primary-text-color);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-width: 0;
  }

  .master-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
  }

  .type-pill,
  .meta-pill {
    display: inline-block;
    font-size: 10px;
    font-weight: 500;
    padding: 1px 8px;
    border-radius: 8px;
    letter-spacing: 0.3px;
    text-transform: uppercase;
    color: var(--secondary-text-color);
    background: rgba(255, 255, 255, 0.05);
  }

  .type-pill {
    color: var(--primary-color);
    background: rgba(3, 169, 244, 0.12);
  }

  .external-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 10px;
    font-weight: 500;
    color: var(--warning-color, #ff9800);
    background: rgba(255, 152, 0, 0.1);
    padding: 2px 8px;
    border-radius: 10px;
    letter-spacing: 0.3px;
    text-transform: uppercase;
    flex-shrink: 0;
  }

  .detail-panel {
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding: 12px 16px;
    background: rgba(255, 255, 255, 0.02);
    border: 1px solid var(--divider-color, rgba(255, 255, 255, 0.08));
    border-radius: 12px;
    min-width: 0;
    min-height: 200px;
  }

  .empty-detail {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 10px;
    flex: 1;
    min-height: 180px;
    color: var(--secondary-text-color);
    font-size: 13px;
    font-style: italic;
    opacity: 0.7;
    text-align: center;
  }

  .empty-detail ha-icon {
    --mdc-icon-size: 28px;
    opacity: 0.6;
  }

  .detail-head {
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding-bottom: 6px;
    border-bottom: 1px solid var(--divider-color, rgba(255, 255, 255, 0.06));
  }

  .detail-title {
    font-size: 15px;
    font-weight: 500;
    color: var(--primary-text-color);
  }

  .detail-entity-id {
    font-family: var(--code-font-family, monospace);
    font-size: 11px;
    color: var(--secondary-text-color);
    opacity: 0.7;
  }

  .detail-field {
    display: flex;
    flex-direction: column;
  }

  .detail-field ha-select {
    width: 100%;
  }

  .detail-field.with-info {
    flex-direction: row;
    align-items: center;
    gap: 6px;
  }

  .detail-field.with-info ha-select,
  .detail-field.with-info ha-textfield {
    flex: 1;
    min-width: 0;
  }

  .detail-field.with-info rs-info-icon {
    flex-shrink: 0;
  }

  .detail-hint {
    font-size: 12px;
    color: var(--secondary-text-color);
    line-height: 1.5;
  }

  .detail-toggle-row {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 8px 0;
  }

  .detail-toggle-row ha-checkbox {
    margin-top: -8px;
    margin-left: -8px;
  }

  .detail-toggle-label {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 14px;
    color: var(--primary-text-color);
  }

  .detail-toggle-label ha-icon {
    --mdc-icon-size: 16px;
    color: var(--secondary-text-color);
  }

  .inline-hint {
    margin-top: 2px;
  }

  .block {
    margin-top: 4px;
  }

  .block-divider {
    height: 1px;
    background: var(--divider-color, rgba(255, 255, 255, 0.08));
    margin: 16px 0 8px;
  }

  .block-title {
    font-size: 12px;
    font-weight: 500;
    color: var(--secondary-text-color);
    text-transform: uppercase;
    letter-spacing: 0.4px;
    margin-bottom: 8px;
  }

  .empty-list {
    color: var(--secondary-text-color);
    font-size: 13px;
    font-style: italic;
    padding: 12px 14px;
  }

  ha-entity-picker {
    width: 100%;
  }

  .picker-wrap {
    margin-top: 8px;
  }
`;_();var Ut=l`
  .equipment-view {
    display: grid;
    gap: 16px;
  }
  .equipment-view .section-subtitle {
    margin: 0 0 10px;
    text-transform: none;
    letter-spacing: 0;
    font-size: 12px;
    font-weight: 600;
    color: var(--secondary-text-color);
  }
  .equipment-view .device-group {
    padding: 0;
    margin: 0;
    border: 0;
  }
  .equipment-view .view-row {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
    padding: 12px;
    margin-top: 6px;
    border: 1px solid var(--divider-color, rgba(128, 128, 128, 0.16));
    border-radius: 12px;
    background: var(--secondary-background-color, rgba(128, 128, 128, 0.05));
    min-width: 0;
  }
  .equipment-view .view-icon {
    --mdc-icon-size: 20px;
    display: grid;
    place-items: center;
    width: 34px;
    height: 34px;
    border-radius: 10px;
    color: var(--primary-color);
    background: var(--card-background-color);
    flex-shrink: 0;
  }
  .equipment-view .view-name {
    flex: 1;
    min-width: 70px;
    font: inherit;
    font-size: 13px;
    line-height: 1.45;
    color: var(--primary-text-color);
    white-space: normal;
    overflow-wrap: anywhere;
    text-align: start;
  }
  .equipment-view button.view-name {
    padding: 0;
    border: 0;
    background: none;
    cursor: pointer;
  }
  .equipment-view button:focus-visible {
    outline: 2px solid var(--primary-color);
    outline-offset: 4px;
    border-radius: 4px;
  }
  .equipment-view .view-value {
    font-size: 16px;
    font-weight: 600;
    font-variant-numeric: tabular-nums;
    margin-inline-start: auto;
  }
  .equipment-view .delay-view {
    padding: 8px 2px 0;
    font-size: 12px;
    line-height: 1.6;
  }
  .equipment-view .sensor-state {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    color: var(--secondary-text-color);
    font-size: 12px;
  }
  .equipment-view .equipment-edit {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    justify-self: start;
    min-height: 36px;
    padding: 6px 2px;
    border: 0;
    background: none;
    color: var(--primary-color);
    font: inherit;
    font-size: 12px;
    cursor: pointer;
  }
  .equipment-edit ha-icon {
    --mdc-icon-size: 16px;
  }
  .equipment-empty {
    margin: 0;
    color: var(--secondary-text-color);
    font-size: 13px;
    line-height: 1.6;
  }
`;_(),x(),A();var Wt=class extends g{constructor(...e){super(...e),this.masterWidth=`260px`,this.breakpoint=720}static{this.styles=l`
    :host {
      display: block;
      container-type: inline-size;
    }

    .wrap {
      display: grid;
      grid-template-columns: var(--rs-master-width, 260px) minmax(0, 1fr);
      gap: 20px;
      align-items: start;
    }

    @container (max-width: 720px) {
      .wrap {
        grid-template-columns: minmax(0, 1fr);
      }
    }

    /* Fallback for browsers without container queries */
    @media (max-width: 720px) {
      .wrap {
        grid-template-columns: minmax(0, 1fr);
      }
    }

    ::slotted([slot="master"]) {
      min-width: 0;
    }

    ::slotted([slot="detail"]) {
      min-width: 0;
    }
  `}render(){return m`
      <div class="wrap" style="--rs-master-width: ${this.masterWidth};">
        <div class="master"><slot name="master"></slot></div>
        <div class="detail"><slot name="detail"></slot></div>
      </div>
    `}};k([y({type:String})],Wt.prototype,`masterWidth`,void 0),k([y({type:Number})],Wt.prototype,`breakpoint`,void 0),Wt=k([v(`rs-master-detail`)],Wt),_(),x(),A();var Gt=[{option:`fan_only_only_after_cooling`,label:`devices.fan_only_only_after_cooling`},{option:`fan_only_require_presence`,label:`devices.fan_only_require_presence`},{option:`fan_only_require_schedule`,label:`devices.fan_only_require_schedule`}],R=class extends g{constructor(...e){super(...e),this.devices=[],this.selectedTempSensor=``,this.valveProtectionExclude=new Set,this.valveProtectionEnabled=!1,this.editing=!1,this._systemTypeInfoExpanded=!1,this._showBoostHint=!1,this._selectedThermostats=new Set,this._selectedCoolingDevices=new Set,this._heatingSystemType=``,this._selectedForEdit=``,this._entityFilter=e=>{let t=e.entity_id;return t.substring(t.indexOf(`.`)+1).startsWith(`roommind_`)||this.devices.some(e=>e.entity_id===t)?!1:t.startsWith(`climate.`)}}willUpdate(e){if(e.has(`devices`)){this._selectedThermostats=new Set(this.devices.filter(e=>e.type===`trv`).map(e=>e.entity_id)),this._selectedCoolingDevices=new Set(this.devices.filter(e=>e.type===`ac`).map(e=>e.entity_id)),this._heatingSystemType=Vt(this.devices);let e=new Set(this.devices.map(e=>e.entity_id));this._selectedForEdit&&!e.has(this._selectedForEdit)&&(this._selectedForEdit=``),!this._selectedForEdit&&this.devices.length>0&&(this._selectedForEdit=this.devices[0].entity_id)}}static{this.styles=[Ht,I,Ut,l`
      :host {
        display: block;
      }

      .section-subtitle {
        font-size: 12px;
        font-weight: 500;
        color: var(--secondary-text-color);
        margin: 12px 0 8px 0;
        text-transform: uppercase;
        letter-spacing: 0.4px;
      }

      .section-subtitle:first-child {
        margin-top: 0;
      }

      .device-group {
        padding: 4px 0;
      }

      .device-group + .device-group {
        margin-top: 8px;
        padding-top: 12px;
        border-top: 1px solid var(--divider-color, #eee);
      }

      .device-list-scroll {
        max-height: 168px;
        overflow-y: auto;
        overflow-x: hidden;
        scrollbar-width: thin;
      }

      /* Device rows */
      .device-row {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 8px 14px;
        font-size: 14px;
        color: var(--primary-text-color);
        border-radius: 10px;
        margin-bottom: 2px;
        transition: background 0.15s;
      }

      .device-row:last-child {
        margin-bottom: 0;
      }

      .device-row:hover {
        background: rgba(0, 0, 0, 0.02);
      }

      .device-row.selected {
        background: rgba(3, 169, 244, 0.035);
      }

      .device-row ha-checkbox,
      .device-row ha-radio {
        flex-shrink: 0;
      }

      .device-info {
        flex: 1;
        min-width: 0;
      }

      .device-name-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .device-name {
        font-size: 14px;
        font-weight: 450;
        color: var(--primary-text-color);
      }

      .device-value {
        margin-left: auto;
        font-size: 14px;
        font-weight: 500;
        color: var(--primary-text-color);
        flex-shrink: 0;
      }

      .device-entity {
        font-family: var(--code-font-family, monospace);
        font-size: 11px;
        color: var(--secondary-text-color);
        margin-top: 2px;
        opacity: 0.7;
      }

      .external-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        font-size: 10px;
        font-weight: 500;
        color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.1);
        padding: 2px 8px;
        border-radius: 10px;
        letter-spacing: 0.3px;
        text-transform: uppercase;
        flex-shrink: 0;
      }

      .device-type-select {
        flex-shrink: 0;
        --ha-select-min-width: 90px;
      }

      .no-devices {
        color: var(--secondary-text-color);
        font-size: 13px;
        font-style: italic;
        padding: 12px 14px;
      }

      .entity-picker-wrap {
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid var(--divider-color, #eee);
      }

      .subtitle-row {
        display: flex;
        align-items: center;
        gap: 4px;
      }

      .info-icon {
        --mdc-icon-size: 16px;
        color: var(--secondary-text-color);
        cursor: pointer;
        opacity: 0.6;
      }
      .info-icon:hover,
      .info-icon.info-active {
        opacity: 1;
        color: var(--primary-color);
      }

      .system-type-info {
        font-size: 12px;
        line-height: 1.5;
        color: var(--secondary-text-color);
        padding: 8px 14px 4px;
      }

      .boost-hint {
        display: flex;
        align-items: flex-start;
        gap: 8px;
        margin-top: 8px;
        padding: 8px 12px;
        background: rgba(var(--rgb-primary-color, 3, 169, 244), 0.08);
        border-radius: 8px;
        font-size: 13px;
        color: var(--primary-text-color);
        line-height: 1.4;
        --mdc-icon-size: 18px;
      }
      .boost-hint ha-icon {
        color: var(--primary-color);
        flex-shrink: 0;
        margin-top: 1px;
      }

      .idle-action-row {
        display: flex;
        gap: 12px;
        padding: 4px 14px 4px 42px;
      }

      .idle-action-row ha-select {
        flex: 1;
        min-width: 0;
      }

      .setpoint-mode-row {
        display: flex;
        gap: 12px;
        padding: 4px 14px 4px 42px;
      }

      .setpoint-mode-row ha-select {
        flex: 1;
        min-width: 0;
      }

      .setpoint-mode-hint {
        font-size: 12px;
        color: var(--secondary-text-color);
        padding: 2px 14px 4px 42px;
      }

      .valve-exclude-row {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 2px 14px 2px 42px;
        font-size: 12px;
        color: var(--secondary-text-color);
      }

      .valve-exclude-row ha-icon {
        --mdc-icon-size: 14px;
        color: var(--secondary-text-color);
      }

      .valve-exclude-row ha-checkbox {
        --mdc-checkbox-unchecked-color: var(--secondary-text-color);
        margin: -8px -4px -8px -8px;
      }

      .valve-exclude-badge {
        display: inline-flex;
        align-items: center;
        gap: 3px;
        font-size: 10px;
        font-weight: 500;
        color: var(--secondary-text-color);
        background: var(--secondary-background-color);
        padding: 2px 6px;
        border-radius: 8px;
        --mdc-icon-size: 12px;
      }

      .fan-only-conditions {
        display: grid;
        gap: 6px;
        padding: 4px 0 8px;
      }

      .fan-only-condition {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 13px;
        color: var(--secondary-text-color);
      }

      .fan-only-seasons {
        display: flex;
        flex-wrap: wrap;
        gap: 4px 12px;
      }

      .fan-only-hint {
        font-size: 12px;
        color: var(--secondary-text-color);
        line-height: 1.4;
      }

      /* View mode styles */
      .view-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px 14px;
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .view-name {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .entity-link {
        cursor: pointer;
      }

      .entity-link:hover {
        text-decoration: underline;
      }

      .view-value {
        font-weight: 500;
        flex-shrink: 0;
      }
    `]}render(){return this.editing?this._renderEditMode():this._renderViewMode()}_renderViewMode(){let e=this._selectedThermostats.size>0||this._selectedCoolingDevices.size>0;return m`
      <div class="equipment-view">
        ${e?m`
              <div class="device-group">
                <div class="section-subtitle">
                  ${S(`devices.climate_entities`,this.hass.language)}
                </div>
                ${[...this._selectedThermostats].map(e=>this._renderViewRow(e,`climate`))}
                ${[...this._selectedCoolingDevices].map(e=>this._renderViewRow(e,`climate`))}
              </div>
            `:m`<p class="equipment-empty">
              ${S(`equipment.no_devices`,this.hass.language)}
            </p>`}
        ${this._heatingSystemType?m`
              <div class="device-group">
                <div class="section-subtitle">
                  ${S(`devices.heating_system_type`,this.hass.language)}
                </div>
                <div class="view-row">
                  <span class="view-name"
                    >${this._heatingSystemType===`radiator`?S(`devices.system_type_radiator`,this.hass.language):this._heatingSystemType===`underfloor`?S(`devices.system_type_underfloor`,this.hass.language):this._heatingSystemType}</span
                  >
                </div>
              </div>
            `:h}
        <button
          type="button"
          class="equipment-edit"
          @click=${()=>this.dispatchEvent(new CustomEvent(`edit-click`,{bubbles:!0,composed:!0}))}
        >
          <ha-icon icon="mdi:tune-variant"></ha-icon>${S(`equipment.edit_devices`,this.hass.language)}
        </button>
      </div>
    `}_renderViewRow(e,t){let n=this.hass.states[e],r=n?.attributes?.friendly_name||e,i=n?.state,a=n?.attributes??{},o=``;if(t===`climate`){let e=a.current_temperature;e!=null&&(o=`${e.toFixed(1)}${C(this.hass)}`)}else if(t===`temp`){let t=e.startsWith(`climate.`)?a.current_temperature:i;t!=null&&t!==``&&t!==`unknown`&&t!==`unavailable`&&(o=`${Number(t).toFixed(1)}${C(this.hass)}`)}else i&&i!==`unknown`&&i!==`unavailable`&&(o=`${Math.round(Number(i))}%`);let s=t===`climate`&&this.valveProtectionEnabled&&this.valveProtectionExclude.has(e),c=t===`climate`?this.devices.find(t=>t.entity_id===e):void 0,l=c?.idle_action===`fan_only`||c?.idle_action===`setback`||c?.idle_action===`low`,u=c?.setpoint_mode===`direct`&&!!this.selectedTempSensor;return m`
      <div class="view-row">
        <ha-icon
          class="view-icon"
          icon=${c?.type===`trv`?`mdi:radiator`:`mdi:air-conditioner`}
        ></ha-icon>
        <button
          type="button"
          class="view-name entity-link"
          @click=${()=>Rt(this,e)}
        >
          ${r}
        </button>
        ${l?m`<span class="valve-exclude-badge">
              ${c.idle_action===`fan_only`?m`${S(`devices.idle_action_fan_only`,this.hass.language)}${c.idle_fan_mode?` (${c.idle_fan_mode})`:h}`:c.idle_action===`low`?S(`devices.idle_action_low`,this.hass.language):S(`devices.idle_action_setback`,this.hass.language)}
            </span>`:h}
        ${u?m`<span class="valve-exclude-badge">
              ${S(`devices.setpoint_mode_direct`,this.hass.language)}
            </span>`:h}
        ${s?m`<span class="valve-exclude-badge">
              <ha-icon icon="mdi:shield-off-outline"></ha-icon>
              ${S(`devices.valve_protection_excluded`,this.hass.language)}
            </span>`:h}
        ${o?m`<span class="view-value">${o}</span>`:h}
      </div>
    `}_renderEditMode(){let e=bt(this.area.area_id,this.hass?.entities,this.hass?.devices).filter(e=>!e.entity_id.substring(e.entity_id.indexOf(`.`)+1).startsWith(`roommind_`)).filter(e=>e.entity_id.startsWith(`climate.`)),t=new Set(e.map(e=>e.entity_id)),n=new Set(this.devices.map(e=>e.entity_id)),r=[...n].filter(e=>!t.has(e)),i=e=>n.has(e),a=this._selectedForEdit;return m`
      <rs-master-detail>
        <div slot="master" class="master">
          <div class="section-subtitle">
            ${S(`devices.climate_entities`,this.hass.language)}
          </div>
          <div class="master-list">
            ${e.length>0?e.map(e=>this._renderMasterRow(e.entity_id,!1)):m`<div class="no-devices">
                  ${S(`devices.no_climate`,this.hass.language)}
                </div>`}
            ${r.map(e=>this._renderMasterRow(e,!0))}
          </div>
          <div class="entity-picker-wrap">
            <ha-entity-picker
              .hass=${this.hass}
              .includeDomains=${[`climate`]}
              .entityFilter=${this._entityFilter}
              .value=${``}
              label=${S(`devices.add_entity`,this.hass.language)}
              @value-changed=${this._onEntityPicked}
            ></ha-entity-picker>
          </div>
        </div>

        <div slot="detail" class="detail-panel">
          ${a&&i(a)?this._renderDeviceDetail(a):m`<div class="empty-detail">
                <ha-icon icon="mdi:gesture-tap"></ha-icon>
                <span>${S(`devices.select_to_configure`,this.hass.language)}</span>
              </div>`}
        </div>
      </rs-master-detail>

      ${this._selectedThermostats.size>0?m`
            <div class="block-divider"></div>
            <div class="block">
              <div class="subtitle-row">
                <div class="section-subtitle">
                  ${S(`devices.heating_system_type`,this.hass.language)}
                </div>
                <ha-icon
                  class="info-icon ${this._systemTypeInfoExpanded?`info-active`:``}"
                  icon="mdi:information-outline"
                  @click=${()=>{this._systemTypeInfoExpanded=!this._systemTypeInfoExpanded}}
                ></ha-icon>
              </div>
              ${this._systemTypeInfoExpanded?m`
                    <div class="system-type-info">
                      ${S(`devices.heating_system_type_info`,this.hass.language)}
                    </div>
                  `:h}
              <ha-select
                .value=${this._heatingSystemType||`standard`}
                .options=${[{value:`standard`,label:S(`devices.system_type_none`,this.hass.language)},{value:`radiator`,label:S(`devices.system_type_radiator`,this.hass.language)},{value:`underfloor`,label:S(`devices.system_type_underfloor`,this.hass.language)}]}
                @selected=${this._onHeatingSystemTypeChange}
                @closed=${e=>e.stopPropagation()}
                fixedMenuPosition
                style="width: 100%;"
              >
                <ha-list-item value="standard"
                  >${S(`devices.system_type_none`,this.hass.language)}</ha-list-item
                >
                <ha-list-item value="radiator"
                  >${S(`devices.system_type_radiator`,this.hass.language)}</ha-list-item
                >
                <ha-list-item value="underfloor"
                  >${S(`devices.system_type_underfloor`,this.hass.language)}</ha-list-item
                >
              </ha-select>
              ${this._showBoostHint?m`
                    <div class="boost-hint">
                      <ha-icon icon="mdi:information-outline"></ha-icon>
                      <span
                        >${S(`devices.heating_system_type_boost_hint`,this.hass.language)}</span
                      >
                    </div>
                  `:h}
            </div>
          `:h}
    `}_renderMasterRow(e,t){let n=this._selectedThermostats.has(e),r=this._selectedCoolingDevices.has(e),i=n||r,a=this._selectedForEdit===e,o=this.hass.states[e]?.attributes?.friendly_name||e,s=this.devices.find(t=>t.entity_id===e),c=n?S(`devices.type_thermostat`,this.hass.language):r?S(`devices.type_ac`,this.hass.language):``;return m`
      <div
        class="master-row ${a?`focused`:``} ${i?`in-room`:``}"
        @click=${()=>this._onSelectForEdit(e)}
      >
        <ha-checkbox
          .checked=${i}
          @click=${e=>e.stopPropagation()}
          @change=${t=>{let n=t.target;this._onClimateToggle(e,n.checked),n.checked&&(this._selectedForEdit=e)}}
        ></ha-checkbox>
        <div class="master-info">
          <div class="master-name-row">
            <span class="master-name">${o}</span>
            ${t?m`<span class="external-badge"
                  >${S(`devices.other_area`,this.hass.language)}</span
                >`:h}
          </div>
          <div class="master-meta">
            ${c?m`<span class="type-pill">${c}</span>`:h}
            ${s?.idle_action&&s.idle_action!==`off`?m`<span class="meta-pill"
                  >${S(`devices.idle_action_${s.idle_action}`,this.hass.language)}</span
                >`:h}
            ${s?.setpoint_mode===`direct`&&this.selectedTempSensor?m`<span class="meta-pill"
                  >${S(`devices.setpoint_mode_direct`,this.hass.language)}</span
                >`:h}
          </div>
        </div>
      </div>
    `}_onSelectForEdit(e){this._selectedForEdit=e}_renderDeviceDetail(e){let t=this.devices.find(t=>t.entity_id===e);if(!t)return h;let n=t.type===`trv`,r=t.type===`ac`,i=this.hass.states[e],a=i?.attributes?.friendly_name||e,o=(i?.attributes?.hvac_modes??[]).includes(`fan_only`),s=this.valveProtectionExclude.has(e),c=this.hass.language;return m`
      <div class="detail-head">
        <div class="detail-title">${a}</div>
        <div class="detail-entity-id">${e}</div>
      </div>

      <div class="detail-field">
        <ha-select
          .label=${S(`devices.type_label`,c)||`Type`}
          .value=${this._getDeviceDisplayType(e)}
          .options=${[{value:`thermostat`,label:S(`devices.type_thermostat`,c)},{value:`ac`,label:S(`devices.type_ac`,c)}]}
          @selected=${t=>this._onDeviceTypeChange(e,P(t))}
          @closed=${e=>e.stopPropagation()}
          fixedMenuPosition
        >
          <ha-list-item value="thermostat"
            >${S(`devices.type_thermostat`,c)}</ha-list-item
          >
          <ha-list-item value="ac">${S(`devices.type_ac`,c)}</ha-list-item>
        </ha-select>
      </div>

      ${r?m`
            <div class="detail-field">
              <ha-select
                .label=${S(`devices.idle_action`,c)}
                .value=${t.idle_action??`off`}
                .options=${[{value:`off`,label:S(`devices.idle_action_off`,c)},...o?[{value:`fan_only`,label:S(`devices.idle_action_fan_only`,c)}]:[],{value:`setback`,label:S(`devices.idle_action_setback`,c)}]}
                @selected=${t=>this._onIdleActionChange(e,P(t))}
                @closed=${e=>e.stopPropagation()}
                fixedMenuPosition
              >
                <ha-list-item value="off"
                  >${S(`devices.idle_action_off`,c)}</ha-list-item
                >
                ${o?m`<ha-list-item value="fan_only"
                      >${S(`devices.idle_action_fan_only`,c)}</ha-list-item
                    >`:h}
                <ha-list-item value="setback"
                  >${S(`devices.idle_action_setback`,c)}</ha-list-item
                >
              </ha-select>
            </div>
            <div class="detail-field with-info">
              <ha-entity-picker
                .hass=${this.hass}
                .includeDomains=${[`sensor`]}
                .value=${t.power_sensor_entity_id??``}
                .label=${S(`devices.power_sensor`,c)}
                @value-changed=${t=>this._onPowerSensorChange(e,t.detail?.value??``)}
              ></ha-entity-picker>
              <rs-info-icon .text=${S(`devices.power_sensor_hint`,c)}></rs-info-icon>
            </div>
            ${t.idle_action===`fan_only`?m`<div class="detail-field">
                  <ha-select
                    .label=${S(`devices.idle_fan_mode`,c)}
                    .value=${t.idle_fan_mode===``?`__keep__`:t.idle_fan_mode??`low`}
                    .options=${[{value:`__keep__`,label:S(`devices.idle_fan_mode_keep`,c)},...(i?.attributes?.fan_modes??[]).map(e=>({value:e,label:e}))]}
                    @selected=${t=>{let n=P(t);this._onIdleFanModeChange(e,n===`__keep__`?``:n)}}
                    @closed=${e=>e.stopPropagation()}
                    fixedMenuPosition
                  >
                    <ha-list-item value="__keep__"
                      >${S(`devices.idle_fan_mode_keep`,c)}</ha-list-item
                    >
                    ${(i?.attributes?.fan_modes??[]).map(e=>m`<ha-list-item value="${e}">${e}</ha-list-item>`)}
                  </ha-select>
                </div>`:h}
            ${t.idle_action===`fan_only`?m`<div class="detail-field fan-only-conditions">
                  <div class="section-subtitle">
                    ${S(`devices.fan_only_conditions`,c)}
                  </div>
                  ${Gt.map(({option:n,label:r})=>m`<label class="fan-only-condition">
                        <ha-checkbox
                          .checked=${!!t[n]}
                          @change=${t=>this._onFanOnlyOptionChange(e,n,t.target.checked)}
                        ></ha-checkbox>
                        ${S(r,c)}
                      </label>`)}
                  <div class="section-subtitle">${S(`devices.fan_only_seasons`,c)}</div>
                  <div class="fan-only-seasons">
                    ${[`spring`,`summer`,`autumn`,`winter`].map(n=>m`<label class="fan-only-condition">
                          <ha-checkbox
                            .checked=${(t.fan_only_seasons??[]).includes(n)}
                            @change=${t=>this._onFanOnlySeasonChange(e,n,t.target.checked)}
                          ></ha-checkbox>
                          ${S(`devices.fan_only_season_${n}`,c)}
                        </label>`)}
                  </div>
                  <div class="fan-only-hint">${S(`devices.fan_only_season_hint`,c)}</div>
                </div>`:h}
          `:h}
      ${n?m`
            <div class="detail-field with-info">
              <ha-select
                .label=${S(`devices.idle_action`,c)}
                .value=${t.idle_action??`off`}
                .options=${[{value:`off`,label:S(`devices.idle_action_off`,c)},{value:`low`,label:S(`devices.idle_action_low`,c)}]}
                @selected=${t=>this._onIdleActionChange(e,P(t))}
                @closed=${e=>e.stopPropagation()}
                fixedMenuPosition
              >
                <ha-list-item value="off"
                  >${S(`devices.idle_action_off`,c)}</ha-list-item
                >
                <ha-list-item value="low"
                  >${S(`devices.idle_action_low`,c)}</ha-list-item
                >
              </ha-select>
              ${t.idle_action===`low`?m`<rs-info-icon
                    .text=${S(`devices.idle_action_low_hint`,c)}
                  ></rs-info-icon>`:h}
            </div>
          `:h}
      ${this.selectedTempSensor?m`
            <div class="detail-field with-info">
              <ha-select
                .label=${S(`devices.setpoint_mode`,c)}
                .value=${t.setpoint_mode??`proportional`}
                .options=${[{value:`proportional`,label:S(`devices.setpoint_mode_proportional`,c)},{value:`direct`,label:S(`devices.setpoint_mode_direct`,c)}]}
                @selected=${t=>this._onSetpointModeChange(e,P(t))}
                @closed=${e=>e.stopPropagation()}
                fixedMenuPosition
              >
                <ha-list-item value="proportional"
                  >${S(`devices.setpoint_mode_proportional`,c)}</ha-list-item
                >
                <ha-list-item value="direct"
                  >${S(`devices.setpoint_mode_direct`,c)}</ha-list-item
                >
              </ha-select>
              <rs-info-icon .text=${S(`devices.setpoint_mode_hint`,c)}></rs-info-icon>
            </div>
          `:h}
      ${n&&this.valveProtectionEnabled?m`
            <div class="detail-toggle-row">
              <ha-checkbox
                .checked=${s}
                @change=${t=>{let n=t.target;this._onValveProtectionExcludeToggle(e,n.checked)}}
              ></ha-checkbox>
              <div class="detail-toggle-label">
                <ha-icon icon="mdi:shield-off-outline"></ha-icon>
                ${S(`devices.valve_protection_excluded`,c)}
                <rs-info-icon
                  .text=${S(`devices.valve_protection_exclude_hint`,c)}
                ></rs-info-icon>
              </div>
            </div>
          `:h}
    `}_detectClimateType(e){return(this.hass.states[e]?.attributes?.hvac_modes??[]).some(e=>[`cool`,`heat_cool`].includes(e))?`ac`:`thermostat`}_getDeviceDisplayType(e){let t=this.devices.find(t=>t.entity_id===e);return t&&t.type===`ac`?`ac`:`thermostat`}_onClimateToggle(e,t){let n;if(t){let t=this._detectClimateType(e)===`thermostat`?`trv`:`ac`;n=[...this.devices,{entity_id:e,type:t,role:`auto`}]}else n=this.devices.filter(t=>t.entity_id!==e);this._fireDeviceChanged(n)}_onDeviceTypeChange(e,t){let n=t===`thermostat`?`trv`:`ac`,r=this.devices.map(t=>{if(t.entity_id!==e)return t;let r={...t,type:n};return n===`ac`&&r.idle_action===`low`&&(r.idle_action=`off`),r});this._fireDeviceChanged(r)}_onValveProtectionExcludeToggle(e,t){this.dispatchEvent(new CustomEvent(`valve-protection-exclude-toggle`,{detail:{entityId:e,excluded:t},bubbles:!0,composed:!0}))}_onIdleActionChange(e,t){let n=this.devices.map(n=>{if(n.entity_id!==e)return n;let r={...n,idle_action:t};return t===`fan_only`&&!n.idle_fan_mode&&(r.idle_fan_mode=`low`),r});this._fireDeviceChanged(n)}_onIdleFanModeChange(e,t){let n=this.devices.map(n=>n.entity_id===e?{...n,idle_fan_mode:t}:n);this._fireDeviceChanged(n)}_onFanOnlyOptionChange(e,t,n){this._fireDeviceChanged(this.devices.map(r=>r.entity_id===e?{...r,[t]:n}:r))}_onFanOnlySeasonChange(e,t,n){this._fireDeviceChanged(this.devices.map(r=>{if(r.entity_id!==e)return r;let i=new Set(r.fan_only_seasons??[]);return n?i.add(t):i.delete(t),{...r,fan_only_seasons:[...i]}}))}_onPowerSensorChange(e,t){let n=this.devices.map(n=>n.entity_id===e?{...n,power_sensor_entity_id:t}:n);this._fireDeviceChanged(n)}_onSetpointModeChange(e,t){let n=this.devices.map(n=>n.entity_id===e?{...n,setpoint_mode:t}:n);this._fireDeviceChanged(n)}_onHeatingSystemTypeChange(e){let t=P(e)??``,n=t===`standard`?``:t;this._showBoostHint=!0;let r=this.devices.map(e=>e.type===`trv`?{...e,heating_system_type:n}:e);this._fireDeviceChanged(r)}_fireDeviceChanged(e){this.dispatchEvent(new CustomEvent(`device-changed`,{detail:{devices:e},bubbles:!0,composed:!0}))}_onEntityPicked(e){let t=e.detail?.value,n=e.target;if(n.value=``,!t||!t.startsWith(`climate.`)||this.devices.some(e=>e.entity_id===t))return;let r=this._detectClimateType(t)===`thermostat`?`trv`:`ac`,i=[...this.devices,{entity_id:t,type:r,role:`auto`}];this._fireDeviceChanged(i)}};k([y({attribute:!1})],R.prototype,`hass`,void 0),k([y({attribute:!1})],R.prototype,`area`,void 0),k([y({attribute:!1})],R.prototype,`devices`,void 0),k([y({type:String})],R.prototype,`selectedTempSensor`,void 0),k([y({attribute:!1})],R.prototype,`valveProtectionExclude`,void 0),k([y({type:Boolean})],R.prototype,`valveProtectionEnabled`,void 0),k([y({type:Boolean})],R.prototype,`editing`,void 0),k([b()],R.prototype,`_systemTypeInfoExpanded`,void 0),k([b()],R.prototype,`_showBoostHint`,void 0),k([b()],R.prototype,`_selectedThermostats`,void 0),k([b()],R.prototype,`_selectedCoolingDevices`,void 0),k([b()],R.prototype,`_heatingSystemType`,void 0),k([b()],R.prototype,`_selectedForEdit`,void 0),R=k([v(`rs-device-section`)],R),_(),x(),A();var Kt=class extends g{constructor(...e){super(...e),this.label=``,this.value=``,this.includeDomains=[],this.currentValue=``,this.currentValueLabel=``}static{this.styles=[I,l`
      :host {
        display: block;
      }

      ha-entity-picker {
        width: 100%;
      }

      .current-value {
        font-size: 13px;
        color: var(--secondary-text-color);
        margin-top: 4px;
      }
    `]}render(){return m`
      <ha-entity-picker
        .hass=${this.hass}
        .label=${this.label}
        .value=${this.value}
        .includeDomains=${this.includeDomains}
        allow-custom-entity
        @value-changed=${this._onValueChanged}
      ></ha-entity-picker>
      ${this.currentValue?m`<div class="current-value">
            ${this.currentValueLabel?m`${this.currentValueLabel}: `:h}${this.currentValue}
          </div>`:h}
    `}_onValueChanged(e){e.stopPropagation(),this.dispatchEvent(new CustomEvent(`value-changed`,{detail:e.detail.value??``,bubbles:!0,composed:!0}))}};k([y({attribute:!1})],Kt.prototype,`hass`,void 0),k([y({type:String})],Kt.prototype,`label`,void 0),k([y({type:String})],Kt.prototype,`value`,void 0),k([y({type:Array})],Kt.prototype,`includeDomains`,void 0),k([y({type:String})],Kt.prototype,`currentValue`,void 0),k([y({type:String})],Kt.prototype,`currentValueLabel`,void 0),Kt=k([v(`rs-entity-picker-field`)],Kt),_(),x(),A();var qt=class extends g{constructor(...e){super(...e),this.label=``,this.suffix=``,this.hint=``}static{this.styles=[I,l`
      :host {
        display: block;
      }

      .row {
        display: flex;
        align-items: center;
        gap: 6px;
      }

      ha-textfield {
        display: block;
        flex: 1;
        min-width: 0;
      }

      rs-info-icon {
        flex-shrink: 0;
      }
    `]}render(){return m`
      <div class="row">
        <ha-textfield
          .label=${this.label}
          .suffix=${this.suffix}
          .value=${this.value==null?``:String(this.value)}
          .min=${this.min==null?``:String(this.min)}
          .max=${this.max==null?``:String(this.max)}
          .step=${this.step==null?``:String(this.step)}
          type="number"
          @input=${this._onInput}
        ></ha-textfield>
        ${this.hint?m`<rs-info-icon .text=${this.hint}></rs-info-icon>`:h}
      </div>
    `}_onInput(e){let t=parseFloat(e.target.value);isNaN(t)||this.dispatchEvent(new CustomEvent(`value-changed`,{detail:t,bubbles:!0,composed:!0}))}};k([y({type:String})],qt.prototype,`label`,void 0),k([y({type:String})],qt.prototype,`suffix`,void 0),k([y({type:Number})],qt.prototype,`value`,void 0),k([y({type:Number})],qt.prototype,`min`,void 0),k([y({type:Number})],qt.prototype,`max`,void 0),k([y({type:Number})],qt.prototype,`step`,void 0),k([y({type:String})],qt.prototype,`hint`,void 0),qt=k([v(`rs-threshold-field`)],qt),_(),x(),A();var Jt=class extends g{constructor(...e){super(...e),this.label=``,this.hint=``,this.checked=!1,this.disabled=!1}static{this.styles=l`
    :host {
      display: block;
    }

    .toggle-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 16px;
    }

    .toggle-text {
      display: flex;
      align-items: center;
      gap: 4px;
      min-width: 0;
    }

    .toggle-label {
      font-weight: 500;
    }

    ha-switch {
      flex-shrink: 0;
    }
  `}render(){return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${this.label}</span>
          ${this.hint?m`<rs-info-icon .text=${this.hint}></rs-info-icon>`:h}
        </div>
        <ha-switch
          .checked=${this.checked}
          .disabled=${this.disabled}
          @change=${this._onToggle}
        ></ha-switch>
      </div>
    `}_onToggle(e){this.dispatchEvent(new CustomEvent(`toggle-changed`,{detail:e.target.checked,bubbles:!0,composed:!0}))}};k([y({type:String})],Jt.prototype,`label`,void 0),k([y({type:String})],Jt.prototype,`hint`,void 0),k([y({type:Boolean})],Jt.prototype,`checked`,void 0),k([y({type:Boolean})],Jt.prototype,`disabled`,void 0),Jt=k([v(`rs-toggle-row`)],Jt),_(),x(),A();var z=class extends g{constructor(...e){super(...e),this.areaId=``,this.rooms={},this.config=null,this.editing=!1,this.climateControlActive=!0,this.roomControlEnabled=!0,this.currentHumidity=null}static{this.styles=[I,l`
      :host {
        display: block;
      }
      .fields,
      .overview {
        display: grid;
        gap: 16px;
      }
      * {
        box-sizing: border-box;
      }
      .panel,
      .device,
      .room-summary {
        border: 1px solid var(--divider-color, rgba(128, 128, 128, 0.18));
        border-radius: 14px;
        padding: 16px;
        min-width: 0;
      }
      .panel {
        display: grid;
        gap: 14px;
      }
      .panel-heading {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .step,
      .device-icon {
        display: grid;
        place-items: center;
        flex-shrink: 0;
        width: 30px;
        height: 30px;
        border-radius: 9px;
        color: var(--primary-color);
        background: color-mix(in srgb, var(--primary-color) 10%, transparent);
        font-size: 12px;
        font-weight: 700;
      }
      h4 {
        margin: 0;
        font-size: 14px;
        font-weight: 600;
        color: var(--primary-text-color);
      }
      .eyebrow {
        display: block;
        color: var(--secondary-text-color);
        font-size: 12px;
        margin-bottom: 6px;
      }
      .room-summary {
        background: var(--secondary-background-color);
        display: grid;
        gap: 14px;
      }
      .summary-heading,
      .name,
      .summary-values {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        flex-wrap: wrap;
      }
      .summary-values > div {
        flex: 1;
        min-width: 100px;
      }
      .metric {
        font-size: 28px;
        line-height: 1.2;
        font-weight: 600;
        letter-spacing: -0.04em;
        font-variant-numeric: tabular-nums;
      }
      .metric small {
        font-size: 16px;
        color: var(--secondary-text-color);
        margin-inline-start: 3px;
      }
      .badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 5px 9px;
        border-radius: 8px;
        font-size: 11px;
        line-height: 1.4;
        background: var(--secondary-background-color);
        color: var(--secondary-text-color);
      }
      .badge.active {
        color: var(--primary-color);
        background: color-mix(in srgb, var(--primary-color) 12%, transparent);
      }
      .badge.warning {
        color: var(--warning-color, #e99b22);
        background: color-mix(in srgb, var(--warning-color, #e99b22) 12%, transparent);
      }
      .device {
        display: grid;
        gap: 12px;
      }
      .device-identity {
        display: flex;
        align-items: center;
        gap: 10px;
        min-width: 0;
        flex: 1;
      }
      .device-icon {
        width: 38px;
        height: 38px;
        --mdc-icon-size: 22px;
      }
      .device-identity > div {
        min-width: 0;
      }
      .device-name {
        font-weight: 600;
        overflow-wrap: anywhere;
      }
      .chips {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
      }
      .chip {
        padding: 5px 9px;
        border: 1px solid var(--divider-color, rgba(128, 128, 128, 0.18));
        border-radius: 8px;
        font-size: 12px;
      }
      .chip.host {
        border-style: dashed;
        color: var(--primary-color);
      }
      .notice {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 12px;
        border-radius: 10px;
        background: var(--secondary-background-color);
      }
      .notice ha-icon {
        --mdc-icon-size: 18px;
        flex-shrink: 0;
        color: var(--primary-color);
      }
      .notice.warning {
        border-inline-start: 3px solid var(--warning-color, #e99b22);
      }
      .notice strong {
        display: block;
        font-size: 12px;
        margin-bottom: 4px;
        color: var(--primary-text-color);
      }
      .choices {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px;
      }
      .choices.priority {
        grid-template-columns: repeat(3, minmax(0, 1fr));
      }
      .choice {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        justify-content: flex-start;
        padding: 12px;
        border: 1px solid var(--divider-color, rgba(128, 128, 128, 0.2));
        border-radius: 10px;
        color: var(--primary-text-color);
        line-height: 1.5;
      }
      .choice[aria-pressed="true"] {
        border-color: var(--primary-color);
        background: color-mix(in srgb, var(--primary-color) 8%, transparent);
      }
      .choice strong {
        display: block;
        font-size: 13px;
        margin-bottom: 4px;
      }
      .choice .hint {
        font-size: 12px;
      }
      .room-options {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(min(100%, 190px), 1fr));
        gap: 8px;
      }
      .room-option {
        padding: 8px 10px;
        border: 1px solid var(--divider-color, rgba(128, 128, 128, 0.2));
        border-radius: 10px;
        cursor: pointer;
        font-size: 13px;
        min-width: 0;
        overflow-wrap: anywhere;
      }
      .room-option.selected {
        border-color: color-mix(in srgb, var(--primary-color) 45%, transparent);
        background: color-mix(in srgb, var(--primary-color) 6%, transparent);
      }
      details {
        border-top: 1px solid var(--divider-color, rgba(128, 128, 128, 0.16));
        padding-top: 12px;
      }
      summary {
        cursor: pointer;
        color: var(--secondary-text-color);
        font-size: 13px;
        line-height: 1.6;
      }
      summary:focus-visible {
        outline: 2px solid var(--primary-color);
        outline-offset: 4px;
      }
      .details-body {
        display: grid;
        gap: 12px;
        padding-top: 14px;
      }
      .facts {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
        margin: 0;
      }
      dt {
        font-size: 12px;
        color: var(--secondary-text-color);
        margin-bottom: 4px;
      }
      dd {
        margin: 0;
        font-size: 16px;
        font-weight: 600;
      }
      .guide {
        margin: 0;
        padding-inline-start: 20px;
        display: grid;
        gap: 10px;
      }
      .numbers {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(min(100%, 140px), 1fr));
        gap: 12px;
      }
      .hint {
        color: var(--secondary-text-color);
        font-size: 13px;
        line-height: 1.5;
        margin: 0;
      }
      button {
        font: inherit;
        color: var(--primary-color);
        background: none;
        border: 0;
        cursor: pointer;
        padding: 4px 0;
        text-align: start;
      }
      button:focus-visible {
        outline: 2px solid var(--primary-color);
        outline-offset: 2px;
      }
      .configure {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        justify-self: start;
        min-height: 44px;
        padding: 10px 14px;
        border: 1px solid var(--primary-color);
        border-radius: 10px;
      }
      .configure ha-icon {
        --mdc-icon-size: 18px;
      }
      label {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      fieldset {
        border: 0;
        margin: 0;
        padding: 0;
      }
      @media (max-width: 480px) {
        .choices.priority {
          grid-template-columns: 1fr;
        }
        .panel,
        .device,
        .room-summary {
          padding: 12px;
        }
      }
    `]}_label(e){return S(e,this.hass.language)}_roomName(e){return this.rooms[e]?.display_name||this.hass.areas?.[e]?.name||e}_deviceChanged(e){this.dispatchEvent(new CustomEvent(`dehumidifier-changed`,{detail:e,bubbles:!0,composed:!0}))}_humidityChanged(e){this.dispatchEvent(new CustomEvent(`humidity-changed`,{detail:e,bubbles:!0,composed:!0}))}_selectDevice(e){e.stopPropagation(),this._deviceChanged(e.detail?{served_area_ids:[],mode:`auto`,min_run_minutes:5,min_off_minutes:5,power_watts:0,...this.config,entity_id:e.detail}:null)}_number(e,t){this.config&&this._deviceChanged({...this.config,[e]:Math.max(0,Math.min(e===`power_watts`?1e5:1440,t))})}_heading(e,t){return m`<div class="panel-heading">
      <span class="step">${e}</span>
      <h4>${this._label(t)}</h4>
    </div>`}_disabledNotice(e){return m`<div class="notice warning" role="status">
      <ha-icon icon="mdi:pause-circle-outline"></ha-icon>
      <div>
        <strong>${this._label(`dehumidifier.reason_disabled`)}</strong>
        <p class="hint">${S(`dehumidifier.disabled_hint`,this.hass.language,{room:e})}</p>
      </div>
    </div>`}_guide(){return m`<details>
      <summary>${this._label(`dehumidifier.how_it_works`)}</summary>
      <ol class="details-body guide hint">
        <li>${this._label(`dehumidifier.guide_device`)}</li>
        <li>${this._label(`dehumidifier.guide_comfort`)}</li>
        <li>${this._label(`dehumidifier.guide_shared`)}</li>
      </ol>
    </details>`}render(){if(!this.editing)return this._view();let e=this.config,t=(this.live?.devices??[]).filter(e=>e.owner_area_id!==this.areaId);return m`<div class="fields">
      <p class="hint">${this._label(`dehumidifier.intro`)}</p>
      ${this._guide()}
      ${!this.climateControlActive||e&&!this.roomControlEnabled?this._disabledNotice(this._roomName(this.areaId)):h}
      <section class="panel">
        ${this._heading(`1`,`dehumidifier.device`)}
        <rs-entity-picker-field
          .hass=${this.hass}
          .label=${this._label(`dehumidifier.device`)}
          .value=${e?.entity_id??``}
          .includeDomains=${[`humidifier`,`switch`]}
          @value-changed=${this._selectDevice}
        ></rs-entity-picker-field>
        <p class="hint">${this._label(`dehumidifier.device_hint`)}</p>
        ${!e&&t.length?m`<div class="notice">
              <ha-icon icon="mdi:home-group"></ha-icon>
              <div>
                <strong>${this._label(`dehumidifier.shared_available`)}</strong>
                <p class="hint">
                  ${t.map(e=>this._roomName(e.owner_area_id)).join(`, `)}.
                  ${this._label(`dehumidifier.shared_available_hint`)}
                </p>
              </div>
            </div>`:h}
        ${e?m`
              <h4>${this._label(`dehumidifier.mode`)}</h4>
              <div class="choices" role="group" aria-label=${this._label(`dehumidifier.mode`)}>
                ${[`auto`,`manual`].map(t=>m` <button
                      type="button"
                      class="choice"
                      aria-pressed=${e.mode===t}
                      @click=${()=>this._deviceChanged({...e,mode:t})}
                    >
                      <strong>${this._label(`dehumidifier.${t}`)}</strong>
                      <span class="hint"
                        >${this._label(t===`auto`?`dehumidifier.auto_hint`:`dehumidifier.manual_option_hint`)}</span
                      >
                    </button>`)}
              </div>
            `:h}
      </section>
      ${e?m`<section class="panel">
            ${this._heading(`2`,`dehumidifier.served_rooms`)}
            <p class="hint">${this._label(`dehumidifier.coverage_hint`)}</p>
            <div class="chips">
              <span class="chip host"
                >${this._roomName(this.areaId)} · ${this._label(`dehumidifier.host_room`)}</span
              >
            </div>
            <fieldset>
              <legend class="eyebrow">${this._label(`dehumidifier.additional_rooms`)}</legend>
              <div class="room-options">
                ${Object.entries(this.rooms).filter(([e,t])=>e!==this.areaId&&!t.is_outdoor).map(([t])=>m` <label
                        class="room-option ${e.served_area_ids.includes(t)?`selected`:``}"
                      >
                        <ha-checkbox
                          .checked=${e.served_area_ids.includes(t)}
                          @change=${n=>{let r=n.target.checked;this._deviceChanged({...e,served_area_ids:r?[...new Set([...e.served_area_ids,t])]:e.served_area_ids.filter(e=>e!==t)})}}
                        ></ha-checkbox
                        >${this._roomName(t)}
                      </label>`)}
              </div>
            </fieldset>
            ${e.served_area_ids.length?m`<p class="hint">${this._label(`dehumidifier.shared_hint`)}</p>`:h}
          </section>`:h}
      <section class="panel">
        ${this._heading(e?`3`:`2`,`dehumidifier.room_comfort`)}
        <rs-toggle-row
          .label=${this._label(`dehumidifier.comfort`)}
          .checked=${this.humidity.humidity_comfort_enabled}
          @toggle-changed=${e=>this._humidityChanged({humidity_comfort_enabled:e.detail})}
        ></rs-toggle-row>
        <p class="hint">${this._label(`dehumidifier.comfort_hint`)}</p>
        <div class="numbers">
          <rs-threshold-field
            .label=${this._label(`dehumidifier.target`)}
            .value=${this.humidity.humidity_target}
            .min=${30}
            .max=${80}
            .step=${1}
            suffix="%"
            @value-changed=${e=>this._humidityChanged({humidity_target:Math.max(30,Math.min(80,e.detail))})}
          ></rs-threshold-field>
          <rs-threshold-field
            .label=${this._label(`dehumidifier.tolerance`)}
            .value=${this.humidity.humidity_tolerance}
            .min=${0}
            .max=${20}
            .step=${1}
            suffix="%"
            @value-changed=${e=>this._humidityChanged({humidity_tolerance:Math.max(0,Math.min(20,e.detail))})}
          ></rs-threshold-field>
        </div>
        <p class="hint">${this._label(`dehumidifier.tolerance_hint`)}</p>
        <h4>${this._label(`dehumidifier.priority`)}</h4>
        <div
          class="choices priority"
          role="group"
          aria-label=${this._label(`dehumidifier.priority`)}
        >
          ${[`comfort`,`balanced`,`energy`].map(e=>m` <button
                type="button"
                class="choice"
                aria-pressed=${this.humidity.humidity_priority===e}
                @click=${()=>this._humidityChanged({humidity_priority:e})}
              >
                <strong>${this._label(`dehumidifier.priority_${e}`)}</strong>
                <span class="hint">${this._label(`dehumidifier.priority_${e}_hint`)}</span>
              </button>`)}
        </div>
      </section>
      ${e?m`<details>
            <summary>${this._label(`dehumidifier.protections`)}</summary>
            <div class="details-body">
              <p class="hint">${this._label(`dehumidifier.timing_hint`)}</p>
              <div class="numbers">
                ${[`min_run_minutes`,`min_off_minutes`,`power_watts`].map(t=>m` <rs-threshold-field
                      .label=${this._label(`dehumidifier.${t}`)}
                      .value=${e[t]}
                      .min=${0}
                      .max=${t===`power_watts`?1e5:1440}
                      .step=${1}
                      .suffix=${t===`power_watts`?`W`:`min`}
                      @value-changed=${e=>this._number(t,e.detail)}
                    ></rs-threshold-field>`)}
              </div>
              <p class="hint">${this._label(`dehumidifier.power_hint`)}</p>
            </div>
          </details>`:h}
    </div>`}_deviceView(e){let t=e.served_area_ids.length>1,n=e.available?e.state===`on`?e.action===`drying`?`dehumidifier.drying`:e.action===`idle`?`dehumidifier.idle`:`dehumidifier.on`:`dehumidifier.off`:`dehumidifier.reason_unavailable`;return m`<div class="device">
      <div class="name">
        <div class="device-identity">
          <ha-icon class="device-icon" icon="mdi:air-humidifier"></ha-icon>
          <div>
            <button
              type="button"
              class="device-name"
              @click=${()=>Rt(this,e.entity_id)}
            >
              ${this.hass.states[e.entity_id]?.attributes.friendly_name??e.entity_id}
            </button>
            <p class="hint">
              ${this._label(`dehumidifier.host`)}: ${this._roomName(e.owner_area_id)}
            </p>
          </div>
        </div>
        <span class="badge ${e.available&&e.state===`on`?`active`:``}"
          >${this._label(n)}</span
        >
      </div>
      <div>
        <span class="eyebrow"
          >${this._label(t?`dehumidifier.shared_device`:`dehumidifier.local_device`)}</span
        >
        <div class="chips">
          ${e.served_area_ids.map(t=>m`<span class="chip ${t===e.owner_area_id?`host`:``}"
                >${this._roomName(t)}</span
              >`)}
        </div>
      </div>
      ${e.reason===`disabled`?this._disabledNotice(this._roomName(e.owner_area_id)):e.reason?m`<div
              class="notice ${e.reason===`unavailable`||e.reason===`error`?`warning`:``}"
            >
              <ha-icon
                icon=${e.reason===`manual`?`mdi:hand-back-right-outline`:`mdi:pause-circle-outline`}
              ></ha-icon>
              <div>
                <strong>${this._label(`dehumidifier.reason_${e.reason}`)}</strong>
                ${e.reason===`manual`?m`<p class="hint">${this._label(`dehumidifier.manual_hint`)}</p>`:h}
              </div>
            </div>`:e.state===`off`&&!e.requested?m`<p class="hint">${this._label(`dehumidifier.waiting_hint`)}</p>`:h}
      ${e.commanded!=null&&(e.commanded?e.state!==`on`:e.state===`on`)?m`<p class="hint">
            ${this._label(e.commanded?`dehumidifier.command_on`:`dehumidifier.command_off`)}
          </p>`:h}
      ${this.live?.assigned_entity_id===e.entity_id?m`<p class="hint">${this._label(`dehumidifier.assigned`)}</p>`:h}
      ${e.pending_rooms.length?m`<p class="hint">
            ${this._label(`dehumidifier.requests`)}:
            ${e.pending_rooms.map(e=>this._roomName(e)).join(`, `)}
          </p>`:h}
      ${e.target_humidity!=null||e.humidity_floor!=null?m`<details>
            <summary>${this._label(`dehumidifier.device_details`)}</summary>
            <div class="details-body">
              <dl class="facts">
                ${e.target_humidity==null?h:m`<div>
                      <dt>${this._label(`dehumidifier.device_target`)}</dt>
                      <dd>${e.target_humidity}%</dd>
                    </div>`}
                ${e.humidity_floor==null?h:m`<div>
                      <dt>${this._label(`dehumidifier.floor`)}</dt>
                      <dd>${e.humidity_floor}%</dd>
                    </div>`}
              </dl>
              ${t?m`<p class="hint">${this._label(`dehumidifier.device_target_hint`)}</p>`:h}
            </div>
          </details>`:h}
    </div>`}_view(){let e=this.live?.devices??[];return m`<div class="overview">
      <div class="room-summary">
        <div class="summary-heading">
          <h4>${this._label(`dehumidifier.room_comfort`)}</h4>
          <span class="badge ${this.humidity.humidity_comfort_enabled?`active`:``}"
            >${this._label(this.humidity.humidity_comfort_enabled?`dehumidifier.comfort_enabled`:`dehumidifier.comfort_disabled`)}</span
          >
        </div>
        <div class="summary-values">
          ${this.currentHumidity==null?h:m`<div>
                <span class="eyebrow">${this._label(`dehumidifier.measured`)}</span
                ><span class="metric">${Math.round(this.currentHumidity)}<small>%</small></span>
              </div>`}
          <div>
            <span class="eyebrow">${this._label(`dehumidifier.target`)}</span
            ><span class="metric">${this.humidity.humidity_target}<small>%</small></span>
          </div>
        </div>
        ${this.humidity.humidity_comfort_enabled?h:m`<p class="hint">${this._label(`dehumidifier.comfort_off_hint`)}</p>`}
      </div>
      ${e.length?h:m`<div class="notice">
            <ha-icon icon="mdi:air-humidifier"></ha-icon>
            <p class="hint">
              ${this._label(this.config?`dehumidifier.status_pending`:`dehumidifier.empty`)}
            </p>
          </div>`}
      ${e.map(e=>this._deviceView(e))}
      ${this.live?.request?m`<p class="hint">
            ${this._label(this.live.request===`mold`?`dehumidifier.request_mold`:`dehumidifier.request_comfort`)}
          </p>`:h}
      <button
        class="configure"
        type="button"
        @click=${()=>this.dispatchEvent(new CustomEvent(`edit-click`,{bubbles:!0,composed:!0}))}
      >
        <ha-icon icon=${this.config||e.length?`mdi:tune-variant`:`mdi:plus`}></ha-icon>
        ${this._label(this.config||e.length?`dehumidifier.configure`:`dehumidifier.add`)}
      </button>
    </div>`}};k([y({attribute:!1})],z.prototype,`hass`,void 0),k([y({type:String})],z.prototype,`areaId`,void 0),k([y({attribute:!1})],z.prototype,`rooms`,void 0),k([y({attribute:!1})],z.prototype,`config`,void 0),k([y({attribute:!1})],z.prototype,`live`,void 0),k([y({attribute:!1})],z.prototype,`humidity`,void 0),k([y({type:Boolean})],z.prototype,`editing`,void 0),k([y({type:Boolean})],z.prototype,`climateControlActive`,void 0),k([y({type:Boolean})],z.prototype,`roomControlEnabled`,void 0),k([y({type:Number})],z.prototype,`currentHumidity`,void 0),z=k([v(`rs-dehumidifier-section`)],z),_(),x(),A();var Yt=[{value:.8,key:`devices.wall_preset_plain`},{value:.7,key:`devices.wall_preset_corner`},{value:.6,key:`devices.wall_preset_bridge`}],B=class extends g{constructor(...e){super(...e),this.temperatureSensor=``,this.humiditySensor=``,this.occupancySensors=new Set,this.windowSensors=new Set,this.windowOpenDelay=0,this.windowCloseDelay=0,this.keepFanOnlyOnWindowOpen=!0,this.moldFRsi=.8,this._calcSurface=``,this._calcRoom=``,this._calcOutdoor=``,this.heatingSystemType=``,this.editing=!1,this.language=`en`,this._pickerOpen=!1,this._collapsed={},this._globalEntityFilter=e=>{let t=e.entity_id;if(t.substring(t.indexOf(`.`)+1).startsWith(`roommind_`)||this.temperatureSensor===t||this.humiditySensor===t||this.occupancySensors.has(t)||this.windowSensors.has(t))return!1;if(t.startsWith(`sensor.`)){let e=this.hass.states[t]?.attributes?.device_class;return e===`temperature`||e===`humidity`}if(t.startsWith(`binary_sensor.`)){let e=this.hass.states[t]?.attributes?.device_class;return e===`occupancy`||e===`motion`||e===`presence`||e===`window`||e===`door`||e===`opening`}return t.startsWith(`climate.`)?this.hass.states[t]?.attributes?.current_temperature!=null:t.startsWith(`input_number.`)||t.startsWith(`input_boolean.`)},this._onGlobalPickerValueChanged=e=>{let t=e.detail?.value,n=e.target;if(n.value=``,t){if(t.startsWith(`binary_sensor.`)){let e=this.hass.states[t]?.attributes?.device_class;e===`window`||e===`door`||e===`opening`?this.windowSensors.has(t)||this._onWindowToggle(t,!0):this.occupancySensors.has(t)||this._onOccupancyToggle(t,!0)}else if(t.startsWith(`input_boolean.`))this.occupancySensors.has(t)||this._onOccupancyToggle(t,!0);else if(t.startsWith(`input_number.`)){let e=this.hass.states[t]?.attributes?.unit_of_measurement;this._onSensorSelected(t,e===`%`?`humidity`:`temp`)}else if(t.startsWith(`climate.`))this._onSensorSelected(t,`temp`);else{let e=this.hass.states[t]?.attributes?.device_class;this._onSensorSelected(t,e===`humidity`?`humidity`:`temp`)}this._pickerOpen=!1}},this._onKeepFanOnlyWindowChange=e=>{let t=e.target.checked;this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`keep_fan_only_on_window_open`,value:t},bubbles:!0,composed:!0}))},this._onWindowOpenDelayChange=e=>{let t=Math.max(0,parseInt(e.target.value)||0);this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`window_open_delay`,value:t},bubbles:!0,composed:!0}))},this._onWindowCloseDelayChange=e=>{let t=Math.max(0,parseInt(e.target.value)||0);this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`window_close_delay`,value:t},bubbles:!0,composed:!0}))}}static{this.styles=[I,Ut,l`
      :host {
        display: block;
      }

      .sensor-block {
        display: flex;
        flex-direction: column;
        gap: 6px;
        padding: 12px 14px;
        background: rgba(255, 255, 255, 0.02);
        border: 1px solid var(--divider-color, rgba(255, 255, 255, 0.08));
        border-radius: 12px;
      }

      .sensor-block + .sensor-block {
        margin-top: 12px;
      }

      .block-header {
        display: flex;
        align-items: center;
        gap: 8px;
        padding-bottom: 6px;
        cursor: pointer;
        user-select: none;
      }

      .block-header:hover .block-title {
        color: var(--primary-color);
      }

      .block-header ha-icon {
        --mdc-icon-size: 18px;
        color: var(--secondary-text-color);
      }

      .chevron {
        --mdc-icon-size: 18px;
        color: var(--secondary-text-color);
        transition: transform 0.2s ease;
      }

      .chevron.collapsed {
        transform: rotate(-90deg);
      }

      .block-body {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .sensor-block.collapsed .block-header {
        padding-bottom: 0;
      }

      .block-title {
        font-size: 13px;
        font-weight: 500;
        color: var(--primary-text-color);
        letter-spacing: 0.2px;
        flex: 1;
      }

      .count-chip {
        font-size: 11px;
        font-weight: 500;
        padding: 1px 7px;
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.06);
        color: var(--secondary-text-color);
      }

      .count-chip.has-selection {
        background: rgba(3, 169, 244, 0.15);
        color: var(--primary-color);
      }

      .row-list {
        display: flex;
        flex-direction: column;
        gap: 2px;
        max-height: 168px;
        overflow-y: auto;
        overflow-x: hidden;
        scrollbar-width: thin;
      }

      .row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 6px 8px;
        border-radius: 8px;
        cursor: pointer;
        border-left: 2px solid transparent;
        transition:
          background 0.15s,
          border-color 0.15s;
        min-width: 0;
      }

      .row:hover {
        background: rgba(255, 255, 255, 0.03);
      }

      .row.selected {
        background: rgba(3, 169, 244, 0.08);
        border-left-color: var(--primary-color);
      }

      .row ha-checkbox,
      .row ha-radio {
        flex-shrink: 0;
        margin: -4px 0;
      }

      .row-info {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 1px;
      }

      .row-name-line {
        display: flex;
        align-items: center;
        gap: 6px;
        min-width: 0;
      }

      .row-name {
        font-size: 13px;
        font-weight: 450;
        color: var(--primary-text-color);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .row-eid {
        font-family: var(--code-font-family, monospace);
        font-size: 10.5px;
        color: var(--secondary-text-color);
        opacity: 0.65;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .external-badge {
        display: inline-flex;
        align-items: center;
        font-size: 9.5px;
        font-weight: 500;
        color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.1);
        padding: 1px 6px;
        border-radius: 8px;
        letter-spacing: 0.3px;
        text-transform: uppercase;
        flex-shrink: 0;
      }

      .value-chip {
        flex-shrink: 0;
        font-size: 12px;
        font-weight: 500;
        padding: 3px 9px;
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.05);
        color: var(--primary-text-color);
        font-variant-numeric: tabular-nums;
      }

      .row.selected .value-chip {
        background: rgba(3, 169, 244, 0.15);
        color: var(--primary-color);
      }

      .occupancy-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        flex-shrink: 0;
        transition: background 0.2s;
      }

      .occupancy-dot.on {
        background: var(--success-color, #4caf50);
        box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.18);
      }

      .occupancy-dot.off {
        background: rgba(255, 255, 255, 0.2);
      }

      .window-dot.on {
        background: var(--warning-color, #ff9800);
        box-shadow: 0 0 0 3px rgba(255, 152, 0, 0.18);
      }

      .window-dot.off {
        background: rgba(255, 255, 255, 0.2);
      }

      .delay-fields {
        display: flex;
        gap: 8px;
        margin-top: 8px;
      }

      .delay-fields ha-textfield {
        flex: 1;
      }

      .delay-hint {
        display: flex;
        align-items: flex-start;
        gap: 6px;
        font-size: 11.5px;
        line-height: 1.5;
        color: var(--warning-color, #ff9800);
        margin-top: 6px;
      }

      .delay-hint ha-icon {
        --mdc-icon-size: 16px;
        flex-shrink: 0;
        margin-top: 1px;
      }

      .fan-window-toggle {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        margin-top: 10px;
        padding: 9px 10px;
        border-radius: 9px;
        background: rgba(255, 255, 255, 0.025);
      }
      .fan-window-toggle-text {
        min-width: 0;
      }
      .fan-window-toggle-label {
        display: block;
        color: var(--primary-text-color);
        font-size: 12.5px;
        font-weight: 500;
      }
      .fan-window-toggle-hint {
        display: block;
        color: var(--secondary-text-color);
        font-size: 11px;
        line-height: 1.4;
        margin-top: 2px;
      }

      .delay-view {
        font-size: 12px;
        color: var(--secondary-text-color);
        padding-top: 4px;
      }

      .empty-row {
        color: var(--secondary-text-color);
        font-size: 12.5px;
        font-style: italic;
        padding: 6px 4px;
        opacity: 0.7;
      }

      .add-row,
      .global-add {
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .global-add {
        margin-top: 12px;
      }

      .add-row ha-entity-picker,
      .global-add ha-entity-picker {
        flex: 1;
      }

      .add-button {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 10px;
        margin: 12px 0 0 0;
        background: none;
        border: none;
        cursor: pointer;
        color: var(--secondary-text-color);
        font-size: 12px;
        font-weight: 500;
        border-radius: 6px;
        transition:
          color 0.15s,
          background 0.15s;
      }

      .add-button:hover,
      .add-button:focus-visible {
        color: var(--primary-color);
        background: rgba(3, 169, 244, 0.08);
        outline: none;
      }

      .add-button ha-icon {
        --mdc-icon-size: 16px;
      }

      .picker-close {
        --mdc-icon-button-size: 32px;
        --mdc-icon-size: 18px;
        color: var(--secondary-text-color);
        flex-shrink: 0;
      }

      /* View mode rows */
      .view-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 6px 0;
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .view-name {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .entity-link {
        cursor: pointer;
      }

      .entity-link:hover {
        text-decoration: underline;
      }

      .view-value {
        font-weight: 500;
        flex-shrink: 0;
      }

      .section-subtitle {
        font-size: 12px;
        font-weight: 500;
        color: var(--secondary-text-color);
        margin: 12px 0 4px 0;
        text-transform: uppercase;
        letter-spacing: 0.4px;
      }

      .section-subtitle:first-child {
        margin-top: 0;
      }
    `]}render(){return this.editing?this._renderEditMode():this._renderViewMode()}_renderViewMode(){let e=!!this.temperatureSensor,t=!!this.humiditySensor,n=this.occupancySensors.size>0,r=this.windowSensors.size>0,i=this.hass.language;return m`
      <div class="equipment-view">
        ${!e&&!t&&!n&&!r?m`<p class="equipment-empty">${S(`equipment.no_sensors`,i)}</p>`:h}
        ${e?m`
              <div class="sensor-group">
                <div class="section-subtitle">${S(`devices.temp_sensors`,i)}</div>
                ${this._renderSensorViewRow(this.temperatureSensor,`temp`)}
              </div>
            `:h}
        ${t?m`
              <div class="sensor-group">
                <div class="section-subtitle">${S(`devices.humidity_sensors`,i)}</div>
                ${this._renderSensorViewRow(this.humiditySensor,`humidity`)}
                <div class="delay-view">
                  ${S(`devices.wall_factor`,i)}: ${this.moldFRsi.toFixed(2)}
                  (${this._wallPresetLabel(i)})
                </div>
              </div>
            `:h}
        ${n?m`
              <div class="sensor-group">
                <div class="section-subtitle">${S(`devices.occupancy_sensors`,i)}</div>
                ${[...this.occupancySensors].map(e=>this._renderOccupancyViewRow(e))}
              </div>
            `:h}
        ${r?m`
              <div class="sensor-group">
                <div class="section-subtitle">${S(`devices.window_sensors`,i)}</div>
                ${[...this.windowSensors].map(e=>this._renderWindowViewRow(e))}
                ${this.windowOpenDelay||this.windowCloseDelay?m`<div class="delay-view">
                      ${this.windowOpenDelay?m`${S(`devices.window_open_delay`,i)}:
                          ${this.windowOpenDelay}s`:h}
                      ${this.windowOpenDelay&&this.windowCloseDelay?` · `:h}
                      ${this.windowCloseDelay?m`${S(`devices.window_close_delay`,i)}:
                          ${this.windowCloseDelay}s`:h}
                    </div>`:h}
              </div>
            `:h}
        <button
          type="button"
          class="equipment-edit"
          @click=${()=>this.dispatchEvent(new CustomEvent(`edit-click`,{bubbles:!0,composed:!0}))}
        >
          <ha-icon icon="mdi:tune-variant"></ha-icon>${S(`equipment.edit_sensors`,i)}
        </button>
      </div>
    `}_renderWindowViewRow(e){let t=this.hass.states[e],n=t?.attributes?.friendly_name||e,r=t?.state===`on`;return m`
      <div class="view-row">
        <ha-icon class="view-icon" icon="mdi:window-closed-variant"></ha-icon>
        <button
          type="button"
          class="view-name entity-link"
          @click=${()=>Rt(this,e)}
        >
          ${n}
        </button>
        <span class="sensor-state"
          ><span class="occupancy-dot window-dot ${r?`on`:`off`}"></span>
          ${S(t?.state===`on`?`equipment.open`:t?.state===`off`?`equipment.closed`:`equipment.unavailable`,this.hass.language)}
        </span>
      </div>
    `}_renderSensorViewRow(e,t){let n=this.hass.states[e],r=n?.attributes?.friendly_name||e,i=n?.state,a=n?.attributes??{},o=``;if(t===`temp`){let t=e.startsWith(`climate.`)?a.current_temperature:i;t!=null&&t!==``&&t!==`unknown`&&t!==`unavailable`&&(o=`${Number(t).toFixed(1)}${C(this.hass)}`)}else i&&i!==`unknown`&&i!==`unavailable`&&(o=`${Math.round(Number(i))}%`);return m`
      <div class="view-row">
        <ha-icon
          class="view-icon"
          icon=${t===`temp`?`mdi:thermometer`:`mdi:water-percent`}
        ></ha-icon>
        <button
          type="button"
          class="view-name entity-link"
          @click=${()=>Rt(this,e)}
        >
          ${r}
        </button>
        ${o?m`<span class="view-value">${o}</span>`:h}
      </div>
    `}_renderOccupancyViewRow(e){let t=this.hass.states[e],n=t?.attributes?.friendly_name||e,r=t?.state===`on`;return m`
      <div class="view-row">
        <ha-icon class="view-icon" icon="mdi:motion-sensor"></ha-icon>
        <button
          type="button"
          class="view-name entity-link"
          @click=${()=>Rt(this,e)}
        >
          ${n}
        </button>
        <span class="occupancy-dot ${r?`on`:`off`}"></span>
      </div>
    `}_renderEditMode(){let e=bt(this.area.area_id,this.hass?.entities,this.hass?.devices).filter(e=>!e.entity_id.substring(e.entity_id.indexOf(`.`)+1).startsWith(`roommind_`)),t=this.hass?.states?e.filter(e=>e.entity_id.startsWith(`sensor.`)&&this.hass.states[e.entity_id]?.attributes?.device_class===`temperature`||e.entity_id.startsWith(`climate.`)&&this.hass.states[e.entity_id]?.attributes?.current_temperature!=null):[],n=this.hass?.states?e.filter(e=>e.entity_id.startsWith(`sensor.`)&&this.hass.states[e.entity_id]?.attributes?.device_class===`humidity`):[],r=this.hass?.states?e.filter(e=>e.entity_id.startsWith(`binary_sensor.`)&&[`occupancy`,`motion`,`presence`].includes(this.hass.states[e.entity_id]?.attributes?.device_class)||e.entity_id.startsWith(`input_boolean.`)):[],i=new Set(t.map(e=>e.entity_id)),a=this.temperatureSensor&&!i.has(this.temperatureSensor)?this.temperatureSensor:null,o=new Set(n.map(e=>e.entity_id)),s=this.humiditySensor&&!o.has(this.humiditySensor)?this.humiditySensor:null,c=new Set(r.map(e=>e.entity_id)),l=[...this.occupancySensors].filter(e=>!c.has(e)),u=this.hass?.states?e.filter(e=>e.entity_id.startsWith(`binary_sensor.`)&&[`window`,`door`,`opening`].includes(this.hass.states[e.entity_id]?.attributes?.device_class)):[],d=new Set(u.map(e=>e.entity_id)),f=[...this.windowSensors].filter(e=>!d.has(e)),p=this.hass.language;return m`
      ${this._renderBlock({kind:`temp`,icon:`mdi:thermometer`,title:S(`devices.temp_sensors`,p),emptyText:S(`devices.no_temp_sensors`,p),areaSensors:t,externalSensors:a?[a]:[],selectedCount:+!!this.temperatureSensor})}
      ${this._renderBlock({kind:`humidity`,icon:`mdi:water-percent`,title:S(`devices.humidity_sensors`,p),emptyText:S(`devices.no_humidity_sensors`,p),areaSensors:n,externalSensors:s?[s]:[],selectedCount:+!!this.humiditySensor,extras:this._renderHumidityExtras(p)})}
      ${this._renderBlock({kind:`occupancy`,icon:`mdi:account-eye`,title:S(`devices.occupancy_sensors`,p),emptyText:S(`devices.no_occupancy_sensors`,p),areaSensors:r,externalSensors:l,selectedCount:this.occupancySensors.size})}
      ${this._renderBlock({kind:`window`,icon:`mdi:window-open-variant`,title:S(`devices.window_sensors`,p),emptyText:S(`devices.no_window_sensors`,p),areaSensors:u,externalSensors:f,selectedCount:this.windowSensors.size,extras:this._renderWindowExtras(p)})}
      ${this._renderGlobalAdd(p)}
    `}_renderWindowExtras(e){return this.windowSensors.size===0?h:m`
      <div class="delay-fields">
        <ha-textfield
          type="number"
          min="0"
          suffix="s"
          .label=${S(`devices.window_open_delay`,e)}
          .value=${String(this.windowOpenDelay)}
          @change=${this._onWindowOpenDelayChange}
        ></ha-textfield>
        <ha-textfield
          type="number"
          min="0"
          suffix="s"
          .label=${S(`devices.window_close_delay`,e)}
          .value=${String(this.windowCloseDelay)}
          @change=${this._onWindowCloseDelayChange}
        ></ha-textfield>
      </div>
      <div class="fan-window-toggle">
        <div class="fan-window-toggle-text">
          <span class="fan-window-toggle-label"
            >${S(`devices.keep_fan_only_window`,e)}</span
          >
          <span class="fan-window-toggle-hint"
            >${S(`devices.keep_fan_only_window_hint`,e)}</span
          >
        </div>
        <ha-switch
          .checked=${this.keepFanOnlyOnWindowOpen}
          @change=${this._onKeepFanOnlyWindowChange}
        ></ha-switch>
      </div>
      ${this.heatingSystemType===`underfloor`&&this.windowOpenDelay<300?m`
            <div class="delay-hint">
              <ha-icon icon="mdi:information-outline"></ha-icon>
              ${S(`devices.underfloor_delay_hint`,e)}
            </div>
          `:h}
    `}_wallPresetLabel(e){let t=Yt.find(e=>Math.abs(e.value-this.moldFRsi)<.005);return S(t?t.key:`devices.wall_preset_measured`,e)}_renderHumidityExtras(e){if(!this.humiditySensor)return h;let t=Yt.find(e=>Math.abs(e.value-this.moldFRsi)<.005),n=parseFloat(this._calcSurface),r=parseFloat(this._calcRoom),i=parseFloat(this._calcOutdoor),a=(n-i)/(r-i),o=r-i>=5&&a>=.5&&a<=.95,s=C(this.hass);return m`
      <div class="fan-window-toggle-text" style="margin-top: 10px">
        <span class="fan-window-toggle-label">${S(`devices.wall_factor`,e)}</span>
        <span class="fan-window-toggle-hint">${S(`devices.wall_factor_hint`,e)}</span>
      </div>
      <div class="delay-fields">
        <ha-select
          .label=${S(`devices.wall_preset`,e)}
          .value=${t?String(t.value):`custom`}
          fixedMenuPosition
          @selected=${e=>{let t=P(e);t&&t!==`custom`&&this._fireWallFactor(parseFloat(t))}}
          @closed=${e=>e.stopPropagation()}
        >
          ${Yt.map(t=>m`<ha-list-item value=${String(t.value)}
                >${S(t.key,e)} (${t.value.toFixed(2)})</ha-list-item
              >`)}
          <ha-list-item value="custom"
            >${S(`devices.wall_preset_measured`,e)}</ha-list-item
          >
        </ha-select>
        <ha-textfield
          type="number"
          min="0.5"
          max="0.95"
          step="0.01"
          .label=${S(`devices.wall_factor`,e)}
          .value=${this.moldFRsi.toFixed(2)}
          @change=${e=>this._fireWallFactor(parseFloat(e.target.value))}
        ></ha-textfield>
      </div>
      <div class="fan-window-toggle-hint" style="margin-top: 10px">
        ${S(`devices.wall_measure_hint`,e)}
      </div>
      <div class="delay-fields">
        ${[[`devices.wall_measure_surface`,this._calcSurface,e=>this._calcSurface=e],[`devices.wall_measure_room`,this._calcRoom,e=>this._calcRoom=e],[`devices.wall_measure_outdoor`,this._calcOutdoor,e=>this._calcOutdoor=e]].map(([t,n,r])=>m`<ha-textfield
              type="number"
              step="0.1"
              .suffix=${s}
              .label=${S(t,e)}
              .value=${n}
              @input=${e=>r(e.target.value)}
            ></ha-textfield>`)}
      </div>
      ${o?m`<ha-button @click=${()=>this._fireWallFactor(Math.round(a*100)/100)}>
            ${S(`devices.wall_measure_apply`,e,{value:a.toFixed(2)})}
          </ha-button>`:this._calcSurface&&this._calcRoom&&this._calcOutdoor?m`<div class="delay-hint">
              <ha-icon icon="mdi:information-outline"></ha-icon>
              ${S(`devices.wall_measure_invalid`,e)}
            </div>`:h}
    `}_fireWallFactor(e){isNaN(e)||e<.5||e>.95||this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`mold_f_rsi`,value:e},bubbles:!0,composed:!0}))}_renderGlobalAdd(e){return this._pickerOpen?m`
        <div class="global-add">
          <ha-entity-picker
            .hass=${this.hass}
            .includeDomains=${[`sensor`,`binary_sensor`,`climate`,`input_number`,`input_boolean`]}
            .entityFilter=${this._globalEntityFilter}
            .value=${``}
            .autofocus=${!0}
            label=${S(`devices.add_entity`,e)}
            @value-changed=${this._onGlobalPickerValueChanged}
          ></ha-entity-picker>
          <ha-icon-button
            class="picker-close"
            .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
            @click=${()=>this._pickerOpen=!1}
          ></ha-icon-button>
        </div>
      `:m`
      <button type="button" class="add-button global" @click=${()=>this._pickerOpen=!0}>
        <ha-icon icon="mdi:plus"></ha-icon>
        ${S(`devices.add_entity`,e)}
      </button>
    `}_renderBlock(e){let t=e.areaSensors.length+e.externalSensors.length,n=this._collapsed[e.kind]??!0;return m`
      <div class="sensor-block ${n?`collapsed`:``}">
        <div class="block-header" @click=${()=>this._toggleBlock(e.kind)}>
          <ha-icon icon=${e.icon}></ha-icon>
          <div class="block-title">${e.title}</div>
          ${e.selectedCount>0?m`<span class="count-chip has-selection">${e.selectedCount}</span>`:t>0?m`<span class="count-chip">${t}</span>`:h}
          <ha-icon
            class="chevron ${n?`collapsed`:``}"
            icon="mdi:chevron-down"
          ></ha-icon>
        </div>
        ${n?h:m`
              <div class="block-body">
                <div class="row-list">
                  ${e.areaSensors.length>0||e.externalSensors.length>0?m`
                        ${e.areaSensors.map(t=>this._renderEditRow(t.entity_id,e.kind,!1))}
                        ${e.externalSensors.map(t=>this._renderEditRow(t,e.kind,!0))}
                      `:m`<div class="empty-row">${e.emptyText}</div>`}
                </div>
                ${e.extras??h}
              </div>
            `}
      </div>
    `}_toggleBlock(e){let t=this._collapsed[e]??!0;this._collapsed={...this._collapsed,[e]:!t}}_renderEditRow(e,t,n){let r=this.hass.states[e],i=r?.attributes?.friendly_name||e,a=this.hass.language;if(t===`occupancy`||t===`window`){let o=(t===`occupancy`?this.occupancySensors:this.windowSensors).has(e),s=r?.state===`on`,c=t===`window`?`occupancy-dot window-dot`:`occupancy-dot`,l=n=>t===`occupancy`?this._onOccupancyToggle(e,n):this._onWindowToggle(e,n);return m`
        <div
          class="row ${o?`selected`:``}"
          @click=${e=>{e.target.tagName!==`HA-CHECKBOX`&&l(!o)}}
        >
          <ha-checkbox
            .checked=${o}
            @change=${e=>{let t=e.target;l(t.checked)}}
          ></ha-checkbox>
          <div class="row-info">
            <div class="row-name-line">
              <span class="row-name">${i}</span>
              ${n?m`<span class="external-badge">${S(`devices.other_area`,a)}</span>`:h}
            </div>
            <div class="row-eid">${e}</div>
          </div>
          <span class="${c} ${s?`on`:`off`}"></span>
        </div>
      `}let o=(t===`temp`?this.temperatureSensor:this.humiditySensor)===e,s=t===`temp`?C(this.hass):`%`,c=e.startsWith(`climate.`)?r?.attributes?.current_temperature:r?.state,l=c&&c!==`unknown`&&c!==`unavailable`?`${t===`humidity`?Math.round(Number(c)):Number(c).toFixed(1)}${s}`:``;return m`
      <div
        class="row ${o?`selected`:``}"
        @click=${()=>this._onSensorSelected(o?``:e,t)}
      >
        <ha-radio .checked=${o} name="${t}-sensor"></ha-radio>
        <div class="row-info">
          <div class="row-name-line">
            <span class="row-name">${i}</span>
            ${n?m`<span class="external-badge">${S(`devices.other_area`,a)}</span>`:h}
          </div>
          <div class="row-eid">${e}</div>
        </div>
        ${l?m`<span class="value-chip">${l}</span>`:h}
      </div>
    `}_onSensorSelected(e,t){let n=t===`temp`?`temperature_sensor`:`humidity_sensor`;this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:n,value:e},bubbles:!0,composed:!0}))}_onOccupancyToggle(e,t){let n=new Set(this.occupancySensors);t?n.add(e):n.delete(e),this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`occupancy_sensors`,value:[...n]},bubbles:!0,composed:!0}))}_onWindowToggle(e,t){let n=new Set(this.windowSensors);t?n.add(e):n.delete(e),this.dispatchEvent(new CustomEvent(`sensor-changed`,{detail:{key:`window_sensors`,value:[...n]},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],B.prototype,`hass`,void 0),k([y({attribute:!1})],B.prototype,`area`,void 0),k([y({type:String})],B.prototype,`temperatureSensor`,void 0),k([y({type:String})],B.prototype,`humiditySensor`,void 0),k([y({attribute:!1})],B.prototype,`occupancySensors`,void 0),k([y({attribute:!1})],B.prototype,`windowSensors`,void 0),k([y({type:Number})],B.prototype,`windowOpenDelay`,void 0),k([y({type:Number})],B.prototype,`windowCloseDelay`,void 0),k([y({type:Boolean})],B.prototype,`keepFanOnlyOnWindowOpen`,void 0),k([y({type:Number})],B.prototype,`moldFRsi`,void 0),k([b()],B.prototype,`_calcSurface`,void 0),k([b()],B.prototype,`_calcRoom`,void 0),k([b()],B.prototype,`_calcOutdoor`,void 0),k([y({type:String})],B.prototype,`heatingSystemType`,void 0),k([y({type:Boolean})],B.prototype,`editing`,void 0),k([y()],B.prototype,`language`,void 0),k([b()],B.prototype,`_pickerOpen`,void 0),k([b()],B.prototype,`_collapsed`,void 0),B=k([v(`rs-sensor-section`)],B),_(),x(),A();var Xt=class extends g{constructor(...e){super(...e),this.label=``,this.hint=``}static{this.styles=l`
    :host {
      display: inline-block;
    }

    .badge {
      font-size: 10px;
      font-weight: 600;
      color: var(--primary-color);
      background: color-mix(in srgb, var(--primary-color) 12%, transparent);
      padding: 2px 6px;
      border-radius: 4px;
      letter-spacing: 0.5px;
      text-transform: uppercase;
      cursor: default;
    }
  `}render(){return m`<span class="badge" title=${this.hint}>${this.label}</span>`}};k([y({type:String})],Xt.prototype,`label`,void 0),k([y({type:String})],Xt.prototype,`hint`,void 0),Xt=k([v(`rs-badge`)],Xt),_(),x(),A();var Zt=`M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z`,Qt=class extends g{constructor(...e){super(...e),this.icon=``,this.heading=``,this.badge=``,this.badgeHint=``,this.editable=!1}static{this.styles=l`
    :host {
      display: block;
    }

    ha-card {
      overflow: hidden;
      min-width: 0;
      --ha-card-border-radius: 18px;
      --ha-card-box-shadow: none;
      border: 1px solid var(--divider-color, rgba(128, 128, 128, 0.16));
    }

    .section-header {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 19px 22px 16px;
    }

    .section-icon {
      --mdc-icon-size: 20px;
      color: var(--primary-color);
    }

    .section-title {
      font-size: 15px;
      font-weight: 700;
      letter-spacing: -0.02em;
      color: var(--primary-text-color);
      margin: 0;
      flex: 1;
    }

    .edit-btn {
      --mdc-icon-button-size: 32px;
      --mdc-icon-size: 18px;
      color: var(--secondary-text-color);
      margin: -4px -6px -4px 0;
      transition: opacity 0.15s ease;
    }

    @media (hover: hover) {
      .edit-btn {
        opacity: 0;
      }

      ha-card:hover .edit-btn,
      ha-card:focus-within .edit-btn {
        opacity: 1;
      }
    }

    .section-body {
      padding: 0 22px 22px;
    }
    @media (hover: none) {
      .edit-btn {
        opacity: 0.75;
      }
    }
    .edit-btn:focus-visible {
      opacity: 1;
    }
  `}render(){return m`
      <ha-card>
        <div class="section-header">
          <ha-icon class="section-icon" icon=${this.icon}></ha-icon>
          <h3 class="section-title">${this.heading}</h3>
          ${this.badge?m`<rs-badge .label=${this.badge} .hint=${this.badgeHint}></rs-badge>`:h}
          <slot name="header-extras"></slot>
          ${this.editable?m`
                <ha-icon-button
                  class="edit-btn"
                  .path=${Zt}
                  title=${this.heading}
                  aria-label=${this.heading}
                  @click=${this._onEditClick}
                ></ha-icon-button>
              `:h}
        </div>
        <div class="section-body">
          <slot></slot>
        </div>
      </ha-card>
    `}_onEditClick(){this.dispatchEvent(new CustomEvent(`edit-click`,{bubbles:!0,composed:!0}))}};k([y({type:String})],Qt.prototype,`icon`,void 0),k([y({type:String})],Qt.prototype,`heading`,void 0),k([y({type:String})],Qt.prototype,`badge`,void 0),k([y({type:String})],Qt.prototype,`badgeHint`,void 0),k([y({type:Boolean})],Qt.prototype,`editable`,void 0),Qt=k([v(`rs-section-card`)],Qt),_(),x(),A();var V=class extends g{constructor(...e){super(...e),this.climateMode=`auto`,this.comfortHeat=21,this.comfortCool=24,this.ecoHeat=17,this.ecoCool=27,this.language=`en`,this._overridePending=null,this._overrideCustomHeat=21,this._overrideCustomCool=24,this._overrideError=``,this._optimisticOverride=null,this._optimisticClear=!1}static{this.styles=[I,l`
      :host {
        display: block;
      }

      .override-divider {
        border: none;
        border-top: 1px solid var(--divider-color, #e0e0e0);
        margin: 16px 0 12px;
      }

      .override-label {
        font-size: 13px;
        font-weight: 500;
        color: var(--secondary-text-color);
        margin-bottom: 10px;
      }

      .override-presets {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
      }

      .override-preset {
        cursor: pointer;
        border: 1px solid var(--divider-color, #e0e0e0);
        border-radius: 8px;
        padding: 6px 12px;
        font-size: 13px;
        background: transparent;
        color: var(--primary-text-color);
        display: flex;
        align-items: center;
        gap: 6px;
        transition:
          background 0.15s,
          border-color 0.15s;
      }

      .override-preset:hover {
        background: rgba(0, 0, 0, 0.04);
      }

      .override-preset.pending {
        border-color: var(--primary-color);
        background: rgba(var(--rgb-primary-color, 33, 150, 243), 0.08);
      }

      .override-preset.active.boost {
        border-color: var(--warning-color, #ff9800);
        background: rgba(255, 152, 0, 0.15);
        color: var(--warning-color, #ff9800);
      }

      .override-preset.active.eco {
        border-color: #4caf50;
        background: rgba(76, 175, 80, 0.15);
        color: #4caf50;
      }

      .override-preset.active.custom {
        border-color: #2196f3;
        background: rgba(33, 150, 243, 0.15);
        color: #2196f3;
      }

      .override-preset:disabled {
        opacity: 0.35;
        cursor: default;
      }

      .override-preset:disabled:hover {
        background: transparent;
      }

      .override-preset ha-icon {
        --mdc-icon-size: 16px;
      }

      .override-target {
        display: block;
        width: 160px;
        margin-top: 12px;
      }

      .override-duration {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 12px;
        align-items: center;
      }

      .override-duration-label {
        font-size: 13px;
        font-weight: 500;
        color: var(--secondary-text-color);
      }

      .override-dur-chips {
        display: flex;
        gap: 6px;
      }

      .override-dur-chip {
        cursor: pointer;
        border: 1px solid var(--divider-color);
        border-radius: 8px;
        padding: 6px 14px;
        font-size: 13px;
        font-weight: 500;
        background: var(--card-background-color);
        color: var(--primary-text-color);
        transition:
          border-color 0.15s ease,
          background 0.15s ease;
      }

      .override-dur-chip:hover {
        background: rgba(255, 255, 255, 0.04);
        border-color: rgba(3, 169, 244, 0.4);
      }

      .override-dur-chip:disabled {
        opacity: 0.5;
        pointer-events: none;
      }

      .override-error {
        color: var(--error-color, #d32f2f);
        font-size: 12px;
        margin-top: 6px;
      }
    `]}updated(e){if(e.has(`config`)&&this.config?.live){let e=this.config.live;this._optimisticOverride&&e.override_active&&(this._optimisticOverride=null),this._optimisticClear&&!e.override_active&&(this._optimisticClear=!1)}}getEffectiveOverride(){if(this._optimisticClear)return{active:!1,type:null,heat:null,cool:null,until:null};if(this._optimisticOverride)return{active:!0,type:this._optimisticOverride.type,heat:this._optimisticOverride.heat,cool:this._optimisticOverride.cool,until:this._optimisticOverride.until};let e=this.config?.live;return e?.override_active&&e.override_type?{active:!0,type:e.override_type,heat:e.override_heat,cool:e.override_cool,until:e.override_until}:{active:!1,type:null,heat:null,cool:null,until:null}}render(){let e=this.getEffectiveOverride();return m`
      <hr class="override-divider" />
      <div class="override-label">${S(`override.label`,this.language)}</div>
      ${this._renderOverrideButtons(e)}
      ${this._overrideError?m`<div class="override-error">${this._overrideError}</div>`:h}
    `}_renderOverrideButtons(e){let t=e.active?e.type:null,n=!t&&this._overridePending;return m`
      <div class="override-presets">
        ${[`boost`,`eco`,`custom`].map(e=>{let n=t===e,r=t!==null&&!n,i=!t&&this._overridePending===e;return m`
            <button
              class="override-preset ${e} ${n?`active`:``} ${i?`pending`:``}"
              ?disabled=${r}
              @click=${()=>n?this._onClearOverride():this._onOverridePreset(e)}
            >
              <ha-icon
                icon=${e===`boost`?`mdi:fire`:e===`eco`?`mdi:leaf`:`mdi:thermometer`}
              ></ha-icon>
              ${S(e===`boost`?`override.comfort`:e===`eco`?`override.eco`:`override.custom`,this.language)}
            </button>
          `})}
      </div>
      ${n?m`
            ${this._overridePending===`custom`?this._renderCustomInputs():h}
            <div class="override-duration">
              <span class="override-duration-label"
                >${S(`override.activate_for`,this.language)}</span
              >
              <div class="override-dur-chips">
                ${[{label:`1h`,hours:1},{label:`2h`,hours:2},{label:`4h`,hours:4}].map(e=>m`
                    <button
                      class="override-dur-chip"
                      @click=${()=>this._onOverrideActivate(e.hours)}
                    >
                      ${e.label}
                    </button>
                  `)}
              </div>
            </div>
          `:h}
    `}_renderCustomInputs(){let e=O(5,35,this.hass),t=m`
      <ha-textfield
        class="override-target"
        type="number"
        .label=${S(this.climateMode===`auto`?`override.heat_to`:`override.target`,this.language)}
        .suffix=${C(this.hass)}
        min=${e.min}
        max=${e.max}
        step=${D(this.hass)}
        .value=${String(w(this._overrideCustomHeat,this.hass))}
        @input=${this._onCustomHeatInput}
      ></ha-textfield>
    `,n=m`
      <ha-textfield
        class="override-target"
        type="number"
        .label=${S(this.climateMode===`auto`?`override.cool_above`:`override.target`,this.language)}
        .suffix=${C(this.hass)}
        min=${e.min}
        max=${e.max}
        step=${D(this.hass)}
        .value=${String(w(this._overrideCustomCool,this.hass))}
        @input=${this._onCustomCoolInput}
      ></ha-textfield>
    `;return this.climateMode===`heat_only`?t:this.climateMode===`cool_only`?n:m`${t} ${n}`}_onOverridePreset(e){this._overridePending===e?this._overridePending=null:(this._overridePending=e,e===`custom`&&(this._overrideCustomHeat=this.comfortHeat,this._overrideCustomCool=this.comfortCool)),this._overrideError=``}_onCustomHeatInput(e){this._overrideCustomHeat=T(Number(e.target.value)||w(21,this.hass),this.hass)}_onCustomCoolInput(e){this._overrideCustomCool=T(Number(e.target.value)||w(24,this.hass),this.hass)}async _onOverrideActivate(e){if(!this._overridePending||!this.config)return;let t=this._overridePending,n,r;if(t===`boost`?(n=this.comfortHeat,r=this.comfortCool):t===`eco`?(n=this.ecoHeat,r=this.ecoCool):(n=this._overrideCustomHeat,r=this._overrideCustomCool),this.climateMode===`heat_only`&&(r=null),this.climateMode===`cool_only`&&(n=null),n!=null&&r!=null&&r<n){this._overrideError=S(`override.invalid_band`,this.language);return}this._optimisticOverride={type:t,heat:n,cool:r,until:Date.now()/1e3+e*3600},this._optimisticClear=!1,this._overridePending=null,this._overrideError=``;let i={type:`roommind/override/set`,area_id:this.config.area_id,override_type:t,duration:e};t===`custom`&&(this.climateMode!==`cool_only`&&(i.heat=this._overrideCustomHeat),this.climateMode!==`heat_only`&&(i.cool=this._overrideCustomCool));try{await this.hass.callWS(i),this._fireRoomUpdated()}catch(e){this._optimisticOverride=null,this._overrideError=e instanceof Error?e.message:S(`override.error_set`,this.language),console.error(`Override set failed:`,e)}}async _onClearOverride(){if(this.config){this._optimisticClear=!0,this._optimisticOverride=null,this._overrideError=``;try{await this.hass.callWS({type:`roommind/override/clear`,area_id:this.config.area_id}),this._fireRoomUpdated()}catch(e){this._optimisticClear=!1,this._overrideError=e instanceof Error?e.message:S(`override.error_clear`,this.language),console.error(`Override clear failed:`,e)}}}_fireRoomUpdated(){this.dispatchEvent(new CustomEvent(`room-updated`,{bubbles:!0,composed:!0}))}};k([y({attribute:!1})],V.prototype,`hass`,void 0),k([y({attribute:!1})],V.prototype,`config`,void 0),k([y()],V.prototype,`climateMode`,void 0),k([y({type:Number})],V.prototype,`comfortHeat`,void 0),k([y({type:Number})],V.prototype,`comfortCool`,void 0),k([y({type:Number})],V.prototype,`ecoHeat`,void 0),k([y({type:Number})],V.prototype,`ecoCool`,void 0),k([y()],V.prototype,`language`,void 0),k([b()],V.prototype,`_overridePending`,void 0),k([b()],V.prototype,`_overrideCustomHeat`,void 0),k([b()],V.prototype,`_overrideCustomCool`,void 0),k([b()],V.prototype,`_overrideError`,void 0),k([b()],V.prototype,`_optimisticOverride`,void 0),k([b()],V.prototype,`_optimisticClear`,void 0),V=k([v(`rs-override-section`)],V),_(),x(),A();var $t=[``,`work`,`sleep`,`guests`,`away`],H=class extends g{constructor(...e){super(...e),this.activeProfile=``,this.nightModeEnabled=!1,this.nightStart=`22:00`,this.nightEnd=`07:00`,this.nightHeatDelta=-.5,this.nightCoolDelta=.5,this.nightRampMinutes=60}static{this.styles=l`
    :host {
      display: block;
    }
    .profile-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
    }
    button {
      border: 1px solid var(--divider-color, rgba(127, 127, 127, 0.35));
      border-radius: 10px;
      padding: 10px;
      color: var(--primary-text-color);
      background: transparent;
      cursor: pointer;
      font: inherit;
      font-size: 13px;
      transition:
        background 0.15s ease,
        border-color 0.15s ease,
        color 0.15s ease;
    }
    button:hover {
      background: var(--secondary-background-color, rgba(127, 127, 127, 0.08));
    }
    button.active {
      border-color: var(--primary-color);
      color: var(--primary-color);
      background: color-mix(in srgb, var(--primary-color) 10%, transparent);
    }
    button.default {
      grid-column: 1 / -1;
    }
    .profile-hint {
      margin: -4px 0 10px;
      color: var(--secondary-text-color);
      font-size: 12px;
    }
    .profile-label {
      margin: 0 0 10px;
      color: var(--secondary-text-color);
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 0.06em;
    }
    .night {
      margin-top: 20px;
      padding: 14px;
      border: 1px solid var(--divider-color);
      border-radius: 10px;
      background: var(--secondary-background-color, rgba(127, 127, 127, 0.05));
    }
    .night-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 12px;
      margin-top: 14px;
    }
    label {
      display: grid;
      gap: 5px;
      color: var(--secondary-text-color);
      font-size: 12px;
    }
    input {
      min-width: 0;
      box-sizing: border-box;
      width: 100%;
      padding: 8px;
      border: 1px solid var(--divider-color);
      border-radius: 6px;
      color: var(--primary-text-color);
      background: var(--card-background-color, transparent);
      font: inherit;
    }
    .wide {
      grid-column: 1 / -1;
    }
  `}render(){let e=this.hass.language;return m`
      <p class="profile-label">${S(`comfort.profiles`,e)}</p>
      ${this.activeProfile?m`<p class="profile-hint">${S(`comfort.profile_clear_hint`,e)}</p>`:``}
      <div class="profile-grid">
        ${$t.map(t=>m`<button
              class=${`${t?``:`default`} ${this.activeProfile===t?`active`:``}`}
              aria-pressed=${this.activeProfile===t?`true`:`false`}
              @click=${()=>this._emit(`active_profile`,this.activeProfile===t?``:t)}
            >
              ${S(`comfort.profile.${t||`default`}`,e)}
            </button>`)}
      </div>
      <div class="night">
        <rs-toggle-row
          .label=${S(`comfort.night_mode`,e)}
          .hint=${S(`comfort.night_mode_hint`,e)}
          .checked=${this.nightModeEnabled}
          @toggle-changed=${e=>this._emit(`night_mode_enabled`,e.detail)}
        ></rs-toggle-row>
        ${this.nightModeEnabled?m`<div class="night-grid">
              ${this._timeField(`comfort.night_start`,this.nightStart,`night_start`)}
              ${this._timeField(`comfort.night_end`,this.nightEnd,`night_end`)}
              ${this._numberField(`comfort.night_heat_delta`,this.nightHeatDelta,`night_heat_delta`,-5,0,.1)}
              ${this._numberField(`comfort.night_cool_delta`,this.nightCoolDelta,`night_cool_delta`,0,5,.1)}
              ${this._numberField(`comfort.night_ramp`,this.nightRampMinutes,`night_ramp_minutes`,0,240,5,!0)}
            </div>`:``}
      </div>
    `}_timeField(e,t,n){return m`<label
      >${S(e,this.hass.language)}<input
        type="time"
        .value=${t}
        @change=${e=>this._emit(n,e.target.value)}
    /></label>`}_numberField(e,t,n,r,i,a,o=!1){return m`<label class=${o?`wide`:``}
      >${S(e,this.hass.language)}<input
        type="number"
        min=${r}
        max=${i}
        step=${a}
        .value=${String(t)}
        @change=${e=>{let t=Number(e.target.value);Number.isNaN(t)||this._emit(n,t)}}
    /></label>`}_emit(e,t){this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:e,value:t},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],H.prototype,`hass`,void 0),k([y({type:String})],H.prototype,`activeProfile`,void 0),k([y({type:Boolean})],H.prototype,`nightModeEnabled`,void 0),k([y({type:String})],H.prototype,`nightStart`,void 0),k([y({type:String})],H.prototype,`nightEnd`,void 0),k([y({type:Number})],H.prototype,`nightHeatDelta`,void 0),k([y({type:Number})],H.prototype,`nightCoolDelta`,void 0),k([y({type:Number})],H.prototype,`nightRampMinutes`,void 0),H=k([v(`rs-comfort-section`)],H),_(),x(),A();var en=class extends g{constructor(...e){super(...e),this.presenceEnabled=!1,this.presencePersons=[],this.selectedPresencePersons=[],this.ignorePresence=!1,this.editing=!1,this.language=`en`}static{this.styles=l`
    :host {
      display: block;
    }

    .presence-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 8px;
      margin-top: 12px;
    }

    .presence-card {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 12px 8px 6px;
      border: 1px solid var(--divider-color);
      border-radius: 10px;
      background: var(--card-background-color);
      cursor: pointer;
      transition:
        border-color 0.15s ease,
        background 0.15s ease;
      user-select: none;
    }

    .presence-card:hover {
      background: rgba(255, 255, 255, 0.03);
    }

    .presence-card.active {
      border-color: rgba(3, 169, 244, 0.4);
      background: rgba(3, 169, 244, 0.08);
    }

    .presence-card ha-checkbox {
      flex-shrink: 0;
    }

    .person-icon {
      --mdc-icon-size: 18px;
      color: var(--secondary-text-color);
      flex-shrink: 0;
    }

    .presence-card.active .person-icon {
      color: var(--primary-color);
    }

    .person-name {
      flex: 1;
      font-size: 14px;
      font-weight: 450;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .presence-list {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .presence-row {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 14px;
      border-radius: 8px;
      transition: background 0.3s;
    }

    .presence-row.home {
      background: rgba(76, 175, 80, 0.1);
    }

    .presence-row.away {
      background: rgba(0, 0, 0, 0.04);
    }

    .presence-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      flex-shrink: 0;
    }

    .presence-row.home .presence-dot {
      background: #4caf50;
      box-shadow: 0 0 6px rgba(76, 175, 80, 0.5);
    }

    .presence-row.away .presence-dot {
      background: var(--disabled-text-color, #bdbdbd);
    }

    .presence-name {
      flex: 1;
      font-size: 14px;
      font-weight: 500;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .presence-row.home .presence-name {
      color: var(--primary-text-color);
    }

    .presence-row.away .presence-name {
      color: var(--secondary-text-color);
    }

    .presence-state {
      font-size: 12px;
      white-space: nowrap;
    }

    .presence-row.home .presence-state {
      color: #2e7d32;
    }

    .presence-row.away .presence-state {
      color: var(--secondary-text-color);
    }

    .section-divider {
      border-top: 1px solid var(--divider-color, #e0e0e0);
      margin: 8px 0;
    }

    .field-hint {
      color: var(--secondary-text-color);
      font-size: 12px;
    }

    .presence-card.missing {
      border-color: var(--warning-color, #ff9800);
    }

    .missing-icon {
      --mdc-icon-size: 16px;
      color: var(--warning-color, #ff9800);
      flex-shrink: 0;
    }

    .missing-hint {
      margin-top: 8px;
      color: var(--secondary-text-color);
      font-size: 12px;
    }
  `}get _allPersons(){let e=this.selectedPresencePersons.filter(e=>!this.presencePersons.includes(e));return[...this.presencePersons,...e]}_isMissing(e){return!this.hass.states[e]}render(){return!this.presenceEnabled||!this.editing&&this._allPersons.length===0?h:this.editing?m`
      <rs-toggle-row
        .label=${S(`presence.ignore_toggle`,this.language)}
        .checked=${this.ignorePresence}
        @toggle-changed=${this._onIgnoreToggle}
      ></rs-toggle-row>
      ${this.ignorePresence?h:m`<div class="section-divider"></div>
            ${this._renderEditMode()}`}
    `:this.ignorePresence?m`<span class="field-hint"
          >${S(`presence.tile_ignored`,this.language)}</span
        >`:this._renderViewMode()}_renderEditMode(){let e=this._allPersons,t=e.some(e=>this._isMissing(e));return m`
      <div class="presence-grid">
        ${e.map(e=>{let t=this.selectedPresencePersons.includes(e),n=this._isMissing(e),r=this.hass.states[e]?.attributes?.friendly_name??e.split(`.`).slice(1).join(`.`);return m`
            <div
              class="presence-card ${t?`active`:``} ${n?`missing`:``}"
              role="checkbox"
              tabindex="0"
              aria-checked=${t}
              @click=${()=>this._onTogglePerson(e,t)}
              @keydown=${n=>{(n.key===`Enter`||n.key===` `)&&(n.preventDefault(),this._onTogglePerson(e,t))}}
            >
              <ha-checkbox
                .checked=${t}
                tabindex="-1"
                @click=${e=>e.stopPropagation()}
                @change=${()=>this._onTogglePerson(e,t)}
              ></ha-checkbox>
              <ha-icon class="person-icon" icon="mdi:account"></ha-icon>
              <span class="person-name">${r}</span>
              ${n?this._renderMissingIcon():h}
            </div>
          `})}
      </div>
      ${t?m`<div class="missing-hint">
            ${S(`presence.missing_entity_hint`,this.language)}
          </div>`:h}
    `}_renderMissingIcon(){return m`<ha-icon
      class="missing-icon"
      icon="mdi:alert-circle-outline"
      title=${S(`presence.missing_entity_hint`,this.language)}
    ></ha-icon>`}_renderViewMode(){return this.selectedPresencePersons.length===0?m`<span class="field-hint"
        >${S(`presence.room_none_assigned`,this.language)}</span
      >`:m`
      <div class="presence-list">
        ${this.selectedPresencePersons.map(e=>{let t=this.hass.states[e]?.attributes?.friendly_name??e.split(`.`).slice(1).join(`.`),n=this.hass.states[e]?.state,r=e.startsWith(`person.`)||e.startsWith(`device_tracker.`)?n===`home`:n===`on`;return m`
            <div class="presence-row ${r?`home`:`away`}">
              <span class="presence-dot"></span>
              <span class="presence-name">${t}</span>
              ${this._isMissing(e)?this._renderMissingIcon():h}
              <span class="presence-state"
                >${S(r?`presence.state_home`:`presence.state_away`,this.language)}</span
              >
            </div>
          `})}
      </div>
    `}_onIgnoreToggle(e){this.dispatchEvent(new CustomEvent(`ignore-presence-changed`,{detail:e.detail,bubbles:!0,composed:!0}))}_onTogglePerson(e,t){let n;n=t?this.selectedPresencePersons.filter(t=>t!==e):[...this.selectedPresencePersons,e],this.dispatchEvent(new CustomEvent(`presence-persons-changed`,{detail:n,bubbles:!0,composed:!0}))}};k([y({attribute:!1})],en.prototype,`hass`,void 0),k([y({type:Boolean})],en.prototype,`presenceEnabled`,void 0),k([y({attribute:!1})],en.prototype,`presencePersons`,void 0),k([y({attribute:!1})],en.prototype,`selectedPresencePersons`,void 0),k([y({type:Boolean})],en.prototype,`ignorePresence`,void 0),k([y({type:Boolean})],en.prototype,`editing`,void 0),k([y()],en.prototype,`language`,void 0),en=k([v(`rs-presence-section`)],en),_(),x(),A();var tn=class extends zt{constructor(...e){super(...e),this.schedules=[]}static{this.styles=[zt.sharedStyles,I,l`
      .pos-badge {
        font-size: 0.8em;
        padding: 1px 6px;
        border-radius: 10px;
        background: var(--primary-color);
        color: var(--text-primary-color);
        flex-shrink: 0;
      }
      .gate-badge {
        font-size: 0.8em;
        padding: 1px 6px;
        border-radius: 10px;
        background: var(--accent-color, var(--primary-color));
        color: var(--text-primary-color);
        opacity: 0.8;
        flex-shrink: 0;
      }
      .mode-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px;
        padding: 4px 0 0;
      }
      @media (max-width: 480px) {
        .mode-row {
          grid-template-columns: 1fr;
        }
      }
      .mode-option {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 6px 12px;
        font-size: 13px;
        cursor: pointer;
        color: var(--primary-text-color);
        border: 1px solid var(--divider-color);
        border-radius: 8px;
        background: var(--card-background-color);
        transition:
          border-color 0.15s ease,
          background 0.15s ease;
      }
      .mode-option.active {
        border-color: rgba(3, 169, 244, 0.4);
        background: rgba(3, 169, 244, 0.08);
      }
    `]}render(){return this.editing?this._renderEdit():this._renderView()}_renderView(){let e=this.hass.language;if(this.schedules.length===0)return h;let t=this.schedules.length>=2;return m`
      <div class="schedule-list">
        ${this.schedules.map((n,r)=>{let i=this._getScheduleState(r,this.schedules.length),a=n.mode===`gate`,o=a?null:this._getBlockPosition(n.entity_id);return m`
            <div class="schedule-row ${i}">
              ${t?m`<span class="schedule-number">${r+1}</span>`:h}
              <span class="schedule-status-dot"></span>
              <span
                class="schedule-name schedule-link"
                @click=${()=>this._openEntityInfo(n.entity_id)}
                >${this._getFriendlyName(n.entity_id)}</span
              >
              ${a?m`<span class="gate-badge"
                    >${S(`covers.schedule_mode_gate_short`,e)}</span
                  >`:o===null?h:m`<span class="pos-badge">${o}%</span>`}
              <span class="schedule-status">${this._statusText(i,e)}</span>
            </div>
          `})}
      </div>
    `}_renderEdit(){let e=this.hass.language,t=this.schedules.length,n=new Set(this.schedules.map(e=>e.entity_id));return m`
      ${t>0?m`
            <div class="schedule-list">
              ${this.schedules.map((n,r)=>{let i=this._getScheduleState(r,t);return m`
                  <div class="schedule-row ${i}">
                    ${t>=2?m`<span class="schedule-number">${r+1}</span>`:h}
                    <span class="schedule-status-dot"></span>
                    <span class="schedule-name">${this._getFriendlyName(n.entity_id)}</span>
                    <span class="schedule-status">${this._statusText(i,e)}</span>
                    ${this._renderScheduleControls(r,t,(e,t)=>this._moveSchedule(e,t),e=>this._removeSchedule(e))}
                  </div>
                  <div class="mode-row">
                    <div
                      class="mode-option ${(n.mode??`force`)===`force`?`active`:``}"
                      role="radio"
                      tabindex="0"
                      aria-checked=${(n.mode??`force`)===`force`}
                      @click=${()=>this._updateMode(r,`force`)}
                      @keydown=${e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),this._updateMode(r,`force`))}}
                    >
                      <ha-radio
                        .checked=${(n.mode??`force`)===`force`}
                        tabindex="-1"
                      ></ha-radio>
                      ${S(`covers.schedule_mode_force`,e)}
                    </div>
                    <div
                      class="mode-option ${n.mode===`gate`?`active`:``}"
                      role="radio"
                      tabindex="0"
                      aria-checked=${n.mode===`gate`}
                      @click=${()=>this._updateMode(r,`gate`)}
                      @keydown=${e=>{(e.key===`Enter`||e.key===` `)&&(e.preventDefault(),this._updateMode(r,`gate`))}}
                    >
                      <ha-radio .checked=${n.mode===`gate`} tabindex="-1"></ha-radio>
                      ${S(`covers.schedule_mode_gate`,e)}
                    </div>
                  </div>
                `})}
            </div>
          `:h}
      ${this._renderAddRow(S(`covers.add_schedule`,e),this._getAvailableEntities(n),e=>this._addSchedule(e),S(`covers.schedule_create_link`,e))}
      ${this._renderSelectorSection(t,S(`covers.schedule_selector`,e),S(`covers.schedule_selector_hint`,e),S(`covers.schedule_selector_warning`,e),e=>this._emitSelectorChanged(e))}
    `}_getBlockPosition(e){let t=this.hass?.states?.[e];if(!t||t.state!==`on`)return null;let n=t.attributes?.position;return n==null?null:Number(n)}_statusText(e,t){return S(e===`active`?`covers.schedule_state_active`:e===`unreachable`?`covers.schedule_state_unreachable`:`covers.schedule_state_inactive`,t)}_addSchedule(e){this._emitSchedules([...this.schedules,{entity_id:e,mode:`force`}])}_removeSchedule(e){this._emitSchedules(this.schedules.filter((t,n)=>n!==e))}_moveSchedule(e,t){let n=e+t;if(n<0||n>=this.schedules.length)return;let r=[...this.schedules];[r[e],r[n]]=[r[n],r[e]],this._emitSchedules(r)}_updateMode(e,t){let n=this.schedules.map((n,r)=>r===e?{...n,mode:t}:n);this._emitSchedules(n)}_emitSchedules(e){this.dispatchEvent(new CustomEvent(`cover-schedules-changed`,{detail:{value:e},bubbles:!0,composed:!0}))}_emitSelectorChanged(e){this.dispatchEvent(new CustomEvent(`cover-schedule-selector-changed`,{detail:{value:e},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],tn.prototype,`schedules`,void 0),tn=k([v(`rs-cover-schedule`)],tn),_(),x(),A();var nn,U=class extends g{static{nn=this}constructor(...e){super(...e),this.selectedCovers=new Set,this.editing=!1,this.autoEnabled=!1,this.deployThreshold=1.5,this.minPosition=0,this.overrideMinutes=60,this.autoPaused=!1,this.overrideUntil=null,this.coverSchedules=[],this.coverScheduleSelectorEntity=``,this.activeCoverScheduleIndex=-1,this.nightClose=!1,this.nightPosition=0,this.snapDeploy=!1,this.forcedReason=``,this.coverOrientations={},this.nightCloseElevation=0,this.nightCloseOffsetMinutes=0,this.outdoorMinTemp=10,this.coverMinPositions={},this._selectedForEdit=``,this._scheduleCollapsed=!0,this._solarCollapsed=!0,this._entityFilter=e=>{let t=e.entity_id;return!t.startsWith(`cover.roommind_`)&&t.startsWith(`cover.`)&&!this.selectedCovers.has(t)}}willUpdate(e){e.has(`selectedCovers`)&&(this._selectedForEdit&&!this.selectedCovers.has(this._selectedForEdit)&&(this._selectedForEdit=``),!this._selectedForEdit&&this.selectedCovers.size>0&&(this._selectedForEdit=[...this.selectedCovers][0]))}static{this.styles=[Ht,I,l`
      :host {
        display: block;
      }

      /* Tile view rows (match rs-sensor-section visual rhythm) */
      .view-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 6px 0;
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .view-name {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .view-pill {
        font-size: 10px;
        font-weight: 500;
        padding: 1px 7px;
        border-radius: 8px;
        background: rgba(255, 255, 255, 0.05);
        color: var(--secondary-text-color);
        letter-spacing: 0.3px;
        text-transform: uppercase;
        flex-shrink: 0;
      }

      .view-value {
        font-weight: 500;
        flex-shrink: 0;
        color: var(--primary-text-color);
      }

      /* Device-row style (matches rs-device-section) */
      .device-list-scroll {
        max-height: 210px;
        overflow-y: auto;
      }
      .device-row {
        display: flex;
        align-items: center;
        padding: 4px 0;
        margin-bottom: 2px;
        border-radius: 8px;
        transition: background 0.15s;
      }
      .device-row:hover {
        background: rgba(0, 0, 0, 0.02);
      }
      .device-row.selected {
        background: rgba(3, 169, 244, 0.035);
      }
      .device-row ha-checkbox {
        flex-shrink: 0;
      }
      .device-info {
        flex: 1;
        min-width: 0;
      }
      .device-name-row {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .device-name {
        font-size: 14px;
        font-weight: 450;
      }
      .device-value {
        margin-left: auto;
        font-size: 13px;
        font-weight: 500;
        padding-right: 4px;
        white-space: nowrap;
      }
      .device-entity {
        font-family: var(--code-font-family, monospace);
        font-size: 11px;
        color: var(--secondary-text-color);
        opacity: 0.7;
      }
      .external-badge {
        display: inline-flex;
        align-items: center;
        font-size: 10px;
        font-weight: 500;
        color: var(--secondary-text-color);
        background: var(--divider-color, rgba(0, 0, 0, 0.06));
        padding: 1px 6px;
        border-radius: 4px;
        white-space: nowrap;
      }
      .no-devices {
        color: var(--secondary-text-color);
        font-size: 13px;
        padding: 8px 0;
      }

      .entity-picker-wrap {
        margin-top: 8px;
      }
      ha-entity-picker {
        width: 100%;
      }
      .settings-group {
        margin-top: 16px;
        display: flex;
        flex-direction: column;
        gap: 12px;
      }
      .sub-section {
        margin-top: 20px;
        display: flex;
        flex-direction: column;
        gap: 12px;
      }
      .sub-section:first-child {
        margin-top: 8px;
      }
      .sub-section-header {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 13px;
        font-weight: 500;
        color: var(--secondary-text-color);
        text-transform: uppercase;
        letter-spacing: 0.3px;
        padding-bottom: 4px;
        border-bottom: 1px solid var(--divider-color, rgba(0, 0, 0, 0.12));
      }
      .sub-section-header ha-icon {
        --mdc-icon-size: 18px;
      }
      .field-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
      }
      @media (max-width: 450px) {
        .field-row {
          grid-template-columns: 1fr;
        }
      }
      .no-items {
        color: var(--secondary-text-color);
        font-size: 0.9em;
        margin: 0;
      }
      .status-hint {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 6px;
        color: var(--secondary-text-color);
        font-size: 0.85em;
      }
      .status-hint.paused {
        color: var(--warning-color, #ff9800);
      }
      .pill {
        font-size: 10px;
        font-weight: 500;
        padding: 1px 6px;
        border-radius: 10px;
        background: var(--divider-color, rgba(0, 0, 0, 0.08));
        color: var(--secondary-text-color);
        white-space: nowrap;
      }

      /* Editing layout — feature card + grouped sections */
      .feature-card {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 14px 16px;
        border: 1px solid var(--divider-color);
        border-radius: 12px;
        background: var(--card-background-color);
        transition:
          border-color 0.2s ease,
          background 0.2s ease;
      }

      .feature-card.enabled {
        border-color: rgba(3, 169, 244, 0.4);
        background: rgba(3, 169, 244, 0.06);
      }

      .feature-text {
        flex: 1;
        min-width: 0;
      }

      .feature-title {
        font-size: 14px;
        font-weight: 500;
        margin: 0 0 4px;
      }

      .feature-description {
        font-size: 12px;
        color: var(--secondary-text-color);
        line-height: 1.5;
        margin: 0;
      }

      .feature-card ha-switch {
        flex-shrink: 0;
      }

      .group-card {
        margin-top: 16px;
        border: 1px solid var(--divider-color);
        border-radius: 12px;
        background: var(--card-background-color);
        padding: 14px 16px;
        display: flex;
        flex-direction: column;
        gap: 12px;
      }

      .group-header {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.4px;
        color: var(--secondary-text-color);
        cursor: pointer;
        user-select: none;
      }

      .group-header > span:first-of-type {
        flex: 1;
        min-width: 0;
      }

      .group-header ha-icon {
        --mdc-icon-size: 18px;
        color: var(--secondary-text-color);
      }

      .group-header .chevron {
        transition: transform 0.2s ease;
        margin-left: auto;
      }

      .group-header .chevron.collapsed {
        transform: rotate(-90deg);
      }

      .group-card.collapsed {
        gap: 0;
        padding-bottom: 14px;
      }

      .group-divider {
        height: 1px;
        background: var(--divider-color);
        margin: 4px -16px;
      }
    `]}render(){let e=this.hass.language;return this.editing?this._renderEdit(e):this._renderView(e)}_renderView(e){let t=[...this.selectedCovers];return t.length===0?m`<p class="no-items">${S(`covers.no_covers`,e)}</p>`:m`
      ${t.map(t=>{let n=this.hass.states[t],r=n?.attributes?.friendly_name??t,i=n?.attributes?.current_position,a=this.coverOrientations[t],o=a===void 0?void 0:nn._DIRECTIONS.find(e=>e.deg===a),s=o?S(o.shortLabel,e):void 0,c=this.coverMinPositions[t];return m`
          <div class="view-row">
            <span class="view-name">${r}</span>
            ${s?m`<span class="view-pill">${s}</span>`:h}
            ${c!==void 0&&c>0?m`<span class="view-pill"
                  >${S(`covers.per_cover_min_short`,e)} ${c}%</span
                >`:h}
            ${i===void 0?h:m`<span class="view-value">${i}%</span>`}
          </div>
        `})}
      ${this.autoPaused?m`
            <div class="status-hint paused">
              <ha-icon icon="mdi:hand-back-right"></ha-icon>
              <span>
                ${this.overrideUntil?`${S(`covers.auto_paused_until`,e)} ${new Date(this.overrideUntil*1e3).toLocaleTimeString(e,{hour:`2-digit`,minute:`2-digit`})}`:S(`covers.auto_paused`,e)}
              </span>
              <ha-button @click=${this._onResumeAuto}
                >${S(`covers.resume_auto`,e)}</ha-button
              >
            </div>
          `:this.autoEnabled?m`
              <div class="status-hint">
                <ha-icon icon="mdi:sun-angle-outline"></ha-icon>
                <span>${S(`covers.shading_active`,e)}</span>
              </div>
            `:h}
      ${this.forcedReason===`schedule_active`?m`
            <div class="status-hint">
              <ha-icon icon="mdi:calendar-clock"></ha-icon>
              <span>${S(`covers.schedule_active`,e)}</span>
            </div>
          `:this.forcedReason===`night_close`?m`
              <div class="status-hint">
                <ha-icon icon="mdi:weather-night"></ha-icon>
                <span>${S(`covers.night_close_active`,e)}</span>
              </div>
            `:h}
    `}_renderMasterRow(e,t){let n=this.selectedCovers.has(e),r=this._selectedForEdit===e,i=this.hass.states[e],a=i?.attributes?.friendly_name||e,o=i?.attributes?.current_position,s=this.hass.language,c=this.coverOrientations[e],l=c===void 0?void 0:nn._DIRECTIONS.find(e=>e.deg===c),u=l?S(l.shortLabel,s):``,d=this.coverMinPositions[e];return m`
      <div
        class="master-row ${r?`focused`:``}"
        @click=${()=>this._selectedForEdit=e}
      >
        <ha-checkbox
          .checked=${n}
          @click=${e=>e.stopPropagation()}
          @change=${t=>{let n=t.target;this._onToggle(e,n.checked),n.checked&&(this._selectedForEdit=e)}}
        ></ha-checkbox>
        <div class="master-info">
          <div class="master-name-row">
            <span class="master-name">${a}</span>
            ${t?m`<span class="external-badge">${S(`devices.other_area`,s)}</span>`:h}
          </div>
          <div class="master-meta">
            ${u?m`<span class="meta-pill">${u}</span>`:h}
            ${d!==void 0&&d>0?m`<span class="meta-pill">min ${d}%</span>`:h}
            ${o===void 0?h:m`<span class="meta-pill" style="color: var(--primary-color);">${o}%</span>`}
          </div>
        </div>
      </div>
    `}_renderCoverDetail(e){let t=this.hass.language,n=this.hass.states[e]?.attributes?.friendly_name||e,r=this.coverOrientations[e],i=this.coverMinPositions[e];return m`
      <div class="detail-head">
        <div class="detail-title">${n}</div>
        <div class="detail-entity-id">${e}</div>
      </div>
      <div class="detail-field">
        <ha-select
          .label=${S(`covers.orientation_group_title`,t)}
          .value=${r===void 0?``:String(r)}
          .options=${[{value:``,label:S(`covers.orientation_none`,t)},...nn._DIRECTIONS.map(e=>({value:String(e.deg),label:S(e.longLabel,t)}))]}
          fixedMenuPosition
          @selected=${t=>{let n=P(t);this._setOrientation(e,n===``?void 0:Number(n))}}
          @closed=${e=>e.stopPropagation()}
        >
          <ha-list-item value="">${S(`covers.orientation_none`,t)}</ha-list-item>
          ${nn._DIRECTIONS.map(e=>m`
              <ha-list-item value=${String(e.deg)}>${S(e.longLabel,t)}</ha-list-item>
            `)}
        </ha-select>
      </div>
      <div class="detail-field">
        <rs-threshold-field
          .label=${S(`covers.per_cover_min_position`,t)}
          .value=${i??0}
          .min=${0}
          .max=${99}
          .step=${1}
          suffix="%"
          @value-changed=${t=>this._setMinPosition(e,t.detail)}
        ></rs-threshold-field>
      </div>
    `}_renderEdit(e){let t=bt(this.area.area_id,this.hass?.entities,this.hass?.devices).filter(e=>!e.entity_id.substring(e.entity_id.indexOf(`.`)+1).startsWith(`roommind_`)).filter(e=>e.entity_id.startsWith(`cover.`)),n=new Set(t.map(e=>e.entity_id)),r=[...this.selectedCovers].filter(e=>!n.has(e)),i=this.selectedCovers.size>0,a=this._selectedForEdit,o=a&&this.selectedCovers.has(a);return m`
      <rs-master-detail>
        <div slot="master" class="master">
          <div class="block-title">${S(`covers.add_cover`,e)}</div>
          <div class="master-list">
            ${t.length>0?t.map(e=>this._renderMasterRow(e.entity_id,!1)):m`<div class="empty-list">${S(`covers.no_covers_in_area`,e)}</div>`}
            ${r.map(e=>this._renderMasterRow(e,!0))}
          </div>
          <div class="picker-wrap">
            <ha-entity-picker
              .hass=${this.hass}
              .includeDomains=${[`cover`]}
              .entityFilter=${this._entityFilter}
              .value=${``}
              .label=${S(`covers.add_cover`,e)}
              @value-changed=${this._onEntityPicked}
            ></ha-entity-picker>
          </div>
        </div>
        <div slot="detail">
          ${o?m`<div class="detail-panel">${this._renderCoverDetail(a)}</div>`:m`<div class="detail-panel">
                <div class="empty-detail">
                  <ha-icon icon="mdi:gesture-tap"></ha-icon>
                  <span>${S(`devices.select_to_configure`,e)}</span>
                </div>
              </div>`}
        </div>
      </rs-master-detail>

      ${i?m`
            <div class="block-divider"></div>
            <div class="feature-card ${this.autoEnabled?`enabled`:``}">
              <div class="feature-text">
                <div class="feature-title">${S(`covers.auto_control`,e)}</div>
                <div class="feature-description">${S(`covers.auto_control_hint`,e)}</div>
              </div>
              <ha-switch
                .checked=${this.autoEnabled}
                @change=${e=>this._emit(`covers_auto_enabled`,e.target.checked)}
              ></ha-switch>
            </div>

            ${this.autoEnabled?m`
                  <div class="group-card ${this._scheduleCollapsed?`collapsed`:``}">
                    <div
                      class="group-header"
                      @click=${()=>this._scheduleCollapsed=!this._scheduleCollapsed}
                    >
                      <ha-icon icon="mdi:calendar-clock"></ha-icon>
                      <span>${S(`covers.schedule_group_title`,e)}</span>
                      <rs-info-icon
                        .text=${S(`covers.schedule_section_hint`,e)}
                      ></rs-info-icon>
                      <ha-icon
                        class="chevron ${this._scheduleCollapsed?`collapsed`:``}"
                        icon="mdi:chevron-down"
                      ></ha-icon>
                    </div>
                    ${this._scheduleCollapsed?h:m`<rs-cover-schedule
                            .hass=${this.hass}
                            .schedules=${this.coverSchedules}
                            .selectorEntity=${this.coverScheduleSelectorEntity}
                            .activeIndex=${this.activeCoverScheduleIndex}
                            .editing=${!0}
                            @cover-schedules-changed=${e=>this._emit(`cover_schedules`,e.detail.value)}
                            @cover-schedule-selector-changed=${e=>this._emit(`cover_schedule_selector_entity`,e.detail.value)}
                          ></rs-cover-schedule>
                          <div class="group-divider"></div>
                          <rs-toggle-row
                            .label=${S(`covers.night_close`,e)}
                            .hint=${S(`covers.night_close_hint`,e)}
                            .checked=${this.nightClose}
                            @toggle-changed=${e=>this._emit(`covers_night_close`,e.detail)}
                          ></rs-toggle-row>
                          ${this.nightClose?m`
                                <rs-threshold-field
                                  .label=${S(`covers.night_position`,e)}
                                  .hint=${S(`covers.night_position_hint`,e)}
                                  .value=${this.nightPosition}
                                  .min=${0}
                                  .max=${100}
                                  .step=${5}
                                  suffix="%"
                                  @value-changed=${e=>this._emit(`covers_night_position`,e.detail)}
                                ></rs-threshold-field>
                                <ha-expansion-panel
                                  .header=${S(`covers.night_close_advanced`,e)}
                                  outlined
                                >
                                  <div class="field-row" style="padding:8px 0;">
                                    <rs-threshold-field
                                      .label=${S(`covers.night_close_elevation`,e)}
                                      .hint=${S(`covers.night_close_elevation_hint`,e)}
                                      .value=${this.nightCloseElevation}
                                      .min=${-18}
                                      .max=${10}
                                      .step=${1}
                                      suffix="°"
                                      @value-changed=${e=>this._emit(`covers_night_close_elevation`,e.detail)}
                                    ></rs-threshold-field>
                                    <rs-threshold-field
                                      .label=${S(`covers.night_close_offset`,e)}
                                      .hint=${S(`covers.night_close_offset_hint`,e)}
                                      .value=${this.nightCloseOffsetMinutes}
                                      .min=${-120}
                                      .max=${120}
                                      .step=${5}
                                      suffix="min"
                                      @value-changed=${e=>this._emit(`covers_night_close_offset_minutes`,e.detail)}
                                    ></rs-threshold-field>
                                  </div>
                                </ha-expansion-panel>
                              `:h}`}
                  </div>

                  <div class="group-card ${this._solarCollapsed?`collapsed`:``}">
                    <div
                      class="group-header"
                      @click=${()=>this._solarCollapsed=!this._solarCollapsed}
                    >
                      <ha-icon icon="mdi:white-balance-sunny"></ha-icon>
                      <span>${S(`covers.solar_group_title`,e)}</span>
                      <ha-icon
                        class="chevron ${this._solarCollapsed?`collapsed`:``}"
                        icon="mdi:chevron-down"
                      ></ha-icon>
                    </div>
                    ${this._solarCollapsed?h:m`<div class="field-row">
                            <rs-threshold-field
                              .label=${S(`covers.deploy_threshold`,e)}
                              .hint=${S(`covers.deploy_threshold_hint`,e)}
                              .value=${this.deployThreshold}
                              .min=${.5}
                              .max=${5}
                              .step=${.5}
                              suffix="°C"
                              @value-changed=${e=>this._emit(`covers_deploy_threshold`,e.detail)}
                            ></rs-threshold-field>
                            <rs-threshold-field
                              .label=${S(`covers.min_position`,e)}
                              .hint=${S(`covers.min_position_hint`,e)}
                              .value=${this.minPosition}
                              .min=${0}
                              .max=${80}
                              .step=${5}
                              suffix="%"
                              @value-changed=${e=>this._emit(`covers_min_position`,e.detail)}
                            ></rs-threshold-field>
                          </div>
                          <div class="field-row">
                            <rs-threshold-field
                              .label=${S(`covers.override_minutes`,e)}
                              .hint=${S(`covers.override_minutes_hint`,e)}
                              .value=${this.overrideMinutes}
                              .min=${0}
                              .max=${480}
                              .step=${15}
                              suffix="min"
                              @value-changed=${e=>this._emit(`covers_override_minutes`,e.detail)}
                            ></rs-threshold-field>
                            <rs-threshold-field
                              .label=${S(`covers.outdoor_min_temp`,e)}
                              .hint=${S(`covers.outdoor_min_temp_hint`,e)}
                              .value=${this.outdoorMinTemp??10}
                              .min=${0}
                              .max=${35}
                              .step=${1}
                              suffix="°C"
                              @value-changed=${e=>this._emit(`covers_outdoor_min_temp`,e.detail)}
                            ></rs-threshold-field>
                          </div>
                          <div class="group-divider"></div>
                          <rs-toggle-row
                            .label=${S(`covers.snap_deploy`,e)}
                            .hint=${S(`covers.snap_deploy_hint`,e)}
                            .checked=${this.snapDeploy}
                            @toggle-changed=${e=>this._emit(`covers_snap_deploy`,e.detail)}
                          ></rs-toggle-row>`}
                  </div>
                `:h}
          `:h}
    `}static{this._DIRECTIONS=[{shortLabel:`covers.orientation_N`,longLabel:`covers.orientation_N_full`,deg:0},{shortLabel:`covers.orientation_NE`,longLabel:`covers.orientation_NE_full`,deg:45},{shortLabel:`covers.orientation_E`,longLabel:`covers.orientation_E_full`,deg:90},{shortLabel:`covers.orientation_SE`,longLabel:`covers.orientation_SE_full`,deg:135},{shortLabel:`covers.orientation_S`,longLabel:`covers.orientation_S_full`,deg:180},{shortLabel:`covers.orientation_SW`,longLabel:`covers.orientation_SW_full`,deg:225},{shortLabel:`covers.orientation_W`,longLabel:`covers.orientation_W_full`,deg:270},{shortLabel:`covers.orientation_NW`,longLabel:`covers.orientation_NW_full`,deg:315}]}_setMinPosition(e,t){let n={...this.coverMinPositions};n[e]=t,this._emit(`cover_min_positions`,n)}_setOrientation(e,t){let n={...this.coverOrientations};t===void 0?delete n[e]:n[e]=t,this._emit(`cover_orientations`,n)}_onEntityPicked(e){e.stopPropagation();let t=e.detail.value;if(!t)return;this._onToggle(t,!0);let n=e.target;n.value=``}_onToggle(e,t){this.dispatchEvent(new CustomEvent(`covers-toggle`,{detail:{entityId:e,checked:t},bubbles:!0,composed:!0}))}_onResumeAuto(){this.dispatchEvent(new CustomEvent(`cover-resume-auto`,{bubbles:!0,composed:!0}))}_emit(e,t){this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:e,value:t},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],U.prototype,`hass`,void 0),k([y({attribute:!1})],U.prototype,`area`,void 0),k([y({attribute:!1})],U.prototype,`selectedCovers`,void 0),k([y({type:Boolean})],U.prototype,`editing`,void 0),k([y({type:Boolean})],U.prototype,`autoEnabled`,void 0),k([y({type:Number})],U.prototype,`deployThreshold`,void 0),k([y({type:Number})],U.prototype,`minPosition`,void 0),k([y({type:Number})],U.prototype,`overrideMinutes`,void 0),k([y({type:Boolean})],U.prototype,`autoPaused`,void 0),k([y({type:Number})],U.prototype,`overrideUntil`,void 0),k([y({attribute:!1})],U.prototype,`coverSchedules`,void 0),k([y({type:String})],U.prototype,`coverScheduleSelectorEntity`,void 0),k([y({type:Number})],U.prototype,`activeCoverScheduleIndex`,void 0),k([y({type:Boolean})],U.prototype,`nightClose`,void 0),k([y({type:Number})],U.prototype,`nightPosition`,void 0),k([y({type:Boolean})],U.prototype,`snapDeploy`,void 0),k([y({type:String})],U.prototype,`forcedReason`,void 0),k([y({attribute:!1})],U.prototype,`coverOrientations`,void 0),k([y({type:Number})],U.prototype,`nightCloseElevation`,void 0),k([y({type:Number})],U.prototype,`nightCloseOffsetMinutes`,void 0),k([y({type:Number})],U.prototype,`outdoorMinTemp`,void 0),k([y({attribute:!1})],U.prototype,`coverMinPositions`,void 0),k([b()],U.prototype,`_selectedForEdit`,void 0),k([b()],U.prototype,`_scheduleCollapsed`,void 0),k([b()],U.prototype,`_solarCollapsed`,void 0),U=nn=k([v(`rs-covers-section`)],U),_(),x(),A();var W=class extends g{constructor(...e){super(...e),this.enabled=!1,this.native=!1,this.hasAc=!1,this.hasTrv=!1,this.heatPumpPower=0,this.primaryDelta=1.5,this.outdoorThreshold=5,this.acMinOutdoor=-15,this.editing=!1}static{this.styles=[I,l`
      :host {
        display: block;
      }

      /* Read-only summary (tile) */
      .summary {
        padding: 0 16px 16px;
        font-size: 13px;
        color: var(--secondary-text-color);
        line-height: 1.6;
      }

      .summary.disabled {
        font-style: italic;
        opacity: 0.75;
      }

      /* Editing layout */
      .feature-card {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 14px 16px;
        border: 1px solid var(--divider-color);
        border-radius: 12px;
        background: var(--card-background-color);
        transition:
          border-color 0.2s ease,
          background 0.2s ease;
      }

      .feature-card.enabled {
        border-color: rgba(3, 169, 244, 0.4);
        background: rgba(3, 169, 244, 0.06);
      }

      .feature-text {
        flex: 1;
        min-width: 0;
      }

      .feature-title {
        font-size: 14px;
        font-weight: 500;
        margin: 0 0 4px;
      }

      .feature-description {
        font-size: 12px;
        color: var(--secondary-text-color);
        line-height: 1.5;
        margin: 0;
      }

      ha-switch {
        flex-shrink: 0;
      }

      .thresholds {
        margin-top: 16px;
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 12px;
      }

      @media (max-width: 600px) {
        .thresholds {
          grid-template-columns: 1fr;
        }
      }

      .threshold-cell {
        display: flex;
        flex-direction: column;
        gap: 8px;
        padding: 12px 14px;
        border: 1px solid var(--divider-color);
        border-radius: 10px;
        background: var(--card-background-color);
      }

      .threshold-label {
        font-size: 12px;
        font-weight: 500;
        color: var(--secondary-text-color);
        display: flex;
        align-items: center;
        gap: 4px;
        line-height: 1.3;
      }

      .threshold-label > span {
        flex: 1;
        min-width: 0;
      }

      .threshold-cell ha-textfield {
        width: 100%;
      }
      .power-learning {
        display: flex;
        flex-wrap: wrap;
        gap: 6px 14px;
        margin-top: 10px;
        color: var(--secondary-text-color);
        font-size: 12px;
        line-height: 1.6;
      }
    `]}render(){let e=this.hass.language;return this.editing?m`
      ${this.hasTrv?m`<div class="feature-card ${this.enabled?`enabled`:``}">
            <div class="feature-text">
              <div class="feature-title">${S(`heat_source.toggle`,e)}</div>
              <div class="feature-description">${S(`heat_source.toggle_hint`,e)}</div>
            </div>
            <ha-switch .checked=${this.enabled} @change=${this._onSwitchChange}></ha-switch>
          </div>`:h}
      ${this.hasAc?m`<div class="thresholds">
            <div class="threshold-cell">
              <div class="threshold-label">
                <span>${S(`heat_source.power_estimate`,e)}</span>
              </div>
              <ha-textfield
                .value=${String(this.heatPumpPower)}
                type="number"
                min="0"
                max="20000"
                step="50"
                .suffix=${`W`}
                @change=${e=>this._onNumberInput(`heat_pump_power_watts`,e)}
              ></ha-textfield>
              <span class="feature-description"
                >${S(`heat_source.power_estimate_hint`,e)}</span
              >
            </div>
          </div>`:h}
      ${this._renderPowerLearning(e)}
      ${this.enabled&&this.hasTrv?m`
            <div class="feature-card">
              <div class="feature-text">
                <div class="feature-title">Heat pump / Hybrid / Boiler</div>
                <div class="feature-description">
                  Use RoomMind's native source selector, central power allocator and boiler demand
                  aggregation.
                </div>
              </div>
              <ha-switch
                .checked=${this.native}
                @change=${e=>this._emit(`native_heat_source`,e.target.checked)}
              ></ha-switch>
            </div>
            <div class="thresholds">
              ${this._renderThresholdCell({label:S(`heat_source.primary_delta`,e),hint:S(`heat_source.primary_delta_hint`,e),suffix:S(`heat_source.primary_delta_suffix`,e),value:this.primaryDelta,min:.5,max:5,step:.1,key:`heat_source_primary_delta`})}
              ${this._renderThresholdCell({label:S(`heat_source.outdoor_threshold`,e),hint:S(`heat_source.outdoor_threshold_hint`,e),suffix:S(`heat_source.outdoor_threshold_suffix`,e),value:this.outdoorThreshold,min:-20,max:25,step:1,key:`heat_source_outdoor_threshold`})}
              ${this._renderThresholdCell({label:S(`heat_source.ac_min_outdoor`,e),hint:S(`heat_source.ac_min_outdoor_hint`,e),suffix:S(`heat_source.ac_min_outdoor_suffix`,e),value:this.acMinOutdoor,min:-30,max:5,step:1,key:`heat_source_ac_min_outdoor`})}
            </div>
          `:h}
    `:this.enabled?m`<div class="summary">
        ${S(`heat_source.primary_delta`,e)}:
        <strong>${this.primaryDelta}${S(`heat_source.primary_delta_suffix`,e)}</strong>
        · ${S(`heat_source.outdoor_threshold`,e)}:
        <strong
          >${this.outdoorThreshold}${S(`heat_source.outdoor_threshold_suffix`,e)}</strong
        >
        · ${S(`heat_source.ac_min_outdoor`,e)}:
        <strong>${this.acMinOutdoor}${S(`heat_source.ac_min_outdoor_suffix`,e)}</strong>
        ${this._renderPowerLearning(e)}
      </div>`:m`<div class="summary disabled">
          ${this.hasTrv?S(`heat_source.summary_disabled`,e):h}
          ${this.hasAc?m`${this.hasTrv?` · `:``}${S(`heat_source.power_estimate`,e)}:
              ${this.heatPumpPower} W`:h}
          ${this._renderPowerLearning(e)}
        </div>`}_renderPowerLearning(e){return!this.hasAc||!this.powerBudgetEstimates?h:m`<div class="power-learning">
      ${[`heating`,`cooling`,`dry`].map(t=>{let n=this.powerBudgetEstimates?.[t];if(!n)return h;let r=S(`heat_source.budget_${t}`,e),i=S(`heat_source.budget_${n.source}`,e);return m`<span
          >${r}: ${n.watts>0?`${n.watts} W`:`—`} (${i})</span
        >`})}
    </div>`}_renderThresholdCell(e){return m`
      <div class="threshold-cell">
        <div class="threshold-label">
          <span>${e.label}</span>
          <rs-info-icon .text=${e.hint}></rs-info-icon>
        </div>
        <ha-textfield
          .value=${String(e.value)}
          .min=${String(e.min)}
          .max=${String(e.max)}
          .step=${String(e.step)}
          .suffix=${e.suffix}
          type="number"
          @input=${t=>this._onNumberInput(e.key,t)}
        ></ha-textfield>
      </div>
    `}_onSwitchChange(e){this._emit(`heat_source_orchestration`,e.target.checked)}_onNumberInput(e,t){let n=parseFloat(t.target.value);isNaN(n)||this._emit(e,n)}_emit(e,t){this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:e,value:t},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],W.prototype,`hass`,void 0),k([y({type:Boolean})],W.prototype,`enabled`,void 0),k([y({type:Boolean})],W.prototype,`native`,void 0),k([y({type:Boolean})],W.prototype,`hasAc`,void 0),k([y({type:Boolean})],W.prototype,`hasTrv`,void 0),k([y({type:Number})],W.prototype,`heatPumpPower`,void 0),k([y({attribute:!1})],W.prototype,`powerBudgetEstimates`,void 0),k([y({type:Number})],W.prototype,`primaryDelta`,void 0),k([y({type:Number})],W.prototype,`outdoorThreshold`,void 0),k([y({type:Number})],W.prototype,`acMinOutdoor`,void 0),k([y({type:Boolean})],W.prototype,`editing`,void 0),W=k([v(`rs-heat-source-section`)],W),_(),x(),A();var rn=`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`,an=`M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z`,on=class extends g{constructor(...e){super(...e),this.open=!1,this.heading=``,this.icon=``,this.hasInfo=!1,this._infoExpanded=!1,this._onKeyDown=e=>{e.key===`Escape`&&this.open&&(e.stopPropagation(),this._close())}}connectedCallback(){super.connectedCallback(),window.addEventListener(`keydown`,this._onKeyDown)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener(`keydown`,this._onKeyDown)}static{this.styles=l`
    :host {
      display: contents;
    }

    .backdrop {
      position: fixed;
      inset: 0;
      z-index: 1000;
      background: rgba(0, 0, 0, 0.55);
      backdrop-filter: blur(2px);
      display: flex;
      align-items: flex-start;
      justify-content: center;
      padding: 32px 16px;
      box-sizing: border-box;
      overflow-y: auto;
      animation: fade-in 0.18s ease-out;
    }

    @media (max-width: 600px) {
      .backdrop {
        padding: 0;
        align-items: stretch;
      }
    }

    .dialog {
      background: var(--card-background-color, #1c1c1c);
      color: var(--primary-text-color);
      border-radius: 14px;
      box-shadow: 0 24px 48px rgba(0, 0, 0, 0.5);
      width: 100%;
      max-width: 760px;
      display: flex;
      flex-direction: column;
      max-height: calc(100vh - 64px);
      animation: pop-in 0.18s ease-out;
    }

    @media (min-width: 1400px) {
      .dialog {
        max-width: 880px;
      }
    }

    @media (max-width: 600px) {
      .dialog {
        max-width: 100%;
        max-height: 100vh;
        border-radius: 0;
      }
    }

    .dialog-header {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 18px 24px;
      border-bottom: 1px solid var(--divider-color, rgba(255, 255, 255, 0.08));
    }

    .dialog-icon {
      --mdc-icon-size: 20px;
      opacity: 0.7;
      flex-shrink: 0;
      margin-right: 8px;
    }

    .dialog-title {
      flex: 1;
      font-size: 16px;
      font-weight: 500;
      margin: 0;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .info-btn {
      --mdc-icon-button-size: 36px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
      transition:
        color 0.15s,
        background 0.15s;
      border-radius: 50%;
    }

    .info-btn.active {
      color: var(--primary-color);
      background: rgba(3, 169, 244, 0.12);
    }

    .close-btn {
      --mdc-icon-button-size: 36px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
      margin: -6px -10px -6px 0;
    }

    .dialog-body {
      flex: 1;
      overflow-y: auto;
      padding: 20px 24px 24px;
    }

    .dialog-body ::slotted(*) {
      display: block;
    }

    .info-panel {
      margin-bottom: 16px;
      padding: 12px 14px;
      background: rgba(3, 169, 244, 0.06);
      border: 1px solid rgba(3, 169, 244, 0.18);
      border-radius: 10px;
      font-size: 13px;
      line-height: 1.6;
      color: var(--primary-text-color);
      animation: info-fade 0.18s ease-out;
    }

    .info-panel ::slotted(*) {
      display: block;
    }

    @keyframes fade-in {
      from {
        opacity: 0;
      }
      to {
        opacity: 1;
      }
    }

    @keyframes pop-in {
      from {
        opacity: 0;
        transform: scale(0.97);
      }
      to {
        opacity: 1;
        transform: scale(1);
      }
    }

    @keyframes info-fade {
      from {
        opacity: 0;
        transform: translateY(-4px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  `}render(){return this.open?m`
      <div class="backdrop" @click=${this._onBackdropClick} role="dialog" aria-modal="true">
        <div class="dialog" @click=${e=>e.stopPropagation()}>
          <div class="dialog-header">
            ${this.icon?m`<ha-icon class="dialog-icon" icon=${this.icon}></ha-icon>`:h}
            <h3 class="dialog-title">${this.heading}</h3>
            ${this.hasInfo?m`<ha-icon-button
                  class="info-btn ${this._infoExpanded?`active`:``}"
                  .path=${an}
                  @click=${this._toggleInfo}
                ></ha-icon-button>`:h}
            <ha-icon-button
              class="close-btn"
              .path=${rn}
              @click=${this._close}
            ></ha-icon-button>
          </div>
          <div class="dialog-body">
            ${this.hasInfo&&this._infoExpanded?m`<div class="info-panel"><slot name="info"></slot></div>`:h}
            <slot></slot>
          </div>
        </div>
      </div>
    `:h}_onBackdropClick(e){e.target===e.currentTarget&&this._close()}_toggleInfo(){this._infoExpanded=!this._infoExpanded}_close(){this._infoExpanded=!1,this.dispatchEvent(new CustomEvent(`rs-dialog-closed`,{bubbles:!0,composed:!0}))}};k([y({type:Boolean,reflect:!0})],on.prototype,`open`,void 0),k([y({type:String})],on.prototype,`heading`,void 0),k([y({type:String})],on.prototype,`icon`,void 0),k([y({type:Boolean})],on.prototype,`hasInfo`,void 0),k([b()],on.prototype,`_infoExpanded`,void 0),on=k([v(`rs-edit-dialog`)],on),_(),x(),A();var sn=`https://github.com/snazzybean/roommind/blob/main/docs/control-and-devices.md`,G=class extends g{constructor(...e){super(...e),this.rooms={},this.config=null,this.presenceEnabled=!1,this.presencePersons=[],this.climateControlActive=!0,this.valveProtectionEnabled=!1,this._dehumidifier=null,this._humidity={humidity_comfort_enabled:!1,humidity_target:55,humidity_tolerance:5,humidity_priority:`balanced`},this._devices=[],this._selectedTempSensor=``,this._selectedHumiditySensor=``,this._selectedOccupancySensors=new Set,this._selectedWindowSensors=new Set,this._windowOpenDelay=0,this._windowCloseDelay=0,this._keepFanOnlyOnWindowOpen=!0,this._moldFRsi=.8,this._climateMode=`auto`,this._schedules=[],this._scheduleSelectorEntity=``,this._comfortHeat=21,this._comfortCool=24,this._ecoHeat=17,this._ecoCool=27,this._activeProfile=``,this._nightModeEnabled=!1,this._nightStart=`22:00`,this._nightEnd=`07:00`,this._nightHeatDelta=-.5,this._nightCoolDelta=.5,this._nightRampMinutes=60,this._error=``,this._dirty=!1,this._editing=null,this._detailView=`overview`,this._selectedPresencePersons=[],this._displayName=``,this._selectedCovers=new Set,this._coversAutoEnabled=!1,this._coversDeployThreshold=1.5,this._coversMinPosition=0,this._coversOverrideMinutes=60,this._coverSchedules=[],this._coverScheduleSelectorEntity=``,this._coversNightClose=!1,this._coversNightPosition=0,this._coversSnapDeploy=!1,this._coverOrientations={},this._coversNightCloseElevation=0,this._coversNightCloseOffsetMinutes=0,this._coversOutdoorMinTemp=10,this._coverMinPositions={},this._ignorePresence=!1,this._isOutdoor=!1,this._valveProtectionExclude=new Set,this._climateControlEnabled=!0,this._heatSourceOrchestration=!1,this._heatSourcePrimaryDelta=1.5,this._heatSourceOutdoorThreshold=5,this._heatSourceAcMinOutdoor=-15,this._nativeHeatSource=!1,this._heatPumpPowerWatts=0,this._optimisticCoverResume=!1,this._prevAreaId=null,this._openEdit=e=>()=>{this._editing=e},this._closeEdit=()=>{this._editing=null}}static{this.styles=l`
    :host {
      display: block;
      max-width: 2400px;
      margin: 0 auto;
    }

    .detail-layout {
      display: flex;
      flex-direction: column;
      gap: 22px;
    }
    .detail-navigation {
      display: flex;
      align-items: center;
      gap: 8px;
      overflow-x: auto;
      padding: 4px;
      border-radius: 15px;
      background: var(--secondary-background-color, rgba(127, 127, 127, 0.09));
      scrollbar-width: thin;
    }
    .detail-tab {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 9px;
      flex: 1 0 auto;
      white-space: nowrap;
      padding: 12px 14px;
      min-height: 44px;
      border: 1px solid transparent;
      border-radius: 12px;
      background: transparent;
      color: var(--secondary-text-color);
      font: inherit;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      transition:
        background 0.2s ease,
        color 0.2s ease,
        box-shadow 0.2s ease;
    }
    .detail-tab ha-icon {
      --mdc-icon-size: 19px;
    }
    .detail-tab:hover {
      color: var(--primary-text-color);
    }
    .detail-tab[aria-pressed="true"] {
      background: var(--card-background-color);
      color: var(--primary-text-color);
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
    }
    .detail-tab[aria-pressed="true"] ha-icon {
      color: var(--primary-color);
    }
    .detail-tab:focus-visible {
      outline: 2px solid var(--primary-color);
      outline-offset: -2px;
    }
    .detail-grid[data-view="overview"] > :not([data-group="overview"]),
    .detail-grid[data-view="equipment"] > :not([data-group="equipment"]),
    .detail-grid[data-view="advanced"] > :not([data-group="advanced"]) {
      display: none;
    }

    .detail-grid {
      display: grid;
      grid-template-columns: repeat(12, minmax(0, 1fr));
      gap: 16px;
      align-items: start;
    }

    .detail-grid > * {
      min-width: 0;
    }
    .detail-grid[data-view="equipment"] > .optional-card {
      grid-column: span 6;
    }

    .control-card,
    .comfort-card,
    .schedule-card {
      grid-column: span 4;
    }
    .devices-card,
    .dehumidifier-card,
    .sensors-card {
      grid-column: span 6;
    }
    .optional-card {
      grid-column: span 4;
    }
    .insights-card {
      grid-column: 1 / -1;
    }

    .control-card rs-toggle-row {
      margin-bottom: 16px;
      padding-bottom: 16px;
      border-bottom: 1px solid var(--divider-color);
    }

    @media (max-width: 1050px) {
      .control-card,
      .comfort-card,
      .schedule-card,
      .optional-card {
        grid-column: span 6;
      }
      .devices-card,
      .dehumidifier-card,
      .sensors-card {
        grid-column: span 6;
      }
    }

    @media (max-width: 680px) {
      .detail-grid {
        grid-template-columns: 1fr;
      }
      .detail-grid > * {
        grid-column: 1;
      }
      .detail-grid[data-view="equipment"] > .optional-card {
        grid-column: 1;
      }
      .detail-navigation {
        border-radius: 12px;
      }
      .detail-tab {
        padding: 10px 12px;
        font-size: 12px;
      }
      .detail-tab ha-icon {
        --mdc-icon-size: 17px;
      }
    }

    /* Section cards handled by rs-section-card */

    /* YAML code block for info panels (slotted into edit dialogs) */
    .yaml-block {
      background: var(--code-editor-background-color, rgba(0, 0, 0, 0.35));
      border: 1px solid var(--divider-color, rgba(255, 255, 255, 0.12));
      border-radius: 6px;
      padding: 10px 14px;
      margin: 8px 0;
      font-family: var(--code-font-family, monospace);
      font-size: 12px;
      line-height: 1.6;
      white-space: pre;
      overflow-x: auto;
      color: var(--primary-text-color);
    }
    .yaml-key {
      color: #82aaff;
    }
    .yaml-value {
      color: #e2a76a;
    }

    /* Actions */
    .actions {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-top: 8px;
      margin-bottom: 24px;
    }

    .error {
      color: var(--error-color, #d32f2f);
      font-size: 13px;
      margin-top: 8px;
    }

    .field-hint {
      color: var(--secondary-text-color);
      font-size: 12px;
    }

    .exceptions-link {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      background: none;
      border: none;
      padding: 8px 0 0;
      margin: 0;
      cursor: pointer;
      font-size: 13px;
      color: var(--primary-color);
      font-family: inherit;
    }

    .exceptions-link:hover {
      text-decoration: underline;
    }

    .helper-link {
      display: inline-block;
      margin-top: 12px;
      color: var(--primary-color);
      font-size: 12px;
      text-decoration: none;
    }

    .helper-link:hover {
      text-decoration: underline;
    }
  `}connectedCallback(){super.connectedCallback(),this._initFromConfig()}disconnectedCallback(){super.disconnectedCallback(),this._saveDebounce&&clearTimeout(this._saveDebounce)}updated(e){let t=this.config?.area_id??this.area?.area_id??null;t===this._prevAreaId?e.has(`config`)&&!this._dirty&&(e.get(`config`)??this._initFromConfig()):(this._detailView=`overview`,this._initFromConfig(),this._prevAreaId=t),e.has(`config`)&&this._optimisticCoverResume&&!this.config?.live?.cover_auto_paused&&(this._optimisticCoverResume=!1)}_initFromConfig(){this._dehumidifier=this.config?.dehumidifier?{...this.config.dehumidifier,served_area_ids:[...this.config.dehumidifier.served_area_ids]}:null,this._humidity={humidity_comfort_enabled:this.config?.humidity_comfort_enabled??!1,humidity_target:this.config?.humidity_target??55,humidity_tolerance:this.config?.humidity_tolerance??5,humidity_priority:this.config?.humidity_priority??`balanced`},this.config?(this._devices=this.config.devices?.length?[...this.config.devices]:[...(this.config.thermostats??[]).map(e=>({entity_id:e,type:`trv`,role:`auto`,heating_system_type:this.config.heating_system_type??``})),...(this.config.acs??[]).map(e=>({entity_id:e,type:`ac`,role:`auto`}))],this._selectedTempSensor=this.config.temperature_sensor,this._selectedHumiditySensor=this.config.humidity_sensor??``,this._selectedOccupancySensors=new Set(this.config.occupancy_sensors??[]),this._selectedWindowSensors=new Set(this.config.window_sensors??[]),this._windowOpenDelay=this.config.window_open_delay??0,this._windowCloseDelay=this.config.window_close_delay??0,this._keepFanOnlyOnWindowOpen=this.config.keep_fan_only_on_window_open??!0,this._moldFRsi=this.config.mold_f_rsi??.8,this._climateMode=this.config.climate_mode,this._schedules=this.config.schedules??[],this._scheduleSelectorEntity=this.config.schedule_selector_entity??``,this._comfortHeat=this.config.comfort_heat??this.config.comfort_temp??21,this._comfortCool=this.config.comfort_cool??24,this._ecoHeat=this.config.eco_heat??this.config.eco_temp??17,this._ecoCool=this.config.eco_cool??27,this._activeProfile=this.config.active_profile??``,this._nightModeEnabled=this.config.night_mode_enabled??!1,this._nightStart=this.config.night_start??`22:00`,this._nightEnd=this.config.night_end??`07:00`,this._nightHeatDelta=this.config.night_heat_delta??-.5,this._nightCoolDelta=this.config.night_cool_delta??.5,this._nightRampMinutes=this.config.night_ramp_minutes??60,this._selectedPresencePersons=this.config.presence_persons??[],this._displayName=this.config.display_name??``,this._selectedCovers=new Set(this.config.covers??[]),this._coversAutoEnabled=this.config.covers_auto_enabled??!1,this._coversDeployThreshold=this.config.covers_deploy_threshold??1.5,this._coversMinPosition=this.config.covers_min_position??0,this._coversOverrideMinutes=this.config.covers_override_minutes??60,this._coverSchedules=this.config.cover_schedules??[],this._coverScheduleSelectorEntity=this.config.cover_schedule_selector_entity??``,this._coversNightClose=this.config.covers_night_close??!1,this._coversNightPosition=this.config.covers_night_position??0,this._coversSnapDeploy=this.config.covers_snap_deploy??!1,this._coverOrientations=this.config.cover_orientations??{},this._coversNightCloseElevation=this.config.covers_night_close_elevation??0,this._coversNightCloseOffsetMinutes=this.config.covers_night_close_offset_minutes??0,this._coversOutdoorMinTemp=this.config.covers_outdoor_min_temp??10,this._coverMinPositions=this.config.cover_min_positions??{},this._ignorePresence=this.config.ignore_presence??!1,this._isOutdoor=this.config.is_outdoor??!1,this._valveProtectionExclude=new Set(this.config.valve_protection_exclude??[]),this._climateControlEnabled=this.config.climate_control_enabled??!0,this._heatSourceOrchestration=this.config.heat_source_orchestration??!1,this._heatSourcePrimaryDelta=this.config.heat_source_primary_delta??1.5,this._heatSourceOutdoorThreshold=this.config.heat_source_outdoor_threshold??5,this._heatSourceAcMinOutdoor=this.config.heat_source_ac_min_outdoor??-15,this._nativeHeatSource=this.config.native_heat_source??!1,this._heatPumpPowerWatts=this.config.heat_pump_power_watts??0):(this._devices=[],this._selectedTempSensor=``,this._selectedHumiditySensor=``,this._selectedOccupancySensors=new Set,this._selectedWindowSensors=new Set,this._windowOpenDelay=0,this._windowCloseDelay=0,this._keepFanOnlyOnWindowOpen=!0,this._moldFRsi=.8,this._climateMode=`auto`,this._schedules=[],this._scheduleSelectorEntity=``,this._comfortHeat=21,this._comfortCool=24,this._ecoHeat=17,this._ecoCool=27,this._activeProfile=``,this._nightModeEnabled=!1,this._nightStart=`22:00`,this._nightEnd=`07:00`,this._nightHeatDelta=-.5,this._nightCoolDelta=.5,this._nightRampMinutes=60,this._selectedPresencePersons=[],this._displayName=``,this._selectedCovers=new Set,this._coversAutoEnabled=!1,this._coversDeployThreshold=1.5,this._coversMinPosition=0,this._coversOverrideMinutes=60,this._coverSchedules=[],this._coverScheduleSelectorEntity=``,this._coversNightClose=!1,this._coversNightPosition=0,this._coversSnapDeploy=!1,this._coverOrientations={},this._coversNightCloseElevation=0,this._coversNightCloseOffsetMinutes=0,this._coversOutdoorMinTemp=10,this._coverMinPositions={},this._ignorePresence=!1,this._isOutdoor=!1,this._valveProtectionExclude=new Set,this._climateControlEnabled=!0,this._heatSourceOrchestration=!1,this._heatSourcePrimaryDelta=1.5,this._heatSourceOutdoorThreshold=5,this._heatSourceAcMinOutdoor=-15),this._dirty=!1,this._devices.length===0&&!this._dehumidifier&&this._editing===null&&!Object.values(this.rooms).some(e=>e.dehumidifier?.served_area_ids.includes(this.area.area_id))&&(this._editing=`devices`)}_getEffectiveOverride(){let e=this.shadowRoot?.querySelector(`rs-override-section`);if(e)return e.getEffectiveOverride();let t=this.config?.live;return t?.override_active&&t.override_type?{active:!0,type:t.override_type,heat:t.override_heat,cool:t.override_cool,until:t.override_until}:{active:!1,type:null,heat:null,cool:null,until:null}}render(){return this.area?m`
      <div class="detail-layout">
        <rs-hero-status
          .hass=${this.hass}
          .area=${this.area}
          .config=${this.config}
          .isOutdoor=${this._isOutdoor}
          .overrideInfo=${this._getEffectiveOverride()}
          .climateControlActive=${this.climateControlActive&&this._climateControlEnabled}
          @display-name-changed=${this._onDisplayNameChanged}
        ></rs-hero-status>

        <nav
          class="detail-navigation"
          aria-label=${S(`room.nav.description`,this.hass.language)}
        >
          ${[[`overview`,`mdi:thermostat`,`room.nav.overview`],[`equipment`,`mdi:devices`,`room.nav.equipment`],[`advanced`,`mdi:creation-outline`,`room.nav.advanced`]].map(([e,t,n])=>m`
              <button
                class="detail-tab"
                type="button"
                aria-pressed=${this._detailView===e?`true`:`false`}
                @click=${()=>{this._detailView=e}}
              >
                <ha-icon icon=${t}></ha-icon>${S(n,this.hass.language)}
              </button>
            `)}
        </nav>

        <div class="detail-grid" data-view=${this._detailView}>
          ${this._isOutdoor?h:m`
                <rs-section-card
                  class="control-card"
                  data-group="overview"
                  icon="mdi:tune-variant"
                  .heading=${S(`room.climate_control_toggle`,this.hass.language)}
                >
                  <rs-info-icon slot="header-extras">
                    <b>${S(`mode.auto`,this.hass.language)}</b> —
                    ${S(`mode.auto_desc`,this.hass.language)}<br />
                    <b>${S(`mode.heat_only`,this.hass.language)}</b> —
                    ${S(`mode.heat_only_desc`,this.hass.language)}<br />
                    <b>${S(`mode.cool_only`,this.hass.language)}</b> —
                    ${S(`mode.cool_only_desc`,this.hass.language)}
                  </rs-info-icon>
                  <rs-toggle-row
                    .label=${S(`comfort.control_enabled`,this.hass.language)}
                    .hint=${S(`room.climate_control_hint`,this.hass.language)}
                    .checked=${this._climateControlEnabled}
                    @toggle-changed=${this._onClimateControlToggle}
                  ></rs-toggle-row>
                  <rs-climate-mode-selector
                    .climateMode=${this._climateMode}
                    .language=${this.hass.language}
                    @mode-changed=${this._onModeChanged}
                  ></rs-climate-mode-selector>
                </rs-section-card>

                <rs-section-card
                  class="schedule-card"
                  data-group="overview"
                  icon="mdi:calendar"
                  .heading=${S(`room.section.schedule`,this.hass.language)}
                  editable
                  @edit-click=${this._openEdit(`schedule`)}
                >
                  <rs-schedule-settings
                    .hass=${this.hass}
                    .schedules=${this._schedules}
                    .scheduleSelectorEntity=${this._scheduleSelectorEntity}
                    .activeScheduleIndex=${this.config?.live?.active_schedule_index??-1}
                    .comfortHeat=${this._comfortHeat}
                    .comfortCool=${this._comfortCool}
                    .ecoHeat=${this._ecoHeat}
                    .ecoCool=${this._ecoCool}
                    .climateMode=${this._climateMode}
                    .editing=${!1}
                    @schedules-changed=${this._onSchedulesChanged}
                    @schedule-selector-changed=${this._onScheduleSelectorChanged}
                    @comfort-heat-changed=${this._onComfortHeatChanged}
                    @comfort-cool-changed=${this._onComfortCoolChanged}
                    @eco-heat-changed=${this._onEcoHeatChanged}
                    @eco-cool-changed=${this._onEcoCoolChanged}
                  ></rs-schedule-settings>
                  ${this.config?m`
                        <rs-override-section
                          .hass=${this.hass}
                          .config=${this.config}
                          .climateMode=${this._climateMode}
                          .comfortHeat=${this._comfortHeat}
                          .comfortCool=${this._comfortCool}
                          .ecoHeat=${this._ecoHeat}
                          .ecoCool=${this._ecoCool}
                          .language=${this.hass.language}
                        ></rs-override-section>
                      `:h}
                </rs-section-card>

                <rs-section-card
                  class="comfort-card"
                  data-group="overview"
                  icon="mdi:heart-outline"
                  .heading=${S(`room.section.comfort`,this.hass.language)}
                >
                  <rs-comfort-section
                    .hass=${this.hass}
                    .activeProfile=${this._activeProfile}
                    .nightModeEnabled=${this._nightModeEnabled}
                    .nightStart=${this._nightStart}
                    .nightEnd=${this._nightEnd}
                    .nightHeatDelta=${this._nightHeatDelta}
                    .nightCoolDelta=${this._nightCoolDelta}
                    .nightRampMinutes=${this._nightRampMinutes}
                    @setting-changed=${this._onComfortSettingChanged}
                  ></rs-comfort-section>
                </rs-section-card>
              `}
          ${this._isOutdoor?h:m`
                <rs-section-card
                  class="devices-card"
                  data-group="equipment"
                  icon="mdi:power-plug"
                  .heading=${S(`room.section.devices`,this.hass.language)}
                  editable
                  @edit-click=${this._openEdit(`devices`)}
                >
                  <rs-device-section
                    .hass=${this.hass}
                    .area=${this.area}
                    .editing=${!1}
                    .devices=${this._devices}
                    .selectedTempSensor=${this._selectedTempSensor}
                    .valveProtectionExclude=${this._valveProtectionExclude}
                    .valveProtectionEnabled=${this.valveProtectionEnabled}
                    @device-changed=${this._onDeviceChanged}
                    @valve-protection-exclude-toggle=${this._onValveProtectionExcludeToggle}
                  ></rs-device-section>
                </rs-section-card>

                <rs-section-card
                  class="dehumidifier-card"
                  data-group="equipment"
                  icon="mdi:air-humidifier"
                  .heading=${S(`dehumidifier.title`,this.hass.language)}
                  editable
                  @edit-click=${this._openEdit(`dehumidifier`)}
                >
                  ${this._renderDehumidifier(!1)}
                </rs-section-card>

                <rs-section-card
                  class="sensors-card"
                  data-group="equipment"
                  icon="mdi:thermometer"
                  .heading=${S(`room.section.sensors`,this.hass.language)}
                  editable
                  @edit-click=${this._openEdit(`sensors`)}
                >
                  <rs-sensor-section
                    .hass=${this.hass}
                    .area=${this.area}
                    .editing=${!1}
                    .temperatureSensor=${this._selectedTempSensor}
                    .humiditySensor=${this._selectedHumiditySensor}
                    .occupancySensors=${this._selectedOccupancySensors}
                    .windowSensors=${this._selectedWindowSensors}
                    .windowOpenDelay=${this._windowOpenDelay}
                    .windowCloseDelay=${this._windowCloseDelay}
                    .keepFanOnlyOnWindowOpen=${this._keepFanOnlyOnWindowOpen}
                    .moldFRsi=${this._moldFRsi}
                    .heatingSystemType=${Vt(this._devices)}
                    .language=${this.hass.language}
                    @sensor-changed=${this._onSensorChanged}
                  ></rs-sensor-section>
                </rs-section-card>

                ${this.presenceEnabled&&(this.presencePersons.length>0||this._selectedPresencePersons.length>0)?m`<rs-section-card
                      class="optional-card"
                      data-group="advanced"
                      icon="mdi:home-account"
                      .heading=${S(`room.section.presence`,this.hass.language)}
                      editable
                      @edit-click=${this._openEdit(`presence`)}
                    >
                      <rs-info-icon
                        slot="header-extras"
                        .text=${S(`presence.ignore_hint`,this.hass.language)}
                      ></rs-info-icon>
                      <rs-presence-section
                        .hass=${this.hass}
                        .presenceEnabled=${this.presenceEnabled}
                        .presencePersons=${this.presencePersons}
                        .selectedPresencePersons=${this._selectedPresencePersons}
                        .ignorePresence=${this._ignorePresence}
                        .editing=${!1}
                        .language=${this.hass.language}
                        @presence-persons-changed=${this._onPresencePersonsChanged}
                        @ignore-presence-changed=${this._onIgnorePresenceChanged}
                      ></rs-presence-section>
                    </rs-section-card>`:h}
              `}
          ${!this._isOutdoor&&(this._selectedCovers.size>0||this._coversAutoEnabled||this._coverSchedules.length>0)?m`<rs-section-card
                class="optional-card"
                data-group="advanced"
                icon="mdi:blinds-horizontal"
                .heading=${S(`room.section.covers`,this.hass.language)}
                .badge=${S(`badge.beta`,this.hass.language)}
                .badgeHint=${S(`badge.beta_hint`,this.hass.language)}
                editable
                @edit-click=${this._openEdit(`covers`)}
              >
                <rs-covers-section
                  .hass=${this.hass}
                  .area=${this.area}
                  .editing=${!1}
                  .selectedCovers=${this._selectedCovers}
                  .autoEnabled=${this._coversAutoEnabled}
                  .deployThreshold=${this._coversDeployThreshold}
                  .minPosition=${this._coversMinPosition}
                  .overrideMinutes=${this._coversOverrideMinutes}
                  .coverSchedules=${this._coverSchedules}
                  .coverScheduleSelectorEntity=${this._coverScheduleSelectorEntity}
                  .activeCoverScheduleIndex=${this.config?.live?.active_cover_schedule_index??-1}
                  .nightClose=${this._coversNightClose}
                  .nightPosition=${this._coversNightPosition}
                  .snapDeploy=${this._coversSnapDeploy}
                  .forcedReason=${this.config?.live?.cover_forced_reason??``}
                  .autoPaused=${this._optimisticCoverResume?!1:this.config?.live?.cover_auto_paused??!1}
                  .overrideUntil=${this.config?.live?.cover_override_until??null}
                  .coverOrientations=${this._coverOrientations}
                  .nightCloseElevation=${this._coversNightCloseElevation}
                  .nightCloseOffsetMinutes=${this._coversNightCloseOffsetMinutes}
                  .outdoorMinTemp=${this._coversOutdoorMinTemp}
                  .coverMinPositions=${this._coverMinPositions}
                  @covers-toggle=${this._onCoversToggle}
                  @setting-changed=${this._onCoverSettingChanged}
                  @cover-resume-auto=${this._onCoverResumeAuto}
                ></rs-covers-section>
              </rs-section-card>`:h}
          ${!this._isOutdoor&&this._selectedTempSensor&&this._devices.some(e=>e.type===`ac`)?m`<rs-section-card
                class="optional-card"
                data-group="overview"
                icon="mdi:swap-horizontal"
                .heading=${S(`room.section.heat_source`,this.hass.language)}
                editable
                @edit-click=${this._openEdit(`heatSource`)}
              >
                <rs-heat-source-section
                  .hass=${this.hass}
                  .editing=${!1}
                  .hasAc=${!0}
                  .hasTrv=${this._devices.some(e=>e.type===`trv`)}
                  .heatPumpPower=${this._heatPumpPowerWatts}
                  .powerBudgetEstimates=${this.config?.live?.power_budget_estimates}
                  .enabled=${this._heatSourceOrchestration}
                  .primaryDelta=${this._heatSourcePrimaryDelta}
                  .outdoorThreshold=${this._heatSourceOutdoorThreshold}
                  .acMinOutdoor=${this._heatSourceAcMinOutdoor}
                  @setting-changed=${this._onHeatSourceSettingChanged}
                ></rs-heat-source-section>
              </rs-section-card>`:h}

          <rs-section-card
            class="optional-card"
            data-group="equipment"
            icon="mdi:tree"
            .heading=${S(`room.section.area`,this.hass.language)}
          >
            <rs-toggle-row
              .label=${S(`room.outdoor_toggle`,this.hass.language)}
              .hint=${S(`room.outdoor_hint`,this.hass.language)}
              .checked=${this._isOutdoor}
              @toggle-changed=${this._onOutdoorToggle}
            ></rs-toggle-row>
          </rs-section-card>
          ${!this._isOutdoor&&this.config?m`<rs-room-insights
                class="insights-card"
                data-group="advanced"
                .hass=${this.hass}
                .readiness=${this.config.readiness}
                .decisionReasons=${this.config.live?.decision_reasons??[]}
                .comfortScore=${this.config.live?.comfort_score}
              ></rs-room-insights>`:h}
        </div>
        ${this._error?m`<div class="error">${this._error}</div>`:h}
        ${this._renderEditDialog()}
      </div>
    `:h}_renderEditDialog(){if(this._editing===null)return h;let e=this.hass.language;switch(this._editing){case`schedule`:return m`<rs-edit-dialog
          open
          icon="mdi:calendar"
          .heading=${S(`room.section.schedule`,e)}
          hasInfo
          @rs-dialog-closed=${this._closeEdit}
        >
          <div slot="info">
            <p><strong>${S(`schedule.help_temps_title`,e)}</strong></p>
            <p>${S(`schedule.help_temps`,e)}</p>
            <ol style="margin: 4px 0 0 0; padding-left: 20px; line-height: 1.8">
              <li>${M(S(`schedule.help_temps_1`,e))}</li>
              <li>${M(S(`schedule.help_temps_2`,e))}</li>
              <li>${M(S(`schedule.help_temps_3`,e))}</li>
              <li>${M(S(`schedule.help_temps_4`,e))}</li>
            </ol>
            <p style="margin-top: 12px">
              <strong>${S(`schedule.help_block_title`,e)}</strong>
            </p>
            <p>${M(S(`schedule.help_block`,e))}</p>
            <div class="yaml-block">
              ${M(`<span class="yaml-key">schedule</span>:
  <span class="yaml-key">living_room_heating</span>:
    <span class="yaml-key">name</span>: <span class="yaml-value">Living Room Heating</span>
    <span class="yaml-key">monday</span>:
      - <span class="yaml-key">from</span>: <span class="yaml-value">"06:00:00"</span>
        <span class="yaml-key">to</span>: <span class="yaml-value">"08:00:00"</span>
        <span class="yaml-key">data</span>:
          <span class="yaml-key">temperature</span>: <span class="yaml-value">23</span>
      - <span class="yaml-key">from</span>: <span class="yaml-value">"17:00:00"</span>
        <span class="yaml-key">to</span>: <span class="yaml-value">"22:00:00"</span>
        <span class="yaml-key">data</span>:
          <span class="yaml-key">temperature</span>: <span class="yaml-value">21.5</span>`)}
            </div>
            <p style="margin-top: 8px">${M(S(`schedule.help_block_note`,e))}</p>
            <p style="margin-top: 12px">
              <strong>${S(`schedule.help_split_title`,e)}</strong>
            </p>
            <p>${M(S(`schedule.help_split`,e))}</p>
            <div class="yaml-block">
              ${M(`- <span class="yaml-key">from</span>: <span class="yaml-value">"06:00:00"</span>
  <span class="yaml-key">to</span>: <span class="yaml-value">"08:00:00"</span>
  <span class="yaml-key">data</span>:
    <span class="yaml-key">heat_temperature</span>: <span class="yaml-value">21</span>
    <span class="yaml-key">cool_temperature</span>: <span class="yaml-value">24</span>`)}
            </div>
            <p style="margin-top: 8px">${M(S(`schedule.help_split_note`,e))}</p>
            <p style="margin-top: 12px">
              <strong>${S(`schedule.help_multi_title`,e)}</strong>
            </p>
            <p>${M(S(`schedule.help_multi`,e))}</p>
          </div>
          <rs-schedule-settings
            .hass=${this.hass}
            .schedules=${this._schedules}
            .scheduleSelectorEntity=${this._scheduleSelectorEntity}
            .activeScheduleIndex=${this.config?.live?.active_schedule_index??-1}
            .comfortHeat=${this._comfortHeat}
            .comfortCool=${this._comfortCool}
            .ecoHeat=${this._ecoHeat}
            .ecoCool=${this._ecoCool}
            .climateMode=${this._climateMode}
            .editing=${!0}
            @schedules-changed=${this._onSchedulesChanged}
            @schedule-selector-changed=${this._onScheduleSelectorChanged}
            @comfort-heat-changed=${this._onComfortHeatChanged}
            @comfort-cool-changed=${this._onComfortCoolChanged}
            @eco-heat-changed=${this._onEcoHeatChanged}
            @eco-cool-changed=${this._onEcoCoolChanged}
          ></rs-schedule-settings>
        </rs-edit-dialog>`;case`dehumidifier`:return m`<rs-edit-dialog
          open
          icon="mdi:air-humidifier"
          .heading=${S(`dehumidifier.title`,e)}
          @rs-dialog-closed=${this._closeEdit}
        >
          ${this._renderDehumidifier(!0)}
        </rs-edit-dialog>`;case`devices`:return m`<rs-edit-dialog
          open
          icon="mdi:power-plug"
          .heading=${S(`room.section.devices`,e)}
          hasInfo
          @rs-dialog-closed=${this._closeEdit}
        >
          <div slot="info">
            <b>${S(`devices.info.types_title`,e)}</b><br />
            ${S(`devices.info.types_body`,e)}
            <br /><br />
            <b>${S(`devices.info.control_title`,e)}</b><br />
            ${S(`devices.info.control_body`,e)}
            <br /><br />
            <b>${S(`devices.info.modes_title`,e)}</b><br />
            ${S(`devices.info.modes_body`,e)}
            <br /><br />
            <b>${S(`devices.info.heat_source_title`,e)}</b><br />
            ${S(`devices.info.heat_source_body`,e)}
            <br />
            <a class="helper-link" href=${sn} target="_blank" rel="noreferrer">
              ${S(`common.learn_more`,e)}
            </a>
          </div>
          <rs-device-section
            .hass=${this.hass}
            .area=${this.area}
            .editing=${!0}
            .devices=${this._devices}
            .selectedTempSensor=${this._selectedTempSensor}
            .valveProtectionExclude=${this._valveProtectionExclude}
            .valveProtectionEnabled=${this.valveProtectionEnabled}
            @device-changed=${this._onDeviceChanged}
            @valve-protection-exclude-toggle=${this._onValveProtectionExcludeToggle}
          ></rs-device-section>
        </rs-edit-dialog>`;case`sensors`:return m`<rs-edit-dialog
          open
          icon="mdi:thermometer"
          .heading=${S(`room.section.sensors`,e)}
          @rs-dialog-closed=${this._closeEdit}
        >
          <rs-sensor-section
            .hass=${this.hass}
            .area=${this.area}
            .editing=${!0}
            .temperatureSensor=${this._selectedTempSensor}
            .humiditySensor=${this._selectedHumiditySensor}
            .occupancySensors=${this._selectedOccupancySensors}
            .windowSensors=${this._selectedWindowSensors}
            .windowOpenDelay=${this._windowOpenDelay}
            .windowCloseDelay=${this._windowCloseDelay}
            .keepFanOnlyOnWindowOpen=${this._keepFanOnlyOnWindowOpen}
            .moldFRsi=${this._moldFRsi}
            .heatingSystemType=${Vt(this._devices)}
            .language=${this.hass.language}
            @sensor-changed=${this._onSensorChanged}
          ></rs-sensor-section>
        </rs-edit-dialog>`;case`presence`:return m`<rs-edit-dialog
          open
          icon="mdi:home-account"
          .heading=${S(`room.section.presence`,e)}
          hasInfo
          @rs-dialog-closed=${this._closeEdit}
        >
          <div slot="info">
            <b>${S(`presence.room_help_header`,e)}</b><br />
            ${S(`presence.room_help_body`,e)}
            <br /><br />
            <b>${S(`presence.help_ignore_title`,e)}</b><br />
            ${S(`presence.help_ignore_body`,e)}
          </div>
          <rs-presence-section
            .hass=${this.hass}
            .presenceEnabled=${this.presenceEnabled}
            .presencePersons=${this.presencePersons}
            .selectedPresencePersons=${this._selectedPresencePersons}
            .ignorePresence=${this._ignorePresence}
            .editing=${!0}
            .language=${this.hass.language}
            @presence-persons-changed=${this._onPresencePersonsChanged}
            @ignore-presence-changed=${this._onIgnorePresenceChanged}
          ></rs-presence-section>
        </rs-edit-dialog>`;case`covers`:return m`<rs-edit-dialog
          open
          icon="mdi:blinds-horizontal"
          .heading=${S(`room.section.covers`,e)}
          hasInfo
          @rs-dialog-closed=${this._closeEdit}
        >
          <div slot="info">
            <b>${S(`covers.info.selection_title`,e)}</b><br />
            ${S(`covers.info.selection_body`,e)}
            <br /><br />
            <b>${S(`covers.info.schedule_title`,e)}</b><br />
            ${S(`covers.info.schedule_body`,e)}
            <div class="yaml-block">
              ${M(`<span class="yaml-key">schedule</span>:
  <span class="yaml-key">cover_evening</span>:
    <span class="yaml-key">name</span>: <span class="yaml-value">Cover Evening</span>
    <span class="yaml-key">monday</span>:
      - <span class="yaml-key">from</span>: <span class="yaml-value">"20:00:00"</span>
        <span class="yaml-key">to</span>: <span class="yaml-value">"06:00:00"</span>
        <span class="yaml-key">data</span>:
          <span class="yaml-key">position</span>: <span class="yaml-value">10</span>`)}
            </div>
            <b>${S(`covers.info.solar_title`,e)}</b><br />
            ${S(`covers.info.solar_body`,e)}
            <br /><br />
            <b>${S(`covers.info.night_title`,e)}</b><br />
            ${S(`covers.info.night_body`,e)}
            <br /><br />
            <b>${S(`covers.info.override_title`,e)}</b><br />
            ${S(`covers.info.override_body`,e)}
            <br /><br />
            <b>${S(`covers.info.priority_title`,e)}</b><br />
            ${S(`covers.info.priority_body`,e)}
            <br /><br />
            <b>${S(`covers.info.entities_title`,e)}</b><br />
            ${S(`covers.info.entities_body`,e)}
          </div>
          <rs-covers-section
            .hass=${this.hass}
            .area=${this.area}
            .editing=${!0}
            .selectedCovers=${this._selectedCovers}
            .autoEnabled=${this._coversAutoEnabled}
            .deployThreshold=${this._coversDeployThreshold}
            .minPosition=${this._coversMinPosition}
            .overrideMinutes=${this._coversOverrideMinutes}
            .coverSchedules=${this._coverSchedules}
            .coverScheduleSelectorEntity=${this._coverScheduleSelectorEntity}
            .activeCoverScheduleIndex=${this.config?.live?.active_cover_schedule_index??-1}
            .nightClose=${this._coversNightClose}
            .nightPosition=${this._coversNightPosition}
            .snapDeploy=${this._coversSnapDeploy}
            .forcedReason=${this.config?.live?.cover_forced_reason??``}
            .autoPaused=${this._optimisticCoverResume?!1:this.config?.live?.cover_auto_paused??!1}
            .overrideUntil=${this.config?.live?.cover_override_until??null}
            .coverOrientations=${this._coverOrientations}
            .nightCloseElevation=${this._coversNightCloseElevation}
            .nightCloseOffsetMinutes=${this._coversNightCloseOffsetMinutes}
            .outdoorMinTemp=${this._coversOutdoorMinTemp}
            .coverMinPositions=${this._coverMinPositions}
            @covers-toggle=${this._onCoversToggle}
            @setting-changed=${this._onCoverSettingChanged}
            @cover-resume-auto=${this._onCoverResumeAuto}
          ></rs-covers-section>
        </rs-edit-dialog>`;case`heatSource`:return m`<rs-edit-dialog
          open
          icon="mdi:swap-horizontal"
          .heading=${S(`room.section.heat_source`,e)}
          @rs-dialog-closed=${this._closeEdit}
        >
          <rs-heat-source-section
            .hass=${this.hass}
            .editing=${!0}
            .hasAc=${this._devices.some(e=>e.type===`ac`)}
            .hasTrv=${this._devices.some(e=>e.type===`trv`)}
            .enabled=${this._heatSourceOrchestration}
            .primaryDelta=${this._heatSourcePrimaryDelta}
            .outdoorThreshold=${this._heatSourceOutdoorThreshold}
            .acMinOutdoor=${this._heatSourceAcMinOutdoor}
            .native=${this._nativeHeatSource}
            .heatPumpPower=${this._heatPumpPowerWatts}
            .powerBudgetEstimates=${this.config?.live?.power_budget_estimates}
            @setting-changed=${this._onHeatSourceSettingChanged}
          ></rs-heat-source-section>
        </rs-edit-dialog>`}}_onModeChanged(e){this._climateMode=e.detail.mode,this._autoSave()}_onSchedulesChanged(e){this._schedules=e.detail.value,this._autoSave()}_onScheduleSelectorChanged(e){this._scheduleSelectorEntity=e.detail.value,this._autoSave()}_onComfortHeatChanged(e){this._comfortHeat=e.detail.value,this._comfortCool<this._comfortHeat&&(this._comfortCool=this._comfortHeat),this._autoSave()}_onComfortCoolChanged(e){this._comfortCool=e.detail.value,this._comfortHeat>this._comfortCool&&(this._comfortHeat=this._comfortCool),this._autoSave()}_onEcoHeatChanged(e){this._ecoHeat=e.detail.value,this._ecoCool<this._ecoHeat&&(this._ecoCool=this._ecoHeat),this._autoSave()}_onEcoCoolChanged(e){this._ecoCool=e.detail.value,this._ecoHeat>this._ecoCool&&(this._ecoHeat=this._ecoCool),this._autoSave()}_renderDehumidifier(e){return m`<rs-dehumidifier-section
      .hass=${this.hass}
      .areaId=${this.area.area_id}
      .rooms=${this.rooms}
      .config=${this._dehumidifier}
      .live=${this.config?.live?.dehumidifier}
      .humidity=${this._humidity}
      .currentHumidity=${this.config?.live?.current_humidity??null}
      .climateControlActive=${this.climateControlActive}
      .roomControlEnabled=${this._climateControlEnabled}
      .editing=${e}
      @dehumidifier-changed=${e=>{this._dehumidifier=e.detail,this._autoSave()}}
      @humidity-changed=${e=>{this._humidity={...this._humidity,...e.detail},this._autoSave()}}
    ></rs-dehumidifier-section>`}_onDeviceChanged(e){let t=new Set(this._devices.map(e=>e.entity_id));this._devices=e.detail.devices;let n=new Set(this._devices.map(e=>e.entity_id));for(let e of t)if(!n.has(e)&&this._valveProtectionExclude.has(e)){let t=new Set(this._valveProtectionExclude);t.delete(e),this._valveProtectionExclude=t}for(let e of this._devices)if(e.type!==`trv`&&this._valveProtectionExclude.has(e.entity_id)){let t=new Set(this._valveProtectionExclude);t.delete(e.entity_id),this._valveProtectionExclude=t}this._autoSave()}_onSensorChanged(e){let{key:t,value:n}=e.detail;t===`temperature_sensor`?this._selectedTempSensor=n:t===`humidity_sensor`?this._selectedHumiditySensor=n:t===`occupancy_sensors`?this._selectedOccupancySensors=new Set(n):t===`window_sensors`?this._selectedWindowSensors=new Set(n):t===`window_open_delay`?this._windowOpenDelay=n:t===`window_close_delay`?this._windowCloseDelay=n:t===`keep_fan_only_on_window_open`?this._keepFanOnlyOnWindowOpen=n:t===`mold_f_rsi`&&(this._moldFRsi=n),this._autoSave()}_onValveProtectionExcludeToggle(e){let{entityId:t,excluded:n}=e.detail,r=new Set(this._valveProtectionExclude);n?r.add(t):r.delete(t),this._valveProtectionExclude=r,this._autoSave()}_onPresencePersonsChanged(e){this._selectedPresencePersons=e.detail,this._autoSave()}_onIgnorePresenceChanged(e){this._ignorePresence=e.detail,this._autoSave()}_onComfortSettingChanged(e){let{key:t,value:n}=e.detail;e.stopPropagation(),t===`active_profile`?this._activeProfile=n:t===`night_mode_enabled`?this._nightModeEnabled=n:t===`night_start`?this._nightStart=n:t===`night_end`?this._nightEnd=n:t===`night_heat_delta`?this._nightHeatDelta=n:t===`night_cool_delta`?this._nightCoolDelta=n:t===`night_ramp_minutes`&&(this._nightRampMinutes=n),this._autoSave()}_onCoversToggle(e){let{entityId:t,checked:n}=e.detail,r=new Set(this._selectedCovers);if(n)r.add(t);else{if(r.delete(t),t in this._coverOrientations){let e={...this._coverOrientations};delete e[t],this._coverOrientations=e}if(t in this._coverMinPositions){let e={...this._coverMinPositions};delete e[t],this._coverMinPositions=e}}this._selectedCovers=r,this._autoSave()}_onCoverSettingChanged(e){let{key:t,value:n}=e.detail;e.stopPropagation(),t===`covers_auto_enabled`?this._coversAutoEnabled=n:t===`covers_deploy_threshold`?this._coversDeployThreshold=n:t===`covers_min_position`?this._coversMinPosition=n:t===`covers_override_minutes`?this._coversOverrideMinutes=n:t===`cover_schedules`?this._coverSchedules=n:t===`cover_schedule_selector_entity`?this._coverScheduleSelectorEntity=n:t===`covers_night_close`?this._coversNightClose=n:t===`covers_night_position`?this._coversNightPosition=n:t===`covers_snap_deploy`?this._coversSnapDeploy=n:t===`cover_orientations`?this._coverOrientations=n:t===`covers_night_close_elevation`?this._coversNightCloseElevation=n:t===`covers_night_close_offset_minutes`?this._coversNightCloseOffsetMinutes=n:t===`covers_outdoor_min_temp`?this._coversOutdoorMinTemp=n:t===`cover_min_positions`&&(this._coverMinPositions=n),this._autoSave()}async _onCoverResumeAuto(){this._optimisticCoverResume=!0;try{await this.hass.callWS({type:`roommind/covers/clear_override`,area_id:this.area.area_id})}catch{this._optimisticCoverResume=!1}}_onHeatSourceSettingChanged(e){let{key:t,value:n}=e.detail;e.stopPropagation(),t===`heat_source_orchestration`?this._heatSourceOrchestration=n:t===`heat_source_primary_delta`?this._heatSourcePrimaryDelta=n:t===`heat_source_outdoor_threshold`?this._heatSourceOutdoorThreshold=n:t===`heat_source_ac_min_outdoor`?this._heatSourceAcMinOutdoor=n:t===`native_heat_source`?this._nativeHeatSource=n:t===`heat_pump_power_watts`&&(this._heatPumpPowerWatts=n),this._autoSave()}_onClimateControlToggle(e){this._climateControlEnabled=e.detail,this._autoSave()}_onOutdoorToggle(e){this._isOutdoor=e.detail,this._autoSave()}_onDisplayNameChanged(e){this._displayName=e.detail.value,this._autoSave()}_autoSave(){this._dirty=!0,this._saveDebounce&&clearTimeout(this._saveDebounce),this._saveDebounce=setTimeout(()=>this._doSave(),500)}async _doSave(){F(this,`saving`),this._error=``;try{await this.hass.callWS({type:`roommind/rooms/save`,area_id:this.area.area_id,devices:this._devices,temperature_sensor:this._selectedTempSensor,humidity_sensor:this._selectedHumiditySensor,dehumidifier:this._dehumidifier,...this._humidity,occupancy_sensors:[...this._selectedOccupancySensors],window_sensors:[...this._selectedWindowSensors],window_open_delay:this._windowOpenDelay,window_close_delay:this._windowCloseDelay,climate_mode:this._climateMode,schedules:this._schedules,schedule_selector_entity:this._scheduleSelectorEntity,comfort_heat:this._comfortHeat,comfort_cool:this._comfortCool,eco_heat:this._ecoHeat,eco_cool:this._ecoCool,active_profile:this._activeProfile,night_mode_enabled:this._nightModeEnabled,night_start:this._nightStart,night_end:this._nightEnd,night_heat_delta:this._nightHeatDelta,night_cool_delta:this._nightCoolDelta,night_ramp_minutes:this._nightRampMinutes,presence_persons:this._selectedPresencePersons.filter(e=>e),display_name:this._displayName,covers:[...this._selectedCovers],climate_control_enabled:this._climateControlEnabled,keep_fan_only_on_window_open:this._keepFanOnlyOnWindowOpen,mold_f_rsi:this._moldFRsi,covers_auto_enabled:this._coversAutoEnabled,covers_deploy_threshold:this._coversDeployThreshold,covers_min_position:this._coversMinPosition,covers_override_minutes:this._coversOverrideMinutes,cover_schedules:this._coverSchedules,cover_schedule_selector_entity:this._coverScheduleSelectorEntity,covers_night_close:this._coversNightClose,covers_night_position:this._coversNightPosition,covers_snap_deploy:this._coversSnapDeploy,cover_orientations:this._coverOrientations,covers_night_close_elevation:this._coversNightCloseElevation,covers_night_close_offset_minutes:this._coversNightCloseOffsetMinutes,covers_outdoor_min_temp:this._coversOutdoorMinTemp,cover_min_positions:this._coverMinPositions,ignore_presence:this._ignorePresence,is_outdoor:this._isOutdoor,valve_protection_exclude:[...this._valveProtectionExclude],heat_source_orchestration:this._heatSourceOrchestration,heat_source_primary_delta:this._heatSourcePrimaryDelta,heat_source_outdoor_threshold:this._heatSourceOutdoorThreshold,heat_source_ac_min_outdoor:this._heatSourceAcMinOutdoor,native_heat_source:this._nativeHeatSource,heat_pump_power_watts:this._heatPumpPowerWatts}),this._dirty=!1,F(this,`saved`),this.dispatchEvent(new CustomEvent(`room-updated`,{bubbles:!0,composed:!0}))}catch(e){let t=e instanceof Error?e.message:S(`room.error_save_fallback`,this.hass.language);this._error=t,F(this,`error`)}}};k([y({attribute:!1})],G.prototype,`area`,void 0),k([y({attribute:!1})],G.prototype,`rooms`,void 0),k([y({attribute:!1})],G.prototype,`config`,void 0),k([y({attribute:!1})],G.prototype,`hass`,void 0),k([y({type:Boolean})],G.prototype,`presenceEnabled`,void 0),k([y({attribute:!1})],G.prototype,`presencePersons`,void 0),k([y({type:Boolean})],G.prototype,`climateControlActive`,void 0),k([y({type:Boolean})],G.prototype,`valveProtectionEnabled`,void 0),k([b()],G.prototype,`_dehumidifier`,void 0),k([b()],G.prototype,`_humidity`,void 0),k([b()],G.prototype,`_devices`,void 0),k([b()],G.prototype,`_selectedTempSensor`,void 0),k([b()],G.prototype,`_selectedHumiditySensor`,void 0),k([b()],G.prototype,`_selectedOccupancySensors`,void 0),k([b()],G.prototype,`_selectedWindowSensors`,void 0),k([b()],G.prototype,`_windowOpenDelay`,void 0),k([b()],G.prototype,`_windowCloseDelay`,void 0),k([b()],G.prototype,`_keepFanOnlyOnWindowOpen`,void 0),k([b()],G.prototype,`_moldFRsi`,void 0),k([b()],G.prototype,`_climateMode`,void 0),k([b()],G.prototype,`_schedules`,void 0),k([b()],G.prototype,`_scheduleSelectorEntity`,void 0),k([b()],G.prototype,`_comfortHeat`,void 0),k([b()],G.prototype,`_comfortCool`,void 0),k([b()],G.prototype,`_ecoHeat`,void 0),k([b()],G.prototype,`_ecoCool`,void 0),k([b()],G.prototype,`_activeProfile`,void 0),k([b()],G.prototype,`_nightModeEnabled`,void 0),k([b()],G.prototype,`_nightStart`,void 0),k([b()],G.prototype,`_nightEnd`,void 0),k([b()],G.prototype,`_nightHeatDelta`,void 0),k([b()],G.prototype,`_nightCoolDelta`,void 0),k([b()],G.prototype,`_nightRampMinutes`,void 0),k([b()],G.prototype,`_error`,void 0),k([b()],G.prototype,`_dirty`,void 0),k([b()],G.prototype,`_editing`,void 0),k([b()],G.prototype,`_detailView`,void 0),k([b()],G.prototype,`_selectedPresencePersons`,void 0),k([b()],G.prototype,`_displayName`,void 0),k([b()],G.prototype,`_selectedCovers`,void 0),k([b()],G.prototype,`_coversAutoEnabled`,void 0),k([b()],G.prototype,`_coversDeployThreshold`,void 0),k([b()],G.prototype,`_coversMinPosition`,void 0),k([b()],G.prototype,`_coversOverrideMinutes`,void 0),k([b()],G.prototype,`_coverSchedules`,void 0),k([b()],G.prototype,`_coverScheduleSelectorEntity`,void 0),k([b()],G.prototype,`_coversNightClose`,void 0),k([b()],G.prototype,`_coversNightPosition`,void 0),k([b()],G.prototype,`_coversSnapDeploy`,void 0),k([b()],G.prototype,`_coverOrientations`,void 0),k([b()],G.prototype,`_coversNightCloseElevation`,void 0),k([b()],G.prototype,`_coversNightCloseOffsetMinutes`,void 0),k([b()],G.prototype,`_coversOutdoorMinTemp`,void 0),k([b()],G.prototype,`_coverMinPositions`,void 0),k([b()],G.prototype,`_ignorePresence`,void 0),k([b()],G.prototype,`_isOutdoor`,void 0),k([b()],G.prototype,`_valveProtectionExclude`,void 0),k([b()],G.prototype,`_climateControlEnabled`,void 0),k([b()],G.prototype,`_heatSourceOrchestration`,void 0),k([b()],G.prototype,`_heatSourcePrimaryDelta`,void 0),k([b()],G.prototype,`_heatSourceOutdoorThreshold`,void 0),k([b()],G.prototype,`_heatSourceAcMinOutdoor`,void 0),k([b()],G.prototype,`_nativeHeatSource`,void 0),k([b()],G.prototype,`_heatPumpPowerWatts`,void 0),k([b()],G.prototype,`_optimisticCoverResume`,void 0),G=k([v(`rs-room-detail`)],G);var cn=n({HaRadioPolyfill:()=>ln}),ln,un=t((()=>{_(),x(),A(),ln=class extends g{constructor(...e){super(...e),this.checked=!1,this.disabled=!1,this.name=``,this.value=``}static{this.shadowRootOptions={mode:`open`,delegatesFocus:!0}}static{this.styles=l`
    :host {
      display: inline-flex;
      align-items: center;
    }
    input {
      width: 18px;
      height: 18px;
      margin: 0;
      accent-color: var(--primary-color, #03a9f4);
      cursor: pointer;
    }
    input:disabled {
      cursor: default;
      opacity: 0.5;
    }
  `}render(){return m`
      <input
        type="radio"
        .checked=${this.checked}
        .value=${this.value}
        name=${this.name||void 0}
        ?disabled=${this.disabled}
        @change=${this._onChange}
      />
    `}_onChange(e){this.checked=e.target.checked,this.dispatchEvent(new Event(`change`,{bubbles:!0,composed:!0}))}},k([y({type:Boolean,reflect:!0})],ln.prototype,`checked`,void 0),k([y({type:Boolean,reflect:!0})],ln.prototype,`disabled`,void 0),k([y({type:String})],ln.prototype,`name`,void 0),k([y({type:String})],ln.prototype,`value`,void 0)})),dn=n({HaTextfieldPolyfill:()=>K}),K,fn=t((()=>{_(),x(),A(),K=class extends g{constructor(...e){super(...e),this.value=``,this.type=`text`,this.label=``,this.placeholder=``,this.suffix=``,this.prefix=``,this.helper=``,this.disabled=!1,this.required=!1,this.readOnly=!1,this.min=``,this.max=``,this.step=null,this.name=``}static{this.shadowRootOptions={mode:`open`,delegatesFocus:!0}}static{this.styles=l`
    :host {
      display: inline-flex;
      flex-direction: column;
      outline: none;
      width: 100%;
    }
    ha-input {
      --ha-input-padding-bottom: 0;
      width: 100%;
    }
    .prefix,
    .suffix {
      color: var(--secondary-text-color);
    }
  `}render(){return m`
      <ha-input
        .type=${this.type}
        .value=${this.value||``}
        .label=${this.label}
        .placeholder=${this.placeholder}
        .disabled=${this.disabled}
        .required=${this.required}
        .readonly=${this.readOnly}
        .min=${this.min===``?void 0:this.min}
        .max=${this.max===``?void 0:this.max}
        .step=${this.step??void 0}
        .name=${this.name||void 0}
        .hint=${this.helper}
        .withoutSpinButtons=${this.type===`number`}
        @input=${this._sync}
        @change=${this._sync}
      >
        ${this.prefix?m`<span class="prefix" slot="start">${this.prefix}</span>`:h}
        ${this.suffix?m`<span class="suffix" slot="end">${this.suffix}</span>`:h}
      </ha-input>
    `}_sync(){this.value=this._haInput?.value??``}},k([y({type:String})],K.prototype,`value`,void 0),k([y({type:String})],K.prototype,`type`,void 0),k([y({type:String})],K.prototype,`label`,void 0),k([y({type:String})],K.prototype,`placeholder`,void 0),k([y({type:String})],K.prototype,`suffix`,void 0),k([y({type:String})],K.prototype,`prefix`,void 0),k([y({type:String})],K.prototype,`helper`,void 0),k([y({type:Boolean})],K.prototype,`disabled`,void 0),k([y({type:Boolean})],K.prototype,`required`,void 0),k([y({type:Boolean,reflect:!0,attribute:`readonly`})],K.prototype,`readOnly`,void 0),k([y()],K.prototype,`min`,void 0),k([y()],K.prototype,`max`,void 0),k([y()],K.prototype,`step`,void 0),k([y({type:String})],K.prototype,`name`,void 0),k([ft(`ha-input`)],K.prototype,`_haInput`,void 0)})),pn=async()=>{if(!customElements.get(`ha-radio`))try{let{HaRadioPolyfill:e}=await Promise.resolve().then(()=>(un(),cn));customElements.get(`ha-radio`)||customElements.define(`ha-radio`,e)}catch(e){console.warn(`RoomMind: ha-radio polyfill failed to load`,e)}if(!customElements.get(`ha-textfield`))try{let{HaTextfieldPolyfill:e}=await Promise.resolve().then(()=>(fn(),dn));customElements.get(`ha-textfield`)||customElements.define(`ha-textfield`,e)}catch(e){console.warn(`RoomMind: ha-textfield polyfill failed to load`,e)}if(!(customElements.get(`ha-entity-picker`)&&customElements.get(`ha-selector`))){if(!customElements.get(`ha-selector`)){await customElements.whenDefined(`partial-panel-resolver`);let e=document.createElement(`partial-panel-resolver`);e.hass={panels:[{url_path:`tmp`,component_name:`config`}]},e._updateRoutes(),await e.routerOptions.routes.tmp.load(),await customElements.whenDefined(`ha-panel-config`),await document.createElement(`ha-panel-config`).routerOptions.routes.automation.load()}if(!customElements.get(`ha-entity-picker`))try{await(await(await window.loadCardHelpers()).createCardElement({type:`entities`,entities:[]})).constructor.getConfigElement()}catch{}if(!customElements.get(`ha-entity-picker`))try{await Promise.race([customElements.whenDefined(`ha-selector`),new Promise((e,t)=>setTimeout(()=>t(Error(`timeout`)),1e4))]);let e=document.querySelector(`home-assistant`)?.hass,t=document.createElement(`div`);t.style.cssText=`position:fixed;left:-9999px;opacity:0;pointer-events:none`,document.body.appendChild(t);try{let n=document.createElement(`ha-selector`);n.hass=e,n.selector={entity:{}},t.appendChild(n),await Promise.race([customElements.whenDefined(`ha-entity-picker`),new Promise(e=>setTimeout(e,5e3))])}finally{t.remove()}}catch{}if(await customElements.whenDefined(`ha-card`),!customElements.get(`ha-date-range-picker`))try{await(await window.loadCardHelpers()).createCardElement({type:`energy-date-selection`,entities:[]}),await Promise.race([customElements.whenDefined(`ha-date-range-picker`),new Promise((e,t)=>setTimeout(t,5e3))])}catch{}if(!customElements.get(`ha-chart-base`))try{await(await window.loadCardHelpers()).createCardElement({type:`statistics-graph`,entities:[]}),await Promise.race([customElements.whenDefined(`ha-chart-base`),new Promise((e,t)=>setTimeout(t,5e3))])}catch{}}};function mn(e){return Array.isArray(e)?e.filter(e=>typeof e==`string`&&e.length>0):typeof e==`string`&&e.length>0?[e]:[]}function hn(e){return e===`consumption`?`consumption`:`available`}function gn(e){return{value:hn(e),hasLocalChange:!0}}function _n(e,t){let n=hn(t);return e.hasLocalChange&&n!==e.value?e:{value:n,hasLocalChange:!1}}function vn(e,t){return{hydraulicBypassEntities:Array.isArray(e)?e.filter(e=>typeof e==`string`&&e.length>0):typeof e==`string`&&e.length>0?[e]:[],powerSensorMode:t===`consumption`?`consumption`:`available`}}var yn=3250368e4;_(),x(),A();var bn=class extends g{constructor(...e){super(...e),this.icon=``,this.heading=``,this.intro=``,this.badge=``,this.badgeHint=``}render(){return m`
      <ha-expansion-panel outlined>
        <div slot="header" class="panel-header">
          <ha-icon .icon=${this.icon}></ha-icon>
          <span>${this.heading}</span>
          ${this.badge?m`<rs-badge .label=${this.badge} .hint=${this.badgeHint}></rs-badge>`:h}
        </div>
        <div class="panel-content">
          ${this.intro?m`<p class="section-intro">${this.intro}</p>`:h}
          <slot></slot>
        </div>
      </ha-expansion-panel>
    `}static{this.styles=l`
    :host {
      display: block;
    }
    :host([hidden]) {
      display: none !important;
    }
    ha-expansion-panel {
      --ha-card-border-radius: 16px;
      --ha-card-box-shadow: none;
    }

    .panel-header {
      display: flex;
      align-items: center;
      gap: 13px;
      min-height: 44px;
      --mdc-icon-size: 20px;
      color: var(--primary-color, var(--secondary-text-color));
    }

    .panel-header span {
      color: var(--primary-text-color);
      font-weight: 650;
      font-size: 14px;
    }

    .panel-content {
      padding: 12px 20px 22px;
    }

    .section-intro {
      color: var(--secondary-text-color);
      font-size: 13px;
      line-height: 1.5;
      margin: 0 0 16px;
      padding: 0;
    }
  `}};k([y({type:String})],bn.prototype,`icon`,void 0),k([y({type:String})],bn.prototype,`heading`,void 0),k([y({type:String})],bn.prototype,`intro`,void 0),k([y({type:String})],bn.prototype,`badge`,void 0),k([y({type:String})],bn.prototype,`badgeHint`,void 0),bn=k([v(`rs-settings-panel`)],bn),_();var q=class extends g{_fire(e,t){this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:e,value:t},bubbles:!0,composed:!0}))}static{this.settingsBaseStyles=l`
    :host {
      display: block;
    }

    /* Round HA's MDC-based inputs to match the rest of the design */
    ha-textfield,
    ha-select,
    ha-entity-picker,
    ha-combo-box {
      --mdc-shape-small: 8px;
      --mdc-shape-medium: 8px;
      --md-filled-text-field-container-shape: 8px;
      --md-outlined-text-field-container-shape: 8px;
      display: block;
      border-radius: 8px;
      overflow: hidden;
      isolation: isolate;
      clip-path: inset(0 round 8px);
    }

    ha-entity-picker {
      clip-path: inset(0 round 8px 8px 4px 4px);
    }

    .settings-section {
      padding: 16px 0;
      border-top: 1px solid var(--divider-color);
    }
    .settings-section:first-child,
    .settings-section.first {
      border-top: none;
      padding-top: 0;
    }

    .toggle-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 16px;
    }
    .toggle-text {
      display: flex;
      flex-direction: column;
      gap: 4px;
      flex: 1;
    }
    .toggle-label {
      font-size: 14px;
      font-weight: 500;
      color: var(--primary-text-color);
    }
    .toggle-hint {
      font-size: 13px;
      color: var(--secondary-text-color);
      line-height: 1.4;
    }

    .threshold-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }
    .threshold-field {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    .threshold-field ha-textfield {
      width: 100%;
    }
    .field-hint {
      color: var(--secondary-text-color);
      font-size: 12px;
    }

    @media (max-width: 600px) {
      .threshold-grid {
        grid-template-columns: 1fr;
      }
    }
  `}};_(),x(),A();var xn=class extends g{constructor(...e){super(...e),this.options=[],this.selected=``}static{this.styles=l`
    :host {
      display: block;
    }

    .radio-group {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    label {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      font-size: 14px;
      color: var(--primary-text-color);
    }
  `}render(){return m`
      <div class="radio-group">
        ${this.options.map(e=>m`
            <label>
              <ha-radio
                .checked=${this.selected===e.value}
                .value=${e.value}
                @change=${this._onRadioChange}
              ></ha-radio>
              ${e.label}
            </label>
          `)}
      </div>
    `}_onRadioChange(e){let t=e.target;t.checked&&this.dispatchEvent(new CustomEvent(`selected-changed`,{detail:t.value,bubbles:!0,composed:!0}))}};k([y({type:Array})],xn.prototype,`options`,void 0),k([y({type:String})],xn.prototype,`selected`,void 0),xn=k([v(`rs-radio-group`)],xn),_(),x(),A();var Sn=class extends q{constructor(...e){super(...e),this.groupByFloor=!1,this.climateControlActive=!0,this.temperatureRoundingMode=`nearest`}render(){let e=this.hass.language;return m`
      ${this.hass.floors&&Object.keys(this.hass.floors).length>0?m`<div class="settings-section first">
            <div class="toggle-row">
              <div class="toggle-text">
                <span class="toggle-label">${S(`settings.group_by_floor`,e)}</span>
              </div>
              <ha-switch
                .checked=${this.groupByFloor}
                @change=${e=>this._fire(`groupByFloor`,e.target.checked)}
              ></ha-switch>
            </div>
          </div>`:h}

      <div
        class="settings-section ${this.hass.floors&&Object.keys(this.hass.floors).length>0?``:`first`}"
      >
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">${S(`settings.climate_control_active`,e)}</span>
            <span class="toggle-hint">${S(`settings.climate_control_hint`,e)}</span>
          </div>
          <ha-switch
            .checked=${this.climateControlActive}
            @change=${e=>this._fire(`climateControlActive`,e.target.checked)}
          ></ha-switch>
        </div>
      </div>

      <div class="settings-section">
        <div class="toggle-text">
          <span class="toggle-label">${S(`settings.temperature_rounding`,e)}</span>
          <span class="toggle-hint">${S(`settings.temperature_rounding_hint`,e)}</span>
        </div>
        <div style="margin-top: 12px">
          <rs-radio-group
            .options=${[{value:`nearest`,label:S(`settings.temperature_rounding_nearest`,e)},{value:`down`,label:S(`settings.temperature_rounding_down`,e)},{value:`up`,label:S(`settings.temperature_rounding_up`,e)}]}
            .selected=${this.temperatureRoundingMode}
            @selected-changed=${e=>this._fire(`temperatureRoundingMode`,e.detail)}
          ></rs-radio-group>
        </div>
      </div>
    `}static{this.styles=[q.settingsBaseStyles]}};k([y({attribute:!1})],Sn.prototype,`hass`,void 0),k([y({type:Boolean})],Sn.prototype,`groupByFloor`,void 0),k([y({type:Boolean})],Sn.prototype,`climateControlActive`,void 0),k([y({type:String})],Sn.prototype,`temperatureRoundingMode`,void 0),Sn=k([v(`rs-settings-general`)],Sn),_(),x(),A();var Cn=class extends q{constructor(...e){super(...e),this.outdoorTempSensor=``,this.outdoorHumiditySensor=``,this.weatherEntity=``,this.outdoorUnavailableNotify=!0,this._filterTemperature=e=>e.attributes?.device_class===`temperature`,this._filterHumidity=e=>e.attributes?.device_class===`humidity`}_getSensorValue(e){let t=this.hass.states[e];if(!t||t.state===`unavailable`||t.state===`unknown`)return null;let n=parseFloat(t.state);return isNaN(n)?null:Math.round(n*10)/10}render(){let e=this.hass.language,t=this.outdoorTempSensor?this._getSensorValue(this.outdoorTempSensor):null,n=this.outdoorHumiditySensor?this._getSensorValue(this.outdoorHumiditySensor):null;return m`
      <div class="settings-section first">
        <div class="sensor-grid">
          <div class="sensor-field">
            <ha-entity-picker
              .hass=${this.hass}
              .value=${this.outdoorTempSensor}
              .includeDomains=${[`sensor`]}
              .entityFilter=${this._filterTemperature}
              .label=${S(`settings.outdoor_sensor_label`,e)}
              allow-custom-entity
              @value-changed=${e=>{let t=e.detail?.value??``;t!==this.outdoorTempSensor&&this._fire(`outdoorTempSensor`,t)}}
            ></ha-entity-picker>
            ${t===null?this.outdoorTempSensor?m`<div class="current-value muted">
                    ${S(`settings.outdoor_waiting`,e)}
                  </div>`:h:m`<div class="current-value">
                  ${S(`settings.outdoor_current`,e,{temp:t.toFixed(1),unit:C(this.hass)})}
                </div>`}
          </div>
          <div class="sensor-field">
            <ha-entity-picker
              .hass=${this.hass}
              .value=${this.outdoorHumiditySensor}
              .includeDomains=${[`sensor`]}
              .entityFilter=${this._filterHumidity}
              .label=${S(`settings.outdoor_humidity_label`,e)}
              allow-custom-entity
              @value-changed=${e=>{let t=e.detail?.value??``;t!==this.outdoorHumiditySensor&&this._fire(`outdoorHumiditySensor`,t)}}
            ></ha-entity-picker>
            ${n===null?this.outdoorHumiditySensor?m`<div class="current-value muted">
                    ${S(`settings.outdoor_waiting`,e)}
                  </div>`:h:m`<div class="current-value">
                  ${S(`settings.outdoor_humidity_current`,e,{value:String(n)})}
                </div>`}
          </div>
        </div>
      </div>

      <div class="settings-section">
        <ha-entity-picker
          .hass=${this.hass}
          .value=${this.weatherEntity}
          .includeDomains=${[`weather`]}
          .label=${S(`settings.weather_entity`,e)}
          allow-custom-entity
          @value-changed=${e=>{let t=e.detail?.value??``;t!==this.weatherEntity&&this._fire(`weatherEntity`,t)}}
        ></ha-entity-picker>
        <span class="field-hint">${S(`settings.weather_entity_hint`,e)}</span>
      </div>

      <div class="settings-section">
        <rs-toggle-row
          .label=${S(`settings.outdoor_unavailable_notify`,e)}
          .hint=${S(`settings.outdoor_unavailable_notify_hint`,e)}
          .checked=${this.outdoorUnavailableNotify}
          @toggle-changed=${e=>this._fire(`outdoorUnavailableNotify`,e.detail)}
        ></rs-toggle-row>
      </div>
    `}static{this.styles=[q.settingsBaseStyles,l`
      .sensor-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
      }
      .current-value {
        margin-top: 8px;
        font-size: 14px;
        color: var(--primary-text-color);
      }
      .current-value.muted {
        color: var(--secondary-text-color);
      }

      @media (max-width: 600px) {
        .sensor-grid {
          grid-template-columns: 1fr;
        }
      }
    `]}};k([y({attribute:!1})],Cn.prototype,`hass`,void 0),k([y({type:String})],Cn.prototype,`outdoorTempSensor`,void 0),k([y({type:String})],Cn.prototype,`outdoorHumiditySensor`,void 0),k([y({type:String})],Cn.prototype,`weatherEntity`,void 0),k([y({type:Boolean})],Cn.prototype,`outdoorUnavailableNotify`,void 0),Cn=k([v(`rs-settings-sensors`)],Cn),_(),x(),A();var wn=`https://github.com/snazzybean/roommind/blob/main/docs/control-and-devices.md`,Tn=class extends q{constructor(...e){super(...e),this.controlMode=`mpc`,this.comfortWeight=70,this.outdoorCoolingMin=16,this.outdoorHeatingMax=22,this.predictionEnabled=!0,this.scheduleOffAction=`eco`}render(){let e=this.hass.language;return m`
      <div class="settings-section first">
        <p class="hint">${S(`settings.control_mode_hint`,e)}</p>
        <div class="radio-group">
          <label class="radio-option" @click=${()=>this._setControlMode(`mpc`)}>
            <ha-radio name="control_mode" .checked=${this.controlMode===`mpc`}></ha-radio>
            <span>${S(`settings.control_mode_mpc`,e)}</span>
          </label>
          <label class="radio-option" @click=${()=>this._setControlMode(`bangbang`)}>
            <ha-radio name="control_mode" .checked=${this.controlMode===`bangbang`}></ha-radio>
            <span>${S(`settings.control_mode_simple`,e)}</span>
          </label>
        </div>
      </div>

      <div class="settings-section">
        <label class="section-label">${S(`settings.comfort_weight`,e)}</label>
        <div class="slider-row">
          <span class="slider-label">${S(`settings.comfort_weight_efficiency`,e)}</span>
          <input
            type="range"
            min="0"
            max="100"
            step="5"
            .value=${String(this.comfortWeight)}
            @change=${e=>{let t=parseInt(e.target.value,10);!isNaN(t)&&t!==this.comfortWeight&&this._fire(`comfortWeight`,t)}}
          />
          <span class="slider-label">${S(`settings.comfort_weight_comfort`,e)}</span>
        </div>
        <p class="hint helper-text">${S(`settings.comfort_weight_hint`,e)}</p>
        <a class="helper-link" href=${wn} target="_blank" rel="noreferrer">
          ${S(`common.learn_more`,e)}
        </a>
      </div>

      <div class="settings-section">
        <p class="hint">${S(`settings.smart_control_hint`,e)}</p>
        <div class="threshold-grid">
          <div class="threshold-field">
            <ha-textfield
              .value=${String(w(this.outdoorCoolingMin,this.hass))}
              .label=${S(`settings.outdoor_cooling_min`,e)}
              .suffix=${C(this.hass)}
              type="number"
              step=${D(this.hass)}
              min=${O(-10,40,this.hass).min}
              max=${O(-10,40,this.hass).max}
              @change=${e=>{let t=parseFloat(e.target.value);isNaN(t)||this._fire(`outdoorCoolingMin`,T(t,this.hass))}}
            ></ha-textfield>
            <span class="field-hint">${S(`settings.outdoor_cooling_min_hint`,e)}</span>
          </div>
          <div class="threshold-field">
            <ha-textfield
              .value=${String(w(this.outdoorHeatingMax,this.hass))}
              .label=${S(`settings.outdoor_heating_max`,e)}
              .suffix=${C(this.hass)}
              type="number"
              step=${D(this.hass)}
              min=${O(0,40,this.hass).min}
              max=${O(0,40,this.hass).max}
              @change=${e=>{let t=parseFloat(e.target.value);isNaN(t)||this._fire(`outdoorHeatingMax`,T(t,this.hass))}}
            ></ha-textfield>
            <span class="field-hint">${S(`settings.outdoor_heating_max_hint`,e)}</span>
          </div>
        </div>
      </div>

      <div class="settings-section">
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">${S(`settings.prediction_enabled`,e)}</span>
            <span class="toggle-hint">${S(`settings.prediction_enabled_hint`,e)}</span>
          </div>
          <ha-switch
            .checked=${this.predictionEnabled}
            @change=${e=>this._fire(`predictionEnabled`,e.target.checked)}
          ></ha-switch>
        </div>
      </div>

      <div class="settings-section">
        <ha-select
          .label=${S(`schedule.off_action_label`,e)}
          .value=${this.scheduleOffAction}
          .options=${[{value:`eco`,label:S(`schedule.off_action_eco`,e)},{value:`off`,label:S(`schedule.off_action_off`,e)}]}
          fixedMenuPosition
          @selected=${e=>{let t=P(e);t&&t!==this.scheduleOffAction&&this._fire(`scheduleOffAction`,t)}}
          @closed=${e=>e.stopPropagation()}
        >
          <ha-list-item value="eco">${S(`schedule.off_action_eco`,e)}</ha-list-item>
          <ha-list-item value="off">${S(`schedule.off_action_off`,e)}</ha-list-item>
        </ha-select>
      </div>
    `}_setControlMode(e){this.controlMode!==e&&this._fire(`controlMode`,e)}static{this.styles=[q.settingsBaseStyles,l`
      .hint {
        color: var(--secondary-text-color);
        font-size: 13px;
        margin: 0 0 12px;
      }
      .helper-text {
        margin: 10px 0 0;
      }
      .section-label {
        display: block;
        margin-bottom: 8px;
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .radio-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }
      .radio-option {
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
      }

      .slider-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .slider-row input[type="range"] {
        flex: 1;
        accent-color: var(--primary-color);
      }
      .slider-label {
        font-size: 12px;
        color: var(--secondary-text-color);
        white-space: nowrap;
      }
      .helper-link {
        display: inline-block;
        margin-top: 6px;
        font-size: 12px;
        color: var(--primary-color);
        text-decoration: none;
      }
      .helper-link:hover {
        text-decoration: underline;
      }
    `]}};k([y({attribute:!1})],Tn.prototype,`hass`,void 0),k([y({type:String})],Tn.prototype,`controlMode`,void 0),k([y({type:Number})],Tn.prototype,`comfortWeight`,void 0),k([y({type:Number})],Tn.prototype,`outdoorCoolingMin`,void 0),k([y({type:Number})],Tn.prototype,`outdoorHeatingMax`,void 0),k([y({type:Boolean})],Tn.prototype,`predictionEnabled`,void 0),k([y({type:String})],Tn.prototype,`scheduleOffAction`,void 0),Tn=k([v(`rs-settings-control`)],Tn),_(),x(),A();var En=class extends q{constructor(...e){super(...e),this.presenceEnabled=!1,this.presencePersons=[],this.presenceAwayAction=`eco`,this.presenceClearsOverride=!1}render(){let e=this.hass.language;return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${S(`presence.title`,e)}</span>
          <span class="toggle-hint">${S(`presence.hint`,e)}</span>
        </div>
        <ha-switch
          .checked=${this.presenceEnabled}
          @change=${e=>this._fire(`presenceEnabled`,e.target.checked)}
        ></ha-switch>
      </div>

      ${this.presenceEnabled?m`
            <div class="detail-section">
              <span class="field-hint">${S(`presence.hint_detail`,e)}</span>
              ${this.presencePersons.length>0?m`
                    <div class="person-list">
                      ${this.presencePersons.map(e=>{let t=this.hass.states[e]?.attributes?.friendly_name??e.split(`.`).slice(1).join(`.`);return m`
                          <div class="person-row">
                            <ha-icon
                              icon="mdi:account"
                              style="--mdc-icon-size: 18px; color: var(--secondary-text-color)"
                            ></ha-icon>
                            <span class="person-name">${t}</span>
                            <ha-icon-button
                              .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
                              @click=${()=>this._fire(`presencePersons`,this.presencePersons.filter(t=>t!==e))}
                            ></ha-icon-button>
                          </div>
                        `})}
                    </div>
                  `:h}
              <ha-entity-picker
                .hass=${this.hass}
                .includeDomains=${[`person`,`device_tracker`,`binary_sensor`,`input_boolean`]}
                .entityFilter=${e=>!this.presencePersons.includes(e.entity_id)}
                .label=${S(`presence.add_entity`,e)}
                @value-changed=${e=>{let t=e.detail?.value;t&&!this.presencePersons.includes(t)&&this._fire(`presencePersons`,[...this.presencePersons,t]);let n=e.target;n.value=``}}
              ></ha-entity-picker>
              <ha-select
                .label=${S(`presence.away_action_label`,e)}
                .value=${this.presenceAwayAction}
                .options=${[{value:`eco`,label:S(`presence.away_action_eco`,e)},{value:`off`,label:S(`presence.away_action_off`,e)}]}
                fixedMenuPosition
                @selected=${e=>{let t=P(e);t&&t!==this.presenceAwayAction&&this._fire(`presenceAwayAction`,t)}}
                @closed=${e=>e.stopPropagation()}
                style="margin-top: 8px"
              >
                <ha-list-item value="eco">${S(`presence.away_action_eco`,e)}</ha-list-item>
                <ha-list-item value="off">${S(`presence.away_action_off`,e)}</ha-list-item>
              </ha-select>
              <div class="toggle-row">
                <div class="toggle-text">
                  <span class="toggle-label">${S(`presence.clears_override_label`,e)}</span>
                  <span class="toggle-hint">${S(`presence.clears_override_hint`,e)}</span>
                </div>
                <ha-switch
                  .checked=${this.presenceClearsOverride}
                  @change=${e=>this._fire(`presenceClearsOverride`,e.target.checked)}
                ></ha-switch>
              </div>
            </div>
          `:h}
    `}static{this.styles=[q.settingsBaseStyles,l`
      .detail-section {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-top: 12px;
      }

      .person-list {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .person-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 4px 8px 4px 12px;
        border-radius: 8px;
        background: rgba(0, 0, 0, 0.04);
      }
      .person-name {
        flex: 1;
        font-size: 14px;
        font-weight: 500;
      }
    `]}};k([y({attribute:!1})],En.prototype,`hass`,void 0),k([y({type:Boolean})],En.prototype,`presenceEnabled`,void 0),k([y({type:Array})],En.prototype,`presencePersons`,void 0),k([y({type:String})],En.prototype,`presenceAwayAction`,void 0),k([y({type:Boolean})],En.prototype,`presenceClearsOverride`,void 0),En=k([v(`rs-settings-presence`)],En),_(),x(),A();var Dn=class extends q{constructor(...e){super(...e),this.vacationActive=!1,this.vacationTemp=15,this.vacationUntil=``}render(){let e=this.hass.language;return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${S(`vacation.title`,e)}</span>
          <span class="toggle-hint">${S(`vacation.hint`,e)}</span>
        </div>
        <ha-switch
          .checked=${this.vacationActive}
          @change=${e=>{let t=e.target.checked;this._fire(`vacationActive`,t),t||this._fire(`vacationUntil`,``)}}
        ></ha-switch>
      </div>

      ${this.vacationActive?m`
            <div class="threshold-grid" style="margin-top: 12px">
              <div class="threshold-field">
                <ha-textfield
                  .value=${this.vacationUntil}
                  .label=${S(`vacation.end_date`,e)}
                  type="datetime-local"
                  @change=${e=>this._fire(`vacationUntil`,e.target.value)}
                ></ha-textfield>
              </div>
              <div class="threshold-field">
                <ha-textfield
                  .value=${String(w(this.vacationTemp,this.hass))}
                  .label=${S(`vacation.setback_temp`,e)}
                  .suffix=${C(this.hass)}
                  type="number"
                  step=${D(this.hass)}
                  min=${O(5,25,this.hass).min}
                  max=${O(5,25,this.hass).max}
                  @change=${e=>{let t=parseFloat(e.target.value);isNaN(t)||this._fire(`vacationTemp`,T(t,this.hass))}}
                ></ha-textfield>
              </div>
            </div>
          `:h}
    `}static{this.styles=[q.settingsBaseStyles]}};k([y({attribute:!1})],Dn.prototype,`hass`,void 0),k([y({type:Boolean})],Dn.prototype,`vacationActive`,void 0),k([y({type:Number})],Dn.prototype,`vacationTemp`,void 0),k([y({type:String})],Dn.prototype,`vacationUntil`,void 0),Dn=k([v(`rs-settings-vacation`)],Dn),_(),x(),A();var On=class extends q{constructor(...e){super(...e),this.valveProtectionEnabled=!1,this.valveProtectionInterval=7}render(){let e=this.hass.language;return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${S(`valve_protection.title`,e)}</span>
          <span class="toggle-hint">${S(`valve_protection.hint`,e)}</span>
        </div>
        <ha-switch
          .checked=${this.valveProtectionEnabled}
          @change=${e=>this._fire(`valveProtectionEnabled`,e.target.checked)}
        ></ha-switch>
      </div>

      ${this.valveProtectionEnabled?m`
            <div class="threshold-grid" style="margin-top: 12px">
              <div class="threshold-field">
                <ha-textfield
                  .value=${String(this.valveProtectionInterval)}
                  .label=${S(`valve_protection.interval_label`,e)}
                  .suffix=${S(`valve_protection.interval_suffix`,e)}
                  type="number"
                  step="1"
                  min="1"
                  max="90"
                  @change=${e=>{let t=parseInt(e.target.value,10);!isNaN(t)&&t>=1&&t<=90&&this._fire(`valveProtectionInterval`,t)}}
                ></ha-textfield>
                <span class="field-hint">${S(`valve_protection.interval_hint`,e)}</span>
              </div>
            </div>
          `:h}
    `}static{this.styles=[q.settingsBaseStyles]}};k([y({attribute:!1})],On.prototype,`hass`,void 0),k([y({type:Boolean})],On.prototype,`valveProtectionEnabled`,void 0),k([y({type:Number})],On.prototype,`valveProtectionInterval`,void 0),On=k([v(`rs-settings-valve`)],On),_(),x(),A();var kn=class extends g{constructor(...e){super(...e),this.label=``,this.confirmMessage=``,this.disabled=!1,this.destructive=!1}static{this.styles=l`
    :host {
      display: block;
    }

    .confirm-btn {
      background: transparent;
      border: 1px solid var(--divider-color);
      border-radius: 8px;
      padding: 8px 16px;
      font-size: 14px;
      font-family: inherit;
      cursor: pointer;
      color: var(--primary-text-color);
      transition: all 0.2s;
    }

    .confirm-btn.destructive {
      border-color: var(--error-color);
      color: var(--error-color);
    }

    .confirm-btn.destructive:hover:not([disabled]) {
      background: var(--error-color);
      color: #fff;
    }

    .confirm-btn[disabled] {
      opacity: 0.5;
      cursor: not-allowed;
    }
  `}render(){return m`
      <button
        class="confirm-btn ${this.destructive?`destructive`:``}"
        ?disabled=${this.disabled}
        @click=${this._onClick}
      >
        ${this.label}
      </button>
    `}_onClick(){this.disabled||this.confirmMessage&&!confirm(this.confirmMessage)||this.dispatchEvent(new CustomEvent(`confirmed`,{bubbles:!0,composed:!0}))}};k([y({type:String})],kn.prototype,`label`,void 0),k([y({type:String})],kn.prototype,`confirmMessage`,void 0),k([y({type:Boolean})],kn.prototype,`disabled`,void 0),k([y({type:Boolean})],kn.prototype,`destructive`,void 0),kn=k([v(`rs-confirm-button`)],kn),_(),x(),A();var An=class extends g{constructor(...e){super(...e),this.compressorGroups=[],this._memberFilter=e=>{let t=e.entity_id;if(t.substring(t.indexOf(`.`)+1).startsWith(`roommind_`))return!1;for(let e of this.compressorGroups)if(e.members.includes(t)||e.master_entity===t)return!1;return!0},this._masterFilter=e=>{let t=e.entity_id;if(t.substring(t.indexOf(`.`)+1).startsWith(`roommind_`))return!1;for(let e of this.compressorGroups)if(e.members.includes(t)||e.master_entity===t)return!1;return!0}}static{this.styles=[I,l`
      :host {
        display: block;
      }
      .group-card {
        border: 1px solid var(--divider-color);
        border-radius: 8px;
        padding: 16px;
        margin-bottom: 16px;
      }
      .member-list {
        display: flex;
        flex-direction: column;
        gap: 4px;
        margin: 8px 0;
      }
      .member-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 4px 8px;
        background: var(--card-background-color);
        border-radius: 4px;
      }
      .member-name {
        font-size: 14px;
        flex: 1;
      }
      .member-area {
        font-size: 12px;
        color: var(--secondary-text-color);
        margin-left: 4px;
      }
      .member-missing {
        color: var(--error-color);
      }
      .field-row {
        margin-top: 12px;
      }
      .field-hint {
        font-size: 12px;
        color: var(--secondary-text-color);
        margin-top: 4px;
      }
      .section-label {
        font-size: 14px;
        font-weight: 500;
        margin-top: 12px;
        margin-bottom: 4px;
      }
      .add-button {
        margin-top: 12px;
      }
      .delete-row {
        margin-top: 16px;
        display: flex;
        justify-content: flex-end;
      }
      .no-groups {
        color: var(--secondary-text-color);
        font-size: 14px;
        padding: 8px 0;
      }
      ha-textfield {
        width: 100%;
      }
      ha-entity-picker {
        width: 100%;
      }
      .number-fields {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
        margin-top: 12px;
      }
      @media (max-width: 500px) {
        .number-fields {
          grid-template-columns: 1fr;
        }
      }
    `]}render(){let e=this.hass.language;return m`
      ${this.compressorGroups.length===0?m`<div class="no-groups">${S(`compressor.no_groups`,e)}</div>`:this.compressorGroups.map((e,t)=>this._renderGroup(e,t))}
      <ha-button class="add-button" @click=${this._addGroup}>
        <ha-icon icon="mdi:plus" slot="icon"></ha-icon>
        ${S(`compressor.add_group`,e)}
      </ha-button>
    `}_renderGroup(e,t){let n=this.hass.language;return m`
      <div class="group-card">
        <ha-textfield
          .value=${e.name}
          .label=${S(`compressor.group_name`,n)}
          @change=${e=>{let n=e.target.value;this._updateGroup(t,`name`,n)}}
        ></ha-textfield>

        <div class="section-label">${S(`compressor.members`,n)}</div>
        ${e.members.length>0?m`
              <div class="member-list">
                ${e.members.map(e=>this._renderMember(e,t))}
              </div>
            `:h}
        <ha-entity-picker
          .hass=${this.hass}
          .value=${``}
          .includeDomains=${[`climate`]}
          .entityFilter=${this._memberFilter}
          @value-changed=${e=>{let n=e.detail?.value??``;if(!n)return;let r=[...this.compressorGroups];r[t]={...r[t],members:[...r[t].members,n]},this._fire(r);let i=e.target;i&&(i.value=``)}}
        ></ha-entity-picker>
        <div class="field-hint">${S(`compressor.members_hint`,n)}</div>

        <div class="number-fields">
          <div>
            <ha-textfield
              type="number"
              .value=${String(e.min_run_minutes)}
              .label=${S(`compressor.min_run`,n)}
              .suffix=${S(`compressor.min_run_suffix`,n)}
              min="1"
              max="60"
              step="1"
              @change=${e=>{let n=parseInt(e.target.value,10);!isNaN(n)&&n>=1&&n<=60&&this._updateGroup(t,`min_run_minutes`,n)}}
            ></ha-textfield>
            <div class="field-hint">${S(`compressor.min_run_hint`,n)}</div>
          </div>
          <div>
            <ha-textfield
              type="number"
              .value=${String(e.min_off_minutes)}
              .label=${S(`compressor.min_off`,n)}
              .suffix=${S(`compressor.min_off_suffix`,n)}
              min="1"
              max="30"
              step="1"
              @change=${e=>{let n=parseInt(e.target.value,10);!isNaN(n)&&n>=1&&n<=30&&this._updateGroup(t,`min_off_minutes`,n)}}
            ></ha-textfield>
            <div class="field-hint">${S(`compressor.min_off_hint`,n)}</div>
          </div>
        </div>

        <div class="section-label">${S(`compressor.master_entity`,n)}</div>
        <ha-entity-picker
          .hass=${this.hass}
          .value=${e.master_entity||``}
          .includeDomains=${[`climate`]}
          .entityFilter=${this._masterFilter}
          @value-changed=${e=>{this._updateGroup(t,`master_entity`,e.detail?.value??``)}}
        ></ha-entity-picker>
        <div class="field-hint">${S(`compressor.master_entity_hint`,n)}</div>

        <div class="field-row">
          <ha-formfield .label=${S(`compressor.enforce_uniform_mode`,n)}>
            <ha-switch
              .checked=${e.enforce_uniform_mode||!1}
              @change=${e=>{this._updateGroup(t,`enforce_uniform_mode`,e.target.checked)}}
            ></ha-switch>
          </ha-formfield>
          <div class="field-hint">${S(`compressor.enforce_uniform_mode_hint`,n)}</div>
        </div>

        ${e.master_entity||e.enforce_uniform_mode?m`
              <div class="field-row">
                <ha-select
                  .label=${S(`compressor.conflict_resolution`,n)}
                  .value=${e.conflict_resolution||`heating_priority`}
                  .options=${[{value:`heating_priority`,label:S(`compressor.conflict_heating_priority`,n)},{value:`cooling_priority`,label:S(`compressor.conflict_cooling_priority`,n)},{value:`majority`,label:S(`compressor.conflict_majority`,n)},{value:`outdoor_temp`,label:S(`compressor.conflict_outdoor_temp`,n)}]}
                  @selected=${e=>{let n=P(e);n&&this._updateGroup(t,`conflict_resolution`,n)}}
                  @closed=${e=>e.stopPropagation()}
                  fixedMenuPosition
                  style="width: 100%;"
                >
                </ha-select>
                <div class="field-hint">${S(`compressor.conflict_resolution_hint`,n)}</div>
              </div>
            `:h}

        <div class="field-row">
          <ha-entity-picker
            .hass=${this.hass}
            .value=${e.action_script||``}
            .includeDomains=${[`script`]}
            .label=${S(`compressor.action_script`,n)}
            @value-changed=${e=>{this._updateGroup(t,`action_script`,e.detail?.value??``)}}
          ></ha-entity-picker>
          <div class="field-hint">${S(`compressor.action_script_hint`,n)}</div>
        </div>

        <div class="delete-row">
          <rs-confirm-button
            .label=${S(`compressor.delete`,n)}
            .confirmMessage=${S(`compressor.delete_confirm`,n).replace(`{name}`,e.name||`#${t+1}`)}
            destructive
            @confirmed=${()=>{this._fire(this.compressorGroups.filter((e,n)=>n!==t))}}
          ></rs-confirm-button>
        </div>
      </div>
    `}_renderMember(e,t){let n=this.hass.states[e],r=!n,i=n?.attributes?.friendly_name||e,a=this.hass.entities[e]?.area_id,o=a?this.hass.areas[a]?.name:void 0;return m`
      <div class="member-row">
        <span class="member-name ${r?`member-missing`:``}"
          >${i}${o?m`<span class="member-area">(${o})</span>`:h}</span
        >
        <ha-icon-button
          .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
          @click=${()=>{let n=[...this.compressorGroups];n[t]={...n[t],members:n[t].members.filter(t=>t!==e)},this._fire(n)}}
        ></ha-icon-button>
      </div>
    `}_updateGroup(e,t,n){let r=[...this.compressorGroups];r[e]={...r[e],[t]:n},this._fire(r)}_addGroup(){this._fire([...this.compressorGroups,{id:self.crypto?.randomUUID?.()??`${Date.now()}-${Math.random().toString(36).slice(2)}`,name:``,members:[],min_run_minutes:15,min_off_minutes:5,master_entity:``,conflict_resolution:`heating_priority`,action_script:``,enforce_uniform_mode:!1}])}_fire(e){this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:`compressorGroups`,value:e},bubbles:!0,composed:!0}))}};k([y({attribute:!1})],An.prototype,`hass`,void 0),k([y({type:Array})],An.prototype,`compressorGroups`,void 0),An=k([v(`rs-settings-compressor`)],An),_(),x(),A();var jn=class extends q{constructor(...e){super(...e),this.moldDetectionEnabled=!1,this.moldHumidityThreshold=70,this.moldSustainedMinutes=30,this.moldPreventionEnabled=!1,this.moldPreventionSustainedMinutes=60,this.moldPreventionDehumidificationEnabled=!0,this.moldPreventionDryMinTemperature=22}render(){let e=this.hass.language,t=O(15,30,this.hass);return m`
      <!-- Detection section -->
      <div class="settings-section first">
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">
              <ha-icon
                icon="mdi:bell-alert"
                style="--mdc-icon-size: 18px; vertical-align: middle; margin-right: 4px"
              ></ha-icon>
              ${S(`mold.detection`,e)}
            </span>
            <span class="toggle-hint">${S(`mold.detection_desc`,e)}</span>
          </div>
          <ha-switch
            .checked=${this.moldDetectionEnabled}
            @change=${e=>this._fire(`moldDetectionEnabled`,e.target.checked)}
          ></ha-switch>
        </div>
        ${this.moldDetectionEnabled?m`
              <div class="threshold-grid" style="margin-top: 12px">
                <div class="threshold-field">
                  <ha-textfield
                    .value=${String(this.moldHumidityThreshold)}
                    .label=${S(`mold.threshold`,e)}
                    .suffix=${`%`}
                    type="number"
                    step="1"
                    min="50"
                    max="90"
                    @change=${e=>{let t=parseFloat(e.target.value);!isNaN(t)&&t>=50&&t<=90&&this._fire(`moldHumidityThreshold`,t)}}
                  ></ha-textfield>
                  <span class="field-hint">${S(`mold.threshold_hint`,e)}</span>
                </div>
                <div class="threshold-field">
                  <ha-textfield
                    .value=${String(this.moldSustainedMinutes)}
                    .label=${S(`mold.sustained`,e)}
                    .suffix=${`min`}
                    type="number"
                    step="5"
                    min="5"
                    max="120"
                    @change=${e=>{let t=parseInt(e.target.value,10);!isNaN(t)&&t>=5&&t<=120&&this._fire(`moldSustainedMinutes`,t)}}
                  ></ha-textfield>
                  <span class="field-hint">${S(`mold.sustained_hint`,e)}</span>
                </div>
              </div>
            `:h}
      </div>

      <!-- Prevention section -->
      <div class="settings-section">
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">
              <ha-icon
                icon="mdi:shield-check"
                style="--mdc-icon-size: 18px; vertical-align: middle; margin-right: 4px"
              ></ha-icon>
              ${S(`mold.prevention`,e)}
            </span>
            <span class="toggle-hint">${S(`mold.prevention_desc`,e)}</span>
          </div>
          <ha-switch
            .checked=${this.moldPreventionEnabled}
            @change=${e=>this._fire(`moldPreventionEnabled`,e.target.checked)}
          ></ha-switch>
        </div>
        ${this.moldPreventionEnabled?m`
              <div class="threshold-field" style="margin-top: 12px; margin-bottom: 12px;">
                <ha-textfield
                  .value=${String(this.moldPreventionSustainedMinutes)}
                  .label=${S(`mold.prevention_sustained`,e)}
                  .suffix=${`min`}
                  type="number"
                  step="1"
                  min="0"
                  max="120"
                  @change=${e=>{let t=parseInt(e.target.value,10);!isNaN(t)&&t>=0&&t<=120&&this._fire(`moldPreventionSustainedMinutes`,t)}}
                ></ha-textfield>
                <span class="field-hint">${S(`mold.prevention_sustained_hint`,e)}</span>
              </div>
              <div class="settings-section" style="margin-top: 16px">
                <div class="toggle-row">
                  <div class="toggle-text">
                    <span class="toggle-label">${S(`mold.dehumidification`,e)}</span>
                    <span class="toggle-hint">${S(`mold.dehumidification_desc`,e)}</span>
                  </div>
                  <ha-switch
                    .checked=${this.moldPreventionDehumidificationEnabled}
                    @change=${e=>this._fire(`moldPreventionDehumidificationEnabled`,e.target.checked)}
                  ></ha-switch>
                </div>
                ${this.moldPreventionDehumidificationEnabled?m`
                      <div class="threshold-field" style="margin-top: 12px">
                        <ha-textfield
                          .value=${String(w(this.moldPreventionDryMinTemperature,this.hass))}
                          .label=${S(`mold.dehumidification_min_temperature`,e)}
                          .suffix=${C(this.hass)}
                          type="number"
                          step=${D(this.hass)}
                          min=${t.min}
                          max=${t.max}
                          @change=${e=>{let t=T(parseFloat(e.target.value),this.hass);!isNaN(t)&&t>=15&&t<=30&&this._fire(`moldPreventionDryMinTemperature`,t)}}
                        ></ha-textfield>
                        <span class="field-hint"
                          >${S(`mold.dehumidification_min_temperature_hint`,e)}</span
                        >
                      </div>
                    `:h}
              </div>
            `:h}
      </div>
    `}static{this.styles=[q.settingsBaseStyles]}};k([y({attribute:!1})],jn.prototype,`hass`,void 0),k([y({type:Boolean})],jn.prototype,`moldDetectionEnabled`,void 0),k([y({type:Number})],jn.prototype,`moldHumidityThreshold`,void 0),k([y({type:Number})],jn.prototype,`moldSustainedMinutes`,void 0),k([y({type:Boolean})],jn.prototype,`moldPreventionEnabled`,void 0),k([y({type:Number})],jn.prototype,`moldPreventionSustainedMinutes`,void 0),k([y({type:Boolean})],jn.prototype,`moldPreventionDehumidificationEnabled`,void 0),k([y({type:Number})],jn.prototype,`moldPreventionDryMinTemperature`,void 0),jn=k([v(`rs-settings-mold`)],jn),_(),x(),A();var Mn=class extends q{constructor(...e){super(...e),this.notificationsEnabled=!0,this.notificationTargets=[],this.notificationCooldown=60,this.moldPreventionEnabled=!1,this.moldPreventionNotify=!1,this.windowOpenNotificationMinutes=0}render(){let e=this.hass.language;return m`
      <div class="toggle-row">
        <div class="toggle-text">
          <span class="toggle-label">${S(`notifications.enabled`,e)}</span>
          <span class="toggle-hint">${S(`notifications.enabled_hint`,e)}</span>
        </div>
        <ha-switch
          .checked=${this.notificationsEnabled}
          @change=${e=>this._fire(`moldNotificationsEnabled`,e.target.checked)}
        ></ha-switch>
      </div>

      ${this.notificationsEnabled?m`
            <div class="detail-section">
              <p class="hint">${S(`notifications.desc`,e)}</p>

              <div class="target-list">
                ${this.notificationTargets.map((t,n)=>{let r=t.entity_id?this.hass.states[t.entity_id]?.attributes?.friendly_name??t.entity_id.replace(`notify.`,``):S(`notifications.target_unnamed`,e);return m`
                    <div class="target-card">
                      <div class="target-header">
                        <ha-icon
                          icon="mdi:bell"
                          style="--mdc-icon-size: 18px; color: var(--secondary-text-color)"
                        ></ha-icon>
                        <span>${r}</span>
                        <ha-icon-button
                          .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
                          @click=${()=>{this._fire(`moldNotificationTargets`,this.notificationTargets.filter((e,t)=>t!==n))}}
                        ></ha-icon-button>
                      </div>
                      <div class="target-detail">
                        <ha-entity-picker
                          .hass=${this.hass}
                          .value=${t.person_entity}
                          .includeDomains=${[`person`]}
                          .label=${S(`notifications.target_person`,e)}
                          allow-custom-entity
                          @value-changed=${e=>{let t=[...this.notificationTargets];t[n]={...t[n],person_entity:e.detail?.value??``},this._fire(`moldNotificationTargets`,t)}}
                        ></ha-entity-picker>
                        <ha-select
                          .value=${t.notify_when}
                          .options=${[{value:`always`,label:S(`notifications.target_when_always`,e)},{value:`home_only`,label:S(`notifications.target_when_home`,e)}]}
                          fixedMenuPosition
                          @selected=${e=>{let t=P(e);if(!t)return;let r=[...this.notificationTargets];r[n]={...r[n],notify_when:t},this._fire(`moldNotificationTargets`,r)}}
                          @closed=${e=>e.stopPropagation()}
                        >
                          <ha-list-item value="always"
                            >${S(`notifications.target_when_always`,e)}</ha-list-item
                          >
                          <ha-list-item value="home_only"
                            >${S(`notifications.target_when_home`,e)}</ha-list-item
                          >
                        </ha-select>
                      </div>
                    </div>
                  `})}
              </div>

              <div style="margin-top: 8px">
                <ha-entity-picker
                  .hass=${this.hass}
                  .value=${``}
                  .includeDomains=${[`notify`]}
                  .label=${S(`notifications.add_target_label`,e)}
                  allow-custom-entity
                  @value-changed=${e=>{let t=e.detail?.value??``;if(!t)return;this._fire(`moldNotificationTargets`,[...this.notificationTargets,{entity_id:t,person_entity:``,notify_when:`always`}]);let n=e.target;n&&(n.value=``)}}
                ></ha-entity-picker>
                <span class="field-hint">${S(`notifications.add_target_hint`,e)}</span>
              </div>

              <div class="threshold-grid" style="margin-top: 12px">
                <div class="threshold-field">
                  <ha-textfield
                    .value=${String(this.notificationCooldown)}
                    .label=${S(`notifications.cooldown`,e)}
                    .suffix=${`min`}
                    type="number"
                    step="5"
                    min="10"
                    max="1440"
                    @change=${e=>{let t=parseInt(e.target.value,10);!isNaN(t)&&t>=10&&t<=1440&&this._fire(`moldNotificationCooldown`,t)}}
                  ></ha-textfield>
                  <span class="field-hint">${S(`notifications.cooldown_hint`,e)}</span>
                </div>
                <div class="threshold-field">
                  <ha-textfield
                    .value=${String(this.windowOpenNotificationMinutes)}
                    .label=${S(`notifications.window_open_after`,e)}
                    .suffix=${`min`}
                    type="number"
                    step="5"
                    min="0"
                    max="1440"
                    @change=${e=>{let t=parseInt(e.target.value,10);!isNaN(t)&&t>=0&&t<=1440&&this._fire(`windowOpenNotificationMinutes`,t)}}
                  ></ha-textfield>
                  <span class="field-hint"
                    >${S(`notifications.window_open_after_hint`,e)}</span
                  >
                </div>
              </div>

              ${this.moldPreventionEnabled?m`
                    <div class="toggle-row" style="margin-top: 12px">
                      <div class="toggle-text">
                        <span class="toggle-label"
                          >${S(`notifications.mold_prevention_notify`,e)}</span
                        >
                        <span class="toggle-hint"
                          >${S(`notifications.mold_prevention_notify_hint`,e)}</span
                        >
                      </div>
                      <ha-switch
                        .checked=${this.moldPreventionNotify}
                        @change=${e=>this._fire(`moldPreventionNotify`,e.target.checked)}
                      ></ha-switch>
                    </div>
                  `:h}
            </div>
          `:h}
    `}static{this.styles=[q.settingsBaseStyles,l`
      .hint {
        color: var(--secondary-text-color);
        font-size: 13px;
        margin: 12px 0;
        line-height: 1.4;
      }
      .detail-section {
        margin-top: 4px;
      }
      .field-hint {
        color: var(--secondary-text-color);
        font-size: 12px;
      }

      .target-list {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .target-card {
        display: flex;
        flex-direction: column;
        gap: 4px;
        padding: 8px 8px 8px 12px;
        border-radius: 8px;
        background: rgba(0, 0, 0, 0.04);
      }
      .target-header {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .target-header span {
        flex: 1;
        font-size: 14px;
        font-weight: 500;
      }
      .target-detail {
        display: flex;
        gap: 8px;
        align-items: center;
        padding-left: 26px;
      }
      .target-detail ha-entity-picker {
        flex: 1;
      }
      .target-detail ha-select {
        min-width: 120px;
      }

      @media (max-width: 600px) {
        .target-detail {
          flex-direction: column;
          padding-left: 0;
        }
      }
    `]}};k([y({attribute:!1})],Mn.prototype,`hass`,void 0),k([y({type:Boolean})],Mn.prototype,`notificationsEnabled`,void 0),k([y({type:Array})],Mn.prototype,`notificationTargets`,void 0),k([y({type:Number})],Mn.prototype,`notificationCooldown`,void 0),k([y({type:Boolean})],Mn.prototype,`moldPreventionEnabled`,void 0),k([y({type:Boolean})],Mn.prototype,`moldPreventionNotify`,void 0),k([y({type:Number})],Mn.prototype,`windowOpenNotificationMinutes`,void 0),Mn=k([v(`rs-settings-notifications`)],Mn),_(),x(),A();var Nn=250,Pn=class extends q{constructor(...e){super(...e),this.rooms={},this.learningDisabledRooms=[],this.boostAppliedAt={},this.roomsLive={},this._showLearningExceptions=!1,this._boostSelectedRoom=``}render(){let e=this.hass.language,t=Object.entries(this.rooms).map(([e])=>({areaId:e,name:this.hass.areas?.[e]?.name??e})).sort((e,t)=>e.name.localeCompare(t.name)),n=Object.keys(this.rooms),r=n.length===0||this.learningDisabledRooms.length<n.length,i=this.learningDisabledRooms.filter(e=>n.includes(e)).length;return m`
      <!-- Learning toggle -->
      <div class="settings-section first">
        <div class="toggle-row">
          <div class="toggle-text">
            <span class="toggle-label">${S(`settings.learning_title`,e)}</span>
            <span class="toggle-hint">${S(`settings.learning_hint`,e)}</span>
          </div>
          <ha-switch
            .checked=${r}
            @change=${e=>{let t=e.target.checked;this._fire(`learningDisabledRooms`,t?[]:Object.keys(this.rooms)),t||(this._showLearningExceptions=!1)}}
          ></ha-switch>
        </div>
        ${r&&t.length>0?m`
              <button
                class="exceptions-link"
                @click=${()=>{this._showLearningExceptions=!this._showLearningExceptions}}
              >
                <span
                  >${i>0?`${i} ${S(i===1?`settings.learning_room_paused`:`settings.learning_rooms_paused`,e)}`:S(`settings.learning_exceptions`,e)}</span
                >
                <ha-icon
                  icon=${this._showLearningExceptions?`mdi:chevron-up`:`mdi:chevron-down`}
                  style="--mdc-icon-size: 16px"
                ></ha-icon>
              </button>
              ${this._showLearningExceptions?m`
                    <div class="room-toggles">
                      ${t.map(e=>m`
                          <div class="room-toggle-row">
                            <span class="room-toggle-name">${e.name}</span>
                            <ha-switch
                              .checked=${!this.learningDisabledRooms.includes(e.areaId)}
                              @change=${t=>{let n=!t.target.checked,r=new Set(this.learningDisabledRooms);n?r.add(e.areaId):r.delete(e.areaId),this._fire(`learningDisabledRooms`,[...r])}}
                            ></ha-switch>
                          </div>
                        `)}
                    </div>
                  `:h}
            `:h}
      </div>

      <!-- Boost learning -->
      <div class="settings-section">
        <span class="toggle-label">${S(`settings.boost_title`,e)}</span>
        <p class="hint">${S(`settings.boost_hint`,e)}</p>

        ${t.length>0?m`
              <div class="room-select-row">
                <ha-select
                  .value=${this._boostSelectedRoom}
                  .label=${S(`settings.boost_room_select`,e)}
                  .options=${t.map(e=>({value:e.areaId,label:e.name}))}
                  fixedMenuPosition
                  @selected=${e=>{this._boostSelectedRoom=P(e)}}
                  @closed=${e=>e.stopPropagation()}
                >
                  ${t.map(e=>m`<ha-list-item value=${e.areaId}>${e.name}</ha-list-item>`)}
                </ha-select>
                ${this._boostSelectedRoom?m`<ha-icon-button
                      .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
                      @click=${()=>{this._boostSelectedRoom=``}}
                    ></ha-icon-button>`:h}
                ${this._boostSelectedRoom&&this._isCooldown(this._boostSelectedRoom)?m`<span class="boost-status">
                      <ha-icon icon="mdi:check-circle-outline"></ha-icon>
                      ${S(`settings.boost_cooldown`,e)}
                    </span>`:m`<button
                      class="boost-btn"
                      ?disabled=${!this._boostSelectedRoom||this._isCooldown(this._boostSelectedRoom)}
                      @click=${()=>this._boostSelectedRoom&&this._boostLearning(this._boostSelectedRoom)}
                    >
                      <ha-icon icon="mdi:lightning-bolt"></ha-icon>
                      ${S(`settings.boost_btn`,e)}
                    </button>`}
              </div>
            `:m`<p class="hint">${S(`settings.boost_no_rooms`,e)}</p>`}
      </div>
    `}_isCooldown(e){let t=this.roomsLive?.[e]?.n_observations??0,n=this.boostAppliedAt[e];return n!==void 0&&t-n<Nn}async _boostLearning(e){try{F(this,`saving`);let t=await this.hass.callWS({type:`roommind/model/boost_learning`,area_id:e});F(this,`saved`),this.dispatchEvent(new CustomEvent(`boost-applied`,{detail:{area_id:e,n_observations:t.n_observations},bubbles:!0,composed:!0}))}catch{F(this,`error`)}}static{this.styles=[q.settingsBaseStyles,l`
      .hint {
        color: var(--secondary-text-color);
        font-size: 13px;
        margin: 4px 0 12px;
        line-height: 1.4;
      }

      .exceptions-link {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        background: none;
        border: none;
        padding: 8px 0 0;
        margin: 0;
        cursor: pointer;
        font-size: 13px;
        color: var(--primary-color);
        font-family: inherit;
      }
      .exceptions-link:hover {
        text-decoration: underline;
      }

      .room-toggles {
        display: flex;
        flex-direction: column;
        gap: 4px;
        margin-top: 12px;
      }
      .room-toggle-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 4px 0;
      }
      .room-toggle-name {
        font-size: 14px;
        color: var(--primary-text-color);
      }

      .room-select-row {
        display: flex;
        align-items: center;
        gap: 12px;
      }
      .room-select-row ha-select {
        flex: 1;
      }

      .boost-btn {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 14px;
        border: 1px solid var(--primary-color);
        border-radius: 8px;
        background: transparent;
        color: var(--primary-color);
        font-size: 13px;
        font-family: inherit;
        cursor: pointer;
        transition: background 0.15s;
        --mdc-icon-size: 16px;
        white-space: nowrap;
      }
      .boost-btn:hover {
        background: rgba(var(--rgb-primary-color), 0.08);
      }
      .boost-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
      }
      .boost-btn:disabled:hover {
        background: transparent;
      }

      .boost-status {
        display: flex;
        align-items: center;
        gap: 6px;
        color: var(--success-color, #4caf50);
        font-size: 13px;
        --mdc-icon-size: 16px;
        white-space: nowrap;
      }
    `]}};k([y({attribute:!1})],Pn.prototype,`hass`,void 0),k([y({attribute:!1})],Pn.prototype,`rooms`,void 0),k([y({type:Array})],Pn.prototype,`learningDisabledRooms`,void 0),k([y({attribute:!1})],Pn.prototype,`boostAppliedAt`,void 0),k([y({attribute:!1})],Pn.prototype,`roomsLive`,void 0),k([b()],Pn.prototype,`_showLearningExceptions`,void 0),k([b()],Pn.prototype,`_boostSelectedRoom`,void 0),Pn=k([v(`rs-settings-learning`)],Pn),_(),x(),A();var Fn=class extends q{constructor(...e){super(...e),this.rooms={},this._resetSelectedRoom=``}render(){let e=this.hass.language,t=Object.entries(this.rooms).map(([e])=>({areaId:e,name:this.hass.areas?.[e]?.name??e})).sort((e,t)=>e.name.localeCompare(t.name));return m`
      <div class="settings-section first">
        <div class="reset-row">
          <div class="reset-text">
            <span class="toggle-label">${S(`settings.reset_all_label`,e)}</span>
            <span class="toggle-hint">${S(`settings.reset_all_hint`,e)}</span>
          </div>
          <button class="reset-btn" @click=${this._resetAllModels}>
            <ha-icon icon="mdi:restart-alert"></ha-icon>
            ${S(`settings.reset_all_btn`,e)}
          </button>
        </div>
      </div>

      <div class="settings-section">
        <div class="reset-text" style="margin-bottom: 12px">
          <span class="toggle-label">${S(`settings.reset_room_label`,e)}</span>
          <span class="toggle-hint">${S(`settings.reset_room_hint`,e)}</span>
        </div>
        ${t.length>0?m`
              <div class="reset-room-row">
                <ha-select
                  .value=${this._resetSelectedRoom}
                  .label=${S(`settings.reset_room_select`,e)}
                  .options=${t.map(e=>({value:e.areaId,label:e.name}))}
                  fixedMenuPosition
                  @selected=${e=>{this._resetSelectedRoom=P(e)}}
                  @closed=${e=>e.stopPropagation()}
                >
                  ${t.map(e=>m`<ha-list-item value=${e.areaId}>${e.name}</ha-list-item>`)}
                </ha-select>
                ${this._resetSelectedRoom?m`<ha-icon-button
                      .path=${`M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z`}
                      @click=${()=>{this._resetSelectedRoom=``}}
                    ></ha-icon-button>`:h}
                <button
                  class="reset-btn"
                  ?disabled=${!this._resetSelectedRoom}
                  @click=${()=>this._resetSelectedRoom&&this._resetRoomModel(this._resetSelectedRoom)}
                >
                  <ha-icon icon="mdi:restart"></ha-icon>
                  ${S(`settings.reset_btn`,e)}
                </button>
              </div>
            `:m`<p class="hint">${S(`settings.reset_no_rooms`,e)}</p>`}
      </div>
    `}async _resetRoomModel(e){let t=this.hass.language;if(confirm(S(`settings.reset_room_confirm`,t)))try{F(this,`saving`),await this.hass.callWS({type:`roommind/thermal/reset`,area_id:e}),F(this,`saved`)}catch{F(this,`error`)}}async _resetAllModels(){let e=this.hass.language;if(confirm(S(`settings.reset_all_confirm`,e)))try{F(this,`saving`),await this.hass.callWS({type:`roommind/thermal/reset_all`}),F(this,`saved`)}catch{F(this,`error`)}}static{this.styles=[q.settingsBaseStyles,l`
      .hint {
        color: var(--secondary-text-color);
        font-size: 13px;
        margin: 0;
      }

      .reset-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
      }
      .reset-text {
        display: flex;
        flex-direction: column;
        gap: 4px;
        flex: 1;
      }

      .reset-btn {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 14px;
        border: 1px solid var(--error-color, #d32f2f);
        border-radius: 8px;
        background: transparent;
        color: var(--error-color, #d32f2f);
        font-size: 13px;
        font-family: inherit;
        cursor: pointer;
        transition: background 0.15s;
        --mdc-icon-size: 16px;
        white-space: nowrap;
      }
      .reset-btn:hover {
        background: rgba(211, 47, 47, 0.08);
      }
      .reset-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
      }
      .reset-btn:disabled:hover {
        background: transparent;
      }

      .reset-room-row {
        display: flex;
        align-items: center;
        gap: 12px;
      }
      .reset-room-row ha-select {
        flex: 1;
      }

      @media (max-width: 600px) {
        .reset-row {
          flex-direction: column;
          align-items: flex-start;
          gap: 12px;
        }
      }
    `]}};k([y({attribute:!1})],Fn.prototype,`hass`,void 0),k([y({attribute:!1})],Fn.prototype,`rooms`,void 0),k([b()],Fn.prototype,`_resetSelectedRoom`,void 0),Fn=k([v(`rs-settings-reset`)],Fn),_(),x(),A();var In={entity:{multiple:!0,filter:[{domain:`climate`}]}},J=class extends g{constructor(...e){super(...e),this.boilerEntity=``,this.boilerControlType=`climate`,this.bypassEntities=[],this.startupDelay=30,this.shutdownDelay=60,this.bypassTemperature=28,this.bypassChildLock=!0,this.minDemandRooms=1,this.demandUnit=`valves`,this.minRunMinutes=5,this.minOffMinutes=3,this.faultRetryMinutes=5,this.maxWaitMinutes=120,this.budgetEnabled=!1,this.powerSensor=``,this.powerMode=`available`,this.maxPower=3300,this.reserve=200,this.energyPricePerKwh=0,this._powerModeState={value:`available`,hasLocalChange:!1}}willUpdate(e){e.has(`powerMode`)&&(this._powerModeState=_n(this._powerModeState,this.powerMode))}render(){let e=(e,t)=>this.dispatchEvent(new CustomEvent(`setting-changed`,{detail:{key:e,value:t},bubbles:!0,composed:!0})),t=(t,n)=>m`<ha-textfield
        type="number"
        .value=${String(n)}
        @change=${n=>e(t,Number(n.target.value))}
      ></ha-textfield>`,n=e=>{let t=e.detail,n=e.target,r=e.currentTarget;if(typeof t==`string`||Array.isArray(t))return t;if(t&&typeof t==`object`){let e=t;return e.value??e.values??e.selected}return n?.value??n?.values??n?.selected??r?.value??r?.values};return m`<div class="section">
        <b>Central boiler</b>
        <ha-entity-picker
          .hass=${this.hass}
          .includeDomains=${[`climate`,`switch`]}
          .value=${this.boilerEntity}
          label="Boiler control entity"
          @value-changed=${t=>e(`boilerEntity`,t.detail.value||``)}
        ></ha-entity-picker>
        ${this.boilerEntity?m`<ha-select
                .value=${this.boilerControlType}
                label="Control type"
                @selected=${t=>e(`boilerControlType`,t.detail.value)}
                ><ha-list-item value="climate">Climate</ha-list-item
                ><ha-list-item value="switch">Switch</ha-list-item></ha-select
              >
              <div class="grid">
                <label>Startup delay ${t(`startupDelay`,this.startupDelay)}</label
                ><label>Shutdown hold ${t(`shutdownDelay`,this.shutdownDelay)}</label>
              </div>
              <ha-selector
                .hass=${this.hass}
                .selector=${In}
                .value=${this.bypassEntities}
                .label=${`Hydraulic bypass TRVs (required for gas boiler safety)`}
                @value-changed=${t=>{let r=n(t);console.debug(`RoomMind hydraulic bypass picker event`,{type:t.type,detail:t.detail,targetValue:t.target?.value,currentTargetValue:t.currentTarget?.value,value:r}),e(`bypassEntities`,mn(r))}}
              ></ha-selector>
              <small
                >RoomMind opens and verifies at least one bypass valve before starting the boiler,
                and keeps it open while the boiler runs.</small
              >
              <label
                >Forced bypass temperature
                ${t(`bypassTemperature`,this.bypassTemperature)}</label
              >
              <div class="toggle">
                <span
                  ><b>${S(`settings.boiler.child_lock`,this.hass.language)}</b
                  ><small
                    >${S(`settings.boiler.child_lock_hint`,this.hass.language)}</small
                  ></span
                ><ha-switch
                  .checked=${this.bypassChildLock}
                  @change=${t=>e(`bypassChildLock`,t.target.checked)}
                ></ha-switch>
              </div>
              <ha-select
                .value=${this.demandUnit}
                .label=${S(`settings.boiler.demand_unit`,this.hass.language)}
                @selected=${t=>{let n=P(t);(n===`valves`||n===`rooms`)&&e(`demandUnit`,n)}}
                ><ha-list-item value="valves"
                  >${S(`settings.boiler.demand_unit_valves`,this.hass.language)}</ha-list-item
                ><ha-list-item value="rooms"
                  >${S(`settings.boiler.demand_unit_rooms`,this.hass.language)}</ha-list-item
                ></ha-select
              >
              <label
                >${S(`settings.boiler.min_demand_rooms`,this.hass.language)}
                ${t(`minDemandRooms`,this.minDemandRooms)}</label
              >
              <small>${S(`settings.boiler.min_demand_hint`,this.hass.language)}</small>
              <label
                >${S(`settings.boiler.max_wait_minutes`,this.hass.language)}
                ${t(`maxWaitMinutes`,this.maxWaitMinutes)}</label
              >
              <small>${S(`settings.boiler.max_wait_hint`,this.hass.language)}</small>
              <div class="grid">
                <label
                  >${S(`settings.boiler.min_run_minutes`,this.hass.language)}
                  ${t(`minRunMinutes`,this.minRunMinutes)}</label
                ><label
                  >${S(`settings.boiler.min_off_minutes`,this.hass.language)}
                  ${t(`minOffMinutes`,this.minOffMinutes)}</label
                >
              </div>
              <label
                >${S(`settings.boiler.fault_retry_minutes`,this.hass.language)}
                ${t(`faultRetryMinutes`,this.faultRetryMinutes)}</label
              >`:h}
      </div>
      <div class="section">
        <b>${S(`settings.energy_price`,this.hass.language)}</b>
        <label
          >${S(`settings.energy_price_hint`,this.hass.language)}
          ${t(`energyPricePerKwh`,this.energyPricePerKwh)}</label
        >
      </div>
      <div class="section">
        <div class="toggle">
          <span
            ><b>Electrical power budget</b
            ><small
              >Allocate heat-pump starts centrally; a missing sensor falls back to boiler.</small
            ></span
          ><ha-switch
            .checked=${this.budgetEnabled}
            @change=${t=>e(`budgetEnabled`,t.target.checked)}
          ></ha-switch>
        </div>
        ${this.budgetEnabled?m`<ha-entity-picker
                .hass=${this.hass}
                .includeDomains=${[`sensor`]}
                .value=${this.powerSensor}
                label="Available power / consumption sensor"
                @value-changed=${t=>e(`powerSensor`,t.detail.value||``)}
              ></ha-entity-picker
              ><ha-select
                .value=${this._powerModeState.value}
                .options=${[{value:`available`,label:`Available power`},{value:`consumption`,label:`House consumption`}]}
                label="Sensor reports"
                @selected=${t=>{let n=P(t);console.debug(`RoomMind power sensor mode selected`,{type:t.type,detail:t.detail,targetValue:t.target?.value,currentTargetValue:t.currentTarget?.value,value:n}),this._powerModeState=gn(n),e(`powerMode`,this._powerModeState.value)}}
              ></ha-select>
              <div class="grid">
                <label>Maximum house load (W) ${t(`maxPower`,this.maxPower)}</label
                ><label>Safety reserve (W) ${t(`reserve`,this.reserve)}</label>
              </div>`:h}
      </div>`}static{this.styles=l`
    .section {
      display: grid;
      gap: 12px;
    }
    .section + .section {
      border-top: 1px solid var(--divider-color);
      margin-top: 18px;
      padding-top: 18px;
    }
    .grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }
    .grid label,
    label {
      display: grid;
      gap: 4px;
      font-size: 13px;
    }
    .toggle {
      display: flex;
      justify-content: space-between;
      gap: 16px;
    }
    .toggle small {
      display: block;
      color: var(--secondary-text-color);
      margin-top: 4px;
    }
  `}};k([y({attribute:!1})],J.prototype,`hass`,void 0),k([y({type:String})],J.prototype,`boilerEntity`,void 0),k([y({type:String})],J.prototype,`boilerControlType`,void 0),k([y({type:Array})],J.prototype,`bypassEntities`,void 0),k([y({type:Number})],J.prototype,`startupDelay`,void 0),k([y({type:Number})],J.prototype,`shutdownDelay`,void 0),k([y({type:Number})],J.prototype,`bypassTemperature`,void 0),k([y({type:Boolean})],J.prototype,`bypassChildLock`,void 0),k([y({type:Number})],J.prototype,`minDemandRooms`,void 0),k([y({type:String})],J.prototype,`demandUnit`,void 0),k([y({type:Number})],J.prototype,`minRunMinutes`,void 0),k([y({type:Number})],J.prototype,`minOffMinutes`,void 0),k([y({type:Number})],J.prototype,`faultRetryMinutes`,void 0),k([y({type:Number})],J.prototype,`maxWaitMinutes`,void 0),k([y({type:Boolean})],J.prototype,`budgetEnabled`,void 0),k([y({type:String})],J.prototype,`powerSensor`,void 0),k([y({type:String})],J.prototype,`powerMode`,void 0),k([y({type:Number})],J.prototype,`maxPower`,void 0),k([y({type:Number})],J.prototype,`reserve`,void 0),k([y({type:Number})],J.prototype,`energyPricePerKwh`,void 0),k([b()],J.prototype,`_powerModeState`,void 0),J=k([v(`rs-settings-heating-system`)],J),_(),x(),A();var Ln=class extends g{constructor(...e){super(...e),this._mode=`cooling`,this._loading=!1,this._error=!1}static{this.styles=l`
    :host {
      display: block;
      font-size: 13px;
    }
    .controls {
      display: flex;
      align-items: center;
      gap: 12px;
      flex-wrap: wrap;
    }
    select,
    button {
      padding: 8px 12px;
      border-radius: 9px;
      background: var(--card-background-color);
      color: var(--primary-text-color);
      border: 1px solid var(--divider-color);
    }
    button {
      cursor: pointer;
    }
    button:disabled {
      opacity: 0.6;
      cursor: default;
    }
    .summary {
      margin: 12px 0;
      color: var(--secondary-text-color);
      line-height: 1.6;
    }
    .room {
      padding: 10px 0;
      border-top: 1px solid var(--divider-color);
      display: grid;
      gap: 3px;
    }
    .room strong {
      color: var(--primary-text-color);
    }
    .reason {
      color: var(--secondary-text-color);
    }
  `}async _refresh(){this._loading=!0,this._error=!1;try{this._result=await this.hass.callWS({type:`roommind/control/preview`,mode:this._mode})}catch{this._error=!0}finally{this._loading=!1}}render(){let e=this.hass.language,t=this._result;return m`
      <div class="controls">
        <select
          aria-label=${S(`preview.mode`,e)}
          .value=${this._mode}
          @change=${e=>{this._mode=e.target.value,this._result=void 0}}
        >
          <option value="heating">${S(`heat_source.budget_heating`,e)}</option>
          <option value="cooling">${S(`heat_source.budget_cooling`,e)}</option>
          <option value="dry">${S(`heat_source.budget_dry`,e)}</option>
        </select>
        <button ?disabled=${this._loading} @click=${()=>this._refresh()}>
          ${S(`preview.run`,e)}
        </button>
      </div>
      <div class="summary">${S(`preview.scope`,e)}</div>
      ${this._error?m`<div>${S(`preview.error`,e)}</div>`:h}
      ${t?m`
            <div class="summary">
              ${S(`preview.headroom`,e)}:
              ${t.house_available_watts===null?`—`:`${Math.round(t.house_available_watts)} W`}
              · ${S(`preview.meter`,e)}:
              ${t.power_sensor_healthy?S(`preview.healthy`,e):S(`preview.unavailable`,e)}
              ${t.power_sensor_age_seconds===null?h:`(${Math.round(t.power_sensor_age_seconds)} s)`}
              · ${S(`preview.boiler`,e)}: ${t.boiler_state} ·
              ${S(`preview.bypass`,e)}:
              ${t.bypass_acknowledged?S(`preview.acknowledged`,e):S(`preview.not_acknowledged`,e)}
            </div>
            ${Object.entries(t.rooms).map(([t,n])=>m`
                <div class="room">
                  <strong>${t.replaceAll(`_`,` `)}</strong>
                  <span
                    >${n.watts} W · ${S(`heat_source.budget_${n.source}`,e)}</span
                  >
                  <span class="reason">${S(`preview.reason_${n.reason}`,e)}</span>
                  ${n.current_decision_reasons.length?m`<span class="reason"
                        >${S(`preview.current_reasons`,e)}:
                        ${n.current_decision_reasons.join(`, `)}</span
                      >`:h}
                </div>
              `)}
          `:h}
    `}};k([y({attribute:!1})],Ln.prototype,`hass`,void 0),k([b()],Ln.prototype,`_mode`,void 0),k([b()],Ln.prototype,`_result`,void 0),k([b()],Ln.prototype,`_loading`,void 0),k([b()],Ln.prototype,`_error`,void 0),Ln=k([v(`rs-settings-preview`)],Ln),_(),x(),A();var Y=class extends g{constructor(...e){super(...e),this.rooms={},this._groupByFloor=!1,this._climateControlActive=!0,this._temperatureRoundingMode=`nearest`,this._learningDisabledRooms=[],this._outdoorTempSensor=``,this._outdoorHumiditySensor=``,this._outdoorCoolingMin=16,this._outdoorHeatingMax=22,this._controlMode=`mpc`,this._comfortWeight=70,this._weatherEntity=``,this._outdoorUnavailableNotify=!0,this._predictionEnabled=!0,this._vacationActive=!1,this._vacationTemp=15,this._vacationUntil=``,this._presenceEnabled=!1,this._presencePersons=[],this._presenceAwayAction=`eco`,this._presenceClearsOverride=!1,this._scheduleOffAction=`eco`,this._valveProtectionEnabled=!1,this._valveProtectionInterval=7,this._moldDetectionEnabled=!1,this._moldHumidityThreshold=70,this._moldSustainedMinutes=30,this._moldNotificationCooldown=60,this._moldNotificationsEnabled=!0,this._moldNotificationTargets=[],this._moldPreventionEnabled=!1,this._moldPreventionSustainedMinutes=15,this._moldPreventionDehumidificationEnabled=!0,this._moldPreventionDryMinTemperature=23,this._moldPreventionNotify=!1,this._windowOpenNotificationMinutes=0,this._compressorGroups=[],this._boostAppliedAt={},this._boilerEntity=``,this._boilerControlType=`climate`,this._bypassEntities=[],this._startupDelay=30,this._shutdownDelay=60,this._bypassTemperature=28,this._bypassChildLock=!0,this._minDemandRooms=1,this._demandUnit=`valves`,this._minRunMinutes=5,this._minOffMinutes=3,this._faultRetryMinutes=5,this._maxWaitMinutes=120,this._budgetEnabled=!1,this._powerSensor=``,this._powerMode=`available`,this._powerModeDirty=!1,this._maxPower=3300,this._reserve=200,this._energyPricePerKwh=0,this._loaded=!1,this._category=`overview`}connectedCallback(){super.connectedCallback(),this._loadSettings()}disconnectedCallback(){super.disconnectedCallback(),this._saveDebounce&&clearTimeout(this._saveDebounce)}async _loadSettings(){try{let e=(await this.hass.callWS({type:`roommind/settings/get`})).settings;this._groupByFloor=e.group_by_floor??!1,this._climateControlActive=e.climate_control_active??!0,this._temperatureRoundingMode=e.temperature_rounding_mode??`nearest`,this._learningDisabledRooms=e.learning_disabled_rooms??[],this._outdoorTempSensor=e.outdoor_temp_sensor??``,this._outdoorHumiditySensor=e.outdoor_humidity_sensor??``,this._outdoorCoolingMin=e.outdoor_cooling_min??16,this._outdoorHeatingMax=e.outdoor_heating_max??22,this._controlMode=e.control_mode??`mpc`,this._comfortWeight=e.comfort_weight??70,this._weatherEntity=e.weather_entity??``,this._outdoorUnavailableNotify=e.outdoor_unavailable_notify??!0,this._predictionEnabled=e.prediction_enabled??!0;let t=e.vacation_until;this._vacationActive=!!(t&&t>Date.now()/1e3),this._vacationTemp=e.vacation_temp??15,this._vacationUntil=t&&t>Date.now()/1e3&&t<3250368e4?this._tsToDatetimeLocal(t):``,this._presenceEnabled=e.presence_enabled??!1,this._presencePersons=e.presence_persons??[],this._presenceAwayAction=e.presence_away_action??`eco`,this._presenceClearsOverride=e.presence_clears_override??!1,this._scheduleOffAction=e.schedule_off_action??`eco`,this._valveProtectionEnabled=e.valve_protection_enabled??!1,this._valveProtectionInterval=e.valve_protection_interval_days??7,this._moldDetectionEnabled=e.mold_detection_enabled??!1,this._moldHumidityThreshold=e.mold_humidity_threshold??70,this._moldSustainedMinutes=e.mold_sustained_minutes??30,this._moldNotificationCooldown=e.mold_notification_cooldown??60,this._moldNotificationsEnabled=e.mold_notifications_enabled??!0,this._moldNotificationTargets=e.mold_notification_targets??[],this._moldPreventionEnabled=e.mold_prevention_enabled??!1,this._moldPreventionSustainedMinutes=e.mold_prevention_sustained_minutes??60,this._moldPreventionDehumidificationEnabled=e.mold_prevention_dehumidification_enabled??!0,this._moldPreventionDryMinTemperature=e.mold_prevention_dry_min_temperature??22,this._moldPreventionNotify=e.mold_prevention_notify_enabled??!1,this._windowOpenNotificationMinutes=e.window_open_notification_minutes??0,this._compressorGroups=e.compressor_groups??[],this._boostAppliedAt=e.boost_applied_at??{},this._boilerEntity=e.boiler_entity??``,this._boilerControlType=e.boiler_control_type??`climate`,this._bypassEntities=mn(e.hydraulic_bypass_entities),this._startupDelay=e.boiler_startup_delay_seconds??30,this._shutdownDelay=e.boiler_shutdown_delay_seconds??60,this._bypassTemperature=e.hydraulic_bypass_open_temperature??28,this._bypassChildLock=e.hydraulic_bypass_child_lock??!0,this._minDemandRooms=e.boiler_min_demand_rooms??1,this._demandUnit=e.boiler_demand_unit??`valves`,this._minRunMinutes=e.boiler_min_run_minutes??5,this._minOffMinutes=e.boiler_min_off_minutes??3,this._faultRetryMinutes=e.boiler_fault_retry_minutes??5,this._maxWaitMinutes=e.boiler_max_wait_minutes??120,this._budgetEnabled=e.power_budget_enabled??!1,this._powerSensor=e.power_sensor??``,this._powerModeDirty||(this._powerMode=hn(e.power_sensor_mode)),this._maxPower=e.power_budget_max_watts??3300,this._reserve=e.power_budget_reserve_watts??200,this._energyPricePerKwh=e.energy_price_per_kwh??0}catch(e){console.debug(`[RoomMind] loadSettings:`,e)}finally{this._loaded=!0}}render(){if(!this._loaded)return m`<div class="loading">${S(`panel.loading`,this.hass.language)}</div>`;let e=this.hass.language;return m`
      <div class="settings-intro">
        <div class="eyebrow">ROOMMIND / ${S(`settings.hub.eyebrow`,e)}</div>
        <h1>${S(`settings.hub.title`,e)}</h1>
        <p>${S(`settings.hub.description`,e)}</p>
        <div class="control-status ${this._climateControlActive?`running`:`paused`}">
          <span class="status-dot"></span>
          ${this._climateControlActive?S(`settings.hub.running`,e):S(`settings.hub.paused`,e)}
        </div>
      </div>
      <div class="settings-workspace">
        <nav class="settings-navigation" aria-label=${S(`settings.hub.navigation`,e)}>
          ${[{id:`overview`,icon:`mdi:view-dashboard-outline`,count:4},{id:`system`,icon:`mdi:hvac`,count:4},{id:`protection`,icon:`mdi:shield-check-outline`,count:3},{id:`advanced`,icon:`mdi:tune-vertical`,count:2}].map(t=>m`
              <button
                class="category-button ${this._category===t.id?`selected`:``}"
                type="button"
                aria-current=${this._category===t.id?`page`:`false`}
                @click=${()=>{this._category=t.id}}
              >
                <ha-icon icon=${t.icon}></ha-icon>
                <span class="category-copy">
                  <strong>${S(`settings.hub.${t.id}`,e)}</strong>
                  <small>${S(`settings.hub.${t.id}_hint`,e)}</small>
                </span>
                <span class="category-count">${t.count}</span>
              </button>
            `)}
        </nav>
        <div class="settings-body">
          <div class="category-heading">
            <div class="eyebrow">${S(`settings.hub.category_label`,e)}</div>
            <h2>${S(`settings.hub.${this._category}`,e)}</h2>
            <p>${S(`settings.hub.${this._category}_hint`,e)}</p>
          </div>
          <rs-settings-panel
            ?hidden=${this._category!==`system`}
            icon="mdi:home-thermometer"
            .heading=${S(`settings.hub.heating`,e)}
            .intro=${S(`settings.hub.heating_hint`,e)}
            ><rs-settings-heating-system
              .hass=${this.hass}
              .boilerEntity=${this._boilerEntity}
              .boilerControlType=${this._boilerControlType}
              .bypassEntities=${this._bypassEntities}
              .startupDelay=${this._startupDelay}
              .shutdownDelay=${this._shutdownDelay}
              .bypassTemperature=${this._bypassTemperature}
              .bypassChildLock=${this._bypassChildLock}
              .minDemandRooms=${this._minDemandRooms}
              .demandUnit=${this._demandUnit}
              .minRunMinutes=${this._minRunMinutes}
              .minOffMinutes=${this._minOffMinutes}
              .faultRetryMinutes=${this._faultRetryMinutes}
              .maxWaitMinutes=${this._maxWaitMinutes}
              .budgetEnabled=${this._budgetEnabled}
              .powerSensor=${this._powerSensor}
              .powerMode=${this._powerMode}
              .maxPower=${this._maxPower}
              .reserve=${this._reserve}
              .energyPricePerKwh=${this._energyPricePerKwh}
              @setting-changed=${this._onSettingChanged}
            ></rs-settings-heating-system>
          </rs-settings-panel>

          <rs-settings-panel
            ?hidden=${this._category!==`protection`}
            icon="mdi:shield-search"
            .heading=${S(`preview.title`,e)}
            .intro=${S(`preview.intro`,e)}
          >
            <rs-settings-preview .hass=${this.hass}></rs-settings-preview>
          </rs-settings-panel>

          <rs-settings-panel
            ?hidden=${this._category!==`overview`}
            icon="mdi:power"
            .heading=${S(`settings.general_title`,e)}
            .intro=${S(`settings.intro.general`,e)}
          >
            <rs-settings-general
              .hass=${this.hass}
              .groupByFloor=${this._groupByFloor}
              .climateControlActive=${this._climateControlActive}
              .temperatureRoundingMode=${this._temperatureRoundingMode}
              @setting-changed=${this._onSettingChanged}
            ></rs-settings-general>
          </rs-settings-panel>

          <rs-settings-panel
            ?hidden=${this._category!==`system`}
            icon="mdi:thermometer"
            .heading=${S(`settings.sensors_title`,e)}
            .intro=${S(`settings.intro.sensors`,e)}
          >
            <rs-settings-sensors
              .hass=${this.hass}
              .outdoorTempSensor=${this._outdoorTempSensor}
              .outdoorHumiditySensor=${this._outdoorHumiditySensor}
              .weatherEntity=${this._weatherEntity}
              .outdoorUnavailableNotify=${this._outdoorUnavailableNotify}
              @setting-changed=${this._onSettingChanged}
            ></rs-settings-sensors>
          </rs-settings-panel>

          <rs-settings-panel
            ?hidden=${this._category!==`overview`}
            icon="mdi:tune-variant"
            .heading=${S(`settings.control_title`,e)}
            .intro=${S(`settings.intro.control`,e)}
          >
            <rs-settings-control
              .hass=${this.hass}
              .controlMode=${this._controlMode}
              .comfortWeight=${this._comfortWeight}
              .outdoorCoolingMin=${this._outdoorCoolingMin}
              .outdoorHeatingMax=${this._outdoorHeatingMax}
              .predictionEnabled=${this._predictionEnabled}
              .scheduleOffAction=${this._scheduleOffAction}
              @setting-changed=${this._onSettingChanged}
            ></rs-settings-control>
          </rs-settings-panel>

          <rs-settings-panel
            ?hidden=${this._category!==`overview`}
            icon="mdi:home-account"
            .heading=${S(`presence.title`,e)}
            .intro=${S(`settings.intro.presence`,e)}
          >
            <rs-settings-presence
              .hass=${this.hass}
              .presenceEnabled=${this._presenceEnabled}
              .presencePersons=${this._presencePersons}
              .presenceAwayAction=${this._presenceAwayAction}
              .presenceClearsOverride=${this._presenceClearsOverride}
              @setting-changed=${this._onSettingChanged}
            ></rs-settings-presence>
          </rs-settings-panel>

          <rs-settings-panel
            ?hidden=${this._category!==`overview`}
            icon="mdi:airplane"
            .heading=${S(`vacation.title`,e)}
            .intro=${S(`settings.intro.vacation`,e)}
          >
            <rs-settings-vacation
              .hass=${this.hass}
              .vacationActive=${this._vacationActive}
              .vacationTemp=${this._vacationTemp}
              .vacationUntil=${this._vacationUntil}
              @setting-changed=${this._onSettingChanged}
            ></rs-settings-vacation>
          </rs-settings-panel>

          <rs-settings-panel
            ?hidden=${this._category!==`system`}
            icon="mdi:shield-refresh"
            .heading=${S(`valve_protection.title`,e)}
            .intro=${S(`settings.intro.valve`,e)}
          >
            <rs-settings-valve
              .hass=${this.hass}
              .valveProtectionEnabled=${this._valveProtectionEnabled}
              .valveProtectionInterval=${this._valveProtectionInterval}
              @setting-changed=${this._onSettingChanged}
            ></rs-settings-valve>
          </rs-settings-panel>

          <rs-settings-panel
            ?hidden=${this._category!==`system`}
            icon="mdi:heat-pump-outline"
            .heading=${S(`compressor.title`,e)}
            .intro=${S(`settings.intro.compressor`,e)}
          >
            <rs-settings-compressor
              .hass=${this.hass}
              .compressorGroups=${this._compressorGroups}
              @setting-changed=${this._onSettingChanged}
            ></rs-settings-compressor>
          </rs-settings-panel>

          <rs-settings-panel
            ?hidden=${this._category!==`protection`}
            icon="mdi:water-alert"
            .heading=${S(`mold.title`,e)}
            .intro=${S(`settings.intro.mold`,e)}
          >
            <rs-settings-mold
              .hass=${this.hass}
              .moldDetectionEnabled=${this._moldDetectionEnabled}
              .moldHumidityThreshold=${this._moldHumidityThreshold}
              .moldSustainedMinutes=${this._moldSustainedMinutes}
              .moldPreventionEnabled=${this._moldPreventionEnabled}
              .moldPreventionSustainedMinutes=${this._moldPreventionSustainedMinutes}
              .moldPreventionDehumidificationEnabled=${this._moldPreventionDehumidificationEnabled}
              .moldPreventionDryMinTemperature=${this._moldPreventionDryMinTemperature}
              @setting-changed=${this._onSettingChanged}
            ></rs-settings-mold>
          </rs-settings-panel>

          <rs-settings-panel
            ?hidden=${this._category!==`protection`}
            icon="mdi:bell-outline"
            .heading=${S(`notifications.title`,e)}
            .intro=${S(`settings.intro.notifications`,e)}
            .badge=${S(`badge.beta`,e)}
            .badgeHint=${S(`badge.beta_hint`,e)}
          >
            <rs-settings-notifications
              .hass=${this.hass}
              .notificationsEnabled=${this._moldNotificationsEnabled}
              .notificationTargets=${this._moldNotificationTargets}
              .notificationCooldown=${this._moldNotificationCooldown}
              .moldPreventionEnabled=${this._moldPreventionEnabled}
              .moldPreventionNotify=${this._moldPreventionNotify}
              .windowOpenNotificationMinutes=${this._windowOpenNotificationMinutes}
              @setting-changed=${this._onSettingChanged}
            ></rs-settings-notifications>
          </rs-settings-panel>

          <rs-settings-panel
            ?hidden=${this._category!==`advanced`}
            icon="mdi:brain"
            .heading=${S(`settings.learning_title`,e)}
            .intro=${S(`settings.intro.learning`,e)}
          >
            <rs-settings-learning
              .hass=${this.hass}
              .rooms=${this.rooms}
              .learningDisabledRooms=${this._learningDisabledRooms}
              .boostAppliedAt=${this._boostAppliedAt}
              .roomsLive=${Object.fromEntries(Object.entries(this.rooms).map(([e,t])=>[e,t.live??{}]))}
              @setting-changed=${this._onSettingChanged}
              @boost-applied=${this._onBoostApplied}
            ></rs-settings-learning>
          </rs-settings-panel>

          <rs-settings-panel
            ?hidden=${this._category!==`advanced`}
            icon="mdi:restart"
            .heading=${S(`settings.reset_title`,e)}
            .intro=${S(`settings.intro.reset`,e)}
          >
            <rs-settings-reset .hass=${this.hass} .rooms=${this.rooms}></rs-settings-reset>
          </rs-settings-panel>
        </div>
      </div>
    `}_onBoostApplied(e){let{area_id:t,n_observations:n}=e.detail;this._boostAppliedAt={...this._boostAppliedAt,[t]:n}}_onSettingChanged(e){let{key:t,value:n}=e.detail;t===`bypassEntities`?this._bypassEntities=mn(n):t===`powerMode`?(this._powerMode=hn(n),this._powerModeDirty=!0):this[`_${t}`]=n,this._autoSave()}_tsToDatetimeLocal(e){let t=new Date(e*1e3),n=e=>String(e).padStart(2,`0`);return`${t.getFullYear()}-${n(t.getMonth()+1)}-${n(t.getDate())}T${n(t.getHours())}:${n(t.getMinutes())}`}_autoSave(){this._saveDebounce&&clearTimeout(this._saveDebounce),this._saveDebounce=setTimeout(()=>this._doSave(),500)}async _doSave(){F(this,`saving`);try{let e=this._bypassEntities,t=this._powerMode,{hydraulicBypassEntities:n,powerSensorMode:r}=vn(e,t),i={type:`roommind/settings/save`,group_by_floor:this._groupByFloor,climate_control_active:this._climateControlActive,temperature_rounding_mode:this._temperatureRoundingMode,learning_disabled_rooms:this._learningDisabledRooms,outdoor_temp_sensor:this._outdoorTempSensor,outdoor_humidity_sensor:this._outdoorHumiditySensor,outdoor_cooling_min:this._outdoorCoolingMin,outdoor_heating_max:this._outdoorHeatingMax,control_mode:this._controlMode,comfort_weight:this._comfortWeight,weather_entity:this._weatherEntity,outdoor_unavailable_notify:this._outdoorUnavailableNotify,prediction_enabled:this._predictionEnabled,vacation_temp:this._vacationTemp,vacation_until:this._vacationActive?this._vacationUntil?new Date(this._vacationUntil).getTime()/1e3:yn:null,presence_enabled:this._presenceEnabled,presence_persons:this._presencePersons.filter(e=>e),presence_away_action:this._presenceAwayAction,presence_clears_override:this._presenceClearsOverride,schedule_off_action:this._scheduleOffAction,valve_protection_enabled:this._valveProtectionEnabled,valve_protection_interval_days:this._valveProtectionInterval,compressor_groups:this._compressorGroups.filter(e=>e.members.length>0),boiler_entity:this._boilerEntity,boiler_control_type:this._boilerControlType,boiler_startup_delay_seconds:this._startupDelay,boiler_shutdown_delay_seconds:this._shutdownDelay,hydraulic_bypass_entities:n,hydraulic_bypass_open_temperature:this._bypassTemperature,hydraulic_bypass_child_lock:this._bypassChildLock,boiler_min_demand_rooms:this._minDemandRooms,boiler_demand_unit:this._demandUnit,boiler_min_run_minutes:this._minRunMinutes,boiler_min_off_minutes:this._minOffMinutes,boiler_fault_retry_minutes:this._faultRetryMinutes,boiler_max_wait_minutes:this._maxWaitMinutes,power_budget_enabled:this._budgetEnabled,power_sensor:this._powerSensor,power_sensor_mode:r,power_budget_max_watts:this._maxPower,power_budget_reserve_watts:this._reserve,power_budget_unavailable_behavior:`boiler`,energy_price_per_kwh:this._energyPricePerKwh,mold_detection_enabled:this._moldDetectionEnabled,mold_humidity_threshold:this._moldHumidityThreshold,mold_sustained_minutes:this._moldSustainedMinutes,mold_notification_cooldown:this._moldNotificationCooldown,mold_notifications_enabled:this._moldNotificationsEnabled,mold_notification_targets:this._moldNotificationTargets.filter(e=>e.entity_id),mold_prevention_enabled:this._moldPreventionEnabled,mold_prevention_sustained_minutes:this._moldPreventionSustainedMinutes,mold_prevention_dehumidification_enabled:this._moldPreventionDehumidificationEnabled,mold_prevention_dry_min_temperature:this._moldPreventionDryMinTemperature,mold_prevention_notify_enabled:this._moldPreventionNotify,mold_prevention_notify_targets:this._moldPreventionNotify?this._moldNotificationTargets.filter(e=>e.entity_id):[],window_open_notification_minutes:this._windowOpenNotificationMinutes};console.debug(`RoomMind heating settings save payload`,i),console.debug(`RoomMind heating settings save values`,typeof i.hydraulic_bypass_entities,i.hydraulic_bypass_entities,i.power_sensor_mode),console.error(`[RoomMind DEBUG FINAL PAYLOAD]`,{hydraulic_bypass_entities:i.hydraulic_bypass_entities,bypassIsArray:Array.isArray(i.hydraulic_bypass_entities),power_sensor_mode:i.power_sensor_mode,fullPayload:i}),await this.hass.callWS(i),this._powerMode===r&&(this._powerModeDirty=!1),F(this,`saved`)}catch{F(this,`error`)}}static{this.styles=l`
    :host {
      display: block;
      --rs-ui-line: var(--divider-color, rgba(125, 125, 125, 0.16));
    }
    .settings-intro {
      padding: 12px 2px 30px;
      position: relative;
    }
    .eyebrow {
      color: var(--secondary-text-color);
      text-transform: uppercase;
      font-size: 11px;
      letter-spacing: 0.13em;
      font-weight: 700;
    }
    .settings-intro h1 {
      font-size: clamp(27px, 3vw, 38px);
      line-height: 1.15;
      letter-spacing: -0.035em;
      margin: 10px 0 10px;
      font-weight: 700;
    }
    .settings-intro p,
    .category-heading p {
      color: var(--secondary-text-color);
      font-size: 14px;
      line-height: 1.65;
      max-width: 620px;
      margin: 0;
    }
    .control-status {
      display: inline-flex;
      gap: 8px;
      align-items: center;
      margin-top: 17px;
      padding: 8px 12px;
      border-radius: 999px;
      font-size: 12px;
      font-weight: 650;
      background: var(--secondary-background-color, rgba(128, 128, 128, 0.1));
    }
    .status-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--secondary-text-color);
    }
    .running .status-dot {
      background: var(--success-color, #36a578);
    }
    .settings-workspace {
      display: grid;
      grid-template-columns: 250px minmax(0, 1fr);
      gap: 34px;
      align-items: start;
    }
    .settings-navigation {
      display: grid;
      gap: 6px;
      position: sticky;
      top: 132px;
    }
    .category-button {
      display: flex;
      align-items: center;
      gap: 12px;
      text-align: left;
      border: 1px solid transparent;
      border-radius: 14px;
      padding: 12px 14px;
      font: inherit;
      color: var(--secondary-text-color);
      background: transparent;
      cursor: pointer;
      min-height: 64px;
      transition:
        background 0.18s ease,
        border-color 0.18s ease;
    }
    .category-button:hover {
      background: var(--secondary-background-color, rgba(128, 128, 128, 0.08));
    }
    .category-button.selected {
      color: var(--primary-text-color);
      border-color: var(--rs-ui-line);
      background: var(--card-background-color);
      box-shadow: 0 3px 18px rgba(0, 0, 0, 0.04);
    }
    .category-button ha-icon {
      --mdc-icon-size: 21px;
      flex-shrink: 0;
    }
    .category-button.selected ha-icon {
      color: var(--primary-color);
    }
    .category-copy {
      display: grid;
      gap: 4px;
      min-width: 0;
      flex: 1;
    }
    .category-copy strong {
      font-size: 14px;
      font-weight: 650;
    }
    .category-copy small {
      font-size: 11px;
      opacity: 0.75;
      line-height: 1.3;
    }
    .category-count {
      font-size: 11px;
      opacity: 0.55;
      font-variant-numeric: tabular-nums;
    }
    .category-button:focus-visible {
      outline: 2px solid var(--primary-color);
      outline-offset: 2px;
    }
    .settings-body {
      display: grid;
      gap: 12px;
      min-width: 0;
    }
    .category-heading {
      padding: 5px 0 13px;
    }
    .category-heading h2 {
      font-size: 23px;
      font-weight: 650;
      letter-spacing: -0.025em;
      margin: 8px 0 6px;
    }
    rs-settings-panel[hidden] {
      display: none !important;
    }
    @media (max-width: 850px) {
      .settings-workspace {
        display: block;
      }
      .settings-navigation {
        display: flex;
        overflow-x: auto;
        gap: 8px;
        position: relative;
        top: auto;
        padding: 0 0 14px;
        margin-bottom: 20px;
        scrollbar-width: thin;
      }
      .category-button {
        flex: 0 0 auto;
        min-height: 48px;
        padding: 10px 13px;
        white-space: nowrap;
      }
      .category-copy small,
      .category-count {
        display: none;
      }
      .category-copy {
        display: block;
      }
      .settings-intro {
        padding-bottom: 22px;
      }
    }
    @media (max-width: 500px) {
      .settings-intro h1 {
        font-size: 28px;
      }
      .category-button ha-icon {
        --mdc-icon-size: 18px;
      }
      .category-heading h2 {
        font-size: 21px;
      }
    }

    .loading {
      padding: 80px 16px;
      text-align: center;
      color: var(--secondary-text-color);
    }
  `}};k([y({attribute:!1})],Y.prototype,`hass`,void 0),k([y({attribute:!1})],Y.prototype,`rooms`,void 0),k([b()],Y.prototype,`_groupByFloor`,void 0),k([b()],Y.prototype,`_climateControlActive`,void 0),k([b()],Y.prototype,`_temperatureRoundingMode`,void 0),k([b()],Y.prototype,`_learningDisabledRooms`,void 0),k([b()],Y.prototype,`_outdoorTempSensor`,void 0),k([b()],Y.prototype,`_outdoorHumiditySensor`,void 0),k([b()],Y.prototype,`_outdoorCoolingMin`,void 0),k([b()],Y.prototype,`_outdoorHeatingMax`,void 0),k([b()],Y.prototype,`_controlMode`,void 0),k([b()],Y.prototype,`_comfortWeight`,void 0),k([b()],Y.prototype,`_weatherEntity`,void 0),k([b()],Y.prototype,`_outdoorUnavailableNotify`,void 0),k([b()],Y.prototype,`_predictionEnabled`,void 0),k([b()],Y.prototype,`_vacationActive`,void 0),k([b()],Y.prototype,`_vacationTemp`,void 0),k([b()],Y.prototype,`_vacationUntil`,void 0),k([b()],Y.prototype,`_presenceEnabled`,void 0),k([b()],Y.prototype,`_presencePersons`,void 0),k([b()],Y.prototype,`_presenceAwayAction`,void 0),k([b()],Y.prototype,`_presenceClearsOverride`,void 0),k([b()],Y.prototype,`_scheduleOffAction`,void 0),k([b()],Y.prototype,`_valveProtectionEnabled`,void 0),k([b()],Y.prototype,`_valveProtectionInterval`,void 0),k([b()],Y.prototype,`_moldDetectionEnabled`,void 0),k([b()],Y.prototype,`_moldHumidityThreshold`,void 0),k([b()],Y.prototype,`_moldSustainedMinutes`,void 0),k([b()],Y.prototype,`_moldNotificationCooldown`,void 0),k([b()],Y.prototype,`_moldNotificationsEnabled`,void 0),k([b()],Y.prototype,`_moldNotificationTargets`,void 0),k([b()],Y.prototype,`_moldPreventionEnabled`,void 0),k([b()],Y.prototype,`_moldPreventionSustainedMinutes`,void 0),k([b()],Y.prototype,`_moldPreventionDehumidificationEnabled`,void 0),k([b()],Y.prototype,`_moldPreventionDryMinTemperature`,void 0),k([b()],Y.prototype,`_moldPreventionNotify`,void 0),k([b()],Y.prototype,`_windowOpenNotificationMinutes`,void 0),k([b()],Y.prototype,`_compressorGroups`,void 0),k([b()],Y.prototype,`_boostAppliedAt`,void 0),k([b()],Y.prototype,`_boilerEntity`,void 0),k([b()],Y.prototype,`_boilerControlType`,void 0),k([b()],Y.prototype,`_bypassEntities`,void 0),k([b()],Y.prototype,`_startupDelay`,void 0),k([b()],Y.prototype,`_shutdownDelay`,void 0),k([b()],Y.prototype,`_bypassTemperature`,void 0),k([b()],Y.prototype,`_bypassChildLock`,void 0),k([b()],Y.prototype,`_minDemandRooms`,void 0),k([b()],Y.prototype,`_demandUnit`,void 0),k([b()],Y.prototype,`_minRunMinutes`,void 0),k([b()],Y.prototype,`_minOffMinutes`,void 0),k([b()],Y.prototype,`_faultRetryMinutes`,void 0),k([b()],Y.prototype,`_maxWaitMinutes`,void 0),k([b()],Y.prototype,`_budgetEnabled`,void 0),k([b()],Y.prototype,`_powerSensor`,void 0),k([b()],Y.prototype,`_powerMode`,void 0),k([b()],Y.prototype,`_powerModeDirty`,void 0),k([b()],Y.prototype,`_maxPower`,void 0),k([b()],Y.prototype,`_reserve`,void 0),k([b()],Y.prototype,`_energyPricePerKwh`,void 0),k([b()],Y.prototype,`_loaded`,void 0),k([b()],Y.prototype,`_category`,void 0),Y=k([v(`rs-settings`)],Y);function Rn(e){let t=[...e.history,...e.detail];return t.length===0?null:[`timestamp,datetime,room_temp,outdoor_temp,target_temp,mode,predicted_temp,window_open,heating_power,solar_irradiance,blind_position,cover_reason,device_setpoint`,...t.map(e=>{let t=new Date(e.ts*1e3).toISOString(),n=e.room_temp??``,r=e.outdoor_temp??``,i=e.target_temp??``,a=e.predicted_temp??``,o=e.heating_power??``,s=e.solar_irradiance??``,c=e.blind_position??``,l=e.cover_reason??``,u=e.device_setpoint??``;return`${e.ts},${t},${n},${r},${i},${e.mode},${a},${e.window_open},${o},${s},${c},${l},${u}`})].join(`
`)}function zn(e,t,n){let r=new Blob([e],{type:`${n};charset=utf-8`}),i=URL.createObjectURL(r),a=document.createElement(`a`);a.href=i,a.download=t,a.click(),URL.revokeObjectURL(i)}function Bn(e,t,n,r,i,a,o){let s=e?.areas?.[n],c=(t[n]?.display_name||s?.name||n).replace(/\s+/g,`_`).toLowerCase();return a?`roommind_${a}_${c}.${o}`:`roommind_${c}_${new Date(r).toISOString().slice(0,10)}_${new Date(i).toISOString().slice(0,10)}.${o}`}function Vn(e){return navigator.clipboard?.writeText?(navigator.clipboard.writeText(e).catch(()=>{Hn(e)}),!0):Hn(e)}function Hn(e){let t=document.createElement(`textarea`);t.value=e,t.style.position=`fixed`,t.style.opacity=`0`,document.body.appendChild(t),t.select();let n=!1;try{n=document.execCommand(`copy`)}catch(e){console.debug(`[RoomMind] clipboard fallback:`,e)}return document.body.removeChild(t),n}_(),x(),A();var X=class extends g{constructor(...e){super(...e),this.rooms={},this.selectedRoom=``,this.rangeStart=0,this.rangeEnd=0,this.activeQuick=`24h`,this.data=null,this.language=`en`,this._openDropdown=null,this._diagLoading=!1,this._boundCloseDropdowns=this._closeDropdowns.bind(this)}connectedCallback(){super.connectedCallback(),document.addEventListener(`click`,this._boundCloseDropdowns)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener(`click`,this._boundCloseDropdowns)}updated(e){(e.has(`rooms`)||e.has(`selectedRoom`))&&this.selectedRoom&&this.updateComplete.then(()=>{let e=this.renderRoot?.querySelector(`ha-select`);e&&e.value!==this.selectedRoom&&(e.value=this.selectedRoom)})}render(){let e=this.language,t=this._getConfiguredRooms();return m`
      ${this._renderRoomSelector(t,e)}
      ${this.selectedRoom?this._renderRangeButtons(e):h}
    `}_getConfiguredRooms(){return Object.entries(this.rooms).map(([e,t])=>{let n=this.hass?.areas?.[e];return{area_id:e,name:t.display_name||n?.name||e}})}_renderRoomSelector(e,t){return m`
      <div class="selector-row">
        <ha-select
          .value=${this.selectedRoom}
          .label=${S(`analytics.select_room`,t)}
          .options=${e.map(e=>({value:e.area_id,label:e.name}))}
          naturalMenuWidth
          fixedMenuPosition
          @selected=${this._onRoomSelected}
          @closed=${e=>e.stopPropagation()}
        >
          ${e.map(e=>m` <ha-list-item value=${e.area_id}>${e.name}</ha-list-item> `)}
        </ha-select>
      </div>
    `}_renderRangeButtons(e){let t=[{key:`24h`,label:S(`analytics.range_1d`,e),days:1},{key:`2d`,label:S(`analytics.range_2d`,e),days:2},{key:`7d`,label:S(`analytics.range_7d`,e),days:7},{key:`30d`,label:S(`analytics.range_30d`,e),days:30}],n=this.data&&(this.data.history.length>0||this.data.detail.length>0),r=e=>new Date(e).toLocaleString(this.hass.language,{month:`2-digit`,day:`2-digit`,hour:`2-digit`,minute:`2-digit`});return m`
      <div class="range-row">
        <div class="range-controls">
          <div class="range-bar">
            ${t.map(e=>m`
                <button
                  class="range-chip"
                  ?active=${this.activeQuick===e.key}
                  @click=${()=>this._onQuickRange(e.key,e.days)}
                >
                  ${e.label}
                </button>
              `)}
            <div class="range-chip picker-chip ${this.activeQuick===null?`picker-active`:``}">
              <ha-date-range-picker
                .hass=${this.hass}
                .startDate=${new Date(this.rangeStart)}
                .endDate=${new Date(this.rangeEnd)}
                .ranges=${!1}
                time-picker
                auto-apply
                minimal
                @value-changed=${this._onDateRangeChanged}
              ></ha-date-range-picker>
            </div>
          </div>
          <span class="date-label ${this.activeQuick===null?`custom-active`:``}"
            >${r(this.rangeStart)} – ${r(this.rangeEnd)}</span
          >
        </div>
        <div class="action-buttons">
          <div class="export-split">
            <button
              class="export-btn"
              ?disabled=${!n}
              @click=${e=>{e.stopPropagation(),this._toggleDropdown(`csv`)}}
            >
              <ha-icon icon="mdi:download"></ha-icon>
              ${S(`analytics.export`,e)}
              <ha-icon class="arrow-icon" icon="mdi:chevron-down"></ha-icon>
            </button>
            ${this._openDropdown===`csv`?m`<div class="export-dropdown" @click=${e=>e.stopPropagation()}>
                  <button @click=${this._exportCsv}>
                    <ha-icon icon="mdi:download"></ha-icon>
                    ${S(`analytics.export_download`,e)}
                  </button>
                  <button @click=${this._copyCsvToClipboard}>
                    <ha-icon icon="mdi:content-copy"></ha-icon>
                    ${S(`analytics.export_clipboard`,e)}
                  </button>
                </div>`:h}
          </div>
          <div class="export-split">
            <button
              class="export-btn"
              ?disabled=${this._diagLoading}
              @click=${e=>{e.stopPropagation(),this._toggleDropdown(`diag`)}}
            >
              <ha-icon icon=${this._diagLoading?`mdi:loading`:`mdi:bug-outline`}></ha-icon>
              ${S(`analytics.copy_diagnostics`,e)}
              <ha-icon class="arrow-icon" icon="mdi:chevron-down"></ha-icon>
            </button>
            ${this._openDropdown===`diag`?m`<div class="export-dropdown" @click=${e=>e.stopPropagation()}>
                  <button @click=${this._exportDiagnostics}>
                    <ha-icon icon="mdi:download"></ha-icon>
                    ${S(`analytics.export_download`,e)}
                  </button>
                  <button @click=${this._copyDiagnosticsToClipboard}>
                    <ha-icon icon="mdi:content-copy"></ha-icon>
                    ${S(`analytics.export_clipboard`,e)}
                  </button>
                </div>`:h}
          </div>
        </div>
      </div>
    `}_onRoomSelected(e){let t=P(e);t&&t!==this.selectedRoom&&this.dispatchEvent(new CustomEvent(`room-selected`,{detail:{areaId:t},bubbles:!0,composed:!0}))}_onQuickRange(e,t){let n=new Date,r=new Date(n);r.setDate(r.getDate()-(t-1)),r.setHours(0,0,0,0),this.dispatchEvent(new CustomEvent(`range-changed`,{detail:{activeQuick:e,rangeStart:r.getTime(),rangeEnd:n.getTime(),chartAnchor:n.getTime()},bubbles:!0,composed:!0}))}_onDateRangeChanged(e){let{startDate:t,endDate:n}=e.detail.value;!t||!n||this.dispatchEvent(new CustomEvent(`range-changed`,{detail:{activeQuick:null,rangeStart:t.getTime(),rangeEnd:n.getTime(),chartAnchor:n.getTime()},bubbles:!0,composed:!0}))}_exportCsv(){if(!this.data)return;let e=Rn(this.data);e&&(zn(e,Bn(this.hass,this.rooms,this.selectedRoom,this.rangeStart,this.rangeEnd,``,`csv`),`text/csv`),this._openDropdown=null)}async _exportDiagnostics(){if(!this._diagLoading){this._diagLoading=!0,this._openDropdown=null;try{let e=await this.hass.callWS({type:`roommind/diagnostics/get`});zn(JSON.stringify(e,null,2),`roommind_diagnostics.json`,`application/json`)}catch(e){console.warn(`[RoomMind] diagnostics export failed:`,e)}finally{this._diagLoading=!1}}}_copyCsvToClipboard(){if(!this.data)return;let e=Rn(this.data);e&&(Vn(e),this._openDropdown=null)}async _copyDiagnosticsToClipboard(){if(!this._diagLoading){this._diagLoading=!0,this._openDropdown=null;try{let e=await this.hass.callWS({type:`roommind/diagnostics/get`});Vn(JSON.stringify(e,null,2))}catch(e){console.warn(`[RoomMind] diagnostics clipboard failed:`,e)}finally{this._diagLoading=!1}}}_toggleDropdown(e){this._openDropdown=this._openDropdown===e?null:e}_closeDropdowns(){this._openDropdown&&=null}static{this.styles=[I,l`
      :host {
        display: block;
      }

      .selector-row {
        margin-bottom: 16px;
      }

      .selector-row ha-select {
        width: 100%;
      }

      .range-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 16px;
        gap: 12px;
      }

      .range-controls {
        display: flex;
        align-items: center;
        gap: 8px;
        position: relative;
      }

      .range-bar {
        display: inline-flex;
        border-radius: 12px;
        border: 1px solid var(--divider-color);
        background: var(--card-background-color);
      }

      .range-bar > :first-child {
        border-radius: 12px 0 0 12px;
      }

      .range-bar > :last-child {
        border-radius: 0 12px 12px 0;
      }

      .range-chip {
        padding: 7px 14px;
        border: none;
        border-right: 1px solid var(--divider-color);
        background: transparent;
        color: var(--secondary-text-color);
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition:
          background 0.15s ease,
          color 0.15s ease;
        font-family: inherit;
        white-space: nowrap;
      }

      .range-chip:last-child {
        border-right: none;
      }

      .range-chip:hover:not([active]) {
        background: rgba(var(--rgb-primary-color, 3, 169, 244), 0.08);
        color: var(--primary-text-color);
      }

      .range-chip[active] {
        background: var(--primary-color);
        color: var(--text-primary-color, #fff);
      }

      .picker-chip {
        display: flex;
        align-items: center;
        padding: 0;
        cursor: pointer;
      }

      .picker-chip ha-date-range-picker {
        --mdc-icon-size: 18px;
        --mdc-icon-button-size: 32px;
      }

      .picker-chip.picker-active {
        background: var(--primary-color);
        color: var(--text-primary-color, #fff);
      }

      .date-label {
        font-size: 12px;
        color: var(--secondary-text-color);
        white-space: nowrap;
      }

      .date-label.custom-active {
        color: var(--primary-color);
      }

      .action-buttons {
        display: flex;
        gap: 8px;
      }

      .export-split {
        position: relative;
        display: inline-flex;
      }

      .export-btn {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 7px 14px;
        border: 1px solid var(--divider-color);
        border-radius: 12px;
        background: var(--card-background-color);
        color: var(--secondary-text-color);
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.15s ease;
        font-family: inherit;
        white-space: nowrap;
        --mdc-icon-size: 14px;
      }

      .export-btn:hover {
        color: var(--primary-text-color);
        border-color: var(--primary-color);
      }

      .export-btn[disabled] {
        opacity: 0.4;
        cursor: default;
      }

      .arrow-icon {
        --mdc-icon-size: 14px;
        margin-left: 2px;
        margin-right: -4px;
      }

      .export-dropdown {
        position: absolute;
        top: 100%;
        right: 0;
        margin-top: 4px;
        min-width: 100%;
        background: var(--card-background-color);
        border: 1px solid var(--divider-color);
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        z-index: 10;
        overflow: hidden;
      }

      .export-dropdown button {
        display: flex;
        align-items: center;
        gap: 8px;
        width: 100%;
        padding: 10px 14px;
        border: none;
        background: transparent;
        color: var(--primary-text-color);
        font-size: 12px;
        font-family: inherit;
        cursor: pointer;
        white-space: nowrap;
        --mdc-icon-size: 14px;
      }

      .export-dropdown button:hover {
        background: rgba(var(--rgb-primary-color, 3, 169, 244), 0.08);
      }

      .export-dropdown button + button {
        border-top: 1px solid var(--divider-color);
      }

      @media (max-width: 600px) {
        .range-row {
          flex-wrap: wrap;
        }
        .range-controls {
          flex-wrap: wrap;
        }
        .range-chip {
          padding: 6px 10px;
          font-size: 11px;
        }
      }
    `]}};k([y({attribute:!1})],X.prototype,`hass`,void 0),k([y({attribute:!1})],X.prototype,`rooms`,void 0),k([y({type:String})],X.prototype,`selectedRoom`,void 0),k([y({type:Number})],X.prototype,`rangeStart`,void 0),k([y({type:Number})],X.prototype,`rangeEnd`,void 0),k([y({type:String})],X.prototype,`activeQuick`,void 0),k([y({attribute:!1})],X.prototype,`data`,void 0),k([y({type:String})],X.prototype,`language`,void 0),k([b()],X.prototype,`_openDropdown`,void 0),k([b()],X.prototype,`_diagLoading`,void 0),X=k([v(`rs-analytics-toolbar`)],X),_();var Un=l`
  .info-icon {
    --mdc-icon-size: 16px;
    color: var(--secondary-text-color);
    opacity: 0.3;
    cursor: pointer;
    flex-shrink: 0;
    transition:
      opacity 0.15s,
      color 0.15s;
  }

  .info-icon:hover {
    opacity: 0.7;
  }

  .info-icon.info-active {
    opacity: 1;
    color: var(--primary-color);
  }

  .info-panel {
    padding: 12px;
    border-radius: 8px;
    background: var(--secondary-background-color, rgba(128, 128, 128, 0.06));
    font-size: 13px;
    line-height: 1.6;
    color: var(--secondary-text-color);
  }

  .info-panel strong {
    display: block;
    margin-bottom: 4px;
    color: var(--primary-text-color);
    font-size: 13px;
  }

  .info-panel .yaml-block {
    background: var(--primary-background-color, #f5f5f5);
    border: 1px solid var(--divider-color, #e0e0e0);
    border-radius: 6px;
    padding: 10px 14px;
    margin: 8px 0;
    font-family: var(--code-font-family, monospace);
    font-size: 12px;
    line-height: 1.6;
    white-space: pre;
    overflow-x: auto;
    color: var(--primary-text-color);
  }
  .info-panel .yaml-key {
    color: #0550ae;
  }
  .info-panel .yaml-value {
    color: #0a3069;
  }
`,Wn=108e5;function Gn(e,t){let{hass:n,language:r,chartAnchor:i,forecast:a,isOutdoor:o}=t,s=e=>w(e,n),c=[],l=[],u=[],d=[],f=[];for(let t of e){let e=t.ts*1e3;t.room_temp!==null&&c.push([e,s(t.room_temp)]),!o&&t.target_temp!==null&&l.push([e,s(t.target_temp)]),!o&&t.predicted_temp!==null&&u.push([e,s(t.predicted_temp)]),t.outdoor_temp!==null&&d.push([e,s(t.outdoor_temp)]),!o&&t.device_setpoint!=null&&f.push([e,s(t.device_setpoint)])}for(let e of a??[]){let t=e.ts*1e3;!o&&e.target_temp!==null&&l.push([t,s(e.target_temp)]),!o&&e.predicted_temp!==null&&u.push([t,s(e.predicted_temp)])}let p=[{id:`room_temp`,type:`line`,name:S(`analytics.temperature`,r),color:`rgb(255, 152, 0)`,data:c,showSymbol:!1,smooth:!0,lineStyle:{width:2},yAxisIndex:0}];o||p.push({id:`target_temp`,type:`line`,name:S(`analytics.target`,r),color:`rgb(76, 175, 80)`,data:l,showSymbol:!1,smooth:!1,lineStyle:{width:2,type:`dashed`},yAxisIndex:0}),u.length>0&&p.push({id:`predicted_temp`,type:`line`,name:S(`analytics.prediction`,r),color:`rgb(33, 150, 243)`,data:u,showSymbol:!1,smooth:!0,lineStyle:{width:2,type:`dotted`},yAxisIndex:0}),f.length>0&&p.push({id:`device_target`,type:`line`,name:`TRV / AC`,color:`rgb(156, 39, 176)`,data:f,showSymbol:!1,smooth:!1,step:`end`,lineStyle:{width:1,type:`dashed`},yAxisIndex:0}),d.length>0&&p.push({id:`outdoor_temp`,type:`line`,name:S(`analytics.outdoor`,r),color:`rgb(158, 158, 158)`,data:d,showSymbol:!1,smooth:!0,lineStyle:{width:1},yAxisIndex:0});let ee=[],te=[],ne=[],re=!1,ie=!1,ae=!1;for(let t of e){let e=t.ts*1e3;t.mode===`heating`?(ee.push([e,999]),re=!0):ee.push([e,null]),t.mode===`cooling`?(te.push([e,999]),ie=!0):te.push([e,null]),t.window_open?(ne.push([e,999]),ae=!0):ne.push([e,null])}return re&&p.push({id:`heating_events`,type:`line`,name:S(`analytics.heating_period`,r),color:`rgb(244, 67, 54)`,data:ee,showSymbol:!1,lineStyle:{width:0},areaStyle:{color:`rgba(244, 67, 54, 0.08)`,origin:`start`},tooltip:{show:!1},yAxisIndex:0,z:-1,connectNulls:!1}),ie&&p.push({id:`cooling_events`,type:`line`,name:S(`analytics.cooling_period`,r),color:`rgb(63, 81, 181)`,data:te,showSymbol:!1,lineStyle:{width:0},areaStyle:{color:`rgba(63, 81, 181, 0.08)`,origin:`start`},tooltip:{show:!1},yAxisIndex:0,z:-1,connectNulls:!1}),ae&&p.push({id:`window_events`,type:`line`,name:S(`analytics.window_open_period`,r),color:`rgb(0, 150, 136)`,data:ne,showSymbol:!1,lineStyle:{width:0},areaStyle:{color:`rgba(0, 150, 136, 0.1)`,origin:`start`},tooltip:{show:!1},yAxisIndex:0,z:-1,connectNulls:!1}),p.push({id:`now_marker`,type:`line`,name:``,color:`rgba(255,255,255,0.3)`,data:[[i,-999],[i,999]],showSymbol:!1,lineStyle:{width:1,type:`dashed`},yAxisIndex:0,tooltip:{show:!1},z:-2}),p}function Kn(e,t,n){let{hass:r,language:i,chartAnchor:a,rangeStart:o,rangeEnd:s}=n,c=C(r),l={type:`value`,name:c};if(e.length>0){let t=1/0,n=-1/0;for(let r of e)r<t&&(t=r),r>n&&(n=r);let r=n-t,i=Math.max(r*.1,.5);l.min=Math.floor((t-i)*2)/2,l.max=Math.ceil((n+i)*2)/2}return{xAxis:{type:`time`,min:o,max:Math.abs(s-Date.now())<36e5?a+Wn:s},yAxis:l,dataZoom:[{type:`inside`,xAxisIndex:0,filterMode:`none`}],tooltip:{trigger:`axis`,axisPointer:{snap:!1},valueFormatter:e=>e.toFixed(1)+`\xA0`+c,formatter:e=>{if(!Array.isArray(e)||e.length===0)return``;let n=`<div style="font-weight:500;margin-bottom:4px">${new Date(e[0].value[0]).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})}</div>`,a=null,o=null;for(let t of e){if(t.seriesId?.endsWith(`_events`))continue;let e=t.value?.[1];e!=null&&(n+=`<div>${t.color?`<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${t.color};margin-right:6px"></span>`:``}${t.seriesName}: ${e.toFixed(1)}\u00A0${c}</div>`,t.seriesId===`room_temp`&&(a=e),t.seriesId===`predicted_temp`&&(o=e))}if(a!==null&&o!==null){let e=a-o;n+=`<div style="border-top:1px solid rgba(128,128,128,0.3);margin-top:4px;padding-top:4px">Delta: ${e>=0?`+`:``}${e.toFixed(2)}\u00A0${c}</div>`}if(t.length>0){let a=e[0].value[0]/1e3,o=null,s=1/0;for(let e of t){let t=Math.abs(e.ts-a);t<s&&(s=t,o=e)}if(o){let e=[];if(o.mode===`heating`){let t=o.heating_power;t!=null&&t>0&&t<100?e.push(`${S(`analytics.heating_period`,i)} ${t}%`):e.push(S(`analytics.heating_period`,i)),o.device_setpoint!=null&&e.push(`TRV ${E(o.device_setpoint,r)}\u00A0${c}`)}else o.mode===`cooling`&&(e.push(S(`analytics.cooling_period`,i)),o.device_setpoint!=null&&e.push(`AC ${E(o.device_setpoint,r)}\u00A0${c}`));o.window_open&&e.push(S(`analytics.window_open_period`,i)),e.length>0&&(n+=`<div style="border-top:1px solid rgba(128,128,128,0.3);margin-top:4px;padding-top:4px;color:rgba(255,255,255,0.7)">${e.join(` · `)}</div>`),o.blind_position!=null&&(n+=`<div style="color:rgba(255,255,255,0.7)">${S(`analytics.blind_position`,i)} ${100-o.blind_position}%</div>`)}}let s=document.createElement(`div`);return s.innerHTML=n,s}},grid:{top:15,left:10,right:10,bottom:5,containLabel:!0}}}_(),x(),A();var Z=class extends g{constructor(...e){super(...e),this.data=null,this.rangeStart=0,this.rangeEnd=0,this.chartAnchor=0,this.language=`en`,this.isOutdoor=!1,this._hiddenSeries=new Set([`outdoor_temp`,`device_target`]),this._chartInfoExpanded=!1}render(){let e=this.language,t=this.data?[...this.data.history,...this.data.detail]:[],n=[...t,...this.data?.forecast??[]],r={hass:this.hass,language:e,chartAnchor:this.chartAnchor,rangeStart:this.rangeStart,rangeEnd:this.rangeEnd,forecast:this.data?.forecast,isOutdoor:this.isOutdoor},i=t.length>0?Gn(t,r):[],a=[],o=i.map(e=>{let t=e.id,n=e.lineStyle||{},r=t.endsWith(`_events`);if(this._hiddenSeries.has(t)){let t={...e,lineStyle:{...n,width:0,opacity:0}};return e.areaStyle&&(t.areaStyle={...e.areaStyle,opacity:0}),t}if(!r&&t!==`now_marker`)for(let t of e.data)t&&t[1]!=null&&a.push(t[1]);let i={...e,lineStyle:{...n,opacity:1}};return e.areaStyle&&(i.areaStyle={...e.areaStyle,opacity:1}),i}),s=Kn(a,n,r);return m`
      <ha-card>
        <div class="card-header">
          <span>${S(`analytics.temperature`,e)}</span>
          <ha-icon
            class="info-icon chart-info-toggle ${this._chartInfoExpanded?`info-active`:``}"
            icon="mdi:information-outline"
            @click=${()=>{this._chartInfoExpanded=!this._chartInfoExpanded}}
          ></ha-icon>
        </div>
        ${this._chartInfoExpanded?m`<div class="chart-info-panel">
              ${this._renderMarkdown(S(`analytics.chart_info_body`,e))}
            </div>`:h}
        ${t.length>0?m`
              <ha-chart-base
                .hass=${this.hass}
                .data=${o}
                .options=${s}
                .height=${`300px`}
                style="height: 300px"
              ></ha-chart-base>
              ${this._renderSeriesLegend(i)}
            `:m`<div class="chart-empty">
              <ha-icon icon="mdi:chart-line"></ha-icon>
              <span>${S(`analytics.no_data`,e)}</span>
            </div>`}
      </ha-card>
    `}_renderSeriesLegend(e){let t=e.filter(e=>e.id!==`now_marker`);return m`
      <div class="series-legend">
        ${t.map(e=>{let t=e.id,n=this._hiddenSeries.has(t);return m`
            <button
              class="legend-item ${n?`legend-hidden`:``}"
              @click=${()=>this._toggleSeries(t)}
            >
              <span class="legend-dot" style="background: ${e.color}"></span>
              ${e.name}
            </button>
          `})}
      </div>
    `}_renderMarkdown(e){return e.split(`

`).map(e=>m`<p>
          ${e.split(/(\*\*.*?\*\*)/).map(e=>e.startsWith(`**`)&&e.endsWith(`**`)?m`<strong>${e.slice(2,-2)}</strong>`:e)}
        </p>`)}_toggleSeries(e){let t=new Set(this._hiddenSeries);t.has(e)?t.delete(e):t.add(e),this._hiddenSeries=t}static{this.styles=[Un,l`
      :host {
        display: block;
      }

      ha-card {
        margin-bottom: 16px;
      }

      .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 16px 0;
        font-size: 16px;
        font-weight: 500;
      }

      .chart-info-toggle {
        --mdc-icon-size: 20px;
      }

      .chart-info-panel {
        margin: 8px 16px 4px;
        padding: 12px 14px;
        border-radius: 8px;
        background: var(--secondary-background-color, rgba(128, 128, 128, 0.06));
        font-size: 13px;
        line-height: 1.6;
        color: var(--secondary-text-color);
      }

      .chart-info-panel p {
        margin: 0 0 8px;
      }

      .chart-info-panel p:last-child {
        margin-bottom: 0;
      }

      .chart-info-panel strong {
        color: var(--primary-text-color);
      }

      .series-legend {
        display: flex;
        justify-content: center;
        gap: 6px;
        padding: 8px 16px 12px;
        flex-wrap: wrap;
      }

      .legend-item {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 4px 10px;
        border: none;
        border-radius: 12px;
        background: transparent;
        color: var(--primary-text-color);
        font-size: 12px;
        font-family: inherit;
        cursor: pointer;
        transition: opacity 0.2s;
      }

      .legend-item:hover {
        background: var(--secondary-background-color, rgba(128, 128, 128, 0.1));
      }

      .legend-item.legend-hidden {
        opacity: 0.35;
      }

      .legend-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        flex-shrink: 0;
      }

      .chart-empty {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 200px;
        gap: 8px;
        color: var(--secondary-text-color);
        opacity: 0.5;
        --mdc-icon-size: 40px;
        font-size: 13px;
      }
    `]}};k([y({attribute:!1})],Z.prototype,`hass`,void 0),k([y({attribute:!1})],Z.prototype,`data`,void 0),k([y({type:Number})],Z.prototype,`rangeStart`,void 0),k([y({type:Number})],Z.prototype,`rangeEnd`,void 0),k([y({type:Number})],Z.prototype,`chartAnchor`,void 0),k([y({type:String})],Z.prototype,`language`,void 0),k([y({type:Boolean})],Z.prototype,`isOutdoor`,void 0),k([b()],Z.prototype,`_hiddenSeries`,void 0),k([b()],Z.prototype,`_chartInfoExpanded`,void 0),Z=k([v(`rs-analytics-chart`)],Z),_(),x(),A();var qn=[`#03a9f4`,`#ff9800`,`#8bc34a`,`#9c27b0`,`#009688`,`#f44336`],Jn=108e5,Yn=class extends g{constructor(...e){super(...e),this.data=null,this.rangeStart=0,this.rangeEnd=0,this.chartAnchor=0,this.language=`en`,this._hiddenSeries=new Set,this._chartInfoExpanded=!1}_points(){return this.data?[...this.data.history,...this.data.detail]:[]}_deviceIds(e,t){let n=new Set;for(let r of[...e,...t]){for(let e of Object.keys(r.ac_device_power_w??{}))n.add(e);for(let e of Object.keys(r.predicted_device_power_w??{}))n.add(e)}return[...n].sort()}_friendlyName(e){let t=this.hass.states[e]?.attributes?.friendly_name;return typeof t==`string`&&t?t:e.split(`.`).pop().replaceAll(`_`,` `)}_integrate(e){let t=e.filter(e=>e.value!=null).sort((e,t)=>e.ts-t.ts),n=0;for(let e=1;e<t.length;e++){let r=Math.min(Math.max(t[e].ts-t[e-1].ts,0),900)/3600;n+=(t[e-1].value+t[e].value)/2*r}return n/1e3}_connectForecast(e,t){if(e.length===0||t.length===0)return t;let n=e.reduce((e,t)=>t[0]>e[0]?t:e);return n[0]<t[0][0]?[n,...t]:t}_toggleSeries(e){let t=new Set(this._hiddenSeries);t.has(e)?t.delete(e):t.add(e),this._hiddenSeries=t}render(){let e=this._points(),t=this.data?.forecast??[];if(!(e.some(e=>e.ac_power_w!=null)||t.some(e=>e.predicted_power_w!=null)))return h;let n=this._deviceIds(e,t),r=e.filter(e=>e.ac_power_w!=null).map(e=>[e.ts*1e3,e.ac_power_w]),i=t.filter(e=>e.predicted_power_w!=null).map(e=>[e.ts*1e3,e.predicted_power_w]),a=getComputedStyle(this).getPropertyValue(`--primary-color`).trim()||`#03a9f4`,o=[{id:`room_power`,name:S(`analytics.energy_room_power`,this.language),type:`line`,showSymbol:!1,data:r,color:a,lineStyle:{width:2.5},emphasis:{disabled:!0}}];i.length>0&&o.push({id:`room_power_forecast`,name:S(`analytics.energy_forecast`,this.language),type:`line`,showSymbol:!1,data:this._connectForecast(r,i),color:a,lineStyle:{width:2,type:`dashed`},emphasis:{disabled:!0}}),n.forEach((n,r)=>{let i=qn[r%qn.length],a=e.filter(e=>e.ac_device_power_w?.[n]!=null).map(e=>[e.ts*1e3,e.ac_device_power_w[n]]),s=t.filter(e=>e.predicted_device_power_w?.[n]!=null).map(e=>[e.ts*1e3,e.predicted_device_power_w[n]]);o.push({id:`device_${n}`,name:this._friendlyName(n),type:`line`,showSymbol:!1,data:a,color:i,lineStyle:{width:1.5,opacity:.75},emphasis:{disabled:!0}}),s.length&&o.push({id:`device_forecast_${n}`,name:`${this._friendlyName(n)} · ${S(`analytics.energy_forecast_short`,this.language)}`,type:`line`,showSymbol:!1,data:this._connectForecast(a,s),color:i,lineStyle:{width:1.5,type:`dashed`,opacity:.75},emphasis:{disabled:!0}})});let s=[...e].reverse().find(e=>e.ac_power_w!=null),c=this._integrate(e.map(e=>({ts:e.ts,value:e.ac_power_w}))),l=this._integrate(t.map(e=>({ts:e.ts,value:e.predicted_power_w}))),u=[...e].reverse().find(e=>e.energy_learning_samples!=null)?.energy_learning_samples??0,d=[...t,...e].reverse().find(e=>e.energy_prediction_confidence!=null)?.energy_prediction_confidence,f=this.data?.energy_cost,p=[],ee=o.map(e=>{let t=e.id;if(this._hiddenSeries.has(t))return{...e,lineStyle:{...e.lineStyle,width:0,opacity:0}};for(let t of e.data)p.push(t[1]);return e}),te=p.length>0?Math.max(...p):0,ne=Math.abs(this.rangeEnd-Date.now())<36e5;ee.push({id:`now_marker`,name:``,type:`line`,color:`rgba(255,255,255,0.3)`,data:[[this.chartAnchor,-1],[this.chartAnchor,Math.max(te*1.1,1)]],showSymbol:!1,lineStyle:{width:1,type:`dashed`},tooltip:{show:!1},z:-2});let re={animation:!1,grid:{top:15,left:10,right:10,bottom:5,containLabel:!0},tooltip:{trigger:`axis`,axisPointer:{snap:!1},valueFormatter:e=>`${Math.round(e)} W`},xAxis:{type:`time`,min:this.rangeStart,max:ne?this.chartAnchor+Jn:this.rangeEnd},yAxis:{type:`value`,min:0,name:`W`,nameGap:12,splitLine:{show:!0}},dataZoom:[{type:`inside`,xAxisIndex:0,filterMode:`none`}]};return m`
      <ha-card>
        <div class="card-header">
          <span>${S(`analytics.energy_title`,this.language)}</span>
          <ha-icon
            class="info-icon chart-info-toggle ${this._chartInfoExpanded?`info-active`:``}"
            icon="mdi:information-outline"
            @click=${()=>{this._chartInfoExpanded=!this._chartInfoExpanded}}
          ></ha-icon>
        </div>
        ${this._chartInfoExpanded?m`<div class="chart-info-panel">
              ${S(`analytics.energy_chart_info_body`,this.language)}
            </div>`:h}
        <div class="stats">
          <div class="stat">
            <span>${S(`analytics.energy_now`,this.language)}</span
            ><strong
              >${s?.ac_power_w==null?`—`:`${Math.round(s.ac_power_w)} W`}</strong
            >
          </div>
          <div class="stat">
            <span>${S(`analytics.energy_period`,this.language)}</span
            ><strong>${c.toFixed(2)} kWh</strong>
          </div>
          <div class="stat">
            <span>${S(`analytics.energy_next_3h`,this.language)}</span
            ><strong>${i.length>0?`${l.toFixed(2)} kWh`:`—`}</strong>
          </div>
          <div class="stat">
            <span>${S(`analytics.energy_learning`,this.language)}</span
            ><strong>${u}</strong>
          </div>
          <div class="stat">
            <span>${S(`analytics.energy_confidence`,this.language)}</span
            ><strong
              >${d?S(`analytics.energy_confidence_${d}`,this.language):`â€”`}</strong
            >
          </div>
          ${f?m`
                <div class="stat">
                  <span>${S(`analytics.energy_cost_today`,this.language)}</span
                  ><strong>€${f.today_eur.toFixed(2)}</strong>
                </div>
                <div class="stat">
                  <span>${S(`analytics.energy_cost_7d`,this.language)}</span
                  ><strong>€${f.last_7d_eur.toFixed(2)}</strong>
                </div>
                <div class="stat">
                  <span>${S(`analytics.energy_cost_next_3h`,this.language)}</span
                  ><strong>€${f.forecast_3h_eur.toFixed(2)}</strong>
                </div>
              `:h}
        </div>
        <ha-chart-base
          .hass=${this.hass}
          .data=${ee}
          .options=${re}
          .height=${`300px`}
          style="height: 300px"
        ></ha-chart-base>
        <div class="series-legend">
          ${o.map(e=>{let t=e.id,n=this._hiddenSeries.has(t);return m`
              <button
                class="legend-item ${n?`legend-hidden`:``}"
                @click=${()=>this._toggleSeries(t)}
              >
                <span class="legend-dot" style="background: ${e.color}"></span>
                ${e.name}
              </button>
            `})}
        </div>
      </ha-card>
    `}static{this.styles=[Un,l`
      :host {
        display: block;
      }
      ha-card {
        margin-bottom: 16px;
      }
      .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 16px 0;
        font-size: 16px;
        font-weight: 500;
      }
      .chart-info-toggle {
        --mdc-icon-size: 20px;
      }
      .chart-info-panel {
        margin: 8px 16px 4px;
        padding: 12px 14px;
        border-radius: 8px;
        background: var(--secondary-background-color, rgba(128, 128, 128, 0.06));
        font-size: 13px;
        line-height: 1.6;
        color: var(--secondary-text-color);
      }
      .stats {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 8px;
        padding: 12px 16px 4px;
      }
      .stat {
        background: var(--secondary-background-color);
        border-radius: 10px;
        padding: 10px 12px;
        display: flex;
        flex-direction: column;
        gap: 3px;
      }
      .stat span {
        font-size: 11px;
        color: var(--secondary-text-color);
      }
      .stat strong {
        font-size: 15px;
        font-weight: 600;
      }
      .series-legend {
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        gap: 6px;
        padding: 8px 16px 12px;
      }
      .legend-item {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 4px 10px;
        border: none;
        border-radius: 12px;
        background: transparent;
        color: var(--primary-text-color);
        font-size: 12px;
        font-family: inherit;
        cursor: pointer;
        transition: opacity 0.2s;
      }
      .legend-item:hover {
        background: var(--secondary-background-color, rgba(128, 128, 128, 0.1));
      }
      .legend-item.legend-hidden {
        opacity: 0.35;
      }
      .legend-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        flex-shrink: 0;
      }
      @media (max-width: 700px) {
        .stats {
          grid-template-columns: repeat(2, minmax(0, 1fr));
        }
      }
    `]}};k([y({attribute:!1})],Yn.prototype,`hass`,void 0),k([y({attribute:!1})],Yn.prototype,`data`,void 0),k([y({type:Number})],Yn.prototype,`rangeStart`,void 0),k([y({type:Number})],Yn.prototype,`rangeEnd`,void 0),k([y({type:Number})],Yn.prototype,`chartAnchor`,void 0),k([y({type:String})],Yn.prototype,`language`,void 0),k([b()],Yn.prototype,`_hiddenSeries`,void 0),k([b()],Yn.prototype,`_chartInfoExpanded`,void 0),Yn=k([v(`rs-energy-analytics-chart`)],Yn),_(),x(),A();var Xn=class extends g{constructor(...e){super(...e),this.data=null,this.language=`en`,this._expandedStat=null}render(){let e=this.language,t=!!this.data?.model?.model,n=this.data?.model,r=n?.model,i=n?.confidence??0,a=n?.n_samples??0,o=n?.n_heating??0,s=n?.n_cooling??0,c=n?.applicable_modes??[],l=n?.prediction_std_idle,u=n?.prediction_std_heating,d=n?.mpc_active??!1,f=Math.round(i*100),p=new Set(c),ee=p.has(`heating`),te=p.has(`cooling`),ne=o>=10,re=s>=10,ie=a-o-s>=10,ae=n?.n_observations??a,oe=[],se=(t,n,r,i,a)=>{oe.push({id:t,labelKey:r,infoKey:a});let o=this._expandedStat===t;return m`
        <div class="model-stat ${o?`active`:``}" @click=${()=>this._toggleStat(t)}>
          <div class="stat-content">
            <span class="model-value ${n===`—`?`pending`:``}">${n}</span>
            <span class="model-label">${S(r,e)}${i?` (${i})`:``}</span>
          </div>
          <ha-icon
            class="info-icon ${o?`info-active`:``}"
            icon="mdi:information-outline"
          ></ha-icon>
        </div>
      `};return m`
      <ha-card>
        <div class="card-header">
          <span>${S(`analytics.model_status`,e)}</span>
        </div>
        <div class="card-content">
          <div class="confidence-hero">
            <div class="confidence-top">
              <div class="confidence-main">
                <span class="confidence-value">${t?f+`%`:`0%`}</span>
                <span class="confidence-label">
                  ${S(`analytics.confidence`,e)}
                  <ha-icon
                    class="info-icon ${this._expandedStat===`confidence`?`info-active`:``}"
                    icon="mdi:information-outline"
                    @click=${()=>this._toggleStat(`confidence`)}
                  ></ha-icon>
                </span>
              </div>
              <div class="confidence-meta">
                <span class="meta-value">${t?ae:0}</span>
                <span class="meta-label">
                  ${S(`analytics.data_points`,e)}
                  <ha-icon
                    class="info-icon ${this._expandedStat===`data_points`?`info-active`:``}"
                    icon="mdi:information-outline"
                    @click=${()=>this._toggleStat(`data_points`)}
                  ></ha-icon>
                </span>
              </div>
            </div>
            <div class="confidence-bar">
              <div class="confidence-fill" style="width: ${t?f:0}%"></div>
            </div>
            <div class="control-mode-badge ${d?`mpc`:`bangbang`}">
              <ha-icon icon=${d?`mdi:brain`:`mdi:school-outline`}></ha-icon>
              ${S(d?`analytics.control_mode_mpc`:`analytics.control_mode_bangbang`,e)}
            </div>
            ${this._expandedStat===`confidence`?m`<div class="info-panel stat-info-panel">
                  <strong>${S(`analytics.confidence`,e)}</strong>
                  ${S(`analytics.info.confidence`,e)}
                </div>`:h}
            ${this._expandedStat===`data_points`?m`<div class="info-panel stat-info-panel">
                  <strong>${S(`analytics.data_points`,e)}</strong>
                  ${S(`analytics.info.data_points`,e)}
                </div>`:h}
          </div>

          <div class="model-grid">
            ${se(`time_constant`,ie&&r&&r.U>0?(1/r.U).toFixed(1)+`h`:`—`,`analytics.time_constant`,``,`analytics.info.time_constant`)}
            ${ee?se(`heating_rate`,ne&&r?Dt(r.Q_heat,this.hass).toFixed(1)+C(this.hass)+`/h`:`—`,`analytics.heating_rate`,``,`analytics.info.heating_rate`):h}
            ${te?se(`cooling_rate`,re&&r?Dt(r.Q_cool,this.hass).toFixed(1)+C(this.hass)+`/h`:`—`,`analytics.cooling_rate`,``,`analytics.info.cooling_rate`):h}
            ${r&&r.Q_solar>.1?se(`solar_gain`,Dt(r.Q_solar,this.hass).toFixed(1)+C(this.hass)+`/h`,`analytics.solar_gain`,``,`analytics.info.solar_gain`):h}
            ${r&&n?.has_occupancy_sensors?se(`occupancy_gain`,Dt(r.Q_occupancy,this.hass).toFixed(1)+C(this.hass)+`/h`,`analytics.occupancy_gain`,``,`analytics.info.occupancy_gain`):h}
            ${se(`accuracy_idle`,ie&&l!=null?`±`+Dt(l,this.hass).toFixed(2)+C(this.hass):`—`,`analytics.accuracy_idle`,``,`analytics.info.accuracy_idle`)}
            ${ee?se(`accuracy_heating`,ne&&u!=null?`±`+Dt(u,this.hass).toFixed(2)+C(this.hass):`—`,`analytics.accuracy_heating`,``,`analytics.info.accuracy_heating`):h}
          </div>
          ${this._expandedStat&&oe.find(e=>e.id===this._expandedStat)?m`<div class="info-panel stat-info-panel">
                <strong
                  >${S(oe.find(e=>e.id===this._expandedStat).labelKey,e)}</strong
                >
                ${S(oe.find(e=>e.id===this._expandedStat).infoKey,e)}
              </div>`:h}
        </div>
      </ha-card>
    `}_toggleStat(e){this._expandedStat=this._expandedStat===e?null:e}static{this.styles=[Un,l`
      :host {
        display: block;
      }

      ha-card {
        margin-bottom: 16px;
      }

      .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 16px 0;
        font-size: 16px;
        font-weight: 500;
      }

      .card-content {
        padding: 16px;
      }

      .confidence-hero {
        margin-bottom: 16px;
      }

      .confidence-top {
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
        margin-bottom: 8px;
      }

      .confidence-main {
        display: flex;
        align-items: baseline;
        gap: 8px;
      }

      .confidence-value {
        font-size: 28px;
        font-weight: 600;
        color: var(--primary-text-color);
      }

      .confidence-label {
        font-size: 13px;
        color: var(--secondary-text-color);
      }

      .confidence-meta {
        display: flex;
        align-items: baseline;
        gap: 6px;
      }

      .meta-value {
        font-size: 16px;
        font-weight: 500;
        color: var(--primary-text-color);
      }

      .meta-label {
        font-size: 12px;
        color: var(--secondary-text-color);
      }

      .control-mode-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin-top: 8px;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 500;
        --mdc-icon-size: 14px;
      }

      .control-mode-badge.mpc {
        background: rgba(76, 175, 80, 0.12);
        color: var(--success-color, #4caf50);
      }

      .control-mode-badge.bangbang {
        background: rgba(158, 158, 158, 0.12);
        color: var(--secondary-text-color);
      }

      .confidence-bar {
        height: 4px;
        border-radius: 2px;
        background: var(--divider-color);
        overflow: hidden;
      }

      .confidence-fill {
        height: 100%;
        border-radius: 2px;
        background: var(--primary-color);
        transition: width 0.6s ease;
      }

      .model-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
        gap: 12px;
      }

      .model-stat {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 12px;
        border-radius: 8px;
        border: 1px solid var(--divider-color);
        cursor: pointer;
        transition: border-color 0.2s;
      }

      .model-stat.active {
        border-color: var(--primary-color);
      }

      .stat-content {
        display: flex;
        flex-direction: column;
        gap: 2px;
      }

      .model-value {
        font-size: 18px;
        font-weight: 500;
        color: var(--primary-text-color);
      }

      .model-value.pending {
        opacity: 0.2;
      }

      .model-label {
        font-size: 12px;
        color: var(--secondary-text-color);
      }

      .info-panel.stat-info-panel {
        margin-top: 12px;
      }

      @media (max-width: 600px) {
        .model-grid {
          grid-template-columns: repeat(2, 1fr);
          gap: 8px;
        }
      }
    `]}};k([y({attribute:!1})],Xn.prototype,`hass`,void 0),k([y({attribute:!1})],Xn.prototype,`data`,void 0),k([y({type:String})],Xn.prototype,`language`,void 0),k([b()],Xn.prototype,`_expandedStat`,void 0),Xn=k([v(`rs-analytics-model`)],Xn),_(),x(),A();var Zn,Q=class extends g{static{Zn=this}constructor(...e){super(...e),this.rooms={},this.initialRoom=``,this.controlMode=`bangbang`,this._selectedRoom=``,this._rangeStart=new Date(new Date().setHours(0,0,0,0)).getTime(),this._rangeEnd=Date.now(),this._data=null,this._chartAnchor=Date.now(),this._loading=!1,this._activeQuick=`24h`,this._comparison=[],this._comparisonInfoExpanded=!1}static{this._comparisonQualityKeys={insufficient_samples:`analytics.comparison_quality_insufficient_samples`,no_power_measurements:`analytics.comparison_quality_no_power_measurements`,history_gaps:`analytics.comparison_quality_history_gaps`}}connectedCallback(){super.connectedCallback(),this._refreshInterval=setInterval(()=>this._silentRefresh(),6e4)}disconnectedCallback(){super.disconnectedCallback(),this._refreshInterval&&=(clearInterval(this._refreshInterval),void 0)}willUpdate(e){e.has(`initialRoom`)&&this.initialRoom&&(this._selectedRoom=this.initialRoom);let t=!1;if(e.has(`rooms`)&&!this._selectedRoom){let e=Object.keys(this.rooms);e.length>0&&(this._selectedRoom=e[0],t=!0,this.dispatchEvent(new CustomEvent(`room-selected`,{detail:{areaId:e[0]},bubbles:!0,composed:!0})))}(t||e.has(`_selectedRoom`)||e.has(`_rangeStart`)||e.has(`_rangeEnd`))&&this._selectedRoom&&this._fetchData()}render(){let e=this.hass.language;return m`
      <header class="analytics-intro">
        <div class="eyebrow">ROOMMIND / ${S(`tabs.analytics`,e)}</div>
        <h1>${S(`analytics.overview_title`,e)}</h1>
        <p>${S(`analytics.overview_hint`,e)}</p>
      </header>
      <rs-analytics-toolbar
        .hass=${this.hass}
        .rooms=${this.rooms}
        .selectedRoom=${this._selectedRoom}
        .rangeStart=${this._rangeStart}
        .rangeEnd=${this._rangeEnd}
        .activeQuick=${this._activeQuick}
        .data=${this._data}
        .language=${e}
        @room-selected=${this._onRoomSelected}
        @range-changed=${this._onRangeChanged}
      ></rs-analytics-toolbar>
      ${this._selectedRoom?this._loading?m`<div class="loading">${S(`panel.loading`,e)}</div>`:m`
              <rs-analytics-chart
                .hass=${this.hass}
                .data=${this._data}
                .rangeStart=${this._rangeStart}
                .rangeEnd=${this._rangeEnd}
                .chartAnchor=${this._chartAnchor}
                .language=${e}
                .isOutdoor=${this.rooms[this._selectedRoom]?.is_outdoor??!1}
              ></rs-analytics-chart>
              ${this.rooms[this._selectedRoom]?.is_outdoor?h:m` <rs-energy-analytics-chart
                      .hass=${this.hass}
                      .data=${this._data}
                      .rangeStart=${this._rangeStart}
                      .rangeEnd=${this._rangeEnd}
                      .chartAnchor=${this._chartAnchor}
                      .language=${e}
                    ></rs-energy-analytics-chart>
                    ${this._comparison.length>1?m`<ha-card class="comparison">
                          <div class="comparison-header">
                            <h3>${S(`analytics.comparison_title`,e)}</h3>
                            <ha-icon
                              class="info-icon ${this._comparisonInfoExpanded?`info-active`:``}"
                              icon="mdi:information-outline"
                              @click=${()=>{this._comparisonInfoExpanded=!this._comparisonInfoExpanded}}
                            ></ha-icon>
                          </div>
                          ${this._comparisonInfoExpanded?m`<div class="info-panel comparison-info-panel">
                                ${S(`analytics.comparison_info`,e)}
                              </div>`:h}
                          <table>
                            <thead>
                              <tr>
                                <th>${S(`analytics.comparison_room`,e)}</th>
                                <th>kWh</th>
                                <th>€</th>
                                <th>${S(`analytics.comparison_active`,e)}</th>
                                <th>${S(`analytics.comparison_efficiency`,e)}</th>
                                <th>${S(`analytics.comparison_target`,e)}</th>
                              </tr>
                            </thead>
                            <tbody>
                              ${this._comparison.map(t=>m`<tr>
                                    <td>
                                      ${t.name}
                                      ${Array.isArray(t.data_quality)&&t.data_quality.length?m`<div class="comparison-quality">
                                            ${S(`analytics.comparison_data_incomplete`,e)}:
                                            ${t.data_quality.map(t=>S(Zn._comparisonQualityKeys[t]??`analytics.comparison_data_incomplete`,e)).join(`, `)}
                                          </div>`:h}
                                    </td>
                                    <td>${t.energy_kwh??`—`}</td>
                                    <td>${t.cost_eur??`—`}</td>
                                    <td>
                                      ${t.active_minutes==null?`—`:`${t.active_minutes} min`}
                                    </td>
                                    <td>${t.delta_t_per_kwh??`—`}</td>
                                    <td>
                                      ${t.target_reach_minutes==null?`—`:`${t.target_reach_minutes} min`}
                                    </td>
                                  </tr>`)}
                            </tbody>
                          </table>
                        </ha-card>`:h}
                    <rs-analytics-model
                      .hass=${this.hass}
                      .data=${this._data}
                      .language=${e}
                    ></rs-analytics-model>`}
            `:m`
            <div class="no-data">
              <ha-icon icon="mdi:chart-line" style="--mdc-icon-size: 48px; opacity: 0.4"></ha-icon>
              <p>${S(`analytics.select_room`,e)}</p>
            </div>
          `}
    `}_onRoomSelected(e){let t=e.detail.areaId;t&&t!==this._selectedRoom&&(this._selectedRoom=t,this.dispatchEvent(new CustomEvent(`room-selected`,{detail:{areaId:t},bubbles:!0,composed:!0})))}_onRangeChanged(e){let{activeQuick:t,rangeStart:n,rangeEnd:r,chartAnchor:i}=e.detail;this._activeQuick=t,this._rangeStart=n,this._rangeEnd=r,this._chartAnchor=i}_buildWsParams(){return{type:`roommind/analytics/get`,area_id:this._selectedRoom,start_ts:this._rangeStart/1e3,end_ts:this._rangeEnd/1e3}}async _fetchData(){if(this._selectedRoom){this._loading=!0,this._data=null,this._chartAnchor=this._rangeEnd;try{let e=await this.hass.callWS(this._buildWsParams());this._data=e;try{let e=await this.hass.callWS({type:`roommind/analytics/compare`,start_ts:this._rangeStart/1e3,end_ts:this._rangeEnd/1e3});this._comparison=e.rooms}catch(e){console.debug(`[RoomMind] comparison:`,e)}}catch(e){console.debug(`[RoomMind] fetchData:`,e),this._data=null}finally{this._loading=!1}}}async _silentRefresh(){if(!(!this._selectedRoom||this._loading))try{let e=await this.hass.callWS(this._buildWsParams());this._data=e;try{let e=await this.hass.callWS({type:`roommind/analytics/compare`,start_ts:this._rangeStart/1e3,end_ts:this._rangeEnd/1e3});this._comparison=e.rooms}catch(e){console.debug(`[RoomMind] comparison:`,e)}this._chartAnchor=Date.now()}catch(e){console.debug(`[RoomMind] silentRefresh:`,e)}}static{this.styles=l`
    :host {
      display: block;
    }
    .analytics-intro {
      padding: 8px 2px 24px;
    }
    .analytics-intro .eyebrow {
      font-size: 10px;
      letter-spacing: 0.14em;
      font-weight: 750;
      text-transform: uppercase;
      color: var(--secondary-text-color);
    }
    .analytics-intro h1 {
      margin: 9px 0 7px;
      font-size: clamp(25px, 3vw, 34px);
      line-height: 1.2;
      letter-spacing: -0.04em;
      font-weight: 750;
    }
    .analytics-intro p {
      margin: 0;
      max-width: 650px;
      font-size: 13px;
      line-height: 1.6;
      color: var(--secondary-text-color);
    }

    .no-data {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 80px 16px;
      text-align: center;
      color: var(--secondary-text-color);
    }

    .no-data p {
      font-size: 15px;
      max-width: 400px;
      line-height: 1.5;
      margin-top: 16px;
    }

    .loading {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 80px 16px;
      color: var(--secondary-text-color);
      font-size: 14px;
    }

    .comparison {
      margin: 0 0 16px;
      overflow-x: auto;
      padding: 12px 16px;
    }
    .comparison-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 10px;
    }
    .comparison h3 {
      margin: 0;
      font-size: 16px;
    }
    .comparison-info-panel {
      margin-bottom: 10px;
    }
    .comparison-quality {
      margin-top: 3px;
      color: var(--warning-color, #ff9800);
      font-size: 11px;
      white-space: normal;
    }
    .info-icon {
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
      cursor: pointer;
      opacity: 0.5;
    }
    .info-icon.info-active {
      color: var(--primary-color);
      opacity: 1;
    }
    .info-panel {
      padding: 12px;
      border-radius: 8px;
      background: var(--secondary-background-color, rgba(128, 128, 128, 0.06));
      font-size: 13px;
      line-height: 1.6;
      color: var(--secondary-text-color);
    }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 13px;
    }
    th,
    td {
      padding: 8px;
      text-align: right;
      border-top: 1px solid var(--divider-color);
      white-space: nowrap;
    }
    th:first-child,
    td:first-child {
      text-align: left;
    }
  `}};k([y({attribute:!1})],Q.prototype,`hass`,void 0),k([y({type:Object})],Q.prototype,`rooms`,void 0),k([y()],Q.prototype,`initialRoom`,void 0),k([y()],Q.prototype,`controlMode`,void 0),k([b()],Q.prototype,`_selectedRoom`,void 0),k([b()],Q.prototype,`_rangeStart`,void 0),k([b()],Q.prototype,`_rangeEnd`,void 0),k([b()],Q.prototype,`_data`,void 0),k([b()],Q.prototype,`_chartAnchor`,void 0),k([b()],Q.prototype,`_loading`,void 0),k([b()],Q.prototype,`_activeQuick`,void 0),k([b()],Q.prototype,`_comparison`,void 0),k([b()],Q.prototype,`_comparisonInfoExpanded`,void 0),Q=Zn=k([v(`rs-analytics`)],Q),_(),x(),A();var Qn=`M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z`,$n=`M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z`,er=`M16,11.78L20.24,4.45L21.97,5.45L16.74,14.5L10.23,10.75L5.46,19H22V21H2V3H4V17.54L9.5,8L16,11.78Z`,tr=`M15 13V5A3 3 0 0 0 9 5V13A5 5 0 1 0 15 13M12 4A1 1 0 0 1 13 5V8H11V5A1 1 0 0 1 12 4Z`,$=class extends g{constructor(...e){super(...e),this.narrow=!1,this.route={path:``},this.panel={},this._activeTab=`areas`,this._rooms={},this._roomsLoaded=!1,this._selectedAreaId=null,this._analyticsRoom=``,this._vacationActive=!1,this._vacationTemp=null,this._vacationUntil=null,this._hiddenRooms=[],this._showHiddenRooms=!1,this._controlMode=`bangbang`,this._climateControlActive=!0,this._presenceEnabled=!1,this._valveProtectionEnabled=!1,this._anyoneHome=!0,this._presencePersons=[],this._presenceAwayAction=`eco`,this._saveStatus=`idle`,this._roomOrder=[],this._groupByFloor=!1,this._reorderMode=!1,this._elementsLoaded=!1,this._routeApplied=!1,this._areaInfosCache=[],this._onSaveStatus=e=>{e.stopPropagation(),this._saveStatusTimeout&&clearTimeout(this._saveStatusTimeout),this._saveStatus=e.detail.status,e.detail.status===`saved`&&(this._saveStatusTimeout=setTimeout(()=>{this._saveStatus=`idle`},2e3))}}static{this.styles=l`
    :host {
      display: block;
      font-family: var(
        --primary-font-family,
        Inter,
        -apple-system,
        BlinkMacSystemFont,
        "Segoe UI",
        sans-serif
      );
      color: var(--primary-text-color);
      background: var(--primary-background-color);
      min-height: 100vh;
      --rs-radius: 18px;
      --rs-stroke: var(--divider-color, rgba(127, 127, 127, 0.16));

      /* Round the corners of all MDC-based inputs (ha-textfield, ha-select,
         ha-entity-picker, ha-combo-box) to match the rest of the design.
         The bottom corners are rounded via inputStyles in each component. */
      --mdc-shape-small: 12px;
      --mdc-shape-medium: 12px;
      --md-filled-text-field-container-shape: 12px;
      --md-outlined-text-field-container-shape: 12px;
    }

    .toolbar {
      display: flex;
      align-items: center;
      min-height: 64px;
      padding: 0 22px;
      font-size: 18px;
      background-color: var(--card-background-color, var(--primary-background-color));
      color: var(--primary-text-color);
      border-bottom: 1px solid var(--rs-stroke);
      box-sizing: border-box;
      position: sticky;
      top: 0;
      z-index: 4;
    }
    .brand-mark {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 34px;
      height: 34px;
      border-radius: 11px;
      background: var(--primary-color);
      color: white;
      margin-right: 10px;
      flex-shrink: 0;
    }
    .brand-mark ha-icon {
      --mdc-icon-size: 19px;
    }

    .toolbar .title {
      margin-left: 4px;
      font-weight: 750;
      letter-spacing: -0.035em;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      flex: 1;
    }

    .toolbar ha-icon-button {
      color: var(--app-header-text-color, var(--primary-text-color));
    }

    .save-indicator {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 13px;
      font-weight: 400;
      margin-right: 8px;
      opacity: 1;
      transition: opacity 0.3s ease;
    }

    .save-indicator.fade-out {
      opacity: 0;
    }

    .save-indicator ha-icon {
      --mdc-icon-size: 18px;
    }

    .save-indicator.saving {
      color: var(--primary-color, #03a9f4);
    }

    .save-indicator.saved {
      color: var(--success-color, #4caf50);
    }

    .save-indicator.error {
      color: var(--error-color, #d32f2f);
    }

    .tabs {
      display: flex;
      gap: 6px;
      border-bottom: 1px solid var(--rs-stroke);
      padding: 8px 24px;
      background: var(--card-background-color, var(--primary-background-color));
      position: sticky;
      top: 64px;
      z-index: 3;
      overflow-x: auto;
      scrollbar-width: none;
    }

    .tab {
      padding: 11px 18px;
      cursor: pointer;
      border: none;
      border-radius: 11px;
      background: transparent;
      color: var(--secondary-text-color);
      font-size: 13px;
      font-weight: 650;
      transition:
        background 0.18s ease,
        color 0.18s ease;
      font-family: inherit;
      display: inline-flex;
      align-items: center;
      gap: 9px;
      white-space: nowrap;
    }
    .tab ha-icon {
      --mdc-icon-size: 18px;
    }

    .tab:hover {
      color: var(--primary-text-color);
    }

    .tab[active] {
      background: var(--primary-background-color);
      color: var(--primary-text-color);
    }
    .tab[active] ha-icon {
      color: var(--primary-color);
    }
    .tab:focus-visible {
      outline: 2px solid var(--primary-color);
      outline-offset: -2px;
    }

    .content {
      padding: 30px 24px 64px;
      max-width: 1320px;
      margin: 0 auto;
      box-sizing: border-box;
    }

    @media (max-width: 600px) {
      .toolbar {
        padding: 0 10px;
        min-height: 56px;
      }
      .tabs {
        top: 56px;
        padding: 7px 12px;
        gap: 4px;
      }
      .tab {
        padding: 10px 12px;
        font-size: 12px;
        gap: 6px;
      }
      .tab ha-icon {
        --mdc-icon-size: 16px;
      }
      .content {
        padding: 20px 14px 58px;
      }
    }

    .placeholder {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 80px 16px;
      text-align: center;
      color: var(--secondary-text-color);
    }

    .placeholder ha-icon {
      margin-bottom: 16px;
    }

    .placeholder p {
      font-size: 15px;
      max-width: 400px;
      line-height: 1.5;
    }

    .area-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(min(320px, 100%), 1fr));
      gap: 18px;
    }
    .dashboard-heading {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      gap: 18px;
      margin: 0 0 20px;
    }
    .dashboard-heading h1 {
      margin: 7px 0 6px;
      font-weight: 750;
      letter-spacing: -0.04em;
      font-size: clamp(25px, 3vw, 34px);
      line-height: 1.2;
    }
    .dashboard-heading p {
      margin: 0;
      color: var(--secondary-text-color);
      line-height: 1.5;
      font-size: 13px;
    }
    .dashboard-eyebrow {
      text-transform: uppercase;
      font-size: 10px !important;
      letter-spacing: 0.14em;
      font-weight: 750;
    }
    .system-chip {
      display: inline-flex;
      align-items: center;
      gap: 9px;
      flex: 0 0 auto;
      padding: 10px 13px;
      font-size: 12px;
      font-weight: 650;
      border-radius: 999px;
      background: var(--card-background-color);
      border: 1px solid var(--rs-stroke);
    }
    .system-chip .dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--secondary-text-color);
    }
    .system-chip.active .dot {
      background: var(--success-color, #36aa78);
    }
    @media (max-width: 650px) {
      .dashboard-heading {
        align-items: flex-start;
        flex-direction: column;
        gap: 13px;
      }
    }

    .loading {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 80px 16px;
      color: var(--secondary-text-color);
      font-size: 14px;
    }

    .stats-separator {
      width: 1px;
      height: 28px;
      background: var(--divider-color, #444);
      margin: 0 4px;
      flex-shrink: 0;
    }

    .stats-bar {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      gap: 12px 24px;
      margin-bottom: 24px;
      padding: 18px 22px;
      --ha-card-border-radius: var(--rs-radius);
      --ha-card-box-shadow: none;
      border: 1px solid var(--rs-stroke);
    }

    .stats-actions {
      display: flex;
      align-items: center;
      margin-left: auto;
      gap: 0;
    }

    .hidden-rooms-toggle {
      --mdc-icon-button-size: 36px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
    }

    .hidden-rooms-panel {
      margin-bottom: 20px;
      padding: 12px 16px;
    }

    .hidden-rooms-header {
      font-size: 13px;
      font-weight: 500;
      color: var(--secondary-text-color);
      margin-bottom: 8px;
    }

    .hidden-room-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 6px 0;
    }

    .hidden-room-name {
      font-size: 14px;
      color: var(--primary-text-color);
    }

    .stat {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .stat-value {
      font-size: 24px;
      font-weight: 700;
      letter-spacing: -0.04em;
      color: var(--primary-text-color);
      --mdc-icon-size: 22px;
      line-height: 1;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 24px;
    }

    .stat-label {
      font-size: 10px;
      color: var(--secondary-text-color);
      text-transform: uppercase;
      letter-spacing: 0.09em;
    }

    .floor-heading {
      font-size: 13px;
      font-weight: 750;
      color: var(--secondary-text-color);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin: 20px 0 8px 0;
    }

    .floor-heading:first-of-type {
      margin-top: 0;
    }

    .reorder-btn {
      --mdc-icon-button-size: 36px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
    }

    .reorder-done {
      font-size: 14px;
      margin-left: auto;
    }
  `}connectedCallback(){super.connectedCallback(),pn().then(()=>{this._elementsLoaded=!0}),this._loadRooms(),this._refreshInterval=setInterval(()=>this._loadRooms(),5e3),this.addEventListener(`save-status`,this._onSaveStatus),this._routeApplied||=(this._applyRoute(),!0),this._boundVisibilityHandler||(this._boundVisibilityHandler=()=>{if(!document.hidden){if(!this.isConnected){window.location.reload();return}this._loadRooms(),this.requestUpdate()}},document.addEventListener(`visibilitychange`,this._boundVisibilityHandler))}disconnectedCallback(){super.disconnectedCallback(),this._refreshInterval&&=(clearInterval(this._refreshInterval),void 0),this._saveStatusTimeout&&clearTimeout(this._saveStatusTimeout),this.removeEventListener(`save-status`,this._onSaveStatus),this._boundConnectionReady&&=(this.hass?.connection?.removeEventListener(`ready`,this._boundConnectionReady),void 0)}render(){if(!this._elementsLoaded||!this.hass)return m``;let e=this.hass.language,t=!!this._selectedAreaId,n=t?this.hass?.areas?.[this._selectedAreaId]:null,r={areas:S(`panel.tab.rooms`,e),analytics:S(`tabs.analytics`,e),settings:S(`panel.tab.settings`,e)};return m`
      <div class="toolbar">
        ${t?m`<ha-icon-button
              .path=${Qn}
              aria-label=${S(`panel.tab.rooms`,e)}
              @click=${this._onBackFromDetail}
            ></ha-icon-button>`:m`<ha-menu-button .hass=${this.hass} .narrow=${this.narrow}></ha-menu-button>`}
        ${t?h:m`<span class="brand-mark"
              ><ha-icon icon="mdi:home-thermometer-outline"></ha-icon
            ></span>`}
        <div class="title">
          ${t?this._rooms[this._selectedAreaId]?.display_name||n?.name||``:S(`panel.title`,e)}
        </div>
        ${this._renderSaveIndicator()}
        ${t&&this._rooms[this._selectedAreaId]?m`<ha-icon-button
                .path=${er}
                @click=${this._onGoToAnalytics}
              ></ha-icon-button
              ><ha-icon-button .path=${$n} @click=${this._onDeleteRoom}></ha-icon-button>`:h}
        ${!t&&this._activeTab===`analytics`&&this._analyticsRoom?m`<ha-icon-button
              .path=${tr}
              @click=${this._onGoToRoomFromAnalytics}
            ></ha-icon-button>`:h}
      </div>

      ${t?h:m`
            <div class="tabs">
              ${Object.keys(r).map(e=>m`
                  <button
                    class="tab"
                    ?active=${this._activeTab===e}
                    aria-current=${this._activeTab===e?`page`:`false`}
                    @click=${()=>this._onTabClicked(e)}
                  >
                    <ha-icon
                      icon=${e===`areas`?`mdi:home-outline`:e===`analytics`?`mdi:chart-areaspline`:`mdi:cog-outline`}
                    ></ha-icon>
                    ${r[e]}
                  </button>
                `)}
            </div>
          `}

      <div class="content">${this._renderTab()}</div>
    `}_renderTab(){switch(this._activeTab){case`areas`:return this._renderAreas();case`analytics`:return m`<rs-analytics
          .hass=${this.hass}
          .rooms=${this._rooms}
          .initialRoom=${this._analyticsRoom}
          .controlMode=${this._controlMode}
          @room-selected=${this._onAnalyticsRoomSelected}
        ></rs-analytics>`;case`settings`:return this._renderSettings();default:return h}}_renderAreas(){if(!this._roomsLoaded)return m`<div class="loading">${S(`panel.loading`,this.hass.language)}</div>`;if(this._selectedAreaId){let e=this.hass?.areas?.[this._selectedAreaId];if(e){let t=this._rooms[this._selectedAreaId]??null;return m`
          <rs-room-detail
            .rooms=${this._rooms}
            .area=${e}
            .config=${t}
            .hass=${this.hass}
            .presenceEnabled=${this._presenceEnabled}
            .presencePersons=${this._presencePersons}
            .climateControlActive=${this._climateControlActive}
            .valveProtectionEnabled=${this._valveProtectionEnabled}
            @back-clicked=${this._onBackFromDetail}
            @room-updated=${this._onRoomUpdated}
          ></rs-room-detail>
        `}this._selectedAreaId=null}let e=this._areaInfosCache,t=e.filter(e=>!this._hiddenRooms.includes(e.area.area_id)),n=e.filter(e=>this._hiddenRooms.includes(e.area.area_id));if(e.length===0)return m`
        <div class="placeholder">
          <ha-icon icon="mdi:home" style="--mdc-icon-size: 56px; opacity: 0.4"></ha-icon>
          <p>
            ${S(`panel.no_areas`,this.hass.language)}<br />${S(`panel.no_areas_hint`,this.hass.language)}
          </p>
        </div>
      `;let r=t.filter(e=>e.config).length,i=t.filter(e=>e.config?.live?.mode===`heating`).length,a=t.filter(e=>e.config?.live?.mode===`cooling`).length,o=t.filter(e=>e.config?.live?.mold_risk_level===`warning`||e.config?.live?.mold_risk_level===`critical`).length,s=this._vacationActive||this._presenceEnabled&&!this._anyoneHome||o>0,c=this.hass.language;return m`
      <section class="dashboard-heading">
        <div>
          <p class="dashboard-eyebrow">ROOMMIND / ${S(`panel.tab.rooms`,c)}</p>
          <h1>${S(`panel.overview`,c)}</h1>
          <p>${S(`panel.overview_hint`,c)}</p>
        </div>
        <div class="system-chip ${this._climateControlActive?`active`:``}">
          <span class="dot"></span>
          ${this._climateControlActive?S(`panel.control_active`,c):S(`panel.control_paused`,c)}
        </div>
      </section>
      ${r>0||n.length>0?m`
            <ha-card class="stats-bar">
              ${r>0?m`
                    <div class="stat">
                      <span class="stat-value">${r}</span>
                      <span class="stat-label">${S(`panel.stat.rooms`,c)}</span>
                    </div>
                    <div class="stat">
                      <span class="stat-value" style="color: var(--warning-color, #ff9800)"
                        >${i}</span
                      >
                      <span class="stat-label">${S(`panel.stat.heating`,c)}</span>
                    </div>
                    <div class="stat">
                      <span class="stat-value" style="color: var(--info-color, #2196f3)"
                        >${a}</span
                      >
                      <span class="stat-label">${S(`panel.stat.cooling`,c)}</span>
                    </div>
                  `:h}
              ${s?m`<div class="stats-separator"></div>`:h}
              ${this._vacationActive?m`
                    <div class="stat">
                      <span class="stat-value" style="color: var(--success-color, #4caf50)">
                        <ha-icon icon="mdi:airplane"></ha-icon>
                      </span>
                      <span class="stat-label">${S(`panel.stat.vacation`,c)}</span>
                    </div>
                  `:h}
              ${this._presenceEnabled&&!this._anyoneHome?m`
                    <div class="stat">
                      <span class="stat-value" style="color: var(--secondary-text-color)">
                        <ha-icon icon="mdi:power"></ha-icon>
                      </span>
                      <span class="stat-label">${S(`panel.stat.away`,c)}</span>
                    </div>
                  `:h}
              ${o>0?m`
                    <div class="stat">
                      <span class="stat-value" style="color: var(--error-color, #f44336)"
                        >${o}</span
                      >
                      <span class="stat-label">${S(`panel.stat.mold`,c)}</span>
                    </div>
                  `:h}
              <span class="stats-actions">
                ${n.length>0?m`<ha-icon-button
                      class="hidden-rooms-toggle"
                      .path=${Tt}
                      @click=${()=>{this._showHiddenRooms=!this._showHiddenRooms}}
                    ></ha-icon-button>`:h}
                ${this._reorderMode?m`<ha-button class="reorder-done" @click=${this._onReorderDone}>
                      ${S(`panel.reorder_done`,c)}
                    </ha-button>`:m`<ha-icon-button
                      class="reorder-btn"
                      .path=${`M9,3L5,7H8V14H10V7H13M16,17V10H14V17H11L15,21L19,17H16Z`}
                      @click=${()=>{this._reorderMode=!0}}
                      title=${S(`panel.reorder`,c)}
                    ></ha-icon-button>`}
              </span>
            </ha-card>
          `:h}
      ${this._showHiddenRooms&&n.length>0?m`
            <ha-card class="hidden-rooms-panel">
              <div class="hidden-rooms-header">
                <span>${S(`panel.hidden_rooms`,c)} (${n.length})</span>
              </div>
              ${n.map(e=>m`
                  <div class="hidden-room-row">
                    <span class="hidden-room-name">${e.area.name}</span>
                    <ha-button @click=${()=>this._unhideRoom(e.area.area_id)}>
                      ${S(`panel.unhide`,c)}
                    </ha-button>
                  </div>
                `)}
            </ha-card>
          `:h}
      ${this._getFloorGroups(t).map(e=>m`
          ${e.name?m`<h4 class="floor-heading">${e.name}</h4>`:h}
          <div class="area-grid">
            ${e.items.map((t,n)=>m`
                <rs-area-card
                  .area=${t.area}
                  .config=${t.config}
                  .climateEntityCount=${t.climateEntityCount}
                  .tempSensorCount=${t.tempSensorCount}
                  .hass=${this.hass}
                  .controlMode=${this._controlMode}
                  .climateControlActive=${this._climateControlActive}
                  .reordering=${this._reorderMode}
                  .canMoveUp=${n>0}
                  .canMoveDown=${n<e.items.length-1}
                  @area-selected=${this._onAreaSelected}
                  @hide-room=${this._onHideRoom}
                  @move-room-up=${this._onMoveRoomUp}
                  @move-room-down=${this._onMoveRoomDown}
                ></rs-area-card>
              `)}
          </div>
        `)}
    `}_renderSettings(){return m`<rs-settings .hass=${this.hass} .rooms=${this._rooms}></rs-settings>`}_computeAreaInfos(){if(!this.hass?.areas)return[];let e=Object.values(this.hass.areas).map(e=>{let t=bt(e.area_id,this.hass.entities,this.hass.devices).filter(e=>!e.entity_id.substring(e.entity_id.indexOf(`.`)+1).startsWith(`roommind_`)),n=t.filter(e=>e.entity_id.startsWith(`climate.`)).length,r=t.filter(e=>e.entity_id.startsWith(`sensor.`)&&this.hass.states[e.entity_id]?.attributes?.device_class===`temperature`).length;return{area:e,config:this._rooms[e.area_id]??null,climateEntityCount:n,tempSensorCount:r}}),t=new Map(this._roomOrder.map((e,t)=>[e,t]));return e.sort((e,n)=>{let r=t.get(e.area.area_id),i=t.get(n.area.area_id);if(r!==void 0&&i!==void 0)return r-i;if(r!==void 0)return-1;if(i!==void 0)return 1;let a=e.config?2:+(e.climateEntityCount>0),o=n.config?2:+(n.climateEntityCount>0);return a===o?e.area.name.localeCompare(n.area.name):o-a}),e}_getFloorGroups(e){if(!this._groupByFloor||!this.hass.floors)return[{name:``,items:e}];let t=this.hass.floors,n=this.hass.language,r=new Map,i=[];for(let t of e){let e=t.area.floor_id??null;r.has(e)||(r.set(e,[]),i.push(e)),r.get(e).push(t)}return i.sort((e,n)=>{if(e===null)return 1;if(n===null)return-1;let r=t[e],i=t[n];return r?.level!=null&&i?.level!=null?i.level-r.level:r?.level==null?i?.level==null?(r?.name??``).localeCompare(i?.name??``):1:-1}),i.map(e=>({name:e===null?S(`panel.floor_other`,n):t[e]?.name??S(`panel.floor_other`,n),items:r.get(e)}))}async _loadRooms(){if(this.hass)try{let e=await this.hass.callWS({type:`roommind/rooms/list`});this._rooms=e.rooms,this._vacationActive=e.vacation_active??!1,this._vacationTemp=e.vacation_temp??null,this._vacationUntil=e.vacation_until??null,this._hiddenRooms=e.hidden_rooms??[],this._roomOrder=e.room_order??[],this._groupByFloor=e.group_by_floor??!1,this._controlMode=e.control_mode??`bangbang`,this._climateControlActive=e.climate_control_active??!0,this._presenceEnabled=e.presence_enabled??!1,this._valveProtectionEnabled=e.valve_protection_enabled??!1,this._anyoneHome=e.anyone_home??!0,this._presencePersons=e.presence_persons??[],this._presenceAwayAction=e.presence_away_action??`eco`}catch(e){console.debug(`[RoomMind] loadRooms:`,e)}finally{this._roomsLoaded=!0}}_onBackFromDetail(){this._selectedAreaId=null,this._navigate(``)}async _onDeleteRoom(){if(!this._selectedAreaId)return;let e=this.hass?.areas?.[this._selectedAreaId];if(e&&confirm(S(`room.confirm_delete`,this.hass.language,{name:e.name})))try{await this.hass.callWS({type:`roommind/rooms/delete`,area_id:this._selectedAreaId}),this._selectedAreaId=null,this._navigate(``),this._loadRooms()}catch(e){console.debug(`[RoomMind] deleteRoom:`,e)}}_onTabClicked(e){this._activeTab=e,this._selectedAreaId=null,e===`areas`?this._navigate(``):this._navigate(`/${e}`)}_onAreaSelected(e){this._selectedAreaId=e.detail.areaId,this._navigate(`/room/${e.detail.areaId}`)}async _onHideRoom(e){let t=[...new Set([...this._hiddenRooms,e.detail.areaId])];this._hiddenRooms=t;try{await this.hass.callWS({type:`roommind/settings/save`,hidden_rooms:t})}catch(e){console.debug(`[RoomMind] hideRoom:`,e)}}async _unhideRoom(e){let t=this._hiddenRooms.filter(t=>t!==e);this._hiddenRooms=t,t.length===0&&(this._showHiddenRooms=!1);try{await this.hass.callWS({type:`roommind/settings/save`,hidden_rooms:t})}catch(e){console.debug(`[RoomMind] unhideRoom:`,e)}}_onGoToAnalytics(){this._selectedAreaId&&(this._analyticsRoom=this._selectedAreaId,this._selectedAreaId=null,this._activeTab=`analytics`,this._navigate(`/analytics/${this._analyticsRoom}`))}_onGoToRoomFromAnalytics(){this._analyticsRoom&&(this._selectedAreaId=this._analyticsRoom,this._activeTab=`areas`,this._navigate(`/room/${this._analyticsRoom}`))}_onAnalyticsRoomSelected(e){this._analyticsRoom=e.detail.areaId,this._navigate(`/analytics/${e.detail.areaId}`)}async _onMoveRoomUp(e){this._moveRoom(e.detail.areaId,-1)}async _onMoveRoomDown(e){this._moveRoom(e.detail.areaId,1)}async _moveRoom(e,t){let n=this._areaInfosCache.filter(e=>!this._hiddenRooms.includes(e.area.area_id));if(this._groupByFloor&&this.hass.floors){let r=this._getFloorGroups(n);for(let n of r){let i=n.items.map(e=>e.area.area_id),a=i.indexOf(e);if(a===-1)continue;let o=a+t;if(o<0||o>=i.length)return;[i[a],i[o]]=[i[o],i[a]];let s=r.flatMap(e=>e===n?i:e.items.map(e=>e.area.area_id));await this._saveRoomOrder(s);return}}else{let r=n.map(e=>e.area.area_id),i=r.indexOf(e);if(i===-1)return;let a=i+t;if(a<0||a>=r.length)return;[r[i],r[a]]=[r[a],r[i]],await this._saveRoomOrder(r)}}async _saveRoomOrder(e){this._roomOrder=e,this._areaInfosCache=this._computeAreaInfos();try{await this.hass.callWS({type:`roommind/settings/save`,room_order:e})}catch(e){console.debug(`[RoomMind] saveRoomOrder:`,e)}}_onReorderDone(){this._reorderMode=!1}_onRoomUpdated(){this._loadRooms()}_renderSaveIndicator(){if(this._saveStatus===`idle`)return h;let e=this.hass.language,t=this._saveStatus===`saving`?`mdi:content-save-outline`:this._saveStatus===`saved`?`mdi:check`:`mdi:alert-circle-outline`,n=this._saveStatus===`saving`?S(`settings.saving`,e):this._saveStatus===`saved`?S(`settings.saved`,e):S(`settings.error`,e);return m`
      <span class="save-indicator ${this._saveStatus}">
        <ha-icon .icon=${t}></ha-icon>
        ${n}
      </span>
    `}willUpdate(e){e.has(`route`)&&this._routeApplied&&this._applyRoute(),(e.has(`_rooms`)||e.has(`hass`))&&(this._areaInfosCache=this._computeAreaInfos())}updated(e){e.has(`hass`)&&this.hass&&!this._roomsLoaded&&this._loadRooms(),e.has(`hass`)&&this.hass?.connection&&!this._boundConnectionReady&&(this._boundConnectionReady=()=>{this._loadRooms(),this.requestUpdate()},this.hass.connection.addEventListener(`ready`,this._boundConnectionReady))}_navigate(e){history.replaceState(null,``,`/roommind${e}`),window.dispatchEvent(new Event(`location-changed`))}_applyRoute(){let e=this.route?.path??``;e.startsWith(`/room/`)?(this._activeTab=`areas`,this._selectedAreaId=decodeURIComponent(e.slice(6))):e.startsWith(`/analytics/`)?(this._activeTab=`analytics`,this._selectedAreaId=null,this._analyticsRoom=decodeURIComponent(e.slice(11))):e===`/analytics`?(this._activeTab=`analytics`,this._selectedAreaId=null,this._analyticsRoom=``):e===`/settings`?(this._activeTab=`settings`,this._selectedAreaId=null):(this._activeTab=`areas`,this._selectedAreaId=null)}};k([y({attribute:!1})],$.prototype,`hass`,void 0),k([y({type:Boolean,reflect:!0})],$.prototype,`narrow`,void 0),k([y({type:Object})],$.prototype,`route`,void 0),k([y({type:Object})],$.prototype,`panel`,void 0),k([b()],$.prototype,`_activeTab`,void 0),k([b()],$.prototype,`_rooms`,void 0),k([b()],$.prototype,`_roomsLoaded`,void 0),k([b()],$.prototype,`_selectedAreaId`,void 0),k([b()],$.prototype,`_analyticsRoom`,void 0),k([b()],$.prototype,`_vacationActive`,void 0),k([b()],$.prototype,`_vacationTemp`,void 0),k([b()],$.prototype,`_vacationUntil`,void 0),k([b()],$.prototype,`_hiddenRooms`,void 0),k([b()],$.prototype,`_showHiddenRooms`,void 0),k([b()],$.prototype,`_controlMode`,void 0),k([b()],$.prototype,`_climateControlActive`,void 0),k([b()],$.prototype,`_presenceEnabled`,void 0),k([b()],$.prototype,`_valveProtectionEnabled`,void 0),k([b()],$.prototype,`_anyoneHome`,void 0),k([b()],$.prototype,`_presencePersons`,void 0),k([b()],$.prototype,`_presenceAwayAction`,void 0),k([b()],$.prototype,`_saveStatus`,void 0),k([b()],$.prototype,`_roomOrder`,void 0),k([b()],$.prototype,`_groupByFloor`,void 0),k([b()],$.prototype,`_reorderMode`,void 0),k([b()],$.prototype,`_elementsLoaded`,void 0),$=k([v(`roommind-panel`)],$)})();